-- 110800's Lua and Manifest Created by Hubcap Manifest
-- L.A. Noire
-- Created: July 11, 2026 at 00:18:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(110800, 1, "4164ca93339aea96e138751a0460e1a7367c5b576741ba80c34524412694f9bb") -- L.A. Noire
-- MAIN APP DEPOTS
addappid(110802, 1, "74851338b906da06cd9e860d075ed5d8eb654b326d152a518ef3b62bea4baae6") -- LANExecutables
setManifestid(110802, "3234208118368148040", 24345993)
addappid(110801, 1, "34360e9d27bff94c1c6135d12ed4818d28e60082b3f7f984ed7f0c0eeecfc3b6") -- LANMainContent
setManifestid(110801, "7802845176688782381", 14466771789)
-- SHARED DEPOTS (from other apps)
addappid(1899671, 1, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b") -- RGL/SC Content (Shared from App 1899670)
setManifestid(1899671, "1378788310039702778", 239518253)
-- DLCS WITH DEDICATED DEPOTS
-- L.A. Noire DLC Bundle (AppID: 110810)
addappid(110810)
addappid(110810, 1, "d5ffeca506e20ff835c9f9e6146e7163845408c264596f8d314712855d238f68") -- L.A. Noire DLC Bundle - L.A. Noire: DLC Bundle
setManifestid(110810, "239200575577592374", 167)