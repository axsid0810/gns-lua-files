-- 975680's Lua and Manifest Created by Hubcap Manifest
-- METAL SLUG XX
-- Created: September 30, 2025 at 00:30:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(975680) -- METAL SLUG XX
-- MAIN APP DEPOTS
addappid(975681, 1, "21f6fbebee5780b9d663651af3112f8f440fe42ac4cb833d0ca31f9ff6498ded") -- Pineapple Content
setManifestid(975681, "6650052534457576862", 568609172)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)