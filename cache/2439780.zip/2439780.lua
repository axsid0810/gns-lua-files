-- 2439780's Lua and Manifest Created by Hubcap Manifest
-- Godzilla Voxel Wars
-- Created: October 02, 2025 at 12:50:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2439780) -- Godzilla Voxel Wars
-- MAIN APP DEPOTS
addappid(2439781, 1, "0180dc5274c13213bf264cdfaa0a87d340b01049b8de5d138c751142a9eceadd") -- Depot 2439781
setManifestid(2439781, "5372542688476371972", 1895172466)