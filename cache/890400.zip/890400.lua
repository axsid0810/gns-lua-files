-- 890400's Lua and Manifest Created by Hubcap Manifest
-- Uncharted Waters Online - Steam
-- Created: June 15, 2026 at 15:54:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(890400) -- Uncharted Waters Online - Steam
-- MAIN APP DEPOTS
addappid(890401, 1, "519cadd69c338340c92dadbb483cbf481e50439845cf7e1cddd0ed33e81e03ab") -- Uncharted Waters Online Content
setManifestid(890401, "5668094081276906836", 10209519355)