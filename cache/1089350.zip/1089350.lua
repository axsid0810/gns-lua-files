-- 1089350's Lua and Manifest Created by Hubcap Manifest
-- NBA 2K20
-- Created: March 16, 2026 at 15:40:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1089350, 1, "17a291c40e7edbf8e62f5672aa45299ca3831e13666cde1f94285168d9765adf") -- NBA 2K20
-- MAIN APP DEPOTS
addappid(1089351, 1, "5f64f254a290569bd9659b6ccef6ec373a9d712b205817f57c419b12ffb4355e") -- NBA 2K20 Content
setManifestid(1089351, "420431534788638456", 105515181782)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1128700) -- NBA 2K20 Pre-Order Content
addtoken(1128700, "8973148196506222058")
addappid(1128701) -- NBA 2K20 Digital Deluxe Content
addappid(1128702) -- NBA 2K20 Legend Edition Content
addtoken(1128702, "15271422322451601289")
addappid(1128703) -- NBA 2K20 Legend Edition Content BE