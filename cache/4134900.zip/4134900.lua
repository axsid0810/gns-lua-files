-- 4134900's Lua and Manifest Created by Hubcap Manifest
-- CuckTales 2 🐓
-- Created: March 30, 2026 at 07:49:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(4134900) -- CuckTales 2 🐓
-- MAIN APP DEPOTS
addappid(4134901, 1, "b056e3d833099cea11d158ab0a33d66af8d00b47087c84fbc28fccbc12dbf6d5") -- Depot 4134901
setManifestid(4134901, "6524039025367433842", 2644891949)
-- DLCS WITH DEDICATED DEPOTS
-- CuckTales 2  - Artbook (AppID: 4489020)
addappid(4489020)
addappid(4489020, 1, "04753f82c3c6189923b2896d8654326d67f4b212dcf876ebcbe83d95b70f7c9e") -- CuckTales 2  - Artbook - Depot 4489020
setManifestid(4489020, "1311216978824299682", 52054369)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4489020) -- Depot 4489020 (empty depot)