-- 41070's Lua and Manifest Created by Hubcap Manifest
-- Serious Sam 3: BFE
-- Created: July 18, 2026 at 18:36:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 25
-- Total DLCs: 7
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(41070, 1, "b06c26d01acbdb76a4d071307f8a648fcd313bb5c4fff67c7c7f93d91e229e76") -- Serious Sam 3: BFE
-- MAIN APP DEPOTS
addappid(41079, 1, "2aaa600a99321c8d4f0d5171942789d8d1b7c9c6545e51acbd71382d274d669b") -- SS3 CommonCatalog
setManifestid(41079, "6066902042617027627", 1781994)
addappid(41071, 1, "61b8d1d317b737b104990781f25cfd06f174370c318ef74a1d72d8beb30c764a") -- SS3_GameBin_Windows
setManifestid(41071, "6095136272987054324", 24921296)
addappid(41072, 1, "6fa83e6aa77d87ed28563dc31bd9d0e6d0543b8cab8c937d566d5013098acac6") -- SS3_GameBin_OSX
setManifestid(41072, "1443443063832947662", 43609888)
addappid(41084, 1, "c33b614f39b5fadf56d96a42267a20e8b394b70698590fc65b0c255d0c08145f") -- SS3_GameBin_Linux
setManifestid(41084, "4295467050685980708", 43846424)
addappid(41075, 1, "1ea9d2a67dc83db49bde234ef6bd00c1a3fe3672b9a7f3a74fe89254a4b3944a") -- SS3_Common
setManifestid(41075, "5015710105525347733", 5084294636)
addappid(41076, 1, "895e0d94235925d06a664f219b3ab668f2dbbe1a0e7976c6d9b9668f8a8fb033") -- SS3_Common_Windows
setManifestid(41076, "4017863373071154036", 18068686)
addappid(41077, 1, "c44398efafe88a065dddd89951ebedc1b6f7c65cd0dc419f6169ba1b8d3c8f3b") -- SS3_Common_OSX
setManifestid(41077, "6877124042687632634", 457434)
addappid(41078, 1, "4c7243b335aaaf677f9c76dfa2feaa262f1cb640515028cce5155483053832e2") -- SS3_Common_Linux
setManifestid(41078, "4635760834128063288", 206227)
addappid(104805, 1, "bbc97de00fdee010e91a8ae054fcdf4adb5692f0f1951026adfb09e1e80b2628") -- Serious Sam 3: BFE Czech
setManifestid(104805, "2285833362600735151", 135)
addappid(104806, 1, "966532826cc7311ce7f8d2287ba842547f6d9d00eebd8cdcda6c9d9d5521ed33") -- Serious Sam 3: BFE Polish
setManifestid(104806, "6718218615379461709", 135)
addappid(104807, 1, "1cf6d8ae37de868d1a0fc02e64bd0d2365b3e6a36e00be2ab2a8ca598d10fbcd") -- Serious Sam 3: BFE English
setManifestid(104807, "3052230628437117707", 123)
addappid(104808, 1, "d6d8d6cedea6ad34c7ab851d96c5e2765bdd5ac15b68469c4d76fb5312f654c3") -- Serious Sam 3: BFE French
setManifestid(104808, "2742690012694701916", 121)
addappid(104809, 1, "c097a9819e7a91ed3470aac7ef585565f10e3830e8d2f0a72622a66fe8a5ecbf") -- Serious Sam 3: BFE German
setManifestid(104809, "902678129750744678", 122)
addappid(104810, 1, "18a12c6096d8688d6077823d91f79ad4e9bd5608f442d68fd6ad86b512294c0d") -- Serious Sam 3: BFE Spanish
setManifestid(104810, "6882966359828773874", 106)
addappid(104811, 1, "dae88b1188b4450b6e1a333a0647b7693b5bbedbb9733710435c79557bad13d2") -- Serious Sam 3: BFE Italian
setManifestid(104811, "974490381230134430", 135)
addappid(104812, 1, "e17b68d3c5925392bf0fe4dde2b832f58c7d106850db3a10d6b16b8a1daa7687") -- Serious Sam 3: BFE Russian
setManifestid(104812, "8082952782342644023", 135)
addappid(104813, 1, "0ff3777c1e73763421137d22b306d9b8616a3a582d32371cad547ed302f1d2d9") -- Serious Sam 3: BFE Japanese
setManifestid(104813, "1332766529770311746", 124)
addappid(104814, 1, "9880bc6daadc33753695d3f4d66eea175baf1dc5b08d6e2eabada2a665e9b3dc") -- Serious Sam 3: BFE SChinese
setManifestid(104814, "5311658765120350585", 120)
addappid(104815, 1, "ddb1ba5c3fa462ff3bfff4872562f471cd9bdeb2d618d5965279460fb4880bb1") -- Serious Sam 3: BFE Bulgarian
setManifestid(104815, "2862592498760979204", 135)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Serious Sam 3 Jewel of the Nile (AppID: 41074)
addappid(41074)
addappid(41074, 1, "6bd652f81be60c994ce4f36b823ef03b009f1ee655f5405469af88cf3382b2e8") -- Serious Sam 3 Jewel of the Nile - DLC_Sam3Extended
setManifestid(41074, "4413385596380264624", 396322519)
-- Serious Sam 3 Preorder DLC (AppID: 200320)
addappid(200320)
addappid(200320, 1, "2b0324090f11afef312508df06c149a0661d83ed221125f0efc1629af26b5964") -- Serious Sam 3 Preorder DLC - Serious Sam 3 DLC1_Models
setManifestid(200320, "9199144312413391809", 583)
-- Serious Sam 3 DLC2_Models (AppID: 200321)
addappid(200321)
addappid(200321, 1, "66f445d0b6d928ae9be03a6d3bba8fb418ed00db787d4bd2917a961d077866d4") -- Serious Sam 3 DLC2_Models - Serious Sam 3 DLC2_Models
setManifestid(200321, "3195428351865353597", 1078)
-- Serious Sam 3 DLC3_Models (AppID: 200322)
addappid(200322)
addappid(200322, 1, "6f7637bf3716b52b61ebafc7dc2c424fa963cdb56ab09faf01cb693dec9e7536") -- Serious Sam 3 DLC3_Models - Serious Sam 3 DLC3_Models
setManifestid(200322, "2801316443043420546", 388)
-- Serious Sam 3 Bonus Content DLC (AppID: 616060)
addappid(616060)
addtoken(616060, "18144882488224112727")
addappid(616060, 1, "77b7942203f142dc222844f2edffca188e93cd87e636a91d5eaee51415518807") -- Serious Sam 3 Bonus Content DLC - Serious Sam 3 Bonus Content DLC (616060) Depot
setManifestid(616060, "8517577945223276398", 3367824316)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(41073) -- DLC_Preview
addappid(200323) -- Sniper Scope for Devastator