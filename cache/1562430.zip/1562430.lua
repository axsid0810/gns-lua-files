-- 1562430's Lua and Manifest Created by Hubcap Manifest
-- DREDGE
-- Created: October 16, 2025 at 09:56:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(1562430) -- DREDGE
-- MAIN APP DEPOTS
addappid(1562431, 1, "acf9eaa218c2a21d4505c6c9554bcef5b09bb049af53bdcf759b27c5bb16b7f8") -- Depot 1562431
setManifestid(1562431, "6824303945564843279", 796014527)
addappid(1562432, 1, "df7109e5cbf70a0c68998601d6bbab069037180905b28c8002f37b77cf6fe191") -- Depot 1562432
setManifestid(1562432, "7499666556946835789", 812771281)
-- DLCS WITH DEDICATED DEPOTS
-- DREDGE - Digital Artbook (AppID: 2198610)
addappid(2198610)
addappid(2198610, 1, "24e82ac895be0fe904414677a48514d8230f80f0e8f2c050a2d81d41490d2e96") -- DREDGE - Digital Artbook - DREDGE - Digital Artbook
setManifestid(2198610, "8837623262127469519", 118687443)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2104240) -- DREDGE - Blackstone Key
addappid(2198600) -- DREDGE - Custom Rod
addappid(2561440) -- DREDGE - The Pale Reach
addappid(2561450) -- DREDGE - The Iron Rig