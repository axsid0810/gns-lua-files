-- 867290's Lua and Manifest Created by Hubcap Manifest
-- Crossroads Inn Anniversary Edition
-- Created: September 29, 2025 at 05:43:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 7
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(867290, 1, "7e5ee2feb6ed393bee1b51252fb15ab46be116bd002416f23275cdb78e23135b") -- Crossroads Inn Anniversary Edition
-- MAIN APP DEPOTS
addappid(867291, 1, "946d57dead5d938dbd782c3c56fe6fad23ea5dda3fbef17510fa46239a662c35") -- Crossroads Inn Content
setManifestid(867291, "3161187241140154236", 14475564909)
addappid(867294, 1, "168b338e26024bbc37aa60196c4b816364a053b490b9f69a9e4909c9847d0fff") -- Crossroads Inn MAC
setManifestid(867294, "1701793088738827517", 9862677948)
addappid(867295, 1, "79f6ebf78f9679ab2f38bdd57ec3f3aea885b1a0520759e5d435fc4a4470540a") -- Crossroads Inn Linux
setManifestid(867295, "9180769123478672413", 10525847033)
addappid(867292, 1, "e0b53ba818849d833cf7873dce585251711bab5130f9da0b8aa9be894d9e90e2") -- Crossroads Inn BETABUILD
setManifestid(867292, "1665093136548035540", 90732031)
addappid(867293, 1, "21471f2f834b3a97ff57f937f2449ce063ade83a09035233252022212edb846c") -- Crossroads Inn PRESS & TEST
setManifestid(867293, "3034861251425879051", 14475564909)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Crossroads Inn - Digital Goodies Pack (AppID: 1150370)
addappid(1150370)
addappid(1150370, 1, "9e8c87bdcf781f63105f1e59dc81043ed0e81dda8b9ced108350cc88622336e4") -- Crossroads Inn - Digital Goodies Pack - Crossroads Inn - Digital Goodies Pack (1150370) Depot
setManifestid(1150370, "496722458291125592", 2578887327)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1150380) -- Crossroads Inn Anniversary Edition - Season Pass 2
addappid(1154630) -- Crossroads Inn - Supporters Content
addappid(1205180) -- Crossroads Inn - Pests  Puppies
addappid(1281620) -- Crossroads Inn - The Pit
addappid(1363450) -- Crossroads Inn - Hooves  Wagons
addappid(1395950) -- Crossroads Inn - Bath  Beauty