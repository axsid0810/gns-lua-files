-- 2051120's Lua and Manifest Created by Hubcap Manifest
-- HOT WHEELS UNLEASHED™ 2 - Turbocharged
-- Created: September 29, 2025 at 18:18:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 25
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2051120) -- HOT WHEELS UNLEASHED™ 2 - Turbocharged
-- MAIN APP DEPOTS
addappid(2051121, 1, "a3a1a2c67616cb63b8fe7830719af6ce7ff2ee70aeb15f6723f08c2a71d64d9e") -- Depot 2051121
setManifestid(2051121, "8562777406195562958", 23670680890)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2370240) -- HOT WHEELS UNLEASHED 2 - Rust and Fast Pack
addappid(2370241) -- HOT WHEELS UNLEASHED 2 - Unstoppables Pack
addappid(2370242) -- HOT WHEELS UNLEASHED 2 - Speed Kings Pack
addappid(2370243) -- HOT WHEELS UNLEASHED 2 - Just a Scratch Pack
addappid(2370244) -- HOT WHEELS UNLEASHED 2 - Twin Mill Unleashed Edition
addappid(2370245) -- HOT WHEELS UNLEASHED 2 - AcceleRacers All-Star Pack
addappid(2370246) -- HOT WHEELS UNLEASHED 2 - Speed and Style Pack
addappid(2370247) -- HOT WHEELS UNLEASHED 2 - Manga Free Pack
addappid(2370248) -- HOT WHEELS UNLEASHED 2 - Highway 35 Free Pack
addappid(2370249) -- HOT WHEELS UNLEASHED 2 - Honda Modern Classics Pack
addappid(2370250) -- HOT WHEELS UNLEASHED 2 - AcceleRacers Free Pack 1
addappid(2370251) -- HOT WHEELS UNLEASHED 2 - Highway 35 World Race Pack
addappid(2370252) -- HOT WHEELS UNLEASHED 2 - Monster Trucks Pack
addappid(2370253) -- HOT WHEELS UNLEASHED 2 - Mega Bites Free Pack
addappid(2370254) -- HOT WHEELS UNLEASHED 2 - AcceleRacers Free Pack 2
addappid(2370255) -- HOT WHEELS UNLEASHED 2 - Old but Gold Pack
addappid(2370256) -- HOT WHEELS UNLEASHED 2 - AcceleRacers Free Pack 3
addappid(2370257) -- HOT WHEELS UNLEASHED 2 - Mercedes-Benz Pack
addappid(2475560) -- HOT WHEELS UNLEASHED 2 - Season Pass Vol. 1
addappid(2475570) -- HOT WHEELS UNLEASHED 2 - Season Pass Vol. 2
addappid(2492920) -- HOT WHEELS UNLEASHED 2 - Fast X Pack
addappid(2524800) -- HOT WHEELS UNLEASHED 2 - AcceleRacers Expansion Pack
addappid(2524810) -- HOT WHEELS UNLEASHED 2 - Made in Italy Expansion Pack
addappid(2524820) -- HOT WHEELS UNLEASHED 2 - Fast  Furious Expansion Pack
addappid(2524830) -- HOT WHEELS UNLEASHED 2 - Alien Encounters Expansion Pack