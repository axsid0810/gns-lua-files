-- 674750's Lua and Manifest Created by Hubcap Manifest
-- Yet Another Zombie Defense HD
-- Created: July 24, 2026 at 08:15:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(674750, 1, "b5ed69cfecac6430471abdb4dbfc795dc071d5bcb1c65782e14135dd2c43b53d") -- Yet Another Zombie Defense HD
-- MAIN APP DEPOTS
addappid(674751, 1, "9d8be20f924b4717062e08d5c9d06cac99d7628d2c18d3b72b84e44683bd0593") -- Yet Another Zombie Defense HD Content
setManifestid(674751, "2457577781212323348", 363298132)