-- 2806120's Lua and Manifest Created by Hubcap Manifest
-- Bio Goddess: Doomsday Begins
-- Created: July 23, 2026 at 11:45:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2806120) -- Bio Goddess: Doomsday Begins
-- MAIN APP DEPOTS
addappid(2806121, 1, "b2fdbde8cee12f9bfa492ac7083e3b922b06eb750d4ed3133a2ec34d67381ccb") -- Depot 2806121
setManifestid(2806121, "2714251831203711960", 14595731343)