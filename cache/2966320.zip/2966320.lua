-- 2966320's Lua and Manifest Created by Hubcap Manifest
-- Starsand Island
-- Created: July 02, 2026 at 08:27:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(2966320, 1, "208ea6f9923a37a7b011f392e50f7f7ab2952497337e184dbd00448c63bd1a50") -- Starsand Island
addtoken(2966320, "1152859757700171993")
-- MAIN APP DEPOTS
addappid(2966321, 1, "ce86c628c5c525587d2aea36d5a745c980584e22eca6389d8bfd7a63c0db1c4c") -- Depot 2966321
setManifestid(2966321, "3555655029483849704", 8504341567)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4391920) --  DLC
addtoken(4391920, "4278437199386008459")
addappid(4395490) --  DLC
addtoken(4395490, "10139208446148904551")
addappid(4424260) --  DLC
addtoken(4424260, "18153694763478506076")
addappid(4460980) --  DLC
addappid(4621220) --  DLC
addtoken(4621220, "985130833684389911")