-- 1088710's Lua and Manifest Created by Hubcap Manifest
-- Yakuza 3 Remastered
-- Created: October 01, 2025 at 08:39:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1088710) -- Yakuza 3 Remastered
-- MAIN APP DEPOTS
addappid(1088711, 1, "c1b7e189e92f1444dccf6f8b7f8e0210e613a88b9d8de8c178044862d9c946f4") -- RINO Content
setManifestid(1088711, "5255602264781295535", 26990339964)
addappid(1088712, 1, "cca872cb599f2e4755fe421841cf97f37a1664954eb4f96f09edd06b956da99e") -- RINO 3 Depot - bin
setManifestid(1088712, "8896346631425795919", 19621168)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)