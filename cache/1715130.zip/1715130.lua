-- 1715130's Lua and Manifest Created by Hubcap Manifest
-- Crysis Remastered
-- Created: September 29, 2025 at 05:51:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1715130) -- Crysis Remastered
-- MAIN APP DEPOTS
addappid(1715131, 1, "24355fe086b76003e1311e9e110fa69dfa08cb060f9f31d9d91af0a32fc37234") -- Crysis Remastered Content
setManifestid(1715131, "4229129126705849415", 21330901122)