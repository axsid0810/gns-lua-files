-- 48000's Lua and Manifest Created by Hubcap Manifest
-- LIMBO
-- Created: September 29, 2025 at 22:13:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(48000) -- LIMBO
-- MAIN APP DEPOTS
addappid(48003, 1, "38e1d9684662db75e3ca547186abbf41df7d1dbd382644c7a275c7a35e4e753b") -- Limbo Mac
setManifestid(48003, "7717996545831822757", 113048283)
addappid(48002, 1, "8c3a1b09c8ec82102b1e7c25c1572df4fa7e82b77373d8f9386b7a6ff04dc794") -- limbo_exec
setManifestid(48002, "6867798692379060871", 5453312)
addappid(48001, 1, "f43855f824b0c92b5ecc36ae42651ae40b32411461822f41f9fb19969b3fd14d") -- Limbo Content
setManifestid(48001, "1261656871327265848", 98229897)
addappid(48004, 1, "9639ec99166818982187cc413d6dbbdf84690d6826744b9325fefff30d4dd5d7") -- Limbo Linux
setManifestid(48004, "4729536071049921379", 112551330)
addappid(48005, 1, "c3868dd46e9dfc0ff03c82eab3d09ef723a87b9ef92a90540bcc84409c64dc2a") -- LIMBO Linux 64bit
setManifestid(48005, "5598213330580205879", 103660194)