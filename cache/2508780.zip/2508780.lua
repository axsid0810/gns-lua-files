-- 2508780's Lua and Manifest Created by Hubcap Manifest
-- STORY OF SEASONS: Grand Bazaar
-- Created: May 31, 2026 at 12:35:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 14
-- Total DLCs: 16

-- MAIN APPLICATION
addappid(2508780, 1, "34db92710a920fab17ef00ef9f41849d414e79a09d8e173a8b5d17cf06a44893") -- STORY OF SEASONS: Grand Bazaar
-- MAIN APP DEPOTS
addappid(2508781, 1, "d3d2cecbf425b32af43928d0b54fb991edc1a74dfac4d72d31a47b22d078ec14") -- Depot 2508781
setManifestid(2508781, "1557678708717129949", 5131857761)
-- DLCS WITH DEDICATED DEPOTS
-- STORY OF SEASONS Grand Bazaar - Pastel Flower Set (AppID: 3051770)
addappid(3051770)
addappid(3051770, 1, "48425c228628d91f98d2dfbccacf0c990949331ae7831686b75272939cd409b5") -- STORY OF SEASONS Grand Bazaar - Pastel Flower Set - Depot 3051770
setManifestid(3051770, "4781979651439660224", 1226)
-- STORY OF SEASONS Grand Bazaar - Honey Bee Set (AppID: 3051780)
addappid(3051780)
addappid(3051780, 1, "20ad8f70645e50600b24aa5b5c34748031628880b54a4341d0f7efc0caffdfa3") -- STORY OF SEASONS Grand Bazaar - Honey Bee Set - Depot 3051780
setManifestid(3051780, "6142504203826130606", 1224)
-- STORY OF SEASONS Grand Bazaar - Turnip Set (AppID: 3051790)
addappid(3051790)
addappid(3051790, 1, "301e21e1002634db24ac7ea0bf6a7aebf90a11c6d08e8337a8239ead450139be") -- STORY OF SEASONS Grand Bazaar - Turnip Set - Depot 3051790
setManifestid(3051790, "7233756548924847260", 1220)
-- STORY OF SEASONS Grand Bazaar - Head Chef Set (AppID: 3051800)
addappid(3051800)
addappid(3051800, 1, "2a0efec563aabcf8baf9162677f331803971d4eebfbba9a09e1a9adc4bfb27b8") -- STORY OF SEASONS Grand Bazaar - Head Chef Set - Depot 3051800
setManifestid(3051800, "4141453086276865299", 1220)
-- STORY OF SEASONS Grand Bazaar - Pumpkin Set (AppID: 3051810)
addappid(3051810)
addappid(3051810, 1, "f2ed3c0541419292069873bf33c7dc8be660db6b8a5e6355ef5e09febc626cbf") -- STORY OF SEASONS Grand Bazaar - Pumpkin Set - Depot 3051810
setManifestid(3051810, "8010863435161125787", 1220)
-- STORY OF SEASONS Grand Bazaar - Paw Print Set (AppID: 3051820)
addappid(3051820)
addappid(3051820, 1, "ce0bbf0be49a40ff8b3e544fd42c62751d4a1f228464e2bc1e1ad2767438d30d") -- STORY OF SEASONS Grand Bazaar - Paw Print Set - Depot 3051820
setManifestid(3051820, "6092932639233683545", 1220)
-- STORY OF SEASONS Grand Bazaar - Cow Set (AppID: 3051830)
addappid(3051830)
addappid(3051830, 1, "11061a1ed5036b24ad17351d518ca68411d4fe283cf6156176f5d161b9044ebc") -- STORY OF SEASONS Grand Bazaar - Cow Set - Depot 3051830
setManifestid(3051830, "7047648226728925275", 1220)
-- STORY OF SEASONS Grand Bazaar - Trunk of Transformation (AppID: 3248040)
addappid(3248040)
addappid(3248040, 1, "d671f9d0718c441e13b212891d9003f5260e69433455f44bcf2c768e61173336") -- STORY OF SEASONS Grand Bazaar - Trunk of Transformation - Depot 3248040
setManifestid(3248040, "2588098502636584215", 1220)
-- STORY OF SEASONS Grand Bazaar - Rancher Set (AppID: 3406540)
addappid(3406540)
addappid(3406540, 1, "cbd89f777e21da2a0046f09b6b6aa1625ae6491140fce422c8f6070672427754") -- STORY OF SEASONS Grand Bazaar - Rancher Set - Depot 3406540
setManifestid(3406540, "9076925937056610569", 1226)
-- STORY OF SEASONS Grand Bazaar - Pine Hoverfly Set (AppID: 3482230)
addappid(3482230)
addappid(3482230, 1, "0789e54527d096025f42b5c9e7196eed567c1e7b5a83a8466121fe86a3b6a8bb") -- STORY OF SEASONS Grand Bazaar - Pine Hoverfly Set - Depot 3482230
setManifestid(3482230, "498202292068430120", 1226)
-- STORY OF SEASONS Grand Bazaar - Art Book (AppID: 3847830)
addappid(3847830)
addappid(3847830, 1, "418b5c8fd01c80869d13b37d6ddff62844ed8fa89b0c9c3803a9846c36a96c3f") -- STORY OF SEASONS Grand Bazaar - Art Book - Depot 3847830
setManifestid(3847830, "726245139049856328", 532210025)
-- STORY OF SEASONS Grand Bazaar - Bachelor Sweetheart Set (AppID: 4426530)
addappid(4426530)
addappid(4426530, 1, "014faffc51b17dabb1ef21d485acaa1b08412bae7612442afc0af5e392467539") -- STORY OF SEASONS Grand Bazaar - Bachelor Sweetheart Set - Depot 4426530
setManifestid(4426530, "4110460564971939453", 1228)
-- STORY OF SEASONS Grand Bazaar - Bachelorette Sweetheart Set (AppID: 4426540)
addappid(4426540)
addappid(4426540, 1, "42347e364b2e4a8764dcd902e4a258d48f87db30ca44cf40866dbcd7a9268b47") -- STORY OF SEASONS Grand Bazaar - Bachelorette Sweetheart Set - Depot 4426540
setManifestid(4426540, "1309594991992385732", 1223)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3847810) -- STORY OF SEASONS Grand Bazaar - Super Digital Deluxe DLC Set
addappid(3847820) -- STORY OF SEASONS Grand Bazaar - New You Outfit Set
addappid(4695490) -- STORY OF SEASONS Grand Bazaar - Complete Sweetheart Set