-- 4835250's Lua and Manifest Created by Hubcap Manifest
-- [Stories to Tell] The Stoneville Incident
-- Created: July 19, 2026 at 00:35:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4835250, 1, "3e414615f243f18443a9bc8c11da8b7ca2d72a4f1d0610f0b2806cc523c6c5e2") -- [Stories to Tell] The Stoneville Incident
-- MAIN APP DEPOTS
addappid(4835251, 1, "5cc2e9ba288952fd08bd9ec3c161a0c893914f1c344af5f472bc9d7cbd61d8d9") -- Depot 4835251
setManifestid(4835251, "8516388022232213083", 3027295939)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)