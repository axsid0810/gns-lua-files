-- 300820's Lua and Manifest Created by Hubcap Manifest
-- Toy Story 3
-- Created: October 01, 2025 at 03:02:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 17
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(300820) -- Toy Story 3
-- MAIN APP DEPOTS
addappid(300821, 1, "0e20a5f31271db9325f50cba1901b205d946b59f34731a33468fff2fa78c705e") -- Toy Story 3 Common depot
setManifestid(300821, "4723845939758216585", 2167043993)
addappid(300822, 1, "097aa19657ccac3e43c68c6433797a4125bd80c0034f77f44a7f03a794cd6067") -- Toy Story 3 Cz Depot
setManifestid(300822, "1093847233351468919", 1761061339)
addappid(300823, 1, "bd349db85e26a4762a2f3c6ee502a94fdc45135eba5c25826d8803dae1d921d1") -- Toy Story 3 Po Depot
setManifestid(300823, "2720752851768981594", 1758567804)
addappid(300824, 1, "195ce4d8421eeee4a3dbc9ebc2b563a54b70d1a6701855b02b0d51463d96561a") -- Toy Story 3 Da Depot
setManifestid(300824, "5147673597686385682", 1787961131)
addappid(300825, 1, "cc8c3cdaff351d795ee3d8b1ca681a2390acd4e2415014ef4d257db202af1e44") -- Toy Story 3 Sw Depot
setManifestid(300825, "2033202489655916977", 1787556940)
addappid(300826, 1, "baf1cbacea8ba8b2a48667ef4c57f69dfb3a3d923f4fc57cb5a95dee92aabc9b") -- Toy Story 3 Fn Depot
setManifestid(300826, "3061028769765071797", 1786487692)
addappid(300827, 1, "3dfbb9792d219515bb06ad71ebe2281c05afa5dd8568dae9b659af30b281cfd7") -- Toy Story 3 Nw Depot
setManifestid(300827, "6370562217729398368", 1781328014)
addappid(300828, 1, "b320d12748a65791b79ffe502981d048c515016a3bdb555b2f0166dbf4a88c32") -- Toy Story 3 E Depot
setManifestid(300828, "6523676981648793655", 1882734110)
addappid(300829, 1, "c6094abd8661ea6991c863b1f95f1ce51efa8a2dc97e313de5826168f8613fcf") -- Toy Story 3 F Depot
setManifestid(300829, "7353650582148928137", 1881947560)
addappid(301020, 1, "bb64bf5a9af843d293f082177c6c5bf98dba84e50015280622b48e14a5321046") -- Toy Story 3 I Depot
setManifestid(301020, "6604119855155404007", 1882957513)
addappid(301021, 1, "0c7e407313f9d27d406a76e76d2b2bbc055daf7456b19309b90c097ecaadf09a") -- Toy Story 3 G Depot
setManifestid(301021, "2518676903189347183", 1892304296)
addappid(301022, 1, "6f87172d7e74e5bbbab3d5f5c0a5e57dd138c1ad3853e68b6e0043ad98a78f7e") -- Toy Story 3 S Depot
setManifestid(301022, "3552464321420722186", 1884591273)
addappid(301023, 1, "d47ca0e5ad080229e096747cdf427ff8ceb8ed17b7e611275bc744f1725651fb") -- Toy Story 3 D Depot
setManifestid(301023, "3923462072917622057", 1882297831)
addappid(301024, 1, "4f146e0aed245a2da3de1ec0fde2fc8e3dd649d718d78c1044cb1b8b29b0209f") -- Toy Story 3 Bp Depot
setManifestid(301024, "5099373221538203277", 1865947645)
addappid(301025, 1, "e89df2fe5d2d40c705fa137820112ae2f29c7e07802a78ecef4d62ac42393ecc") -- Toy Story 3 Ru Depot
setManifestid(301025, "3057048892489225807", 1748354323)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)