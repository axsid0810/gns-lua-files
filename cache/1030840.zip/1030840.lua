-- 1030840's Lua and Manifest Created by Hubcap Manifest
-- Mafia: Definitive Edition
-- Created: July 22, 2026 at 11:11:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1030840, 1, "79080e53a9757e2f89c87a78ca83397a6cc0069c5ac00e8c66b463ce7ab276ef") -- Mafia: Definitive Edition
-- MAIN APP DEPOTS
addappid(1030841, 1, "d6e79f53321a7947e8963e27e1baefb862ce738eb51a2fa8eeaa90c476917f64") -- Scotch Content
setManifestid(1030841, "2886022585972111903", 38908493117)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- Chicago Pack (AppID: 1316300)
addappid(1316300)
addtoken(1316300, "16475343798686789276")
addappid(1316300, 1, "724c017202bf35f19f8cdbbec2e6a859a2d88b805b1abe089d4d8a329b318471") -- Chicago Pack - Chicago Pack (1316300) Depot
setManifestid(1316300, "1697495207204236421", 5950)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1030849) -- Depot 1030849 (empty depot)