-- 359870's Lua and Manifest Created by Hubcap Manifest
-- FINAL FANTASY X/X-2 HD Remaster
-- Created: September 29, 2025 at 12:15:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(359870) -- FINAL FANTASY X/X-2 HD Remaster
-- MAIN APP DEPOTS
addappid(359871, 1, "8e28e18ac8cc58c9c81ddd3022ad0bfcb15e378768d5fc713dcb0254e6d93fff") -- FINAL FANTASY X/X-2 HD Remaster Content
setManifestid(359871, "5168047039601173807", 39462582505)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)