-- 311560's Lua and Manifest Created by Hubcap Manifest
-- Assassin's Creed Rogue
-- Created: July 30, 2026 at 04:32:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 5 (14 excluded)
-- Shared Depots: 4
-- Blacklisted Depots: 2
--   Depot 311563, 311564: Blacklisted

-- MAIN APPLICATION
addappid(311560, 1, "b06163921482154f38801b93d9217c556d4f21ecfa1f1a37b6cc1b8c85f14ee7") -- Assassin's Creed Rogue
-- MAIN APP DEPOTS
addappid(311561, 1, "42bdf94957d5fccbb06dae4e835998ffaacee0eb6e08ffbbd77ad7d0be282380") -- Assassin's Creed - Rogue Base
setManifestid(311561, "7137976438714669362", 12587755101)
addappid(311562, 1, "2bcc03afbf14f7a2d4121ef3675f20cf48d8038648a0e3187702620bbcdac0cb") -- Assassin's Creed Rogue WW
setManifestid(311562, "5707643107944744968", 14)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "8936186649444731600", 264933784)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(339030) -- Assassins Creed Rogue - Templar Legacy Pack
addappid(339031) -- Assassins Creed Rogue  Activities Pack
addappid(339032) -- Assassins Creed Rogue  Collectibles Pack
addappid(339033) -- Assassins Creed Rogue  Resources Pack
addappid(339034) -- Assassins Creed Rogue  Technology Pack
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MANIFEST BLACKLIST)
-- addappid(352920) -- DLC 352920 (Breaks the game with some client mods)
-- addappid(352921) -- DLC 352921 (Breaks the game with some client mods)
-- addappid(352922) -- DLC 352922 (Breaks the game with some client mods)
-- addappid(352923) -- DLC 352923 (Breaks the game with some client mods)
-- addappid(352924) -- DLC 352924 (Breaks the game with some client mods)
-- addappid(352925) -- DLC 352925 (Breaks the game with some client mods)
-- addappid(352926) -- DLC 352926 (Breaks the game with some client mods)
-- addappid(352927) -- DLC 352927 (Breaks the game with some client mods)
-- addappid(352928) -- DLC 352928 (Breaks the game with some client mods)
-- addappid(352940) -- DLC 352940 (Breaks the game with some client mods)
-- addappid(352941) -- DLC 352941 (Breaks the game with some client mods)
-- addappid(352942) -- DLC 352942 (Breaks the game with some client mods)
-- addappid(352943) -- DLC 352943 (Breaks the game with some client mods)
-- addappid(352944) -- DLC 352944 (Breaks the game with some client mods)