-- 1295500's Lua and Manifest Created by Hubcap Manifest
-- Warhammer 40,000: Battlesector
-- Created: July 22, 2026 at 10:31:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 11
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1295500, 1, "0baf20c17fef23bd2e9a7039fbaf4fb089fb0907e47c37ba1ebba0cdb8abfdf9") -- Warhammer 40,000: Battlesector
-- MAIN APP DEPOTS
addappid(1295501, 1, "d12f0bcfa736438c73d5829cd28d41cd9bbc7be4f401af778ec81c0cf9d16ae9") -- Warhammer 40,000: Battlesector Content
setManifestid(1295501, "3211032245227978257", 26233607336)
addappid(1295502, 1, "e4bca82705ce54ce78394160a3222f708214c7dbd198a07b320f63f6d9dce0aa") -- Production Files Depot
setManifestid(1295502, "6356118931423404886", 52988849)
-- SHARED DEPOTS (from other apps)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1718640) -- Warhammer 40,000 Battlesector - Blood Angels Elites Pack
addappid(1793050) -- Warhammer 40,000 Battlesector - Tyranid Elites Pack
addappid(1793051) -- Warhammer 40,000 Battlesector - Necrons Faction Pack
addappid(2011980) -- Warhammer 40,000 Battlesector - Sisters of Battle
addappid(2199370) -- Warhammer 40,000 Battlesector - Daemons of Khorne
addappid(2305830) -- Warhammer 40,000 Battlesector - Orks
addappid(2583910) -- Warhammer 40,000 Battlesector - Tau
addappid(3202720) -- Warhammer 40,000 Battlesector - Astra Militarum
addappid(3577600) -- Warhammer 40,000 Battlesector - Deeds of the Fallen
addappid(3577620) -- Warhammer 40,000 Battlesector - Black Legion
addappid(3577690) -- Warhammer 40,000 Battlesector - Ultramarines