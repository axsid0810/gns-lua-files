-- 1918530's Lua and Manifest Created by Hubcap Manifest
-- Pocket Stables
-- Created: September 30, 2025 at 07:21:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1918530) -- Pocket Stables
-- MAIN APP DEPOTS
addappid(1918531, 1, "d0ea855fdb121c5ee51eade6a05deda1bd15496df0a6787e312442aed09e8ad7") -- Depot 1918531
setManifestid(1918531, "3513203526031725515", 78250818)