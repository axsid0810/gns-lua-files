-- 1563180's Lua and Manifest Created by Hubcap Manifest
-- Internet Cafe Simulator 2
-- Created: September 29, 2025 at 19:22:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1563180) -- Internet Cafe Simulator 2
-- MAIN APP DEPOTS
addappid(1563181, 1, "deb015c5f355a865f557ef2511c27ed07fed2214540bad2c41e5567e65cd2c62") -- Depot 1563181
setManifestid(1563181, "3099060878986052939", 7174932664)