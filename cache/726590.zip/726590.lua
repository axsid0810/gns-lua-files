-- 726590's Lua and Manifest Created by Hubcap Manifest
-- NBA 2K Playgrounds 2
-- Created: September 30, 2025 at 02:59:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 1
-- Shared Depots: 8

-- MAIN APPLICATION
addappid(726590) -- NBA 2K Playgrounds 2
-- MAIN APP DEPOTS
addappid(726591, 1, "d263cc83ca3e9d2b4690e6ca3e09c0e7e38c6e6e43f8409de950021c9c1b2756") -- NBA Playgrounds 2 Content
setManifestid(726591, "4222571681796144263", 10433111067)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(950500) -- NBA 2K Playgrounds 2 - 7500 VC