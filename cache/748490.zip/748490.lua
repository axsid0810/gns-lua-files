-- 748490's Lua and Manifest Created by Hubcap Manifest
-- The Legend of Heroes: Trails of Cold Steel II
-- Created: October 01, 2025 at 00:07:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 13
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(748490) -- The Legend of Heroes: Trails of Cold Steel II
-- MAIN APP DEPOTS
addappid(748491, 1, "e76ee9043ce59e5c36abd110d68779207bf1d8911020db5c2c0bc47d7640a6d3") -- The Legend of Heroes: Trails of Cold Steel II Content
setManifestid(748491, "1310767224826461894", 21752017531)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(773110) -- The Legend of Heroes Trails of Cold Steel II - All Casual Clothes
addappid(773760) -- The Legend of Heroes Trails of Cold Steel II - All Ride-Alongs
addappid(773761) -- The Legend of Heroes Trails of Cold Steel II - All Accessories
addappid(773762) -- The Legend of Heroes Trails of Cold Steel II - All Glasses
addappid(773763) -- The Legend of Heroes Trails of Cold Steel II - All Arcus Covers
addappid(773765) -- The Legend of Heroes Trails of Cold Steel II - Unspeakable Costumes
addappid(773800) -- The Legend of Heroes Trails of Cold Steel II - Shining Pom Bait Set 1
addappid(773801) -- The Legend of Heroes Trails of Cold Steel II - Shining Pom Bait Set 2
addappid(773802) -- The Legend of Heroes Trails of Cold Steel II - Shining Pom Bait Set 3
addappid(773803) -- The Legend of Heroes Trails of Cold Steel II - Shining Pom Bait Set 4
addappid(773804) -- The Legend of Heroes Trails of Cold Steel II - Shining Pom Bait Set 5
addappid(773805) -- The Legend of Heroes Trails of Cold Steel II - Shining Pom Bait Value Set 1
addappid(773806) -- The Legend of Heroes Trails of Cold Steel II - Shining Pom Bait Value Set 2