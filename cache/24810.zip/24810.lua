-- 24810's Lua and Manifest Created by Hubcap Manifest
-- Command & Conquer 3: Kane's Wrath™
-- Created: September 29, 2025 at 04:52:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 17
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(24810, 1, "343c98356cd30fa5a6f2452b5377d345f31735df070595362c88050886dd310d") -- Command & Conquer 3: Kane's Wrath™
-- MAIN APP DEPOTS
addappid(24811, 1, "d15d4b6c6d00908d80b9055f19ecb693da0b30cb3ca5aedfe7570c64da10722a") -- command_conquer_3_kane_content
setManifestid(24811, "1836311609551232553", 4964688525)
addappid(24812, 1, "209d961baa4a122efbeeba0888f6d04bc8d4b6a0ea0ad5930311a81c93f0f81a") -- Command and Conquer 3 - Kane's Wrath Spanish
setManifestid(24812, "374240528512756964", 904035333)
addappid(24813, 1, "f7630e7c4308bf771742c65980d03adc993fc7a229ee4bbfd2c731f9a7fe0408") -- Command and Conquer 3 - Kane's Wrath German
setManifestid(24813, "207195481367596447", 897513995)
addappid(24814, 1, "8fcedb1af7ce70518e9e05bea6bbcf4d21a7a663fb04945a6c1b8fe68132e352") -- Command and Conquer 3 - Kane's Wrath French
setManifestid(24814, "1422985688587899632", 907591325)
addappid(24815, 1, "c3cc53abe25f31e1c5e1bdd2fdd9e2326c2177c987208a8197b7764da0a011f4") -- Command and Conquer 3 - Kane's Wrath Italian
setManifestid(24815, "596469914147480154", 892699620)
addappid(24816, 1, "58cd94231075802538d0ee70ca493285ded52cc0c73611291afa482f5d8e0465") -- Command and Conquer 3 - Kane's Wrath Russian
setManifestid(24816, "5705202415649733000", 987094980)
addappid(24817, 1, "1d0592df2463b3bae270c7a2e2394a07ed2da34b2013f31b136467cacc2586bc") -- Command and Conquer 3 - Kane's Wrath Dutch
setManifestid(24817, "4100722994607799626", 3407466)
addappid(24818, 1, "52efd3522ba79de05fc7efef08016b119b3fb60e1640e7475285f08bbfe60410") -- Command and Conquer 3 - Kane's Wrath Swedish
setManifestid(24818, "530299655111048036", 3405526)
addappid(24819, 1, "88baa83988f51c173f4626beca5df5551566d983b781b95ef11353ab458198d2") -- Command and Conquer 3 - Kane's Wrath Polish
setManifestid(24819, "5573649285455939308", 11140642)
addappid(2845540, 1, "5435e46c0a9eea7ede2c6e4e91b53418fcf4bb47f8f649658bc4ced20ddac35d") -- Depot 2845540
setManifestid(2845540, "1968978481089297893", 3448416)
addappid(2845541, 1, "bf861d0f5409d9f7d19c931883e7e202a6d6d907e3fb93ee3c8fa59b6a0a6526") -- Depot 2845541
setManifestid(2845541, "3927675132552944746", 4894019)
addappid(2845542, 1, "db37690dfd510f2a638d62e55eeccbf125dcac5cf9fe643978b9b221239e9974") -- Depot 2845542
setManifestid(2845542, "5026019472153333080", 13450002)
addappid(2845543, 1, "f3b3e31c4ba5b40aae8338acaf0f250c0e19b8b25ceac06d882293afd0ad17e2") -- Depot 2845543
setManifestid(2845543, "2474374181410919663", 14261234)
addappid(2845544, 1, "728bdf255e22cacad0436b356f45f11f06b75911df7aef73432fdfdc02cf8b7d") -- Depot 2845544
setManifestid(2845544, "9188252224261599818", 3440914)
addappid(2845545, 1, "330990f9abfa6ea701bfa0ef68a0099fb2e435b1696b97fd0acc4a2106cf1cf1") -- Depot 2845545
setManifestid(2845545, "1712068527710337378", 3475086)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)