-- 1592520's Lua and Manifest Created by Hubcap Manifest
-- WitchSpring3 Re:Fine - The Story of Eirudy -
-- Created: January 25, 2026 at 22:18:42 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(1592520, 1, "d65cb803d8b3c851ab4dc79f0dbceffe2a57ffc6c8f32159d5bdc56fb77532a2") -- WitchSpring3 Re:Fine - The Story of Eirudy -
-- MAIN APP DEPOTS
addappid(1592521, 1, "fc0ffe7dae93ed9a8c14a36d67a915b01ff4279f25bb874e351981804fdd8f42") -- Witch Spring 3 Content
setManifestid(1592521, "7500565253618156565", 2501769621)
-- DLCS WITH DEDICATED DEPOTS
-- Witch Spring 3 Costume DLC - Gran-magne (AppID: 1611450)
addappid(1611450)
addappid(1611450, 1, "56510502dc8a3d9d18afe87da2f7f2b1bfc50006ccbabdc93a23f7f2ef8dbbd9") -- Witch Spring 3 Costume DLC - Gran-magne - Witch Spring 3 Costume DLC - Gran-magne Depot
setManifestid(1611450, "6373675283831816566", 3864)
-- Witch Spring 3 Costume DLC - Bluebell (AppID: 1612670)
addappid(1612670)
addappid(1612670, 1, "03e4db7f5408074b30f9ed939efc7cfcbaabc1df610015ac47510f4b15891a5a") -- Witch Spring 3 Costume DLC - Bluebell - Witch Spring 3 Costume DLC - Bluebell Depot
setManifestid(1612670, "7411192660626694386", 3864)
-- Witch Spring 3 ReFine EXTRA CONTENTS (AppID: 1753550)
addappid(1753550)
addappid(1753550, 1, "ce2abc5f63e69023f976b1c81d9dc967632ca683e8bf40ce1a2bc80ee00aa4e0") -- Witch Spring 3 ReFine EXTRA CONTENTS - Depot 1753550
setManifestid(1753550, "3727224745724960015", 122035901)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1611450) -- Depot 1611450 (empty depot)
-- addappid(1612670) -- Depot 1612670 (empty depot)