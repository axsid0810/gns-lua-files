-- 2903560's Lua and Manifest Created by Hubcap Manifest
-- Platform 8
-- Created: March 29, 2026 at 04:04:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2903560, 1, "6490276503848e62a669b16527b0f1475353839901658bc4d7d144a900bcfe69") -- Platform 8
-- MAIN APP DEPOTS
addappid(2903561, 1, "b7881ef4fccda50067ecd42b37a78456d65363f912a0e94cdf84aa05249b67c3") -- Depot 2903561
setManifestid(2903561, "543450399353804950", 1595430376)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)