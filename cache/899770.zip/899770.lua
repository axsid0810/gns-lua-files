-- 899770's Lua and Manifest Created by Hubcap Manifest
-- Last Epoch
-- Created: May 13, 2026 at 12:09:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 31

-- MAIN APPLICATION
addappid(899770, 1, "7067141c355e1f204ba26265c813da0307742bfbdb077d43153a4b4650b4ba76") -- Last Epoch
-- MAIN APP DEPOTS
addappid(899771, 1, "c2e2078a202c652383c595f86a2661e2c0bf747e070ab942890d958aaecb06d9") -- LE Windows
setManifestid(899771, "7042486888779928584", 36276871349)
-- DLCS WITH DEDICATED DEPOTS
-- Last Epoch - Digital Sound Track (AppID: 2768220)
addappid(2768220)
addappid(2768220, 1, "d15b6fec494066fa9ecfbd19f48042c6db781c7db9336752a23b066d645c1607") -- Last Epoch - Digital Sound Track - Depot 2768220
setManifestid(2768220, "2377843085109067424", 895650474)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2303580) -- Last Epoch - Eternal Traveler Supporter Pack
addappid(2303581) -- Last Epoch - Eternal Templar Supporter Pack
addappid(2303582) -- Last Epoch - Eternal Vanquisher Supporter Pack
addappid(2303583) -- Last Epoch - Eternal Legend Supporter Pack
addappid(2744750) -- Last Epoch - Golden Guppy the Baby Chronowyrm
addappid(2744760) -- Last Epoch - 100 Epoch Points (EP)
addappid(2744770) -- Last Epoch - Adolescent Chronowyrm
addappid(2744780) -- Last Epoch - Fallen Ronin
addappid(2744790) -- Last Epoch - Fireflys Refuge
addappid(2744800) -- Last Epoch - Temporal Guardian
addappid(2744810) -- Last Epoch - Twilight Fox
addappid(2744820) -- Last Epoch - Adult Chronowyrm
addappid(2744830) -- Last Epoch - Celestial Way
addappid(2768230) -- Last Epoch - 50 Epoch Points (EP)
addappid(3080440) -- Last Epoch - Abyssal Traveler Supporter Pack
addappid(3080450) -- Last Epoch - Abyssal Templar Supporter Pack
addappid(3080460) -- Last Epoch - Abyssal Vanquisher Supporter Pack
addappid(3080470) -- Last Epoch - Abyssal Legend Supporter Pack
addappid(3512570) -- Last Epoch - Woven Traveler Supporter Pack
addappid(3512580) -- Last Epoch - Woven Templar Supporter Pack
addappid(3512590) -- Last Epoch - Woven Vanquisher Supporter Pack
addappid(3512600) -- Last Epoch - Woven Legend Supporter Pack
addappid(3865720) -- Last Epoch - Primal Traveler Supporter Pack
addappid(3865730) -- Last Epoch - Primal Templar Supporter Pack
addappid(3865740) -- Last Epoch - Primal Vanquisher Supporter Pack
addappid(3865750) -- Last Epoch - Primal Legend Supporter Pack
addappid(4322970) -- Last Epoch - Fractured Traveler Supporter Pack
addappid(4322980) -- Last Epoch - Fractured Templar Supporter Pack
addappid(4322990) -- Last Epoch - Fractured Vanquisher Supporter Pack
addappid(4323000) -- Last Epoch - Fractured Legend Supporter Pack