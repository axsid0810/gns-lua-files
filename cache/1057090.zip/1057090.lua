-- 1057090's Lua and Manifest Created by Hubcap Manifest
-- Ori and the Will of the Wisps
-- Created: September 30, 2025 at 05:11:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1057090) -- Ori and the Will of the Wisps
-- MAIN APP DEPOTS
addappid(1057091, 1, "f2095fc72f59315e1315914a5a349e23488d3e48897b16bc733e6cad2ca059a1") -- Patagonia Content
setManifestid(1057091, "1069298212161557632", 12149438740)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)