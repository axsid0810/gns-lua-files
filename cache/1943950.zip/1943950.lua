-- 1943950's Lua and Manifest Created by Hubcap Manifest
-- Escape the Backrooms
-- Created: June 15, 2026 at 07:02:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1943950, 1, "67e88d1bb91401a675aea9580536fdc41e7f9ffe2d2f24dbb9720ebd74f6bb16") -- Escape the Backrooms
-- MAIN APP DEPOTS
addappid(1943951, 1, "7930e28c405ca5c1ab83cb57ad8f6a96adc288960b0e60acbc764ff1154d8bb3") -- Depot 1943951
setManifestid(1943951, "740479633715325867", 27699716282)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)