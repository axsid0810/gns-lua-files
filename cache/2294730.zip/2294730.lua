-- 2294730's Lua and Manifest Created by Hubcap Manifest
-- MILFs of Sunville - Season 2
-- Created: July 10, 2026 at 23:20:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2294730, 1, "3c886f9d3fda7685aa816865c7ac0e90929078f8a7c8dee80c825a81d4d47316") -- MILFs of Sunville - Season 2
-- MAIN APP DEPOTS
addappid(2294731, 1, "e585d86495aaf9d25291a15b2389af5ecc83d2616f07fe22d221b268e00ec84e") -- Depot 2294731
setManifestid(2294731, "6635310079206829940", 11863695689)
addappid(2294732, 1, "46926fd50e5800a83f0e900ef12cf661b74e2cd269b941033d65d11731c698e5") -- Depot 2294732
setManifestid(2294732, "770672789705798636", 11775951381)
addappid(2294733, 1, "c8ad83bd5e475f20c52f9adcabbbb5510b52f3cab6847fa1eb2f051fdcad46d2") -- Depot 2294733
setManifestid(2294733, "428320219598939254", 11863695689)
-- DLCS WITH DEDICATED DEPOTS
-- MILFs of Sunville - Season 2 Extra Content (AppID: 3987020)
addappid(3987020)
addappid(3987020, 1, "0c522b7dec07d07db0f754d341439a4b059d7ef3d5165131b005f13e6b1cff6c") -- MILFs of Sunville - Season 2 Extra Content - Depot 3987020
setManifestid(3987020, "6227301000665625215", 658620151)
-- addappid(3987021, 1, "MISSING_KEY") -- MILFs of Sunville - Season 2 Extra Content - Depot 3987021 (no key available)
-- addappid(3987022, 1, "MISSING_KEY") -- MILFs of Sunville - Season 2 Extra Content - Depot 3987022 (no key available)