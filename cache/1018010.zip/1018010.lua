-- 1018010's Lua and Manifest Created by Hubcap Manifest
-- Castlevania Anniversary Collection
-- Created: September 29, 2025 at 03:29:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1018010) -- Castlevania Anniversary Collection
-- MAIN APP DEPOTS
addappid(1018011, 1, "f369e7edc8f5b3ceafff6f9366fbf8d1b5f3ce2d064444f966315ff1b0cbdf4b") -- Castlevania Anniversary Collection ENG
setManifestid(1018011, "4125351698578021580", 811053866)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)