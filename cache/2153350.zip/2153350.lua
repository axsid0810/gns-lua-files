-- 2153350's Lua and Manifest Created by Hubcap Manifest
-- Brothers: A Tale of Two Sons Remake
-- Created: September 29, 2025 at 02:21:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2153350) -- Brothers: A Tale of Two Sons Remake
-- MAIN APP DEPOTS
addappid(2153351, 1, "997da40415d881772fa4957ed930334f03fd3e2c3c3b6d5d832caadaba4d0d88") -- Depot 2153351
setManifestid(2153351, "5661410614045627278", 29543247619)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)