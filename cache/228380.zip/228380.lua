-- 228380's Lua and Manifest Created by Hubcap Manifest
-- Wreckfest
-- Created: October 01, 2025 at 08:14:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 19
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(228380, 1, "5d35e57cc36484705a0e702fb4b023fbd1d816159b441c09a49be8c489087cbe") -- Wreckfest
-- MAIN APP DEPOTS
addappid(228381, 1, "0271ea41a7c1be1719138e5a1f9b0693cb88c1e55c6422b47179d559b95c9440") -- Next Car Game Public Content
setManifestid(228381, "3017425792384820539", 34162267810)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Wreckfest Soundtrack (AppID: 272880)
addappid(272880)
addappid(272880, 1, "744ba266e5b45c9877051c47ee9d2fb3e9f50559bce63d86ff7ee7fcb6cdd196") -- Wreckfest Soundtrack - Wreckfest Soundtrack (272880) Depot
setManifestid(272880, "8165984606867483938", 243865577)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(272830) -- Wreckfest Wallpaper
addappid(272910) -- Wreckfest Exclusive Car
addappid(884740) -- Wreckfest Team Bugbear Paint Job
addappid(893310) -- Wreckfest - Season Pass Car
addtoken(893310, "4474048546407150732")
addappid(1131170) -- Wreckfest - Season Pass 1
addappid(1135430) -- Wreckfest - Retro Rammers Car Pack
addappid(1135431) -- Wreckfest - Backwoods Bangers Car Pack
addappid(1135432) -- Wreckfest - Modified Monsters Car Pack
addappid(1135433) -- Wreckfest - Rusty Rats Car Pack
addappid(1135434) -- Wreckfest - American All-Stars Car Pack
addappid(1135435) -- Wreckfest - Banger Racing Car Pack
addappid(1135436) -- Wreckfest - Getaway Car Pack
addappid(1135437) -- Wreckfest - Goofy Roofs Pack
addappid(1135438) -- Wreckfest - Steel  Wheels Pack
addappid(1399410) -- Wreckfest - Racing Heroes Car Pack
addappid(1399411) -- Wreckfest - Reckless Car Pack
addappid(1399412) -- Wreckfest - Off-Road Car Pack
addappid(1413450) -- Wreckfest - Season Pass 2