-- 8930's Lua and Manifest Created by Hubcap Manifest
-- Sid Meier's Civilization V
-- Created: September 30, 2025 at 14:06:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 88
-- Total DLCs: 34
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(8930) -- Sid Meier's Civilization V
-- MAIN APP DEPOTS
addappid(8931, 1, "0079942a12cda83cd1e9b92758b7e980515a316cdd32c2b334c85491ee111d1a") -- CivilizationV-BaseContent
setManifestid(8931, "2566665288019907120", 4748489152)
addappid(8932, 1, "326c0f52bb5d88f054184b46f869c225aa77a87c2bf8f1721a8497f56800bb2e") -- CivilizationV-EXE
setManifestid(8932, "1500173799562188053", 46288384)
addappid(8933, 1, "a44a84fd62d99e54b70c0152c6b1f93f9ff2270f3c6ffbe4f6940b9b3130b3b4") -- CivilizationV-Base2
setManifestid(8933, "3972654303751865124", 13870778)
addappid(8934, 1, "f99dc76031a5de234954dc8fc6a71b7a61fb666122ef4ba3ea4f5a077f0d778d") -- Sid Meier's Civilization V French
setManifestid(8934, "2946233043878990808", 14526210)
addappid(8935, 1, "6b384be01fba92465920da359d173095a8cef50f5473299c7016718c925f154f") -- Sid Meier's Civilization V Italian
setManifestid(8935, "3389724086417641770", 14424972)
addappid(8936, 1, "e595d6e053a21da0e878fa22b1725488fb0db0fb3874caf2421686b6ba949bb9") -- Sid Meier's Civilization V German
setManifestid(8936, "2308820381862011329", 14326233)
addappid(8937, 1, "6c64cafaed3cbcb05999b6a237b08f1ff7a90a430fed35ec81dc4f0e921940a6") -- Sid Meier's Civilization V Spanish
setManifestid(8937, "4033290353420267053", 14326452)
addappid(8938, 1, "66ff984e2d2886c254c2d4e734efd00b8b537868a4952070711737b96a243528") -- Sid Meier's Civilization V Japanese
setManifestid(8938, "5647067247059726214", 118942088)
addappid(8939, 1, "ac421799288b0cf247487d02ec3c4e274f914f8b97eed7d9b5114ca54a062def") -- Sid Meier's Civilization V Russian
setManifestid(8939, "7703334065753503678", 181168902)
addappid(16869, 1, "555038b725296d2d8a0573bbd717499d3ba83f1f7589993213703822a9d9ae67") -- Civ V Soundtrack
setManifestid(16869, "1752512657270051788", 304609065)
addappid(16880, 1, "a7cb41efdf985a16c5da69c323afcbbf7a7f3b8dd1e9b9d726261d743d8e3d9a") -- Sid Meier's Civilization V Polish
setManifestid(16880, "5044248757410991860", 169495668)
addappid(16881, 1, "71984781f57c6299996c8f355c5a45d6a1ebe1d4904ebc54b4d46a79dac2d2a4") -- Sid Meier's Civilization V Koreana
setManifestid(16881, "22543732107394664", 127133934)
addappid(34481, 1, "7f14fd69da9fbdcd27560ce57746e561ef82609cdfae640941f2d2a7a4f2036c") -- CivilizationVMac-BaseContent
setManifestid(34481, "2388328581570924122", 4409265287)
addappid(34482, 1, "a78818b18d8794c108f2729ec06488b0e43d91b102235460fdd4a02ae4d9e578") -- CivilizationVMac-APP
setManifestid(34482, "3383990245568193610", 31049582)
addappid(34483, 1, "9a14b430f886c508474ed71dcf5816eb63bc1815ebbf5f20a1cd51958b339d70") -- CivilizationVMac-Base2
setManifestid(34483, "6147563888555940246", 2406648)
addappid(34484, 1, "5b8a18c3cc5651cd1f56f2b56f093154b90f846098c1e16eb5b88ec7045d3386") -- Sid Meier's Civilization V French Mac
setManifestid(34484, "4658102751176592797", 2885903)
addappid(34485, 1, "c8fe376703ad4db756073a8994f237f77071f6da2606d4b97dd90ec15d6b441c") -- Sid Meier's Civilization V Italian Mac
setManifestid(34485, "4438220497198045696", 2766799)
addappid(34486, 1, "d3a76948289a179cb7365b3e695254d07fa06e51b4fcbdd004e3aad7ecd14ab4") -- Sid Meier's Civilization V German Mac
setManifestid(34486, "8224938089841149961", 2747377)
addappid(34487, 1, "88420a954919896bbe00b553e58fdf13ddac20c061cbe7ee082b62cfb7356833") -- Sid Meier's Civilization V Spanish Mac
setManifestid(34487, "1931585391225711903", 2775357)
addappid(235586, 1, "b7aefa32e39e5d20867656983d89c52c41edaeb77059f15a826386e99edb56d1") -- Sid Meier's Civilization V Chinese
setManifestid(235586, "8046246580151360303", 2367305)
addappid(282300, 1, "f776a44446b83021ee6bd55715270a2bde25bd1802296ac0e746d437225d3a5b") -- Civ5 BaseContent Linux
setManifestid(282300, "6389225738581842747", 4409331513)
addappid(282301, 1, "fc52300b632a58482798c8df297731e3e08f13c7e93838540179a8630fa6652c") -- Civ5 Executable Linux
setManifestid(282301, "5267780777055206315", 86932455)
addappid(282302, 1, "4227337599a5418868a0d0c7a2c7c3f1a9209cffc34abdee7fe90df7a5bb2002") -- Civ5 BaseContent2 Linux
setManifestid(282302, "1982156094632779925", 2406775)
addappid(282322, 1, "5c222596bfe2cc9278fe88fc1fd6f98ed1c865ba9b7cbabce7ea14797fc566cf") -- Sid Meier's Civilization V French Linux
setManifestid(282322, "908149319756665729", 2886029)
addappid(282323, 1, "9aa5d97373d86b4550e874cd620b3ee5dc1339f67068641a26176e2e7a277c40") -- Sid Meier's Civilization V Italian Linux
setManifestid(282323, "153737629251596019", 2766799)
addappid(282324, 1, "386976e1180f2b12374c4a5da0690f3087bfa4aa75c919e0dc5c6ac9529c365f") -- Sid Meier's Civilization V German Linux
setManifestid(282324, "1020510729793183846", 2747511)
addappid(282325, 1, "2185c8198fd667b08dd5841b7a833b07e9987d23b6c4213f7e4bece0a9e59ac5") -- Sid Meier's Civilization V Spanish Linux
setManifestid(282325, "1571330514338509481", 2775357)
addappid(16873, 1, "e07dcede3f04e94757e44cfa41b49a5d788975fc9b5c4f23b08c61b2275823b4") -- Launcher Test
setManifestid(16873, "4642352200449048625", 175716202)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Civilization V - Cradle of Civilization Map Pack Mediterranean (AppID: 16860)
addappid(16860)
addappid(16860, 1, "fbb6bf23193d2b6ab9a63fc510ee21bc8d13df2fc950e35b4a932938412ec283") -- Civilization V - Cradle of Civilization Map Pack Mediterranean - Cradle of Civilization - Mediterranean
setManifestid(16860, "170439753274339292", 114204)
addappid(282314, 1, "0dea9192fb71fe64057af224470a45e81c2b348fd8bc44b24f4cac9ea79246cf") -- Civilization V - Cradle of Civilization Map Pack Mediterranean - Cradle of Civilization - Mediterranean Linux
setManifestid(282314, "239834820357537853", 113884)
-- Civilization V - Cradle of Civilization Map Pack Asia (AppID: 16861)
addappid(16861)
addappid(16861, 1, "c06952ed776ec16cf5e32c400a87f9a4047764f4ada7ed548c98523c206db9ca") -- Civilization V - Cradle of Civilization Map Pack Asia - Cradle of Civilization - Asia
setManifestid(16861, "445702972723661441", 112398)
addappid(282315, 1, "013d1923b98c34e35488e17bed32da4c4884414248d65ab90e971f7d78d9f40a") -- Civilization V - Cradle of Civilization Map Pack Asia - Cradle of Civilization - Asia Linux
setManifestid(282315, "528022330178821064", 112067)
-- Civilization V - Cradle of Civilization Map Pack Americas  (AppID: 16862)
addappid(16862)
addappid(16862, 1, "56e895f91375cac9db698748aa249efc59cda73bb4da8938ce903f49800044d6") -- Civilization V - Cradle of Civilization Map Pack Americas  - Cradle of Civilization - Americas
setManifestid(16862, "637396967391839303", 62154)
addappid(282316, 1, "9e648e55cfe10a933cb4c33847eb16f507367eab4f7631dc32e0560a41a734f9") -- Civilization V - Cradle of Civilization Map Pack Americas  - Cradle of Civilization - Americas Linux
setManifestid(282316, "35840779178982127", 61822)
-- Civilization V - Cradle of Civilization Map Pack Mesopotamia (AppID: 16863)
addappid(16863)
addappid(16863, 1, "dad5edf8496b62949c0deb757c03aff640b426a755b0e8022e404a6d03a3bf3f") -- Civilization V - Cradle of Civilization Map Pack Mesopotamia - Cradle of Civilization - Mesopotamia
setManifestid(16863, "422432513321351052", 71761)
addappid(282317, 1, "77ec74ee15f9f4580124485d8e6b3deb4e2185804ffd366a6d154d937272b46b") -- Civilization V - Cradle of Civilization Map Pack Mesopotamia - Cradle of Civilization - Mesopotamia Linux
setManifestid(282317, "240675552619007338", 71390)
-- Civilization V - Digital Deluxe Content (AppID: 16864)
addappid(16864)
addappid(16864, 1, "48fa4386534d96223ddd33944f4b9f35c92b9ddb6f45906ead9753ac900506ff") -- Civilization V - Digital Deluxe Content - Civ V Digital Deluxe Content
setManifestid(16864, "2538230894969058078", 961341169)
addappid(282309, 1, "296f5f4785411f6f29536727791f65bb3f3c237ae472b7bf6528164963eeebd1") -- Civilization V - Digital Deluxe Content - Civ V Digital Deluxe Content Linux
setManifestid(282309, "323705303891630438", 364083216)
-- Civilization V - Civ and Scenario Pack Mongols (Genghis Khan) (AppID: 16865)
addappid(16865)
addappid(16865, 1, "002986f1cafe94473d8cbfe746b3d76ec413bf8f0981528c766f189711d14488") -- Civilization V - Civ and Scenario Pack Mongols (Genghis Khan) - Civ and Scenario Pack - Mongols, Genghis Khan
setManifestid(16865, "5645302925182191203", 56442826)
addappid(282303, 1, "ab6a6b721bca7b505a403a7c7de1b581f8c0e6ccd32a666a44e0ed837442288e") -- Civilization V - Civ and Scenario Pack Mongols (Genghis Khan) - Civ and Scenario Pack - Mongols, Genghis Khan Linux
setManifestid(282303, "120079972373717717", 52157855)
-- Civilization V - Explorers Map Pack (AppID: 16866)
addappid(16866)
addappid(16866, 1, "cddf62220bd6b9ba9434707044c2935331bb0d4718146f226e1d9f2a5430679e") -- Civilization V - Explorers Map Pack - Multiplayer Map Pack 1
setManifestid(16866, "9130183576332888211", 624396)
addappid(282311, 1, "c43f21dacdd938964ee71048fb241481da31a0cffcc937e5d25535693283dab2") -- Civilization V - Explorers Map Pack - Multiplayer Map Pack 1 Linux
setManifestid(282311, "48089012925950836", 619204)
-- Civilization V - Civ and Scenario Double Pack Spain and Inca  (AppID: 16867)
addappid(16867)
addappid(16867, 1, "1e5a99f35403d68117b867f808c84df158d4f6453385d5f8c0fe8f4bcd680673") -- Civilization V - Civ and Scenario Double Pack Spain and Inca  - Double Civ and Scenario Pack - Spain, Isabella and Inca, Pachacuti
setManifestid(16867, "6302478183155461615", 148687059)
addappid(282304, 1, "ccfd18436153659019577a20f97a06541b2b28188e589116946d4c20739e0315") -- Civilization V - Civ and Scenario Double Pack Spain and Inca  - Double Civ and Scenario Pack - Spain, Isabella and Inca, Pachacuti Linux
setManifestid(282304, "2643485439959527777", 138392918)
-- Civilization V - Babylon (Nebuchadnezzar II) (AppID: 16868)
addappid(16868)
addappid(16868, 1, "35ccc657e374faf5a8f88a6bfbd9defb73078c3bf1c5c1360498178a35a8792a") -- Civilization V - Babylon (Nebuchadnezzar II) - Civ Pack - Babylon Nebuchadnezzar II
setManifestid(16868, "4675090471310464815", 59827813)
addappid(282310, 1, "2b011c471f54c30c25a8988d69a1a0c1543eb821c2d17341a4de1fc609398b9c") -- Civilization V - Babylon (Nebuchadnezzar II) - Civ Pack - Babylon Nebuchadnezzar II Linux
setManifestid(282310, "65932600989304912", 57157197)
-- Sid Meiers Civilization V Gods and Kings (AppID: 16870)
addappid(16870)
addappid(16870, 1, "3ac7eab617c30df6e25b4684483be548cd8d5c6752e3b208d6a8cb7ef2deff37") -- Sid Meiers Civilization V Gods and Kings - Expansion - Gods and Kings Content
setManifestid(16870, "7341463768253426297", 1182157626)
addappid(16871, 1, "56ec0aa4e2db20db9a72cff513170723b9d65f9156eb3ed3bf195726dd6eda19") -- Sid Meiers Civilization V Gods and Kings - Expansion - Gods and Kings - EXE
setManifestid(16871, "679307463584834613", 3495424)
addappid(210451, 1, "b311c1c530d9a948499ed578378158368f444514a3a7a01ed92670be2467a467") -- Sid Meiers Civilization V Gods and Kings - Expansion - Gods and Kings - EXE Mac
setManifestid(210451, "2218334048647977308", 5136096)
addappid(282318, 1, "9dcb3e5db2df4c08ff43579c3be75b5b459422ce83595e00d1fb292796efa65e") -- Sid Meiers Civilization V Gods and Kings - Expansion - Gods and Kings Content Linux
setManifestid(282318, "779329514913021136", 1194225446)
-- Cradle of Civilization - Mediterranean (Mac) (AppID: 34490)
addappid(34490)
addappid(34490, 1, "d232419a0bb404164394630ac98c14554823ee3d0bc64495a2abad1bb76bddc7") -- Cradle of Civilization - Mediterranean (Mac) - Cradle of Civilization - Mediterranean Mac
setManifestid(34490, "1432009369858768609", 113884)
-- Cradle of Civilization - Asia (Mac) (AppID: 34491)
addappid(34491)
addappid(34491, 1, "5b6af7c018c10a56e75f754e133fdd81572c6c13f1e9b3139afe375029a7bc2f") -- Cradle of Civilization - Asia (Mac) - Cradle of Civilization - Asia Mac
setManifestid(34491, "5549253660914644022", 112067)
-- Cradle of Civilization - Americas (Mac) (AppID: 34492)
addappid(34492)
addappid(34492, 1, "6b391457ddad535564979495bac2dc03ea78210b114a68311dd1e83565e90daf") -- Cradle of Civilization - Americas (Mac) - Cradle of Civilization - Americas Mac
setManifestid(34492, "1011038399085398327", 61822)
-- Cradle of Civilization - Mesopotamia (Mac) (AppID: 34493)
addappid(34493)
addappid(34493, 1, "763caee4d195de8fec9a8d9f0bd3d4643b67100fca9d8cec3a3eba00b755799d") -- Cradle of Civilization - Mesopotamia (Mac) - Cradle of Civilization - Mesopotamia Mac
setManifestid(34493, "772888426837994951", 71390)
-- Civ V Digital Deluxe Content (Mac) (AppID: 34494)
addappid(34494)
addappid(34494, 1, "eb6cf5a589a9f5ad5d4bb2e2bfe16b98adf956e4c52e1278fe2a4823ba187e6a") -- Civ V Digital Deluxe Content (Mac) - Civ V Digital Deluxe Content Mac
setManifestid(34494, "8944973956243765589", 57122444)
-- Civ and Scenario Pack - Mongols, Genghis Khan (Mac) (AppID: 34495)
addappid(34495)
addappid(34495, 1, "b32db2662362a2194cf0d520c88e5201e589ba1dcd87d919a1e5b882e377b455") -- Civ and Scenario Pack - Mongols, Genghis Khan (Mac) - Civ and Scenario Pack - Mongols, Genghis Khan Mac
setManifestid(34495, "8400126890555297678", 52099152)
-- Civilization V Explorers Map Pack Mac (AppID: 34496)
addappid(34496)
addappid(34496, 1, "940776100de6af7b7d2e23a398c98275deb9a5c30bf631c71b74a44fa2db6ecd") -- Civilization V Explorers Map Pack Mac - Multiplayer Map Pack 1 Mac
setManifestid(34496, "1043411477648563748", 619204)
-- Double Civ and Scenario Pack - Spain, Isabella and Inca, Pachacuti (Mac) (AppID: 34497)
addappid(34497)
addappid(34497, 1, "c78a87e9bc733041c67579f966a7b6b65be8c2f41913f2112b272d1144c1faba") -- Double Civ and Scenario Pack - Spain, Isabella and Inca, Pachacuti (Mac) - Double Civ and Scenario Pack - Spain, Isabella and Inca, Pachacuti Mac
setManifestid(34497, "691699797817605517", 138265941)
-- Civ Pack - Babylon Nebuchadnezzar II (Mac) (AppID: 34498)
addappid(34498)
addappid(34498, 1, "330a1d7be2c91dc1e53fc97b1d9e291443b0e779ce07adf8638b17515725cadc") -- Civ Pack - Babylon Nebuchadnezzar II (Mac) - Civ Pack - Babylon Nebuchadnezzar II Mac
setManifestid(34498, "4515013559133450082", 57122444)
-- Civilization V - Civ and Scenario Pack Polynesia (AppID: 99610)
addappid(99610)
addappid(99610, 1, "b47778586e61f8cb53073c0b7549a44e8e7abbdead1f22b848af31804a74e94c") -- Civilization V - Civ and Scenario Pack Polynesia - Civ and Scenario Pack - Polynesia
setManifestid(99610, "1838032016530508956", 69929093)
addappid(282305, 1, "ccc310d35462c549dcf4327d6a1cb1b51151917a3e3543a61df41020581e8db8") -- Civilization V - Civ and Scenario Pack Polynesia - Civ and Scenario Pack - Polynesia Linux
setManifestid(282305, "313489635234814162", 63428227)
-- Civilization V - Civ and Scenario Pack Denmark (The Vikings) (AppID: 99611)
addappid(99611)
addappid(99611, 1, "3f54af8ef5555aa374acef7a58b1927708cc90b6f4bce659d5d25fbdd0eb2378") -- Civilization V - Civ and Scenario Pack Denmark (The Vikings) - Civ and Scenario Pack - Denmark
setManifestid(99611, "8743623907963094913", 88528740)
addappid(282306, 1, "5a4edac4e9965c20b390c8349e011b2df86c93c65ba063afdb8a076da1883129") -- Civilization V - Civ and Scenario Pack Denmark (The Vikings) - Civ and Scenario Pack - Denmark Linux
setManifestid(282306, "158481880894805329", 83443925)
-- Civilization V - Civ and Scenario Pack Korea (AppID: 99612)
addappid(99612)
addappid(99612, 1, "94988a61fc8e74758b3232215d0f4cbbc8dc149b11a112e12d79ac5c2e140da9") -- Civilization V - Civ and Scenario Pack Korea - Civ and Scenario Pack - Korea
setManifestid(99612, "7101460566003448004", 71252194)
addappid(282307, 1, "d99cd17b47cc00c4555db40951d5176fa108963f6323aba15972f3b60d97334d") -- Civilization V - Civ and Scenario Pack Korea - Civ and Scenario Pack - Korea Linux
setManifestid(282307, "323507258050599970", 66744815)
-- Civilization V - Scenario Pack Wonders of the Ancient World (AppID: 99613)
addappid(99613)
addappid(99613, 1, "c28cc88a4caa2c3860850f743b441666703901b353d6ff2561ba2a7241284026") -- Civilization V - Scenario Pack Wonders of the Ancient World - Scenario Pack - Ancient Wonders
setManifestid(99613, "3521034378861237317", 39615362)
addappid(282308, 1, "a8c16140f800ce1bf1aa1484344003a2d7b2a639e517c78318471391b7d88bcb") -- Civilization V - Scenario Pack Wonders of the Ancient World - Scenario Pack - Ancient Wonders Linux
setManifestid(282308, "261355857334255286", 32886800)
-- Civ and Scenario Pack - Polynesia (Mac) (AppID: 102000)
addappid(102000)
addappid(102000, 1, "ef25beb1c35900c6d63238ba34db19a5042ff1587b0aa1bb60c4eed979c753f1") -- Civ and Scenario Pack - Polynesia (Mac) - Civ and Scenario Pack - Polynesia Mac
setManifestid(102000, "1081144846188256261", 63314800)
-- Civ and Scenario Pack - Denmark Mac (AppID: 102001)
addappid(102001)
addappid(102001, 1, "94d831cd59c9f7ef04959032712dd9b5780bb2841ea538828cb77f63567e4cb3") -- Civ and Scenario Pack - Denmark Mac - Civ and Scenario Pack - Denmark Mac
setManifestid(102001, "1696513202575344551", 83368103)
-- CivilizationV-DLC Korea Mac (AppID: 102002)
addappid(102002)
addappid(102002, 1, "5f95efe40df84de0a2177f7e244ac755396fa334622345933bff08fc71c1cd00") -- CivilizationV-DLC Korea Mac - Civ and Scenario Pack - Korea Mac
setManifestid(102002, "1624213597315523491", 66689472)
-- CivilizationV-DLC Ancient Wonders Mac (AppID: 102003)
addappid(102003)
addappid(102003, 1, "23eae231c1842cdfb8af08859a33216e1262e7b79b481710fa7432a8b587e679") -- CivilizationV-DLC Ancient Wonders Mac - Scenario Pack - Ancient Wonders Mac
setManifestid(102003, "9171523434165050508", 32841636)
-- Civilization V Gods  Kings Mac (AppID: 210450)
addappid(210450)
addappid(210450, 1, "ceecd6b2b7d7d12dc819ed2a17378ec5187ad7e756d8d529f962ef78846c79b5") -- Civilization V Gods  Kings Mac - Expansion - Gods and Kings Content Mac
setManifestid(210450, "2726832630160098374", 1193094447)
-- Sid Meiers Civilization V Brave New World (AppID: 235580)
addappid(235580)
addappid(235580, 1, "e26f125ff4f1bda9e87ae3709f4362078be1631cc4dc7ceec1a35cdc545f47a7") -- Sid Meiers Civilization V Brave New World - Expansion - Brave New World Content
setManifestid(235580, "3944995621630953134", 1324631467)
addappid(235581, 1, "2ae7b563403bed273b31191ec75e6fe2498c325f52cc8d7852bff84f5c4d64c4") -- Sid Meiers Civilization V Brave New World - Expansion - Brave New World - EXE
setManifestid(235581, "1005885633494040832", 4061696)
addappid(235582, 1, "b018f25b4d320340ed84c1ceca3193a6336ee76fe13fd1cab4d7c1fc2466378c") -- Sid Meiers Civilization V Brave New World - Expansion - Brave New World Content Mac
setManifestid(235582, "6647928174275513914", 1345880447)
addappid(235583, 1, "ed2d63e14ba20b85556a5352b24a65264b610536b4ab065b6a86f253215b6846") -- Sid Meiers Civilization V Brave New World - Expansion - Brave New World - EXE Mac
setManifestid(235583, "8678468257144451924", 5891888)
addappid(282320, 1, "a27c77ab9459723a10ada37efcea35ea1847598b89fd7c3d4098ceed96e14396") -- Sid Meiers Civilization V Brave New World - Expansion - Brave New World Content Linux
setManifestid(282320, "2505833101960255592", 1347427829)
-- Civilization V - Scrambled Continents Map Pack (AppID: 235584)
addappid(235584)
addappid(235584, 1, "7d2b94d456604e3925f6611404be028e7789ac0be2f38937076de7f1a7b6f212") -- Civilization V - Scrambled Continents Map Pack - Changing Worlds Map Pack: Continents (235584) Depot
setManifestid(235584, "3388619487526832290", 1882619)
addappid(235587, 1, "9805f8a2124d2e53b850218e01953c7435eb51db3e5fd87a8d313dd3c09df7c4") -- Civilization V - Scrambled Continents Map Pack - Changing Worlds Map Pack: Continents Depot Mac
setManifestid(235587, "3384783463780376329", 1877324)
addappid(282312, 1, "bb36b290270f30b28e1754f8ad09f9561b9f6aa5fccd1251deeb82dd786878c3") -- Civilization V - Scrambled Continents Map Pack - Changing Worlds Map Pack: Continents Depot Linux
setManifestid(282312, "700181433679681602", 1877324)
-- Civilization V - Scrambled Nations Map Pack (AppID: 235585)
addappid(235585)
addappid(235585, 1, "ab843826adc2553d42b1e66d8ff0461cfebddb4279d66db1d3672af051ac633c") -- Civilization V - Scrambled Nations Map Pack - Changing Worlds Map Pack: Nations (235585) Depot
setManifestid(235585, "9089048715899510052", 1961967)
addappid(235588, 1, "09589fdeea15835dec31144b54d1d19ebc4dc5a12c00246e0f24870db968633b") -- Civilization V - Scrambled Nations Map Pack - Changing Worlds Map Pack: Nations Depot Mac
setManifestid(235588, "806796720756814996", 1956244)
addappid(282313, 1, "134251e26945138caf6ab87782444a25dcf26be1cbb1501472fc7fc1501499d0") -- Civilization V - Scrambled Nations Map Pack - Changing Worlds Map Pack: Nations Depot Linux
setManifestid(282313, "95041807267491356", 1956244)
-- Civilization V - Scenario Pack Conquest of the New World (AppID: 266720)
addappid(266720)
addappid(266720, 1, "abdaeab1d642af59b9b4c5c60187fcc7d69fbce9d097cfd9f5183b8c84140a77") -- Civilization V - Scenario Pack Conquest of the New World - Conquest of the New World Deluxe Scenario
setManifestid(266720, "9089176099445456904", 236271323)
addappid(266721, 1, "6b93f3d0658af88483445875d2371e7421bb8c76d3cb4dae56223c0c2e812530") -- Civilization V - Scenario Pack Conquest of the New World - Conquest of the New World Deluxe Mac
setManifestid(266721, "6359824074045590534", 224862415)
addappid(282326, 1, "1c168064467a3d73ac4f7c68364b1d45fbc5ae19d93a67630d96cba9fd559454") -- Civilization V - Scenario Pack Conquest of the New World - Conquest of the New World Deluxe Linux
setManifestid(282326, "7705606035427097533", 225872379)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(16872) -- Civ V Expansion - Gods and Kings
addappid(16879) -- Civ V Gods and Kings Pre-Order