-- 997070's Lua and Manifest Created by Hubcap Manifest
-- Marvel's Avengers - The Definitive Edition
-- Created: September 29, 2025 at 23:49:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 18
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(997070) -- Marvel's Avengers - The Definitive Edition
-- MAIN APP DEPOTS
addappid(997071, 1, "2bbd8910dd110583a6e39ff41e99ea95f5201599ce7e2ef81f86ac1b9db1bc4e") -- Game Content
setManifestid(997071, "8053825048164294578", 97729324147)
addappid(997072, 1, "d161f2895db8915a566e7a7529706c135f2af468c35dc49d026be4d69c4bd6e1") -- Executables
setManifestid(997072, "7372463490027595797", 319632677)
addappid(997076, 1, "e7528fcf5f05436a5414482f8d51a3d9d0b21e85688ecf93185ca4200fcaf470") -- Game Content English
setManifestid(997076, "6062367728168537218", 3559569575)
addappid(997077, 1, "5dbfda03265b5d79d632c7ea02050fce65e3a94baf890b669129fa7266dbb907") -- Game Content French
setManifestid(997077, "1175162434571743379", 3497533607)
addappid(997078, 1, "8e70d9772e5c23007a9a928da56e61d6979a2ae29960bc11896860407ed457e6") -- Game Content German
setManifestid(997078, "3272191448846488929", 3668089063)
addappid(997079, 1, "27f3ca41bb8266ad854530cb1771be77c2e8bf7131efbc6c4a56db3df616c3dc") -- Game Content Italian
setManifestid(997079, "7464315618070041860", 3620038775)
addappid(1159061, 1, "94e60a75b62790fa5658275a31fddd479b9b8b87ab1e30053822ca458af65914") -- Game Content Spanish
setManifestid(1159061, "6225577583917234196", 3604356871)
addappid(1159062, 1, "f33ce31ca5c03efee36ae5f3543f6dba942449cd9e413d8c5ec45bc845ba0066") -- Game Content Portuguese
setManifestid(1159062, "5358078403326263337", 3684329223)
addappid(1159063, 1, "c597019703148f612ff9df722cb1f8652d93751dc5a1177f42e2e25dfbe4a27b") -- Game Content Polish
setManifestid(1159063, "4443807893247731768", 3665359335)
addappid(1159064, 1, "28b5fadcf3203de49c4393f56994a981df19ed1d348b9eb823baa1612d75edaf") -- Game Content Russian
setManifestid(1159064, "7604540984728168049", 3736227015)
addappid(1159065, 1, "f316bd18e228d40d9e31737e9439cff2ee09bcd6a92c541f5f91e3272f2b2d39") -- Game Content Chinese
setManifestid(1159065, "8865971486030177410", 3647378398)
addappid(1159066, 1, "d0356cb76483e49d5b402e2cd89f3722417ac1a676c45262a4b81ba48e268647") -- Game Content Simple Chinese
setManifestid(1159066, "5653194137509388496", 3647378391)
addappid(1159067, 1, "f6ce250caa053e730c60655c3faa792f4c2ac759768196dbb50ec286ce746c4b") -- Game Content Latam Spanish
setManifestid(1159067, "3895884170544226645", 3607696103)
addappid(1159068, 1, "6ff59658ce4c5db14e6624987a690e886a3d48ac06b904e2d3fa18943759f46c") -- Game Content Arabic
setManifestid(1159068, "6053345184197026079", 3866517463)
addappid(1159069, 1, "448ff880a42d103957ac2623fab6b46bf3661014c0999cb09b084312a4eab193") -- Game Content Japanese
setManifestid(1159069, "4372720346211009346", 3679447143)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Marvels Avengers High Resolution Texture Pack (AppID: 1206130)
addappid(1206130)
addtoken(1206130, "10257142369031692540")
addappid(997075, 1, "962130471843a61b56890ec4b2084462b505ecbbc8e7bb822d9b8f8470c44ff8") -- Marvels Avengers High Resolution Texture Pack - Game Content Ultra Textures
setManifestid(997075, "5718314415369291092", 56566927672)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1159060) -- Marvels Avengers Deluxe Upgrade
addappid(1159080) -- Marvels Avengers Pre-Order Content
addtoken(1159080, "5971100673234105118")
addappid(1664020) -- Marvels Avengers Endgame Edition DLC Pack