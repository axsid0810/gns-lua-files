-- 286690's Lua and Manifest Created by Hubcap Manifest
-- Metro 2033 Redux
-- Created: September 30, 2025 at 00:33:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(286690) -- Metro 2033 Redux
-- MAIN APP DEPOTS
addappid(286691, 1, "9f2bfaf0ab2396150e63cd8b6b38d236d0920a9f71c1a985229eaa30e1cd8236") -- Project Redux Content
setManifestid(286691, "8372779298760126532", 8331140192)
addappid(286692, 1, "fcc52f00eb59255ae34e6033cab93c08fd90afa73ca1e540aa945f7d80c5cda9") -- Project Redux Binaries
setManifestid(286692, "8868237258019440096", 57370606)
addappid(286693, 1, "a717bf4f94b493ea0a156cf0499828cd3846cb1e2ad512ce0b14a9ff63367c5c") -- Metro 2033 Redux Linux
setManifestid(286693, "573334550590408811", 8381570020)
addappid(286694, 1, "3ebbefa9c070b65308bb5b94c5817ed0d74faa04b1d147f778b12012699b749c") -- Metro 2033 Redux Mac
setManifestid(286694, "2284810999135531603", 8378693996)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- PhysX System Software 9.13.1220 (Shared from App 228980)
setManifestid(229032, "3616495131483866412", 41178235)