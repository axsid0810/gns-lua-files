-- 2338770's Lua and Manifest Created by Hubcap Manifest
-- NBA 2K24
-- Created: September 30, 2025 at 03:00:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 22
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2338770) -- NBA 2K24
-- MAIN APP DEPOTS
addappid(2338771, 1, "fccdfbb689cd6d6d8c67f7d748c81e0171e74c1fa072643d2ce27d439a871065") -- Depot 2338771
setManifestid(2338771, "4532142158391756958", 163472296375)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2413250) -- NBA 2K24 Pro Season Pass Season 1
addappid(2413251) -- NBA 2K24 Hall of Fame Pass Season 1
addappid(2413260) -- NBA 2K24 Pro Pass Season 2
addappid(2413261) -- NBA 2K24 Hall of Fame Pass Season 2
addappid(2413262) -- NBA 2K24 Pro Pass Season 3
addappid(2413263) -- NBA 2K24 Hall of Fame Pass Season 3
addappid(2413264) -- NBA 2K24 Pro Pass Season 4
addappid(2413265) -- NBA 2K24 Hall of Fame Pass Season 4
addappid(2413266) -- NBA 2K24 Pro Pass Season 5
addappid(2413267) -- NBA 2K24 Hall of Fame Pass Season 5
addappid(2413268) -- NBA 2K24 Pro Pass Season 6
addappid(2413269) -- NBA 2K24 Hall of Fame Pass Season 6
addappid(2413270) -- NBA 2K24 Pro Pass Season 7
addappid(2413271) -- NBA 2K24 Hall of Fame Pass Season 7
addappid(2413272) -- NBA 2K24 Pro Pass Season 8
addappid(2413273) -- NBA 2K24 Hall of Fame Pass Season 8
addappid(2413274) -- NBA 2K24 Pro Pass Season 9
addappid(2413275) -- NBA 2K24 Hall of Fame Pass Season 9
addappid(2514210) -- NBA 2K24 Pre-Purchase Bonus
addappid(2514220) -- NBA 2K24 Black Mamba Edition Bonus
addappid(2514230) -- NBA 2K24 25th Anniversary Edition Bonus
addappid(2514240) -- NBA 2K24 Summer League Bonus