-- 614570's Lua and Manifest Created by Hubcap Manifest
-- Dishonored®: Death of the Outsider™ 
-- Created: September 29, 2025 at 07:57:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 16
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(614570) -- Dishonored®: Death of the Outsider™ 
-- MAIN APP DEPOTS
addappid(614571, 1, "735416b7fc86523edd08b4952a47f83d9181a649ee2e7e851c7e405ec9a339b2") -- Blackheart-common-exe
setManifestid(614571, "568638818998526532", 382952034)
addappid(614573, 1, "79a629b885cdd849e8ccb584d31fe87bdf7c204f9ba1d72187f4b8d87f86ab72") -- Blackheart Depot-Common-0
setManifestid(614573, "7437879288641533154", 2549410104)
addappid(614574, 1, "72a46d950dbc4b6c957b1a5576743f43820e3562b8dd27ebbaa9fa68e70aa54b") -- Blackheart Depot-Common-1
setManifestid(614574, "1250994781956567556", 19242216809)
addappid(614575, 1, "68ad1d3e4ca5d305141b415b8456acb583821663eaf920105567bcc4d0e40bb8") -- Blackheart Depot-english
setManifestid(614575, "1038320836629445140", 3313081789)
addappid(614576, 1, "86401f6344ee59c5a3c0ba6fec6cc2799df153bbf4d8ca6a75616284b8f42196") -- Blackheart Depot-french
setManifestid(614576, "7571677295077253291", 3321710135)
addappid(614577, 1, "96a0cd07efbdbc43f0951870ddafe1b0d86a677327f60e8612266f7e3848a6ab") -- Blackheart Depot-brazilian
setManifestid(614577, "6734263060356953376", 3365287475)
addappid(614578, 1, "adbb79ec1e4bbcfb2b635bca2cfbeb1c9b673f897db5e7d2945bc3c769f2e38d") -- Blackheart Depot-german
setManifestid(614578, "609424267182762704", 3345186205)
addappid(614579, 1, "10883f8bbafb0c1ec0b15341830db49f89108e9f0b83eb0fa2de81159ee4dc30") -- Blackheart Depot-italian
setManifestid(614579, "8198419356264769963", 3405631740)
addappid(619040, 1, "2743059a1e9b1ffb27352f177476ba53877c4dce8062ae0e8b0059eb6afe9e56") -- Blackheart Depot-russian
setManifestid(619040, "603174670925293993", 3400375381)
addappid(619041, 1, "45aa5697bbfe5572c8b8cd157aa21a036c9404371d4fc76a378f6bfdd8f19359") -- Blackheart Depot-polish
setManifestid(619041, "5414687248950195866", 3346371438)
addappid(619042, 1, "a19ef513882daf9aadeed0ee75fe15827e01f1747ebdbbf2e10a60bd241e999d") -- Blackheart Depot-spanish
setManifestid(619042, "3549808596751054836", 3391039401)
addappid(619043, 1, "6c3098b051f3cc9ccf81e5675660fc40a63a780e100e779adad717e91de92b47") -- Blackheart Depot-latinamericanspanish
setManifestid(619043, "1072274842726081070", 3319204048)
addappid(619044, 1, "0c0b72f01ce196cbcb0d2e1b184c237d5a14199b4b16a144a9642e407258e632") -- Blackheart Depot-chinese
setManifestid(619044, "638963703765147799", 2298607310)
addappid(619045, 1, "614b8b8c7135598191e01f33f065dd6ab4e6e9e09d91abb3679be009e6283ba0") -- Blackheart Depot-japanese
setManifestid(619045, "5864513914808656354", 3525611942)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)