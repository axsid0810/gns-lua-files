-- 584400's Lua and Manifest Created by Hubcap Manifest
-- Sonic Mania
-- Created: September 30, 2025 at 18:21:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(584400) -- Sonic Mania
-- MAIN APP DEPOTS
addappid(584401, 1, "bb1637eb4c893c31ad5b560a6d53f01f665438e9f4deab4db1939b18d631a571") -- Sonic Mania Content
setManifestid(584401, "8440811224789314446", 211702471)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(845640) -- Sonic Mania - Encore DLC