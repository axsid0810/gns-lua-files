-- 945360's Lua and Manifest Created by Hubcap Manifest
-- Among Us
-- Created: June 05, 2026 at 19:39:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 8
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(945360, 1, "7f0bd1cc5c537189d88186c93ddc7bb29608c8cff6c3e67bb2bb8bd5bab8f752") -- Among Us
-- MAIN APP DEPOTS
addappid(945361, 1, "cc84ab09a34dfa19f0cf86c30c05345294e788988c95455a7c42d024dc4f33a8") -- Among Us Content
setManifestid(945361, "7623608153396667062", 1057557705)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(946430) -- Among Us - Hamster Pet Bundle
addappid(971924) -- Among Us - Bedcrab Pet Bundle
addappid(971925) -- Among Us - Polus Map
addappid(971995) -- Among Us - Brainslug Pet Bundle
addappid(971996) -- Among Us - Mini Crewmate Bundle
addappid(971998) -- Among Us - MIRA HQ Map
addappid(971999) -- Among Us - Stickmin Pet Bundle
addappid(1579150) -- Among Us - Airship Skins
-- EMPTY DEPOTS (no content on any branch)
-- addappid(945362) -- Depot 945362 (empty depot)