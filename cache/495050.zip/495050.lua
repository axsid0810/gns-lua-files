-- 495050's Lua and Manifest Created by Hubcap Manifest
-- Mega Man Legacy Collection 2
-- Created: September 30, 2025 at 00:13:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(495050) -- Mega Man Legacy Collection 2
-- MAIN APP DEPOTS
addappid(495051, 1, "9d0486a0c0f575c083cc3e416de7a0074cafa01889208f14118ede19b7d22ff7") -- tmemsltc2
setManifestid(495051, "6202217455193765410", 3875996857)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)