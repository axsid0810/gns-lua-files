-- 960910's Lua and Manifest Created by Hubcap Manifest
-- Heavy Rain
-- Created: September 29, 2025 at 17:09:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(960910) -- Heavy Rain
-- MAIN APP DEPOTS
addappid(960911, 1, "57fe2fc09eab86ac6d503e89fc037645053df15f387ab695fcb04411d8ea5593") -- BaseData
setManifestid(960911, "172057479938002753", 25727285506)
addappid(960912, 1, "98995c508adefd7850bd76950fb941e5eacdf0075eef458659aaf622542a778b") -- FullLanguageData
setManifestid(960912, "6023850840263901527", 11222185337)
addappid(960913, 1, "81af1bd341d0823d04d9f818fcc3816ee5c3bfaede466e9d451ff467d4426598") -- JapaneseData
setManifestid(960913, "1327801306330882789", 2236669880)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)