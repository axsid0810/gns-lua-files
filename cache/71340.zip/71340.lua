-- 71340's Lua and Manifest Created by Hubcap Manifest
-- Sonic Generations
-- Created: May 22, 2026 at 06:03:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(71340, 1, "afdac8ad1781822512b6c5a470681a7986e4348fccb436c927417f451fe35289") -- Sonic Generations
-- MAIN APP DEPOTS
addappid(71341, 1, "e9a94a9cea6b1e07fb4ab98e4186c7af965a32ace868d3ed5bf8151adc2016e0") -- Sonic Generations Main
setManifestid(71341, "190831558827569965", 9051255922)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(200590) -- Sonic Generations - Casino Night DLC