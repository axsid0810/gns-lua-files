-- 228200's Lua and Manifest Created by Hubcap Manifest
-- Company of Heroes 
-- Created: September 29, 2025 at 04:57:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 14
-- Total DLCs: 3
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(228200) -- Company of Heroes 
-- MAIN APP DEPOTS
addappid(228201, 1, "5d6bed0e4d50494cfda9f876c9c851d5f0d5b90456f45cb1083b1316338e3fd0") -- Company of Heroes Relaunch Binaries
setManifestid(228201, "6778052271273726154", 69061231)
addappid(228202, 1, "e1d4ee51033ff00a5fab176efaa92d1c7c8d47519880b3444edd9988b5efa51c") -- Company of Heroes Relaunch Game Content
setManifestid(228202, "5659918162838796781", 6642487033)
addappid(228203, 1, "7b564d87178856b4bb20aa971be9300644d9bc3a6bc9da3dccb447922f83116a") -- Company of Heroes Relaunch English Content
setManifestid(228203, "7675744675381325419", 2772321676)
addappid(228204, 1, "0d601b5f2cca71acb2d9920c5df9f936ee3b8e8701fb4aa96763af3ded0cfb10") -- Company of Heroes Relaunch French Content
setManifestid(228204, "7050865856683054936", 1800126768)
addappid(228205, 1, "dfbbce5d3f4b092bfd697b15d16ddc0f0cd5eb3a3730d430e3eebe2f3cd077a1") -- Company of Heroes Relaunch Italian Content
setManifestid(228205, "7660761729838088865", 2772618153)
addappid(228206, 1, "601486a3e1d777ba88fe3ab8fc1eff071b5a894a4b32b40a5ae351ad99e7c14d") -- Company of Heroes Relaunch German Content
setManifestid(228206, "6341777324770310364", 1516990982)
addappid(228207, 1, "8f0d66cf66279c53e2c6eea205de4d16ea3cbdf4283ba41a16215644a362d2f7") -- Company of Heroes Relaunch Spanish Content
setManifestid(228207, "1385701332218810567", 1375259241)
addappid(228209, 1, "84e2e9698afb312d2efac8be482c8e413be2afabff5885a3a1b279e95f802d47") -- Company of Heroes Relaunch ChineseTrad Content
setManifestid(228209, "1224032204716668192", 2794482698)
addappid(228210, 1, "a0e3bc5632baa62801f5e21e85a69ab51eaab22d1e1ebf196de9df12a6b2e043") -- Company of Heroes Relaunch Czech Content
setManifestid(228210, "8191153587921179772", 2772232566)
addappid(228211, 1, "77d671190e479e4eb6be4fea948506dc1941363fceed6e6af56e844f0a0681e7") -- Company of Heroes Relaunch Japanese Content
setManifestid(228211, "8253295158830923089", 2795018009)
addappid(228212, 1, "ffe99980ed112a495130a18ce8348ad0763046f7f65d610c747cf22deeeab2f0") -- Company of Heroes Relaunch Korean Content
setManifestid(228212, "4090848090295888494", 2795132959)
addappid(228213, 1, "dd5682bc26f22c7f92343926cb219482d72811fbe7bbd66e60979dc183dbfcc1") -- Company of Heroes Relaunch Polish Content
setManifestid(228213, "7997109856229164802", 2772389441)
addappid(228214, 1, "2ced19d575cbfc8cc70cadf3180fddf9254d87f440f614ca3d233a69cc035596") -- Company of Heroes Relaunch Russian Content
setManifestid(228214, "3501132835799993052", 1674768470)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(228221) -- Company of Heroes (New Steam Version) - Core Game
addappid(228222) -- Company of Heroes (New Steam Version) - Tales of Valor
addappid(228223) -- Company of Heroes (New Steam Version) - Opposing Fronts