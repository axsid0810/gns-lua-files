-- 1172380's Lua and Manifest Created by Hubcap Manifest
-- STAR WARS Jedi: Fallen Order™ 
-- Created: July 03, 2026 at 00:46:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 18
-- Total DLCs: 6
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1172380, 1, "c207df2af5e17a1471393982c23873ed486ef867517127b81d86c3dab8ed52e8") -- STAR WARS Jedi: Fallen Order™ 
-- MAIN APP DEPOTS
addappid(1172381, 1, "8037ba2edace2f1d0dbf8fb4da5862c6a19848eabde461a8c514434e57a6bfea") -- STAR WARS Jedi: Fallen Order Content
setManifestid(1172381, "1836009592314787599", 54539404148)
addappid(1172382, 1, "7f99e584282765717598ceb3546a1b56ec38b5992ee25ffef2930812bd1f0b81") -- STAR WARS Jedi: Fallen Order Depot - English
setManifestid(1172382, "3379111282441845895", 761009027)
addappid(1172383, 1, "62ca3fb1dca6cf7a4efee8f2c9c7e615f3a0b0a81320085f325ccdfcc0ca68d4") -- STAR WARS Jedi: Fallen Order Depot - Korean
setManifestid(1172383, "3766616418077817145", 761295292)
addappid(1172384, 1, "56197844b3067a3c77fb960e4fb7a8658f09f5d2dd448ba8fd8e1afa48afb002") -- STAR WARS Jedi: Fallen Order Depot - French
setManifestid(1172384, "7594369369776953856", 737142505)
addappid(1172385, 1, "6499696e0d1d0892417fcec9c9c7b4a6e1fc2e9c4b7e37201d5c62658bdc6ef8") -- STAR WARS Jedi: Fallen Order Depot - German
setManifestid(1172385, "8848754183410231431", 767837991)
addappid(1172386, 1, "0f08a648a1d1f52528c3a46697e326d0822e37809f97ca66123ad4e117084340") -- STAR WARS Jedi: Fallen Order Depot - Italian
setManifestid(1172386, "5420388355167484213", 777187388)
addappid(1172387, 1, "4c8b32bbce703e7303b46a5316dc1385b58c42187701e0cd0e7694c68c79a128") -- STAR WARS Jedi: Fallen Order Depot - Spain – Spanish
setManifestid(1172387, "8532360449227748901", 798472484)
addappid(1172388, 1, "20e981d8d491512bdde841158d2da5caf3abcbe5a6ff165a22e880b55ad61fb0") -- STAR WARS Jedi: Fallen Order  Depot - Polish
setManifestid(1172388, "6138049879201806389", 754988943)
addappid(1172389, 1, "6e8513d9dc1d14214e804e13da1868a3db4532e313a9f17c4eb1839984b57850") -- STAR WARS Jedi: Fallen Order Depot - Russian
setManifestid(1172389, "6037452343878301968", 793882666)
addappid(1178731, 1, "37c47c665f0b94902b0e35ac3f0896bc47a38d926ed0be130bb0862f8d55e58d") -- STAR WARS Jedi: Fallen Order - Mexico – Spanish
setManifestid(1178731, "8568801689805437849", 775954991)
addappid(1178732, 1, "34b104d82532928eb9db257dc290150c501c88664e826fd3bce56772f65ca1ef") -- STAR WARS Jedi: Fallen Order Depot - Japanese
setManifestid(1178732, "1009370874698720691", 754555538)
addappid(1178733, 1, "e97530e93516f00aaf0c1c3411062d3d5ae808976c1eeb34603c4ddb3f81636b") -- STAR WARS Jedi: Fallen Order Depot - Brazilian Portuguese
setManifestid(1178733, "8332670376795290915", 776292393)
addappid(1178734, 1, "b8c1457b4c858c8856d560341212b2453db8940ac885e4cc0e2df29ff2028001") -- STAR WARS Jedi: Fallen Order Depot - Simplified Chinese
setManifestid(1178734, "3625300876734945806", 761069361)
addappid(1178735, 1, "253ab7e579624fcfe8433af8931a09bbad808c395057962384518b8e4a21a40a") -- STAR WARS Jedi: Fallen Order Depot - Traditional Chinese
setManifestid(1178735, "1428332209474427029", 761059232)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
setManifestid(3340991, "2155225770093841476", 239536599)
-- DLCS WITH DEDICATED DEPOTS
-- STAR WARS Jedi Fallen Order - Deluxe Edition Content (AppID: 1178730)
addappid(1178730)
addappid(1178730, 1, "2058e7adc34e3aceae1b7dea4c8e0a44dba3a4f2e6a00bb1ac210c0c10ce43a9") -- STAR WARS Jedi Fallen Order - Deluxe Edition Content - Telstar- Deluxe Edition Content Depot
setManifestid(1178730, "8468760542600072956", 4745882339)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1179140) -- STAR WARS Jedi Fallen Order Deluxe Edition Key
addappid(1179141) -- STAR WARS Jedi Fallen Order Deluxe Edition Pre-Purchase Key
addappid(1179142) -- STAR WARS Jedi Fallen Order Key
addappid(1179200) -- STAR WARS Jedi Fallen Order Pre-Purchase Key
addappid(1192320) -- STAR WARS Jedi Fallen Order Pre-Purchase Content Key