-- 2543180's Lua and Manifest Created by Hubcap Manifest
-- POPUCOM
-- Created: May 28, 2026 at 09:13:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(2543180, 1, "1f4ab702036f5e5ccc194451658a6691acbcda3fd204e1a0d9e752d2ec7377f6") -- POPUCOM
-- MAIN APP DEPOTS
addappid(2543181, 1, "710ea94ede6b7341fc677cfed501f4a587ea3d576e9cecd917f056937548d455") -- Depot 2543181
setManifestid(2543181, "5396537959274998798", 10968790487)
addappid(2543182, 1, "02f5079b97e8a2548f5ae2e69794714c27fd0e1629ab5e911a659e5b773f3c23") -- Depot 2543182
setManifestid(2543182, "2066177807817503772", 10949638855)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3025670) -- POPUCOM - Too Many Clothes Pack
addappid(3025970) -- POPUCOM - Rabbids Chic Pack
addappid(3929360) -- POPUCOM X ARKNIGHTS Collab Outfit Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3025670) -- Depot 3025670 (empty depot)
-- addappid(3025970) -- Depot 3025970 (empty depot)