-- 359600's Lua and Manifest Created by Hubcap Manifest
-- Assassin’s Creed® Chronicles: Russia
-- Created: July 04, 2026 at 12:53:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 2
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(359600, 1, "1e18442ed4c7290bb8a7f7f60331a9c469f37df7f977bb995bd06fea0a5abc97") -- Assassin’s Creed® Chronicles: Russia
-- MAIN APP DEPOTS
addappid(359601, 1, "3830d637e9f61d5da62795c0aa9727dd293716618225c14fd8d8d0dfa516af34") -- Assassin's creed Chronicles - Russia Content
setManifestid(359601, "1373372059609134359", 5130957827)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "8936186649444731600", 264933784)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(376430) -- Assassins Creed Chronicles Russia - WW Uplay Activation
addtoken(376430, "16264346285281972737")
addappid(441740) -- Assassins Creed Chronicles Russia - RU Uplay Activation
addtoken(441740, "8366167021312230133")