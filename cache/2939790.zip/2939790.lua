-- 2939790's Lua and Manifest Created by Hubcap Manifest
-- Lunarium
-- Created: July 29, 2026 at 04:58:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2939790) -- Lunarium
addtoken(2939790, "13885911450102068332")
-- MAIN APP DEPOTS
addappid(2939791, 1, "b30295c5743552adf6bd73ffc9a1ccbdb81623e854ab761f45162d8af3f0e188") -- Depot 2939791
setManifestid(2939791, "7339006441207523562", 3619545203)