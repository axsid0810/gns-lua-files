-- 1580020's Lua and Manifest Created by Hubcap Manifest
-- Mimetic
-- Created: July 20, 2026 at 14:27:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1580020, 1, "ece7debb69b56e6dca2e05cabc2657a50316c4d9909b479fb230e8b7c62652d9") -- Mimetic
-- MAIN APP DEPOTS
addappid(1580021, 1, "4da1f6659f758c8083fb7140b22d3cbd4a3de7eb1217f6bbdebe740c531376fc") -- Depot 1580021
setManifestid(1580021, "259054079254161993", 18324588853)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)