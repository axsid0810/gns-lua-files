-- 4879510's Lua and Manifest Created by Hubcap Manifest
-- Earth New Fall
-- Created: July 22, 2026 at 06:39:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4879510) -- Earth New Fall
-- MAIN APP DEPOTS
addappid(4879511, 1, "bc541bcd28a2d763b1eb7152b81348b2da637b62999418e96191b4813643628d") -- Depot 4879511
setManifestid(4879511, "8016570377247521094", 470040438)