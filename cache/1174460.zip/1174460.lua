-- 1174460's Lua and Manifest Created by Hubcap Manifest
-- Poker Club
-- Created: September 30, 2025 at 07:23:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1174460) -- Poker Club
-- MAIN APP DEPOTS
addappid(1174461, 1, "ed8b75ad32145573a7ecb76a9daf57d2a2032907ec25909c72464bdf012c6e79") -- Poker2 Content
setManifestid(1174461, "4989193142734618073", 10973117082)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)