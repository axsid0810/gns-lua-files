-- 2229940's Lua and Manifest Created by Hubcap Manifest
-- [REDACTED]
-- Created: September 30, 2025 at 16:52:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2229940) -- [REDACTED]
-- MAIN APP DEPOTS
addappid(2229942, 1, "90d8946d112621e524c43310fcfdd85e186c283857d67fc48e2d51b7733656ec") -- Depot 2229942
setManifestid(2229942, "6066190841424615416", 10415594465)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)