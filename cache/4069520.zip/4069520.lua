-- 4069520's Lua and Manifest Created by Hubcap Manifest
-- Super Battle Golf
-- Created: July 16, 2026 at 13:15:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4069520, 1, "0dfbf7a5cc6dfbbde7b7d1c6232822bfe89ff4a655427ec3bcd9e3e427c16776") -- Super Battle Golf
-- MAIN APP DEPOTS
addappid(4069521, 1, "7e03356de28c147831a4c06ff74efaa4af6dbeafdfffa371069c5635bd41cf00") -- Depot 4069521
setManifestid(4069521, "3373804759105188235", 1794966225)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)