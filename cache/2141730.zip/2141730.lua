-- 2141730's Lua and Manifest Created by Hubcap Manifest
-- Backrooms: Escape Together
-- Created: July 19, 2026 at 21:49:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2141730, 1, "aaf3b1238f920baec05279c2de2478fbf37c5380c19660e6b4a2a09f7e176e66") -- Backrooms: Escape Together
-- MAIN APP DEPOTS
addappid(2141731, 1, "cfcbb1b05a371faabeb03500c308dbae345a2c7d9a45417a910283c9201e084d") -- Depot 2141731
setManifestid(2141731, "2167984175935939828", 15428133942)
addappid(2141732, 1, "1038f744a70ce5b445cdbfc9ce77601ae45a36279d0a9ad02b59b714acfba762") -- Depot 2141732
setManifestid(2141732, "6866044377255604924", 20151449702)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)