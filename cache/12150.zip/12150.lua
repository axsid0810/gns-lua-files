-- 12150's Lua and Manifest Created by Hubcap Manifest
-- Max Payne 2: The Fall of Max Payne
-- Created: April 05, 2026 at 08:57:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(12150, 1, "a7b79a55ccc3391299dc6d61ed458bf3e0c9363e872491b46631c7335ef205f5") -- Max Payne 2: The Fall of Max Payne
-- MAIN APP DEPOTS
addappid(12151, 1, "7d78588a024003c4989d9dc5a5d86d60223495c8c86c8d2b9591278d0e1e112d") -- Max Payne 2 The Fall of Max Payne content
setManifestid(12151, "1390811977241465426", 1668252304)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(12152) -- Depot 12152 (empty depot)
-- addappid(12154) -- Depot 12154 (empty depot)
-- addappid(12155) -- Depot 12155 (empty depot)
-- addappid(12156) -- Depot 12156 (empty depot)