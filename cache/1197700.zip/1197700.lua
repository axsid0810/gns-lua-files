-- 1197700's Lua and Manifest Created by Hubcap Manifest
-- Hermes: War of the Gods
-- Created: January 19, 2026 at 03:37:00 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1197700) -- Hermes: War of the Gods
-- MAIN APP DEPOTS
addappid(1197701, 1, "37e62343946ca659619e79dc282ab17e36fb01f4558cb1ebc4dee101f7b812bb") -- Hermes: War of the Gods EN
setManifestid(1197701, "6166395787996790059", 587646582)
addappid(1197702, 1, "195a19585909b1e7e2b0836636e21294dd372ca4522c96fb705b8fd5ab8b663f") -- Hermes: War of the Gods DE
setManifestid(1197702, "5925380093037077358", 587679033)
addappid(1197703, 1, "a96eed874810885e3aef82ef48eec310418aa2a6740e00246aab6997e8c13d43") -- Hermes: War of the Gods KO
setManifestid(1197703, "1942741510083868906", 587698254)
addappid(1197704, 1, "4e43b9418c486bae60f992afda0c1f3da1c95dcf9d47544083f56223f47c997d") -- Hermes: War of the Gods RU
setManifestid(1197704, "8707764895545987650", 587813699)