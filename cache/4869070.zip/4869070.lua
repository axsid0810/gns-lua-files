-- 4869070's Lua and Manifest Created by Hubcap Manifest
-- 挖个蛋
-- Created: July 22, 2026 at 10:22:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4869070) -- 挖个蛋
-- MAIN APP DEPOTS
addappid(4869071, 1, "e7f021f05b9ce95ec32acb60cda1c5c9b21976f47d14b5abd995a6371bfcd1b1") -- Depot 4869071
setManifestid(4869071, "3409965879885603426", 287921367)