-- 690640's Lua and Manifest Created by Hubcap Manifest
-- Trine 4: The Nightmare Prince
-- Branch: PUBLIC
-- Created: January 08, 2026 at 10:39:26 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 3
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(690640, 1, "5240722b7b561291590b6ce3fbdac12b229917b8733ee6d7830d18c87728d09f") -- Trine 4: The Nightmare Prince
-- MAIN APP DEPOTS
addappid(690641, 1, "42a0d2c4b4508e91a808d579233e2f5cac28bd41a8610b36809a2ed73090cbd4") -- Trine 4: The Nightmare Prince Windows
setManifestid(690641, "1751452529680355581", 16882667866)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Trine 4 The Nightmare Prince - Artbook (AppID: 1504370)
addappid(1504370)
addappid(1504371, 1, "25cd6a286dbc5bda444a8a9d3a68226ab661ade835f83e57cf04c6f3a751c783") -- Trine 4 The Nightmare Prince - Artbook - Trine 4: The Nightmare Prince - Artbook Depot
setManifestid(1504371, "1312752376837469527", 253871466)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1113990) -- Trine 4 The Nightmare Prince - Tobys Dream (Bonus Level)
addtoken(1113990, "14868629724485229234")
addappid(1444560) -- Trine 4 Melody of Mystery