-- 1946550's Lua and Manifest Created by Hubcap Manifest
-- Toilet Chronicles
-- Created: February 25, 2026 at 12:48:50 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1946550) -- Toilet Chronicles
-- MAIN APP DEPOTS
addappid(1946551, 1, "902669332361615d69899c1cc9e97a10b0a0c43491205cd2ed671b48bced4a81") -- Depot 1946551
setManifestid(1946551, "1828587330851962092", 287014450)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2202610) -- Toilet Chronicles Staff Only
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2202610) -- Depot 2202610 (empty depot)