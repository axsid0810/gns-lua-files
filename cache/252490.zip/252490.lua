-- 252490's Lua and Manifest Created by Hubcap Manifest
-- Rust
-- Created: July 17, 2026 at 07:52:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 6
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(252490, 1, "070d35c4cac50d6b14881a6fd630bf1c58a061bec585e899a48c813972638108") -- Rust
-- MAIN APP DEPOTS
addappid(252494, 1, "5d5f72c0460cb7598666696c1b2f612f22efb43fb87cf4322e596bfec8a231ec") -- Rust Client - Common
setManifestid(252494, "8797553211615438186", 53922256237)
addappid(252492, 1, "96b750328197855f4311ba6ad6d86e9051866cc6b9a6c851de55cc41b8ad9a24") -- Rust Client - OSX
setManifestid(252492, "4434798634398426336", 6921278793)
addappid(252495, 1, "728fcdc1c6af4454f3c86e5bc62a75875af5ba790cc8a2623620e216086e034d") -- Rust Client - Windows 64
setManifestid(252495, "4519162356085432523", 1169574981)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(494560) -- Rust - Early Access Ident
addtoken(494560, "9612755471074374815")
addappid(1174370) -- Instrument Pack
addappid(1353060) -- Rust Sunburn Pack
addappid(1374000) -- Rust Secretlab Chair
addappid(1670430) -- Rust Voice Props Pack
addappid(3891560) -- Rust Warhammer Pack