-- 242550's Lua and Manifest Created by Hubcap Manifest
-- Rayman Legends
-- Created: July 01, 2026 at 10:54:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(242550, 1, "7726c65822b6070b546ea2f2d04af56b0cc57fcf0b3a03e13aa7e49119a537d7") -- Rayman Legends
-- MAIN APP DEPOTS
addappid(242551, 1, "686bb8789459e4e3030ad32b9375d784ae80215a36f25a6e2f7d9ca04a37adcd") -- Rayman Legends Content
setManifestid(242551, "8839431118021240556", 5867774571)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "8936186649444731600", 264933784)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(247811) -- Rayman Legends - Game Key