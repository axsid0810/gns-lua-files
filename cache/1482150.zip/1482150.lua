-- 1482150's Lua and Manifest Created by Hubcap Manifest
-- Made Marion
-- Created: January 21, 2026 at 09:33:18 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1482150) -- Made Marion
-- MAIN APP DEPOTS
addappid(1482151, 1, "02b7901bdb2875e5cc8a108988d37a52d78ea5e408900f9310d4a36454b6ebbc") -- Depot 1482151
setManifestid(1482151, "5871585083533718175", 2214142892)