-- 3861730's Lua and Manifest Created by Hubcap Manifest
-- Class of '09: Puzzle Showdown
-- Created: July 21, 2026 at 03:00:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3861730, 1, "d3562d3e8c5be1757c32558ece54c617891835f892375c32dff1580db2729c0e") -- Class of '09: Puzzle Showdown
-- MAIN APP DEPOTS
addappid(3861731, 1, "7230047b7bbb44a04dd706c0e5609ab632e30ba940c72cb9cedecf3a6d8ae847") -- Depot 3861731
setManifestid(3861731, "6502301539988836672", 1261184895)
addappid(3861732, 1, "861fef5e4e4be0ef60928c5c523b7dca42e786e4019e6998b9814fcb6177affa") -- Depot 3861732
setManifestid(3861732, "6352611947021614461", 1259490092)
addappid(3861733, 1, "e1cfd87df5e580408a18257234eea70f1d3c997ce0e556bedee353e502259f0c") -- Depot 3861733
setManifestid(3861733, "4277530588735769944", 1427583663)