-- 1858630's Lua and Manifest Created by Hubcap Manifest
-- SWORD ART ONLINE Fractured Daydream
-- Created: July 09, 2026 at 07:48:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 13
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1858630, 1, "9b32f746e41b3fa7b3c3260806e4bead05621161eaf4b77f61eb08ee29723329") -- SWORD ART ONLINE Fractured Daydream
addtoken(1858630, "14829250357920636736")
-- MAIN APP DEPOTS
addappid(1858631, 1, "21adba4e332aa48b0f8834b0896bc582f7132947f62dd148cd8d5a3f1df6cfee") -- Depot 1858631
setManifestid(1858631, "3999858075955030505", 55698986276)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- SWORD ART ONLINE Fractured Daydream - Digital Artbook  Soundtrack (AppID: 2387391)
addappid(2387391)
addappid(2387391, 1, "0b159382f281cad0e7b1c810c1dce8d0c7265e096706792f5e90920a8c92bfe1") -- SWORD ART ONLINE Fractured Daydream - Digital Artbook  Soundtrack - Depot 2387391
setManifestid(2387391, "4660245419420526948", 754366859)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2877820) -- SWORD ART ONLINE Fractured Daydream - Demon King Costume Set
addappid(2877830) -- SWORD ART ONLINE Fractured Daydream - Prism Heart Costume Set
addappid(2877840) -- SWORD ART ONLINE Fractured Daydream - Wild Joker Dress
addappid(2939660) -- SWORD ART ONLINE Fractured Daydream Character Pass Vol. 1
addappid(2985460) -- SWORD ART ONLINE Fractured Daydream - Bonus Stamp Set
addappid(3037270) -- SWORD ART ONLINE Fractured Daydream Character Pass Vol. 2
addappid(3037280) -- SWORD ART ONLINE Fractured Daydream Premium Upgrade
addappid(3047110) -- SWORD ART ONLINE Fractured Daydream - A moment in Infinity
addappid(3047120) -- SWORD ART ONLINE Fractured Daydream - The Devils Comeback
addappid(3300980) -- SWORD ART ONLINE Fractured Daydream - Bonus Stamp Set 2
addappid(3428460) -- SWORD ART ONLINE Fractured Daydream - Moonlit Night Fragment
addappid(3428470) -- SWORD ART ONLINE Fractured Daydream - Symphony of a Dazzling Dawn
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1858632) -- Depot 1858632 (empty depot)