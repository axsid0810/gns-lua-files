-- 4449410's Lua and Manifest Created by Hubcap Manifest
-- KYOTO XANADU -the Blooming Phantom-
-- Created: July 16, 2026 at 06:08:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 20
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4449410) -- KYOTO XANADU -the Blooming Phantom-
-- MAIN APP DEPOTS
addappid(4449411, 1, "9c5e523988b316ae37432b8f8cadd52e5b2ea2c65409ac6e50ac5ffdd1b4df49") -- Depot 4449411
setManifestid(4449411, "5312157999627123121", 26522677353)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4630720) -- KYOTO XANADU -the Blooming Phantom- - Support Card LinoN
addappid(4630730) -- KYOTO XANADU -the Blooming Phantom- - Teahouse Costume Hirasakakomachi AO for Rei  Fuka
addappid(4630750) -- KYOTO XANADU -the Blooming Phantom- - Swimsuit Kazenone
addappid(4790000) -- KYOTO XANADU -the Blooming Phantom- - Virtual Singer Costume Set
addappid(4790040) -- KYOTO XANADU -the Blooming Phantom- - Karasu Tengu Set
addappid(4790070) -- KYOTO XANADU -the Blooming Phantom- - Colorful Effect Set
addappid(4790100) -- KYOTO XANADU -the Blooming Phantom- - Comment Panel Set
addappid(4790140) -- KYOTO XANADU -the Blooming Phantom- - Hair Color Set LinoN
addappid(4790160) -- KYOTO XANADU -the Blooming Phantom- - Costume Set Unique Japanese Robe
addappid(4790170) -- KYOTO XANADU -the Blooming Phantom- - Smartphone Wallpaper Set
addappid(4790180) -- KYOTO XANADU -the Blooming Phantom- - Money 100,000 Yen
addappid(4790200) -- KYOTO XANADU -the Blooming Phantom- - Phantom Aether 500ml
addappid(4790210) -- KYOTO XANADU -the Blooming Phantom- - Phantom Aether 1000ml
addappid(4790220) -- KYOTO XANADU -the Blooming Phantom- - Phantom Aether 1500ml
addappid(4790230) -- KYOTO XANADU -the Blooming Phantom- - Xanadu Material Set (Rank 1)
addappid(4790260) -- KYOTO XANADU -the Blooming Phantom- - Books for Status Up - Beginner Level
addappid(4790290) -- KYOTO XANADU -the Blooming Phantom- - Useful Mask Set
addappid(4790310) -- KYOTO XANADU -the Blooming Phantom- - Guardian Skill Card Set Attack
addappid(4790320) -- KYOTO XANADU -the Blooming Phantom- - Guardian Skill Card Set Defense
addappid(4790330) -- KYOTO XANADU -the Blooming Phantom- - Guardian Skill Card Set Spirit