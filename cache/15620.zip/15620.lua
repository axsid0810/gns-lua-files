-- 15620's Lua and Manifest Created by Hubcap Manifest
-- Warhammer 40,000: Dawn of War II - Anniversary Edition
-- Created: April 11, 2026 at 04:27:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 36
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(15620, 1, "63eab18b40afb4439de1e8db5d6b3383d397b30fe3123f40afa043fbda2f5358") -- Warhammer 40,000: Dawn of War II - Anniversary Edition
-- MAIN APP DEPOTS
addappid(15621, 1, "5c4eb19ec9b4ff16b88962ad24cfb39238c0fc86107e3022c2be878f1f85f8b9") -- Dawn of War 2 Common Files
setManifestid(15621, "28819409497659790", 5336409026)
addappid(15622, 1, "f15bdc9e6573b5d97a838b8469ff589090e326c195542e441d69bf6bd5f12825") -- Warhammer 40,000: Dawn of War II English
setManifestid(15622, "415980344314558180", 1399719161)
addappid(15623, 1, "62993c8835994ab7fdc6030fa4ab2f98364d2d04ea3b84af625b3e03642896f4") -- Warhammer 40,000: Dawn of War II French
setManifestid(15623, "2156179944656826920", 940635006)
addappid(15624, 1, "05000d8cd04fd0d85895eeeda38ab8682fd4ffe9280a974518bb378a549a08b7") -- Warhammer 40,000: Dawn of War II Italian
setManifestid(15624, "3117486659222872796", 1398849288)
addappid(15625, 1, "3e3d23025085e19236bfdd7c80a14c3d377bfa7cf3118b492c19a35b69e00174") -- Warhammer 40,000: Dawn of War II German
setManifestid(15625, "6520321097558132592", 1024538105)
addappid(15626, 1, "02f39c4e87fe523f3e54e36e629d6e444bc52a30e9abe1b064a7230f474d6913") -- Warhammer 40,000: Dawn of War II Spanish
setManifestid(15626, "8484043249124747103", 1131122757)
addappid(15627, 1, "b7380480ebafb35f22b45b1c7acc71a58632f7090a39fa67c24c95051f5d93fd") -- Warhammer 40,000: Dawn of War II Russian
setManifestid(15627, "6433233687163740440", 1118775368)
addappid(15628, 1, "a7d9a47f8cf70f369b1d0f769ee6a88898209e6da9fff909c428f255f39d9da3") -- Warhammer 40,000: Dawn of War II Czech
setManifestid(15628, "1126000928349354913", 1399216256)
addappid(15629, 1, "745bdf869180903cc84a84ef65eeea4609a5939149a99fdc2cb37d79572604a5") -- Warhammer 40,000: Dawn of War II Polish
setManifestid(15629, "8788213122552121939", 1399935364)
addappid(15630, 1, "c4bdab2fcbd510c579990ae5d46143c5315071355ceb00e5d6ed8ea80248c71d") -- Warhammer 40,000: Dawn of War II tChinese
setManifestid(15630, "645396518617032873", 1396450690)
addappid(15631, 1, "67699122df8c2c110d2456d8c97fb237c0a13fc142b098a2a9e314f5fc2e5daf") -- Warhammer® 40,000™: Dawn of War® II Separated Files
setManifestid(15631, "8211289346050660002", 17909948)
addappid(15632, 1, "7c87392b1d39aeeb163c6f8b5522a071eab6546455b1781d3e67be420bae1b42") -- Mac Warhammer 40,000: Dawn of War 2 Common Files
setManifestid(15632, "130763235323198243", 6046662488)
addappid(15633, 1, "7deee1a65c64817df68aee1f8c7dbc86852412154a9a3fbb23fe22c0269c0ac1") -- Mac Warhammer 40,00: Dawn of War II English
setManifestid(15633, "186658720435948803", 1399719161)
addappid(15634, 1, "5a01444ed7a3e82da716e96c74da0d846b65511f1080563a5350a8e90712bc26") -- Mac Warhammer 40,000: Dawn of War II French
setManifestid(15634, "376640223051855237", 940635006)
addappid(15635, 1, "20b8f38a6f018e6015ab2396c05e66704ec49045e13ee375af6c8d0655ab84e6") -- Mac Warhammer 40,000: Dawn of War II Italian
setManifestid(15635, "35399783689956267", 1398849288)
addappid(15636, 1, "3797f6701dce872cb446b8558228409535c1215fc9ec07c1b99007a229a4d619") -- Mac Warhammer 40,000: Dawn of War II German
setManifestid(15636, "279731917695336936", 1024538105)
addappid(15637, 1, "77b6c47c3df47ba58b2b5ef4d9e69f57129252ca7289ab5aeaad305c61d8cb77") -- Mac Warhammer 40,000: Dawn of War II Spanish
setManifestid(15637, "83043715331036073", 1131122757)
addappid(15638, 1, "cb2269cd14ff7541942e79bfd21ab5b968a5675f619f19a0113bdd583cc05f78") -- Mac Warhammer 40,000: Dawn of War II Russian
setManifestid(15638, "208051342016628262", 1118775368)
addappid(15639, 1, "981511ce513f3598bcf65128e09934a5d2b3e063701c5a39953e09b6af2acf00") -- Mac Warhammer 40,000: Dawn of War II Czech
setManifestid(15639, "310156842403701808", 1399216256)
addappid(428990, 1, "c4af8d507d1451d23125ad150b8f28d7ea863d6a5d42d7393bf2441c89e2e60f") -- Mac Warhammer 40,000: Dawn of War II Polish
setManifestid(428990, "172153181653514434", 1399935364)
addappid(428991, 1, "ab7a284ada51f171694897da86694bea7cc47ed87d3ddf776600d4700233196e") -- Mac Warhammer 40,000: Dawn of War II tChinese
setManifestid(428991, "175168770255885711", 1396450690)
addappid(428992, 1, "3c668d291cbbb6b7f3ab2076a9bd23850adc9ea25e79838e30b4809517d95919") -- Mac Warhammer® 40,000™: Dawn of War® II Separated Files
setManifestid(428992, "7646783084393710385", 0)
addappid(428993, 1, "5f2a2db163fe1fa3b9a6445a537d9f4a98194ae1f08c47681dcf70a0b735a4fe") -- Mac Binary Warhammer® 40,000™: Dawn of War® II
setManifestid(428993, "2239429791603112707", 92338977)
addappid(428994, 1, "545ab70fdf5d5fe21dab9031727b305806fcccbcbcc265c5df3344f40234b033") -- Linux Dawn of War 2 Common Files
setManifestid(428994, "335428689148893186", 6046662488)
addappid(428995, 1, "1d6491159099ed6bd5afae1883cdfd34fc2aeffeda3f6666ced88518f021933b") -- Linux Warhammer 40,000: Dawn of War II English
setManifestid(428995, "2553543933558509", 1399719161)
addappid(428996, 1, "5092ddb2dd74a4f7aae75805fd67b06c761bff80b460320e760e3338b50de28f") -- Linux Warhammer 40,000: Dawn of War II French
setManifestid(428996, "280350455801707925", 940635006)
addappid(428997, 1, "9d858a8a2dbcd99784d9bd5179dba5643c05499bf0a4adbd6e81b3e6d9098ac1") -- Linux Warhammer 40,000: Dawn of War II German
setManifestid(428997, "494849969348447575", 1024538105)
addappid(428998, 1, "7da82c024c060fd9a2105892faa618968fc17fcc0b7c4048491d950abf67c8d6") -- Linux Warhammer 40,000: Dawn of War II Spanish
setManifestid(428998, "10218816945534592", 1131122757)
addappid(428999, 1, "ccd3d607e42de22b33444a5de6b073a586341dcca52bac546f4f14ee11718b59") -- Linux Warhammer 40,000: Dawn of War II Russian
setManifestid(428999, "148716839504188932", 1118775368)
addappid(429000, 1, "76f48c50af6a22918a8087f78099e5f044bfe86d5a5fec9ae60a21a30eb895f4") -- Linux Warhammer 40,000: Dawn of War II Czech
setManifestid(429000, "162305481531939171", 1399216256)
addappid(429001, 1, "70b7225b2286d86ec5995f427f8387af221c1efa54a270cc36a1953558657f5d") -- Linux Warhammer 40,000: Dawn of War II Polish
setManifestid(429001, "91575254481213398", 1399935364)
addappid(429002, 1, "d98b4f8d9dfb7e1c7de969b18f0a3a41148f70aab31dc5067ef26b448ab77283") -- Linux Warhammer 40,000: Dawn of War II Chinese
setManifestid(429002, "149823186542459159", 1396450690)
addappid(429004, 1, "5a9b46974c454a27bd19b3a452ba5deb06f1abcaa6a39a1cf02cfa96a25c7c10") -- Linux Binary Warhammer® 40,000™: Dawn of War® II
setManifestid(429004, "3406009054981244374", 342135448)
addappid(429005, 1, "45dbadc801dbc7560fa5f9c807b7b621c84a7409c2ee0fc110961f4244feb464") -- Linux Warhammer® 40,000™: Dawn of War® II Italian
setManifestid(429005, "101541045778996446", 1398849288)
addappid(429006, 1, "59dc12f0d52bd4bbc3121323dee3061d0368331b3eb12aca7a786eb153a96f00") -- Linux Warhammer® 40,000™: Dawn of War® II - Launch Overrides
setManifestid(429006, "5843013236167382525", 2323816)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(429003) -- Depot 429003 (empty depot)
-- addappid(429007) -- Depot 429007 (empty depot)
-- addappid(3245400) -- Depot 3245400 (empty depot)