-- 2113920's Lua and Manifest Created by Hubcap Manifest
-- The Legend of Heroes: Kuro no Kiseki Ⅱ -CRIMSON SiN-
-- Created: April 24, 2026 at 18:32:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 83
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(2113920, 1, "10274e80ed65d206e96d1fd19829bb77189b981bba3a80e1e90a3868bc547327") -- The Legend of Heroes: Kuro no Kiseki Ⅱ -CRIMSON SiN-
-- MAIN APP DEPOTS
addappid(2113921, 1, "39841636ef36f57154f3bf12675bf0cc3ce7ba928f69190633d2e6fec0c7cd47") -- Depot 2113921
setManifestid(2113921, "8792013703185739847", 16797902827)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2252080) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Vans Exclusive Costume Mishy Suit  HOLOW CORE VOICE [R.A. Monitoring Target]
addappid(2252081) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Agness Exclusive Costume Z-1 Queen (Agnes Ver.)
addappid(2252082) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Poster Contest Winning Entries
addappid(2252090) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Agness Exclusive Costume Z-1 Queen Type B
addappid(2252091) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Elaines Exclusive Costume Z-1 Queen Type B
addappid(2252092) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Shizunas Exclusive Costume Z-1 Queen Type B
addappid(2252093) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Feris Exclusive Costume Z-1 Queen
addappid(2252094) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Risettes Exclusive Costume Z-1 Queen
addappid(2252095) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Judiths Exclusive Costume Z-1 Queen Type B
addappid(2252096) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Celiss Exclusive Costume Z-1 Queen
addappid(2252097) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Nadias Exclusive Costume Z-1 Queen
addappid(2252098) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Rennes Exclusive Costume Z-1 Queen Type B
addappid(2252099) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Vans Exclusive Costume Suit Style
addappid(2252110) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Aarons Exclusive Costume Suit Style
addappid(2252111) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Quatres Exclusive Costume Suit Style
addappid(2252112) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Rions Exclusive Costume Suit Style
addappid(2252113) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Kincaids Exclusive Costume Suit Style
addappid(2252114) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Swins Exclusive Costume Suit Style
addappid(2252120) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Color Sunglasses Set
addappid(2252121) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Glasses Set
addappid(2252122) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Legendary Weapon Set
addappid(2252123) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Back Accessory Set
addappid(2252124) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Lively Effect Set
addappid(2252125) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Hair Accessory Set
addappid(2252126) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Headgear Set
addappid(2252127) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Unique Banner Set
addappid(2252128) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Ouch Banner Set
addappid(2252129) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- SiN Self-Assertive Panel Set
addappid(2252130) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- HOLOW CORE VOICE Professor Kasim Al-Fayed
addappid(2252131) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- HOLOW CORE VOICE Actress Nina Fenly
addappid(2252132) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- HOLOW CORE VOICE Knight Celis Ortesia
addappid(2252133) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- HOLOW CORE VOICE Substitute Teacher Towa Herschel
addappid(2252134) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- HOLOW CORE VOICE Mishy SiN
addappid(2252150) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Sen no Kiseki I BGM Set
addappid(2252151) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Sen no Kiseki II BGM Set
addappid(2252152) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Sen no Kiseki III BGM Set
addappid(2252153) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Sen no Kiseki IV BGM Set
addappid(2252154) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Zero no Kiseki  Ao no Kiseki BGM Set
addappid(2252155) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Arrangement Selection BGM Set
addappid(2252156) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Vocal Music Selection BGM Set
addappid(2252160) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Sepith Set (1)
addappid(2252161) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Sepith Set (2)
addappid(2252162) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Sepith Set (3)
addappid(2252163) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Sepith Set (4)
addappid(2252164) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Sepith Set (5)
addappid(2252165) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- U-Material Set (1)
addappid(2252166) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- U-Material Set (2)
addappid(2252167) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- U-Material Set (3)
addappid(2252168) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- U-Material Set (4)
addappid(2252169) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- U-Material Set (5)
addappid(2252210) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Monster Ingredients Set (1)
addappid(2252211) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Monster Ingredients Set (2)
addappid(2252212) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Monster Ingredients Set (3)
addappid(2252213) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Advanced Recovery Medicine Set (1)
addappid(2252214) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Advanced Recovery Medicine Set (2)
addappid(2252215) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Advanced Recovery Medicine Set (3)
addappid(2252216) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Advanced Recovery Medicine Set (4)
addappid(2252217) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Advanced Recovery Medicine Set (5)
addappid(2252218) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Zelam Powder Set (1)
addappid(2252219) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Zelam Powder Set (2)
addappid(2252230) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Zelam Powder Set (3)
addappid(2252231) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Zelam Capsule Set (1)
addappid(2252232) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Zelam Capsule Set (2)
addappid(2252233) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Zelam Capsule Set (3)
addappid(2252240) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Shining Pom Fruit Set (1)
addappid(2252241) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Shining Pom Fruit Set (2)
addappid(2252242) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Shining Pom Fruit Set (3)
addappid(2252243) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Shining Pom Fruit Value Pack (1)
addappid(2252244) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Shining Pom Fruit Value Pack (2)
addappid(2252245) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Shining Pom Fruit Value Pack (3)
addappid(2252246) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Droplet Set (1)
addappid(2252247) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Droplet Set (2)
addappid(2252248) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Droplet Set (3)
addappid(2252249) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Kuro Miracle Elixir Set (1)
addappid(2252250) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Kuro Miracle Elixir Set (2)
addappid(2252251) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Kuro Miracle Elixir Set (3)
addappid(2252252) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- SiN Combat Boost Pack A
addappid(2252253) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- SiN Combat Boost Pack B
addappid(2252254) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- SiN Combat Boost Pack C
addappid(2253420) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Free Sample Set Vol.1
addappid(2253421) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Free Sample Set Vol.2
addappid(2253422) -- The Legend of Heroes Kuro no Kiseki  -CRIMSON SiN- Free Sample Set Vol.3
addappid(3464220) -- The Legend of Heroes Kuro no Kiseki II -CRIMSON SiN- DLC Pack