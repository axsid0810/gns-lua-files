-- 212630's Lua and Manifest Created by Hubcap Manifest
-- Tom Clancy's Ghost Recon Future Soldier
-- Created: July 02, 2026 at 08:51:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 7
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(212630, 1, "e7d5c8ef2c6006cd36d0ae796e2e5a68cd127cc80aa8e23051092f1af97c0e10") -- Tom Clancy's Ghost Recon Future Soldier
-- MAIN APP DEPOTS
addappid(212631, 1, "c43bec7fffe8fe518d4671a68ab7c973971699ba8ac2f4cc955a56d8bbfa1bad") -- Tom Clancy's Ghost Recon Future Soldier Content
setManifestid(212631, "5952855941513904570", 18069087214)
-- SHARED DEPOTS (from other apps)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "8936186649444731600", 264933784)
-- DLCS WITH DEDICATED DEPOTS
-- Tom Clancys Ghost Recon Future Soldier - Arctic Strike DLC (AppID: 212671)
addappid(212671)
addappid(212671, 1, "64508cb46acbbebdcf6f4fcff14bd65813fc24dfb82325a810c301442d8f7d59") -- Tom Clancys Ghost Recon Future Soldier - Arctic Strike DLC - Tom Clancy's Ghost Recon Future Soldier - DLC1
setManifestid(212671, "1266992249386689046", 520280910)
-- Tom Clancys Ghost Recon Future Soldier - Raven Strike DLC (AppID: 212672)
addappid(212672)
addappid(212672, 1, "29c92834e0ba13a45a6d9026111ba68d9ed4f8909abf6b97a168764eeb1dcbf7") -- Tom Clancys Ghost Recon Future Soldier - Raven Strike DLC - Tom Clancy's Ghost Recon Future Soldier - DLC2
setManifestid(212672, "343729444442703002", 1040182294)
-- Tom Clancys Ghost Recon Future Soldier - Khyber Strike DLC (AppID: 212673)
addappid(212673)
addappid(212673, 1, "e96d99dc3bc90b22cbea5e3fd1a9d25e8dc675282f8b995204575bf5bdc568de") -- Tom Clancys Ghost Recon Future Soldier - Khyber Strike DLC - Tom Clancy's Ghost Recon Future Soldier - DLC3
setManifestid(212673, "6264598334958646457", 1053007161)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(212675) -- Tom Clancys Ghost Recon Future Soldier - Standard Key
addappid(212676) -- Tom Clancys Ghost Recon Future Soldier - Deluxe Key
addappid(212677) -- Tom Clancys Ghost Recon Future Soldier - Deluxe Preorder Key
addappid(212679) -- Tom Clancys Ghost Recon Future Soldier - Season Pass