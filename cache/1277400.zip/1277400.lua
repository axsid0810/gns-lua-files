-- 1277400's Lua and Manifest Created by Hubcap Manifest
-- Monster Hunter Stories 2: Wings of Ruin
-- Created: November 30, 2025 at 09:49:21 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 26
-- Total DLCs: 22
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1277400) -- Monster Hunter Stories 2: Wings of Ruin
-- MAIN APP DEPOTS
addappid(1277401, 1, "bfee8242944fa2ee92e4cb34e7de90305d919d87e953c7d88ea5caebed832c2c") -- App Content
setManifestid(1277401, "1634741662215371007", 28575628958)
addappid(1277402, 1, "c2d24048e19441d54a6319ec6c08be1dea25e579281d8520a4d6f8467ce4d6dc") -- App Serial
setManifestid(1277402, "8877525865325235051", 0)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Monster Hunter Stories 2 Wings of Ruin - Deluxe Kit (AppID: 1461850)
addappid(1461850)
addappid(1461850, 1, "3d7cbaa195d8259948d4a88175e3a04a6ebd67fd8a1ac1d44e4de9b175d4d6b0") -- Monster Hunter Stories 2 Wings of Ruin - Deluxe Kit - DLC01
setManifestid(1461850, "8678660519187912835", 1555408)
-- Monster Hunter Stories 2 Wings of Ruin - Enas Outfit Tropical Dress (AppID: 1461851)
addappid(1461851)
addappid(1461851, 1, "52c1c57c2f10a5f0a292d8d863fc3673a46413d816775f967121d43fd7c2be6a") -- Monster Hunter Stories 2 Wings of Ruin - Enas Outfit Tropical Dress - DLC02
setManifestid(1461851, "2877038034181250757", 1105376)
-- Monster Hunter Stories 2 Wings of Ruin - Enas Outfit Ancient Raiment (AppID: 1461852)
addappid(1461852)
addappid(1461852, 1, "d1d49af07a5129466f512c62823ef817dcc117184ef44d9322c7e4d38316e10d") -- Monster Hunter Stories 2 Wings of Ruin - Enas Outfit Ancient Raiment - DLC03
setManifestid(1461852, "286854515026779679", 3240312)
-- Monster Hunter Stories 2 Wings of Ruin - Enas Outfit Felyne Shelter Garb (AppID: 1461853)
addappid(1461853)
addappid(1461853, 1, "4a29106bac0fd70be78065fc143785289f5af5c718b336950c1d5ddcb5810737") -- Monster Hunter Stories 2 Wings of Ruin - Enas Outfit Felyne Shelter Garb - DLC04
setManifestid(1461853, "2177601540518807230", 2265168)
-- Monster Hunter Stories 2 Wings of Ruin - Enas Outfits Cheerleader Three-Pack (BlueOrangePink) (AppID: 1461854)
addappid(1461854)
addappid(1461854, 1, "2cab643bd2b3271ccdc2573eef05a7a5359501213df5fb4b62dae618c7d846c6") -- Monster Hunter Stories 2 Wings of Ruin - Enas Outfits Cheerleader Three-Pack (BlueOrangePink) - DLC05
setManifestid(1461854, "5460969751737466934", 4608264)
-- Monster Hunter Stories 2 Wings of Ruin - Enas Outfit Kamura Maiden Outfit (AppID: 1552560)
addappid(1552560)
addtoken(1552560, "4558468668164092074")
addappid(1552560, 1, "11f3271252f31a9c5034348319378e5fa7d4a267b7212b3577eeeecadc2ee9d0") -- Monster Hunter Stories 2 Wings of Ruin - Enas Outfit Kamura Maiden Outfit - DLC06
setManifestid(1552560, "2712072320998351633", 1901936)
-- Monster Hunter Stories 2 Wings of Ruin - Riders Layered Armor Hakum Rider Outfit (AppID: 1552561)
addappid(1552561)
addappid(1552561, 1, "7f2bb5398889a7939d0bafacbe2224556706cf7dea26d3c5755296c21b0eeb80") -- Monster Hunter Stories 2 Wings of Ruin - Riders Layered Armor Hakum Rider Outfit - DLC07
setManifestid(1552561, "6965275492330120002", 0)
-- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Downy Duds (AppID: 1552562)
addappid(1552562)
addappid(1552562, 1, "fed5b104fb22c7ea235ee4bf779a54b7c4e092cdd8704be8a1c204e36b254672") -- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Downy Duds - DLC08
setManifestid(1552562, "1392816447254377202", 65312)
-- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Kulu-Ya-Ku Costume (AppID: 1552563)
addappid(1552563)
addappid(1552563, 1, "338141c75a4ca2b0d88d78f3b45fd937e471c2e6b8e7026883b707004a11430c") -- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Kulu-Ya-Ku Costume - DLC09
setManifestid(1552563, "1500319214672315866", 127904)
-- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Legiana Costume (AppID: 1552564)
addappid(1552564)
addappid(1552564, 1, "e12a6436f268239072c5594b107a0fdd663055c4d2eaa084f987f678a81ed8c6") -- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Legiana Costume - DLC10
setManifestid(1552564, "7925370202793886634", 171296)
-- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Paolumu Costume (AppID: 1552565)
addappid(1552565)
addappid(1552565, 1, "ef99ed51181331b3dcdc73623225fd4f450cb4bba662af760297560579db8702") -- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Paolumu Costume - DLC11
setManifestid(1552565, "3601338423929059569", 96104)
-- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Anjanath Costume (AppID: 1552566)
addappid(1552566)
addappid(1552566, 1, "a908721644ad6a564a39da04644abe0d490fdcac9c2735485b670961eb76110d") -- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Anjanath Costume - DLC12
setManifestid(1552566, "178574111653950346", 112200)
-- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Fulgur Anja Costume (AppID: 1552567)
addappid(1552567)
addappid(1552567, 1, "e7144460ce7992c882ceef0d1d96d4f959c8af2a7dd14ac1042bbb0df91d138b") -- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Fulgur Anja Costume - DLC13
setManifestid(1552567, "1842903270834156609", 172032)
-- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Velkhana Costume (AppID: 1552568)
addappid(1552568)
addappid(1552568, 1, "6452aaea7bd8c38e3f55b730497e1de7d10b29e1a344f84a96e2ad81e441421e") -- Monster Hunter Stories 2 Wings of Ruin - Navirous Outfit Velkhana Costume - DLC14
setManifestid(1552568, "4639491812669329313", 1439528)
-- Monster Hunter Stories 2 Wings of Ruin - Riders Hairstyle Shaggy Legiana (AppID: 1552569)
addappid(1552569)
addappid(1552569, 1, "f8371e88ebd06d18e27835066ca8520d1e5011fb4e47105a8765b0ae769f258f") -- Monster Hunter Stories 2 Wings of Ruin - Riders Hairstyle Shaggy Legiana - DLC15
setManifestid(1552569, "8739963637840408063", 0)
-- Monster Hunter Stories 2 Wings of Ruin - Riders Hairstyle Lumu Afro (AppID: 1552580)
addappid(1552580)
addappid(1552580, 1, "eebbc56e2ba86b23d9e7ef658a38a2050c9b0c178f006b521e895e23b0a4da40") -- Monster Hunter Stories 2 Wings of Ruin - Riders Hairstyle Lumu Afro - DLC16
setManifestid(1552580, "6023603766664640097", 0)
-- Monster Hunter Stories 2 Wings of Ruin - Riders Hairstyle Mizutsune Braid (AppID: 1552581)
addappid(1552581)
addappid(1552581, 1, "fea2bed6275772f94b0e897db74f9362e4ac2bacd5bdc0a6b054422984124f22") -- Monster Hunter Stories 2 Wings of Ruin - Riders Hairstyle Mizutsune Braid - DLC17
setManifestid(1552581, "7150885687942998366", 0)
-- Monster Hunter Stories 2 Wings of Ruin - Riders Hairstyle Mohawk Kulu (AppID: 1552582)
addappid(1552582)
addappid(1552582, 1, "9782c3fdbc44991e070ad9b14ab1edc33b591c4b2ece9117177ec65052326c01") -- Monster Hunter Stories 2 Wings of Ruin - Riders Hairstyle Mohawk Kulu - DLC18
setManifestid(1552582, "4356439379269885765", 0)
-- Monster Hunter Stories 2 Wings of Ruin - Character Edit Ticket One-Pack (AppID: 1552583)
addappid(1552583)
addappid(1552583, 1, "a6bff6bd9accf870d97d7409cd341af100d99ebaabd1314bba446d87d31bbc98") -- Monster Hunter Stories 2 Wings of Ruin - Character Edit Ticket One-Pack - DLC19
setManifestid(1552583, "3589201796155399737", 0)
-- Monster Hunter Stories 2 Wings of Ruin - Character Edit Ticket Two-Pack (AppID: 1552584)
addappid(1552584)
addappid(1552584, 1, "19ade8a8026b834f630404e1e352b1f31b0bdf72244ac84711769c71f080025d") -- Monster Hunter Stories 2 Wings of Ruin - Character Edit Ticket Two-Pack - DLC20
setManifestid(1552584, "3407043936975497130", 0)
-- Monster Hunter Stories 2 Wings of Ruin - Character Edit Ticket Three-Pack (AppID: 1552585)
addappid(1552585)
addappid(1552585, 1, "e1c37014f164b1ae30ed2b880f5392540bd10904258fae5db4febe15ab20998a") -- Monster Hunter Stories 2 Wings of Ruin - Character Edit Ticket Three-Pack - DLC21
setManifestid(1552585, "6285297111413710435", 0)
-- Monster Hunter Stories 2 Wings of Ruin - Launch Starter Pack (AppID: 1552588)
addappid(1552588)
addappid(1552588, 1, "e955a3f3bcb25a160e417b944e41012e7d6d910786136f163a725d8822d2b061") -- Monster Hunter Stories 2 Wings of Ruin - Launch Starter Pack - DLC22
setManifestid(1552588, "8154005847181404831", 0)