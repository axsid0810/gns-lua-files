-- 17460's Lua and Manifest Created by Hubcap Manifest
-- Mass Effect (2007)
-- Created: September 29, 2025 at 23:52:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(17460) -- Mass Effect (2007)
-- MAIN APP DEPOTS
addappid(17461, 1, "b2984ca279c5780917e0d8b1d37281ac2600c18a7b174a0fafa4b407b4616600") -- Mass Effect content
setManifestid(17461, "3291123364866001389", 10662874887)
addappid(17462, 1, "15fba131deac12f505b2c641d03931b26733d644af3ccc72734e0ccbf5cf78eb") -- Mass Effect English
setManifestid(17462, "1494229070932282596", 2474807)
addappid(17463, 1, "2246aee293b06db3a9cc2588f0a9eb15ccb60f7b2ca44e1aaeee765943a33e22") -- Mass Effect Spanish
setManifestid(17463, "8862550287626042070", 3963751)
addappid(17464, 1, "5aa17cd19143d61105440d65580d2e7aa38dd0912ced242ae77c4a8a62c5fcc8") -- Mass Effect German
setManifestid(17464, "875616295590085358", 2651312551)
addappid(17465, 1, "d72351f6844b8159271b23668d1ee985dc5d0e5ff07d2d635a420c96b733723b") -- Mass Effect French
setManifestid(17465, "2275238411588356044", 2888920604)
addappid(17466, 1, "ce90e0ac9b588ed519637077b97cf02b36feee4e725a98b2f3d6536e8e2f1b6f") -- Mass Effect Italian
setManifestid(17466, "2709237609878894253", 2665044758)