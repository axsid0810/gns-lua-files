-- 231430's Lua and Manifest Created by Hubcap Manifest
-- Company of Heroes 2
-- Created: June 12, 2026 at 16:25:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 76
-- Total DLCs: 84
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(231430, 1, "cc68db08231658448b2e7ef8f065890cb59ca6cd106fe8d6acf51c0f27c747d5") -- Company of Heroes 2
-- MAIN APP DEPOTS
addappid(231447, 1, "3892484fe0c3c624d4c94ae46647524326cd68af6d38ba96643e733c03827c26") -- Company of Heroes 2 MP Content [DLC 231452, 287370, 287371]
setManifestid(231447, "6697523075240533043", 3892235522)
addappid(231431, 1, "d29fe5a3e9e3d8a16034b964cc9f3585541987c7fe721aa87304804e0ae8d228") -- Company of Heroes 2 Core Content, Binaries
setManifestid(231431, "8741640619455108217", 26577851594)
addappid(231432, 1, "36a81f6b470f66e122633dc1211efc39a7f802aa8e1be52c374350f634957345") -- Company of Heroes 2 English Content
setManifestid(231432, "5019658887857002473", 1463199231)
addappid(231433, 1, "a364b8dc97ef7fa8b0b74b48c9d76884a27c54e4a94425a6c6dda111e13ad8ec") -- Company of Heroes 2 French Content
setManifestid(231433, "3179671774019521227", 1453598877)
addappid(231434, 1, "c8ace2af252bc75914a683d38aff00100b581539b1b2d0767efdcbc22021ac40") -- Company of Heroes 2 Italian Content
setManifestid(231434, "7231953433516233045", 6440952)
addappid(231435, 1, "6c92de5858f24940e6cbffe5a8ca8196f6e4dd7a2bd58d43690740d05bc7aa73") -- Company of Heroes 2 German Content
setManifestid(231435, "5650000307948778017", 1523880970)
addappid(231436, 1, "c8cec87b23b2a1967bfdcaf2fd6bc36e7cde2c74e3c8043e07cdae2a0d6a5e64") -- Company of Heroes 2 Spanish Content
setManifestid(231436, "4252596086575879306", 1656337323)
addappid(231437, 1, "2c1421fca223307be7dfb2a468cd5503be878e9da1fabfda28192682d4dd9a2b") -- Company of Heroes 2 Polish Content
setManifestid(231437, "2521660887150067732", 1462448307)
addappid(231438, 1, "6a6b6f9d544a4fbb506cc8e30bc1401ea65cec346f4bf35aa40dbe3bfa5b882a") -- Company of Heroes 2 Russian Content
setManifestid(231438, "2466820434614789632", 1380691839)
addappid(231439, 1, "fd1c54f5a0dd80fdfc8299d03a651e8188525f810c3a2930fa8e7329b1e5dcab") -- Company of Heroes 2 Czech Content
setManifestid(231439, "6292255100494849796", 5928836)
addappid(231440, 1, "ecfbc11e77377b3453e0b4b77e686065090d58aa7012a6297718e300ec173473") -- Company of Heroes 2 Full Game Content [DLC 231451]
setManifestid(231440, "2312806561886337710", 8223658703)
addappid(231441, 1, "0a149901620ca1dae714a9f1419b4e4785a53c57455e0cfc2a76d72d39280388") -- Company of Heroes 2 Campaign English Content [DLC 231451]
setManifestid(231441, "7691072594576207274", 156636969)
addappid(231442, 1, "b2be3c419239f00111f7079d15639f2d80748ed106061a802262a96d188e0a79") -- Company of Heroes 2 Campaign French Content [DLC 231451]
setManifestid(231442, "1536201260471962147", 144848990)
addappid(231443, 1, "c1ea0c0d78e114704186f9437de723e3ffc8077743f5826b75a77f7dd80ae15c") -- Company of Heroes 2 Campaign German Content [DLC 231451]
setManifestid(231443, "4217823074376348015", 144506934)
addappid(231444, 1, "150b6b3bee7f84298c8ff1547861e66f9886ab6a152ce1097792b2e513ffa1df") -- Company of Heroes 2 Campaign Spanish Content [DLC 231451]
setManifestid(231444, "1058166320799047860", 158613130)
addappid(231445, 1, "745080c7fb59aaff83c5c84dff16fe1987cfc09500aea48ba06f3e12b0003c1c") -- Company of Heroes 2 Campaign Polish Content [DLC 231451]
setManifestid(231445, "6232259886571915561", 143959498)
addappid(231446, 1, "5436b223ba0cdd5db9d92940067a7ff1a145c3509aeb0d772be90a4517359d79") -- Company of Heroes 2 Campaign Russian Content [DLC 231451]
setManifestid(231446, "2044883682820209223", 142265167)
addappid(231448, 1, "bd7ed9bf36759887e74424c1dc37a4a41f33cd92ed061ba873103c0c03b597ec") -- Mac Company of Heroes 2 Core Content
setManifestid(231448, "5466691802857192112", 27295304080)
addappid(231449, 1, "1d4b7626faa18169ff34eead83f4f2df74717d2a410dc866c4d38303494eaa17") -- Mac Company of Heroes 2 Binaries
setManifestid(231449, "2954655457837923500", 100955499)
addappid(249095, 1, "04cae141cc2e47cfef4d6f8825fa219d3fe3161c531064d063ea1704a7217aa6") -- Mac Company of Heroes 2 English
setManifestid(249095, "1482811871700069296", 1463198697)
addappid(249096, 1, "38ddee1321f3eda6dda7ca19bc11b054ef153a2fdfa5be8da281675a11364d20") -- Mac Company of Heroes 2 Full Game Content
setManifestid(249096, "832314926440604840", 8438070768)
addappid(249097, 1, "018b1c569588e74435a09e390053770900742e073045b4ec253c95659bddb166") -- Mac Company of Heroes 2 Campaign English
setManifestid(249097, "3782733415553498945", 156636969)
addappid(249098, 1, "778f52d3501691f52bd6e5ae7537ec1c8ec3ab4d03886b986c2e65ed192814a0") -- Linux Company of Heroes 2 Core Content
setManifestid(249098, "4385011003760855667", 27295397996)
addappid(249099, 1, "0dfcc4cc077292c4a8f31f862c34ac96181cc2237cebc35047dffe6c03b6ec56") -- Linux Company of Heroes 2 Binaries
setManifestid(249099, "2587339750325794059", 694689260)
addappid(249118, 1, "e40ad30b46b4d84855b3bbc9ed39c89df07eb279ce0a6924f81c0af8b227a656") -- Linux Company of Heroes 2 English
setManifestid(249118, "9045198813159533741", 1463198697)
addappid(249119, 1, "ee2a1a913badccf14c183bd508465f5910b6df6f3186d275163e229d4a4c9128") -- Linux Company of Heroes 2 Full Game Content
setManifestid(249119, "5650306614312749582", 8438070768)
addappid(260295, 1, "0cd7e99a6f42858f62ee5b5b19acc6eecae4bfaebafa4fcb970bf1ed243acbee") -- Linux Company of Heroes 2 Campaign English
setManifestid(260295, "5745158845803345788", 156636969)
addappid(260296, 1, "c56e8fd51e8feac536bbc1e17f30a4e40cb65e5e78632ea0d5522108c1f260c6") -- Mac Company of Heroes 2 French
setManifestid(260296, "7318340483215847434", 1453598495)
addappid(260297, 1, "7ec936a8f0bdf056fdf9a8d4da41137abecc97eded9bfad783b1f5f1b3ed82c8") -- Mac Company of Heroes 2 Italian
setManifestid(260297, "7360371194723565523", 6440604)
addappid(260298, 1, "9c041823c820aebfb88e6eca1c0c852865b28d3f0ddd979f85e9661c7fd292ff") -- Mac Company of Heroes 2 German
setManifestid(260298, "8275495102182435470", 1523880604)
addappid(260299, 1, "c145a608622741a492c8c800e7d9ea6b31d2be7907fb4276e411e15c56e085e9") -- Mac Company of Heroes 2 Spanish
setManifestid(260299, "5906943912161062341", 1656337001)
addappid(287372, 1, "f9a39f833cdafc884eaec14670d2c48496463f0233c4812d49f42732daea17d9") -- Mac Company of Heroes 2 Polish
setManifestid(287372, "7014240372643026565", 1462447981)
addappid(287373, 1, "0f76e9d9cabcae9d0643f904910a07064d3ccc7d97b70e1aa311922a2ea3c5fe") -- Mac Company of Heroes 2 Russian
setManifestid(287373, "3011311655439513040", 1380691553)
addappid(287374, 1, "aa47a20f6f2b549020b645ce727bb74f1cabfc1de9af6fc5178d79353d64f972") -- Mac Company of Heroes 2 Czech
setManifestid(287374, "3095526753742535955", 5928534)
addappid(287375, 1, "48d18d213e0bae4ef973b003cff1fc316fde24bc9eff9865972008dcde8f8840") -- Mac Company of Heroes 2 Campaign French
setManifestid(287375, "4189002293823642513", 144848990)
addappid(287376, 1, "7bb828908bd78660fec3cf893b6f4c9dbb472c484e39dca9d6172786ebe3374a") -- Mac Company of Heroes 2 Campaign German
setManifestid(287376, "63192925181818470", 144506934)
addappid(287377, 1, "24fcefd01dd9aa0e333b4d4592877419deb08e75709d4ad8d04ea8d346b53795") -- Mac Company of Heroes 2 Campaign Spanish
setManifestid(287377, "772110558442842658", 158613130)
addappid(287378, 1, "03f110196d5c5b49ed653fa1a7993ccaf38ceeb195e28233aeca845ff2e1bf8a") -- Mac Company of Heroes 2 Campaign Polish
setManifestid(287378, "6407232489600135954", 143959498)
addappid(287379, 1, "10da2999b886d50fae66069859da508cf3f968f6d902964f4d0ad59a2fcc78fd") -- Mac Company of Heroes 2 Campaign Russian
setManifestid(287379, "1647427615643075481", 142265167)
addappid(297528, 1, "492d477d0fce5593f70796a8e4ab6d0b3c2f29cb3db4e7191c07ddb33d4938b0") -- Linux Company of Heroes 2 French
setManifestid(297528, "8272750681505302026", 1453598495)
addappid(319600, 1, "ab0caace4467896103838a8c7ff0fb6f84c71bb92058f8e7b1f481ed73694b7b") -- Company of Heroes 2 AA Content
setManifestid(319600, "8396237154919544411", 2849902828)
addappid(319601, 1, "7d4cd7571017853a38e9500732c3661147a0ce54486fa6bc25aafbed54ca8d46") -- Company of Heroes 2 AA English
setManifestid(319601, "2775732798062837531", 286114351)
addappid(319602, 1, "23e9ddf2947dadc94607b67499bbb6b0bf4d5e26f04e675dd2b8237fb532da99") -- Company of Heroes 2 AA French
setManifestid(319602, "2132325941425839173", 269371455)
addappid(319603, 1, "10b62ac24bbda6c49e83caafc21d05d47a1948fe614484257a64e30f0a9eb918") -- Company of Heroes 2 AA German
setManifestid(319603, "4391703216476581531", 271913659)
addappid(319604, 1, "311c1ea1ad1e2ad161aa9c5388c6d7c522b78190f809982560c10ed8b4f69ce3") -- Company of Heroes 2 AA Spanish
setManifestid(319604, "316835511213856142", 285254298)
addappid(319605, 1, "18a2b7746cfd8332bbf893b395754633252179fa069e3b8500159d40af531336") -- Company of Heroes 2 AA Polish
setManifestid(319605, "6049459304364210629", 288991377)
addappid(319606, 1, "3e0414960fdef76b68ce80468305e8a6a8fe6c558652b1e5d2ceb23459290e08") -- Company of Heroes 2 AA Russian
setManifestid(319606, "5593000356241197441", 272320118)
addappid(317851, 1, "23ff14e8d061742755486d2f222cdba4486201bfdba96afd21db9cecf760ac3c") -- Mac Company of Heroes 2 AA Content
setManifestid(317851, "6039351015381439908", 1442210870)
addappid(317852, 1, "4b6b99ecfc7fc3ecd692db9c6a1afd5bbfdd57d542d85a2e664e61ac39c90a1e") -- Mac Company of Heroes 2 AA English
setManifestid(317852, "6334242277894919354", 286114351)
addappid(317853, 1, "c68f1e1b678d728c76aa135cbd7ccdaf1d451d61fc9b55fdd8a5d243ab2305b3") -- Mac Company of Heroes 2 AA French
setManifestid(317853, "5661992087902857238", 269371455)
addappid(317854, 1, "4bb99cfb7d28a3f039ba1a5a4016a68ca05a16e4cd65b471b215ed316727cbb6") -- Mac Company of Heroes 2 AA German
setManifestid(317854, "2250300428128787911", 271913659)
addappid(317855, 1, "32894707fdb53f0c41ac7cd665f9d057f320f0ebffb55a69823ce0346695405e") -- Mac Company of Heroes 2 AA Spanish
setManifestid(317855, "1107788777719830343", 285254298)
addappid(317856, 1, "5019ca09040694453747bc110d9caa9f863d6ba905ca03133a6cd33586b70b9b") -- Mac Company of Heroes 2 AA Polish
setManifestid(317856, "6243674026782761223", 288991377)
addappid(317857, 1, "3e76f49d07b80428ea5243af2ab35b21b91e8de0c9eadd64d91d55f75dadca8e") -- Mac Company of Heroes 2 AA Russian
setManifestid(317857, "189914477902114787", 272320118)
addappid(317858, 1, "0f7f82d0cc3e4b66bbe83dceaafa94a194a85b64c4cad1b5d41a931010dd0bf3") -- Linux Company of Heroes 2 Italian Content
setManifestid(317858, "5000963213105349618", 6440604)
addappid(317859, 1, "b92af8c8b0f9cd4427611037777974c73a95cc307c33a940e326a3be40a2f314") -- Linux Company of Heroes 2 German Content
setManifestid(317859, "7464273777798156842", 1523880604)
addappid(319607, 1, "0ccaf5ab897c31eb0e4a813c151520faee9d808ef4854d1cb6a6baafb2548872") -- Linux Company of Heroes 2 Spanish Content
setManifestid(319607, "638329630907223551", 1656337001)
addappid(319608, 1, "73b173ab46618ce48c09bd2a94b16a73d86aeb67054700ad2a5cbe79421ea1ab") -- Linux Company of Heroes 2 Polish Content
setManifestid(319608, "6803040299018183723", 1462447981)
addappid(319609, 1, "e0d4fa38a0eb64acda3aa801118e38f2b00d1535552ca7a65c4ed5349bb8a350") -- Linux Company of Heroes 2 Russian Content
setManifestid(319609, "6220324423697880336", 1380691553)
addappid(319610, 1, "c7df660490af8511e3fb5526320bf4e87ab158712b84fa06e671da168117b000") -- Linux Company of Heroes 2 Czech Content
setManifestid(319610, "4490627408313547509", 5928534)
addappid(319611, 1, "3ac2ec8ee55f49cbcd52de67dc2f0f318013c18aebea2c5c78f6125678d58b15") -- Linux Company of Heroes 2 Campaign French Content [DLC 231451]
setManifestid(319611, "5428591234539126628", 144848990)
addappid(319612, 1, "1cc56a82a14459e5bfb41ac81b148ced05c28e4887417a6abd42d9b58655bac0") -- Linux Company of Heroes 2 Campaign German Content [DLC 231451]
setManifestid(319612, "9177831894938033924", 144506934)
addappid(319613, 1, "3b3ba05c6e5817c3bdad5bb063965f5af60e9db1e82de5780ee1f3151722a753") -- Linux Company of Heroes 2 Campaign Spanish Content [DLC 231451]
setManifestid(319613, "8190721072602956915", 158613130)
addappid(319614, 1, "4bca289f9d9038b26dfe8aa886b29520a974e4c8abaaf1c99a428d4e08a177a1") -- Linux Company of Heroes 2 Campaign Polish Content [DLC 231451]
setManifestid(319614, "8503404105909224649", 143959498)
addappid(319615, 1, "51824c70f8e0bfc5c438358c61bd47c408e3c71a795704ab1605f77d76b080c8") -- Linux Company of Heroes 2 Campaign Russian Content [DLC 231451]
setManifestid(319615, "4755459077191693129", 142265167)
addappid(319616, 1, "33e716e5406b6a2eb5a947dc6417f2284306804ca415617984598da81a95bc79") -- Linux Company of Heroes 2 AA Content
setManifestid(319616, "983517441026794958", 1442210870)
addappid(319617, 1, "ad5f09cf3da6d3996e7a1f961fb50a03db98cf63c2667dd362aec414be97b3e2") -- Linux Company of Heroes 2 AA English
setManifestid(319617, "8774567918694677739", 286114351)
addappid(319618, 1, "52a6d370f531ffe7674a96373f1e13f446aa23d84d488f368c2a90be08eabbc2") -- Linux Company of Heroes 2 AA French
setManifestid(319618, "444946186181836063", 558362832)
addappid(319619, 1, "9e028e1158066d7b0ddb6d18bd84626a57e8b3d6ddc9391fd97c537baade9bd4") -- Linux Company of Heroes 2 AA German
setManifestid(319619, "5781735798427959557", 271913659)
addappid(323231, 1, "b9be3ee42ad8710c73570ca12d2bb1574275c2bd1333752a2346522f1b6a64ca") -- Linux Company of Heroes 2 AA Spanish
setManifestid(323231, "2185843156147239406", 285254298)
addappid(323232, 1, "604f16973fc2783e0376a64bb4a175854cb948176350c054dd6e45a3511d15d6") -- Linux Company of Heroes 2 AA Polish
setManifestid(323232, "2216944565851138145", 288991377)
addappid(323233, 1, "3a8aa3d5f1da84b748a8b9903d05c4219dcc1f80390560f7c723c4fe09ae9385") -- Linux Company of Heroes 2 AA Russian
setManifestid(323233, "2980646045865790183", 272320118)
addappid(323234, 1, "a1dba99d8ba9ea88e6d1f0c6052858e9c40f95f507dcf7a75614b1f25fa39426") -- Mac MP Content [DLC 231452, 287370, 287371]
setManifestid(323234, "1875151220888740212", 4106647587)
addappid(323235, 1, "3d397992b5c0da4c7d642ad48b34edab2c5e4bd65f4140117313d47d7fba9b4a") -- Linux MP Content [DLC 231452, 287370, 287371]
setManifestid(323235, "4398282446236566224", 4106647587)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(231453) -- Company of Heroes 2 - German Skin (H) Three Color Ambush Pattern
addappid(231454) -- Company of Heroes 2 - Soviet Skin (M) Winter Whitewash Voronezh Front
addappid(231455) -- Company of Heroes 2 - German Commander Storm Doctrine
addappid(231456) -- Company of Heroes 2 - Soviet Commander Armored Assault Tactics
addappid(231457) -- Company of Heroes 2 - German Skin (L) Late War Factory Pattern
addappid(231458) -- Company of Heroes 2 - German Skin (M) Late War Factory Pattern
addappid(231459) -- Company of Heroes 2 - German Commander Fortified Armor Doctrine
addappid(231460) -- Company of Heroes 2 - Soviet Commander Conscripts Support Tactics
addappid(231461) -- Company of Heroes 2 - Soviet Commander Mechanized Support Tactics
addappid(231462) -- Company of Heroes 2 - Soviet Commander Anti-Infantry Tactics
addappid(231463) -- Company of Heroes 2 - Soviet Commander Terror Tactics
addappid(231464) -- Company of Heroes 2 - German Commander Joint Operations Doctrine
addappid(231465) -- Company of Heroes 2 - German Commander Lightning War Doctrine
addappid(231466) -- Company of Heroes 2 - German Commander Spearhead Doctrine
addappid(231467) -- Company of Heroes 2 - Soviet Skin (L) Three Color Leningrad Front
addappid(231468) -- Company of Heroes 2 - Soviet Skin (M) Three Color Leningrad Front
addappid(231469) -- Company of Heroes 2 - Soviet Skin (H) Three Color Leningrad Front
addappid(231470) -- Company of Heroes 2 - Soviet Skin (H) Winter Cobblestone West Front
addappid(231471) -- Company of Heroes 2 - Soviet Skin (H) Two Tone Bryansk Front
addappid(231472) -- Company of Heroes 2 - Soviet Skin (M) Three Color Northwestern Front
addappid(231473) -- Company of Heroes 2 - Soviet Skin (M) Four Color Belorussian Front
addappid(231474) -- Company of Heroes 2 - German Skin (H) Late War Factory Pattern
addappid(231475) -- Company of Heroes 2 - German Skin (H) Field Applied Whitewash Pattern
addappid(231476) -- Company of Heroes 2 - German Skin (H) Three Color Disruptive Pattern
addappid(231477) -- Company of Heroes 2 - German Skin (L) Four Color Disruptive Pattern
addappid(231478) -- Company of Heroes 2 - German Skin (H) Winter Ambush Pattern
addappid(231479) -- Company of Heroes 2 - Case Blue Mission Pack
addappid(231480) -- Company of Heroes 2 - Victory at Stalingrad Mission Pack
addappid(231481) -- Company of Heroes 2 - Soviet Skin (L) Four Color Belorussian Front
addappid(231482) -- Company of Heroes 2 - Soviet Skin (H) Four Color Belorussian Front
addappid(231483) -- Company of Heroes 2 - German Skin (L) Three Color Ambush Pattern
addappid(231484) -- Company of Heroes 2 - German Skin (M) Four Color Disruptive Pattern
addappid(231485) -- Company of Heroes 2 - German Skin (H) Four Color Disruptive Pattern
addappid(231486) -- Company of Heroes 2 - German Skin (L) Winter Ambush Pattern
addappid(231487) -- Company of Heroes 2 - German Skin (M) Winter Ambush Pattern
addappid(231488) -- Company of Heroes 2 - Soviet Skin (L) Winter Whitewash Voronezh Front
addappid(231489) -- Company of Heroes 2 - Soviet Skin (H) Winter Whitewash Voronezh Front
addappid(231490) -- Company of Heroes 2 - Soviet Skin (L) Three Color Northwestern Front
addappid(231491) -- Company of Heroes 2 - Soviet Skin (H) Three Color Northwestern Front
addappid(231492) -- Company of Heroes 2 - German Skin (M) Three Color Ambush Pattern
addappid(231504) -- Company of Heroes 2 - Faceplate Studded
addappid(231505) -- Company of Heroes 2 - Faceplate Twisted Gold
addappid(231506) -- Company of Heroes 2 - Faceplate Chainlink
addappid(231507) -- Company of Heroes 2 - Faceplate Engraved
addappid(249081) -- Company of Heroes 2 - Soviet Commander Counterattack Tactics
addappid(249082) -- Company of Heroes 2 - Soviet Commander Industry Tactics
addappid(249083) -- Company of Heroes 2 - Soviet Commander Urban Defense Tactics
addappid(249085) -- Company of Heroes 2 - German Commander Mechanized Assault Doctrine
addappid(249086) -- Company of Heroes 2 - German Commander Osttruppen Doctrine
addappid(249087) -- Company of Heroes 2 - German Commander Luftwaffe Supply Doctrine
addappid(249088) -- Company of Heroes 2 - German Commander Elite Troops Doctrine
addappid(249090) -- Company of Heroes 2 - Soviet Commander Partisan Tactics
addappid(249092) -- Company of Heroes 2 - Soviet Commander Tank Hunter Tactics
addappid(249094) -- Company of Heroes 2 - German Commander Encirclement Doctrine
addappid(249100) -- Company of Heroes 2 -  German Skin (L) Voronezh Improvised Pattern
addappid(249101) -- Company of Heroes 2 - German Skin (M) Voronezh Improvised Pattern
addappid(249102) -- Company of Heroes 2 - German Skin (H) Voronezh Improvised Pattern
addappid(249103) -- Company of Heroes 2 - German Skin (L) Case Blue Summer Pattern
addappid(249104) -- Company of Heroes 2 - German Skin (M) Case Blue Summer Pattern
addappid(249105) -- Company of Heroes 2 - German Skin (H) Case Blue Summer Pattern
addappid(249106) -- Company of Heroes 2 - German Skin (L) Stalingrad Winter Pattern
addappid(249107) -- Company of Heroes 2 - German Skin (M) Stalingrad Winter Pattern
addappid(249108) -- Company of Heroes 2 - German Skin (H) Stalingrad Winter Pattern
addappid(249109) -- Company of Heroes 2 - Soviet Skin (L) Two Tone Don Front
addappid(249110) -- Company of Heroes 2 - Soviet Skin (M) Two Tone Don Front
addappid(249111) -- Company of Heroes 2 - Soviet Skin (H) Two Tone Don Front
addappid(249112) -- Company of Heroes 2 - Soviet Skin (L) Two Tone Spring Front
addappid(249113) -- Company of Heroes 2 - Soviet Skin (M) Two Tone Spring Front
addappid(249114) -- Company of Heroes 2 - Soviet Skin (H) Two Tone Spring Front
addappid(249115) -- Company of Heroes 2 - Soviet Skin (L) Makeshift Sand Southern Front
addappid(249116) -- Company of Heroes 2 - Soviet Skin (M) Makeshift Sand Southern Front
addappid(249117) -- Company of Heroes 2 - Soviet Skin (H) Makeshift Sand Southern Front
addappid(260290) -- Company of Heroes 2 - Southern Fronts Mission Pack
addappid(260291) -- Company of Heroes 2 - British Commander Vanguard Operations Regiment
addappid(260292) -- Company of Heroes 2 - British Commander Tactical Support Regiment
addappid(260293) -- Company of Heroes 2 - British Commander Special Weapons Regiment
addappid(297510) -- CoH 2 - US Forces Commander Recon Support Company
addappid(297511) -- CoH 2 - US Forces Commander Mechanized Company
addappid(297512) -- CoH 2 - US Forces Commander Rifle Company
addappid(297513) -- CoH 2 - OKW Commander Elite Armor Doctrine
addappid(297514) -- CoH 2 - OKW Commander Scavenge Doctrine
addappid(297515) -- CoH 2 - OKW Commander Fortifications Doctrine
addappid(691110) -- Company of Heroes 2 - Whale and Dolphin Conservation Charity Pattern Pack
addappid(691120) -- Company of Heroes 2 - David Sheldrake Trust Charity Pattern Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(323236) -- Depot 323236 (empty depot)
-- addappid(323237) -- Depot 323237 (empty depot)