-- 3764200's Lua and Manifest Created by Hubcap Manifest
-- Resident Evil Requiem
-- Created: July 22, 2026 at 02:08:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 2
-- Shared Depots: 1
-- Blacklisted Depots: 4
--   Depot 3764202, 3764204, 3764205, 3764206: Blacklisted

-- MAIN APPLICATION
addappid(3764200, 1, "d29b7ad461b8b74dce38b7137fc00d4b5a885c5be1211767a4ecae0eaf8ddd96") -- Resident Evil Requiem
-- MAIN APP DEPOTS
addappid(3764201, 1, "bdf443ffde6449192b9863c0fa5e3cda31fdaa5e4d33e5bcded62dc2085b7cb8") -- Depot 3764201
setManifestid(3764201, "2990234554016452841", 79384590628)
addappid(3764203, 1, "b2e820287e6e3f32d1ccb3f2f8c95ec3783e8c0a75abab5d311a0a648626fd92") -- Depot 3764203
setManifestid(3764203, "1507402407513694495", 3971584081)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- DLCS WITH DEDICATED DEPOTS
-- Resident Evil Requiem - Graces Costume Apocalypse (AppID: 3990800)
addappid(3990800)
addappid(3990800, 1, "f5bf116706491176c9eee46a96fe1faa70b3f771d75ccb34f0c8962097a907e5") -- Resident Evil Requiem - Graces Costume Apocalypse - Depot 3990800
setManifestid(3990800, "9181787779883827112", 154141549)
-- Resident Evil Requiem - Deluxe Kit (AppID: 3990820)
addappid(3990820)
addappid(3990820, 1, "9ae4713cb4114effdd34d1cd54dbda8a560f27a05aef06fbaa0370748f69d15c") -- Resident Evil Requiem - Deluxe Kit - Depot 3990820
setManifestid(3990820, "509708311968316285", 989393708)