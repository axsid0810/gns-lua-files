-- 403640's Lua and Manifest Created by Hubcap Manifest
-- Dishonored 2
-- Created: September 29, 2025 at 07:56:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 17
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(403640) -- Dishonored 2
-- MAIN APP DEPOTS
addappid(531614, 1, "5df1167dc992c6a47481f360077cf8959da86e42b96e5507971e2992c9b4440a") -- Dishonored 2 Depot-common-exe
setManifestid(531614, "2793343286160593659", 458568304)
addappid(531331, 1, "35f48f15595210f9f136fcae710bc752de3578abcf7cf7d4d4cd746a7365841f") -- Dishonored 2 Depot-Common-0
setManifestid(531331, "2963729611279531718", 4360841508)
addappid(531332, 1, "114c03a6d0de557654950b295feb6207e81624b2b3ac305ff41953554bc1053a") -- Dishonored 2 Depot-Common-1
setManifestid(531332, "323898925697266621", 34798966426)
addappid(531333, 1, "fa13d85c1332888850c232c5fe0611ed89d8015c300e7af90e4fe02d75820894") -- Dishonored 2 Depot-english
setManifestid(531333, "3073290089482226863", 5645319103)
addappid(531334, 1, "047f03056e35322bac5e476072f72205d1df9a0ef21d26b389bc06d7d943e3ad") -- Dishonored 2 Depot-french
setManifestid(531334, "1509347611848056991", 5660701821)
addappid(531335, 1, "854c87a23e557b35f530ccfa9300a3ffd79596205a696f12f2bbad771caf8716") -- Dishonored 2 Depot-german
setManifestid(531335, "8579808409801044094", 5757798160)
addappid(531336, 1, "fd11dbbc5b226de1bea8c35593b63810fc8d81211d166b3bb5bc1518a016b6da") -- Dishonored 2 Depot-italian
setManifestid(531336, "4349704254291745693", 5852462553)
addappid(531337, 1, "6611c655d3ea1590eea5de2beb57bf8360abbdb2dfd7a01ffd1e508edc2482f0") -- Dishonored 2 Depot-spanish
setManifestid(531337, "2261057237457725075", 5855832785)
addappid(531338, 1, "648a0738049d38c0395254aed4d642772a800b03ec6b1000ac4748411cb00970") -- Dishonored 2 Depot-latinamericanspanish
setManifestid(531338, "1596516164424361891", 5736171268)
addappid(531339, 1, "0704507f25342821cfae2d55fdfcc1ca9f4535e112b33a204c2cd621e558ee42") -- Dishonored 2 Depot-polish
setManifestid(531339, "4011700633239816288", 5758809821)
addappid(531610, 1, "c0ce722ee82c73745c34464d065725464660e1b7271d7d953e5609969bc9bf45") -- Dishonored 2 Depot-russian
setManifestid(531610, "7003273961168830067", 5856671554)
addappid(531611, 1, "6d08d6bdebc39be173564f0375fe938dc1a07edfcf367bebe4e732a7e11c4783") -- Dishonored 2 Depot-brazilian
setManifestid(531611, "8314867122492112307", 5768792417)
addappid(531612, 1, "a11dc394ccd530c33cb40961da9e45e4c55d8007fe39273f164524873e104652") -- Dishonored 2 Depot-chinese
setManifestid(531612, "733220252853249822", 3697724270)
addappid(531613, 1, "13e4d61e4ed6adc86c9597f023e3bc1a53c5400802ea57aca8a36b77974369c9") -- Dishonored 2 Depot-japanese
setManifestid(531613, "3244959933273624495", 5522037402)
addappid(531615, 1, "6c3150443fc3d186d46ff8d8ab2d7b3bfc750e5743e8649c4ad5b11c65a88cc1") -- Dishonored 2 Depot-common-exe-debug
setManifestid(531615, "6377159365043874055", 124204544)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(531330) -- Dishonored 2 Assassins Pack  ( PreOrder )