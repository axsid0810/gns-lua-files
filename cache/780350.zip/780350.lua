-- 780350's Lua and Manifest Created by Hubcap Manifest
-- Unruly Heroes
-- Created: April 05, 2026 at 09:32:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(780350, 1, "888e07745cf2b77da95becaf0e09592da9246bcc7416c38503d86b8d9e7669e9") -- Unruly Heroes
addtoken(780350, "2832215086443470009")
-- MAIN APP DEPOTS
addappid(780351, 1, "c857f55911a12daf25b8f121bb1af4157c9f2c79ad28bb37f755968c9b7620a8") -- Unruly Heroes Content
setManifestid(780351, "2631603953725722654", 2911148711)
addappid(780352, 1, "435c9f9bb62db83000b76f253d351aa510af3573a1783e89933fce851f7868a2") -- Dépôt : Unruly Heroes - Soundtrack contents
setManifestid(780352, "32146365779700725", 174407638)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1165650) -- Depot 1165650 (empty depot)