-- 3017860's Lua and Manifest Created by Hubcap Manifest
-- DOOM: The Dark Ages
-- Created: July 09, 2026 at 21:19:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3017860, 1, "ce570e5aa3168b1e9c8d2004a3b93db4c11a44cf8b9a99158ae4c1baf9384dbb") -- DOOM: The Dark Ages
-- MAIN APP DEPOTS
addappid(3017862, 1, "b537907a613fd29911d2e311eb41fd2f0b309324601b0ef164c8520562eac290") -- Depot 3017862
setManifestid(3017862, "823870443514057064", 382475683)
addappid(3017863, 1, "0c010bdf1623542793fb5765875c715494c4a6c78856f75c124aa7d31f3021cd") -- Depot 3017863
setManifestid(3017863, "9175922958236864967", 402)
addappid(3017864, 1, "35f0d11b6d2b729dd8e5f50a21e7b0300e8d6b79fc6ba487f4198ca6d3402c0d") -- Depot 3017864
setManifestid(3017864, "4051834565771554326", 12269058907)
addappid(3017865, 1, "558521d6ef4cac7a1318bb55268dc878b72482482691e7791ea81bff06c73694") -- Depot 3017865
setManifestid(3017865, "6508691013012284956", 0)
addappid(3017866, 1, "cc9112a06785fd0d7f6e24a50702f1f71e655e35caf8fb3ea09f6036680c0fe4") -- Depot 3017866
setManifestid(3017866, "51450828051076476", 232)
addappid(3017867, 1, "8ffa78f10846725bed8d48d1a182cf4088f770691c44561b2d167f84fdc60789") -- Depot 3017867
setManifestid(3017867, "572084946963546298", 93285095093)
addappid(3017868, 1, "fb3bda82e733857d05419dce15179a1aa642b840af21ef69520346fe8a00e20e") -- Depot 3017868
setManifestid(3017868, "4881802900089150766", 79792482)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3363930) -- DOOM The Dark Ages - Preorder Content
addtoken(3363930, "3317585234173034770")
addappid(3363940) -- DOOM The Dark Ages - Premium Content
addtoken(3363940, "4257299237979279538")
addappid(3469450) -- DOOM The Dark Ages  Revelations
addappid(3698350) -- DOOM The Dark Ages - Premium Upgrade
addtoken(3698350, "553470768921816577")