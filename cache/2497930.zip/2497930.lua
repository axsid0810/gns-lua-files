-- 2497930's Lua and Manifest Created by Hubcap Manifest
-- The Grey Dream
-- Created: July 19, 2026 at 13:03:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2497930, 1, "63f5b56e2726c38a55725dae7e2226a47bb97a41018940840357133c261b2ed5") -- The Grey Dream
-- MAIN APP DEPOTS
addappid(2497931, 1, "af80d4af1a25de8531c4635be4ee9237e8e5b2df826acb45008de83fdd34e40d") -- Depot 2497931
setManifestid(2497931, "4800952743076927811", 16714461096)
-- DLCS WITH DEDICATED DEPOTS
-- The Grey Dream- 4k Wallpaper Set (AppID: 3964510)
addappid(3964510)
addappid(3964511, 1, "d9633b8154127132b4779250c9220aabd1f6fa799d38232530a039842fed5a94") -- The Grey Dream- 4k Wallpaper Set - Depot 3964511
setManifestid(3964511, "319425197634658470", 508641895)