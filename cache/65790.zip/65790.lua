-- 65790's Lua and Manifest Created by Hubcap Manifest
-- Arma: Cold War Assault Remastered
-- Created: July 17, 2026 at 08:46:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(65790, 1, "a504b1373481a9a626419099147d515d81398ee306e0e7f824c8c3e193c8e50e") -- Arma: Cold War Assault Remastered
-- MAIN APP DEPOTS
addappid(65791, 1, "4875303350f459c37a78d1edc36d9de1dd33f0bf39c8fd5f67f392c2e7eedc1a") -- ARMA Cold War Assault depot
setManifestid(65791, "1533415511670551255", 1846875726)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(65792) -- Depot 65792 (empty depot)