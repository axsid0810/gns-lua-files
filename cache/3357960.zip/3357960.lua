-- 3357960's Lua and Manifest Created by Hubcap Manifest
-- KuloNiku
-- Created: June 24, 2026 at 08:44:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3357960, 1, "16362348818fe998b1968d8e3bf420a2b4aaa582fc11abb5994245244e691fe3") -- KuloNiku
-- MAIN APP DEPOTS
addappid(3357961, 1, "41063b5ba12ea1c0eccad05185cf132f3fcd41b3644350c5befbb95fb84831e7") -- Depot 3357961
setManifestid(3357961, "4608643152900832402", 1370992294)
addappid(3357962, 1, "a6d0f76a2bf8ca8fdfb4701e1c9f7f1044b2c323679684a22bedde0adad21e68") -- Depot 3357962
setManifestid(3357962, "7440087138291894302", 1511720870)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- KuloNiku Bowl Up Digital Artbook (AppID: 4338290)
addappid(4338290)
addappid(4338290, 1, "a69565beed99a120a154851e248277eeecc74e003a75d4004616ad0db4ad0726") -- KuloNiku Bowl Up Digital Artbook - Depot 4338290
setManifestid(4338290, "2580728851850102583", 184305582)