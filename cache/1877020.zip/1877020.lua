-- 1877020's Lua and Manifest Created by Hubcap Manifest
-- Jujutsu Kaisen Cursed Clash
-- Created: November 20, 2025 at 01:05:28 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 7
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1877020) -- Jujutsu Kaisen Cursed Clash
-- MAIN APP DEPOTS
addappid(1877021, 1, "f4499035fd1470f7dd2681e390fbbb1cd5160885c4f5b9fcc25183bc557e1568") -- Depot 1877021
setManifestid(1877021, "300403150815350108", 18829622983)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Jujutsu Kaisen Cursed Clash - Digital Artbook  Soundtrack (AppID: 2544910)
addappid(2544910)
addappid(2544910, 1, "93b392c3ea70c794465f9b051e69db14b421062bc65bb03ebfdb25f7b70cf119") -- Jujutsu Kaisen Cursed Clash - Digital Artbook  Soundtrack - Depot 2544910
setManifestid(2544910, "1001922753729079767", 345323520)
-- Jujutsu Kaisen Cursed Clash - Jujusta 2024 (AppID: 2544920)
addappid(2544920)
addappid(2544920, 1, "410c45819542016f665d18953ecc4e08cc691f93f9952ceb7085309cfff121a5") -- Jujutsu Kaisen Cursed Clash - Jujusta 2024 - Depot 2544920
setManifestid(2544920, "4521389808478466249", 180530179)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2441230) -- Jujutsu Kaisen Cursed Clash - Jujutsu High First-Years Outfit Set
addappid(2579320) -- Jujutsu Kaisen Cursed Clash - Hidden InventoryPremature Death
addappid(2579330) -- Jujutsu Kaisen Cursed Clash - Shibuya Incident
addappid(2579350) -- Jujutsu Kaisen Cursed Clash - Anime Ending Theme 1 Outfit Set
addappid(2579360) -- Jujutsu Kaisen Cursed Clash - Kyoto Jujutsu High School Girls Outfit Set