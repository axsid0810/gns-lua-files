-- 213610's Lua and Manifest Created by Hubcap Manifest
-- Sonic Adventure™ 2 
-- Created: September 30, 2025 at 18:19:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(213610) -- Sonic Adventure™ 2 
-- MAIN APP DEPOTS
addappid(213611, 1, "62f1345bc9ba1ad0629de28584b42ae616b50160113d7735b6eda7f0e9434117") -- alpha
setManifestid(213611, "2881461178350562369", 3253731096)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(217900) -- Sonic Adventure 2 Battle Mode DLC