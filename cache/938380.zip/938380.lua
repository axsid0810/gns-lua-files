-- 938380's Lua and Manifest Created by Hubcap Manifest
-- Townsmen - A Kingdom Rebuilt
-- Created: October 01, 2025 at 03:01:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 1
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(938380) -- Townsmen - A Kingdom Rebuilt
-- MAIN APP DEPOTS
addappid(938381, 1, "e2343bc799cc70578f3f833d189447740e9824c230493046aec23b8698c5b545") -- Townsmen - A Kingdom Rebuilt
setManifestid(938381, "3407797103975419192", 1428376222)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- OpenAL 2.0.7.0 Redist (Shared from App 228980)
setManifestid(229020, "5799761707845834510", 810085)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1176670) -- Townsmen - A Kingdom Rebuilt The Seaside Empire