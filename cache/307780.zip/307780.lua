-- 307780's Lua and Manifest Created by Hubcap Manifest
-- Mortal Kombat X
-- Created: July 21, 2026 at 23:13:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 24
-- Total DLCs: 27 (29 excluded)
-- Shared Depots: 2
-- Blacklisted Depots: 29
--   Depot 349160, 349170, 349171, 349172, 349173, 349174, 349175, 349176, 349177, 351557, 351559, 351560, 351561, 351562, 351563, 351564, 354410, 354411, 354412, 354414, 354415, 354416, 354417, 354418, 354419, 354420, 354421, 354428, 354429: not available to the public

-- MAIN APPLICATION
addappid(307780, 1, "43952d7a2565b4900e2acd3c5fee7da8e3c1e0cdc655fd5427d56c03ba8dbda5") -- Mortal Kombat X
-- MAIN APP DEPOTS
addappid(307781, 1, "1f7f19a9bf864918c90642857c72f26158edb7fad42c654c3e7b8223b22082fd") -- Mortal Kombat X
setManifestid(307781, "5624529206982116192", 4467885694)
addappid(307782, 1, "b7d533efdd22f4207278d2b7af52a5c93640666b36c168b959de01431f2ccda5") -- Mortal Kombat X Executable Depot
setManifestid(307782, "6159674384328955878", 10679174)
addappid(307783, 1, "efe55fd4dc5501e4c50424d0c60e5c358c60f555ad66ce9a22378fed90804fb9") -- Mortal Kombat X Scripts Depot
setManifestid(307783, "1816684884894923223", 32173968790)
addappid(307784, 1, "8d29fc1cac2b2a2e6d39047616eb83fa4c83ff6cb1d74bd1453ecf9c192e61ed") -- Ultra
setManifestid(307784, "3401281719433326658", 46280436286)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Character - Jason Voorhees (AppID: 347150)
addappid(347150)
addtoken(347150, "5056622398946101340")
addappid(347150, 1, "567f828cb5fb9f8101da5853b9a1275d3838c209dac533643a82b4d8c238cada") -- Character - Jason Voorhees - Character - Jason Vorhees (347150) Depot
setManifestid(347150, "4338267348866793457", 240)
-- Coarse (Gold) Scorpion (AppID: 347152)
addappid(347152)
addtoken(347152, "18058496923834980440")
addappid(347152, 1, "50dc18e35d2e4757c4e64865d5d6a6cc03e1b981530f98ab137928b51f611ee1") -- Coarse (Gold) Scorpion - Coarse (Gold) Scorpion (347152) Depot
setManifestid(347152, "3968766527137329761", 256)
-- Kollective Kold War Scorpion (AppID: 347153)
addappid(347153)
addtoken(347153, "6584886949805697405")
addappid(347153, 1, "d6827248f56319531816742fc89c2844a46a074d4e9cb751755538dd19ff04ac") -- Kollective Kold War Scorpion - Kollective Kold War Scorpion (347153) Depot
setManifestid(347153, "8805752485552318169", 256)
-- Unlock All Krypt Content (AppID: 347154)
addappid(347154)
addtoken(347154, "3732130513757837914")
addappid(347154, 1, "d42212674617019709b240ed2ae0603bd7fe3ec9910503cc566b0a1d064eabc2") -- Unlock All Krypt Content - Unlock Krypt Content (347154) Depot
setManifestid(347154, "2367601758245063172", 22912)
-- Blue Steel Sub-Zero (AppID: 347155)
addappid(347155)
addtoken(347155, "15778906085675687591")
addappid(347155, 1, "f080434be373fcc4c5e96ab2c6ed4948806fa0f599655cd78e90280119f71384") -- Blue Steel Sub-Zero - Blue Steel Sub-Zero (347155) Depot
setManifestid(347155, "6694947482485861674", 256)
-- Character - Goro (AppID: 347890)
addappid(347890)
addtoken(347890, "16789513768132101430")
addappid(347890, 1, "42b1469fc20df168c0800d4fbc82ca39f7b7518f06e2a3d858632f83c15bfc08") -- Character - Goro - Character - Goro (347890) Depot
setManifestid(347890, "9019825025781604845", 288)
-- Character - Predator (AppID: 351550)
addappid(351550)
addtoken(351550, "2498884398632749421")
addappid(351550, 1, "54a9ebd379096a411ae1e67d93a1bf2f50cc3b4bacccd17928a23b599441394a") -- Character - Predator - Character - Predator (351550) Depot
setManifestid(351550, "8357497103448333710", 256)
-- Character - Tanya (AppID: 351551)
addappid(351551)
addtoken(351551, "12129372819771042838")
addappid(351551, 1, "0947a73c31343a6ad0be7282b34c316e14ced5474c0c07c8d40878bd463753a3") -- Character - Tanya - Character - Tanya (351551) Depot
setManifestid(351551, "4993234369582644430", 256)
-- Character - Tremor (AppID: 351552)
addappid(351552)
addtoken(351552, "8700712936055303222")
addappid(351552, 1, "0c1192c5b43741770032760077c924160390a9a380b6a4b825c8ef3c48ed602a") -- Character - Tremor - Character - Tremor (351552) Depot
setManifestid(351552, "443867069664371166", 256)
-- Skin Pack - Brazil (AppID: 351553)
addappid(351553)
addtoken(351553, "3434961170868107438")
addappid(351553, 1, "fdd70c2164677e35183d1082e3bc37a3d5f0b8913b6b7e36157309c8bb7c41a1") -- Skin Pack - Brazil - Skin Pack - Brazil (351553) Depot
setManifestid(351553, "8998990461481944590", 368)
-- Skin Pack - Klassic Skins 1 (AppID: 351554)
addappid(351554)
addtoken(351554, "145169343468324499")
addappid(351554, 1, "cdffabc419554361aa64c9afdb49c77f2712c37a123af9834f244e0df7402a6d") -- Skin Pack - Klassic Skins 1 - Skin Pack - Klassic Skins 1 (351554) Depot
setManifestid(351554, "4748821729091936932", 368)
-- Skin Pack - Kold War (AppID: 351555)
addappid(351555)
addtoken(351555, "5086585344312368935")
addappid(351555, 1, "3458669120d39f55f18cdbadad33f57e49df28386576485cc2fe7b5016f144a1") -- Skin Pack - Kold War - Skin Pack - Kold War (351555) Depot
setManifestid(351555, "6960533188296214475", 368)
-- Skin Pack - Samurai (AppID: 351556)
addappid(351556)
addtoken(351556, "8777790268329434580")
addappid(351556, 1, "19dda8794a786b7f624caac1bf7808cdcf153195b68ab05c1cf6f17a0ec6f353") -- Skin Pack - Samurai - Skin Pack - Samurai (351556) Depot
setManifestid(351556, "9098838434890469410", 432)
-- Klassic Fatalities 1 (AppID: 351558)
addappid(351558)
addtoken(351558, "11088132336965508389")
addappid(351558, 1, "b750b2890a4757f4e6c22150deb6e904c87dc00708fdd124bac4ba1004777f1b") -- Klassic Fatalities 1 - Klassic Fatalities 1 (351558) Depot
setManifestid(351558, "7593285350191767262", 448)
-- Klassic Fatalities 2 (AppID: 354413)
addappid(354413)
addappid(354413, 1, "e6e51d0adcf4e849a719110e9558d04d1afcf3bccbfa8ebe6235f1531c10d0ee") -- Klassic Fatalities 2 - Klassic Fatalities 2 (354413) Depot
setManifestid(354413, "3458388745384864636", 432)
-- Skin Pack - Horror Skins (AppID: 354425)
addappid(354425)
addtoken(354425, "3672485219721651993")
addappid(354425, 1, "53d201ab259e97138748462c1057e239aa382d9ed22e6bd208bf583ed7c240da") -- Skin Pack - Horror Skins - Skin Pack - Horror Skins (354425) Depot
setManifestid(354425, "7342610577311621078", 368)
-- Skin Pack - Klassic Skins 2 (AppID: 354426)
addappid(354426)
addtoken(354426, "373211202759467881")
addappid(354426, 1, "e034af50242c1fc1dd701d027734e31c5391559e6add5c48bffef0ca87237f35") -- Skin Pack - Klassic Skins 2 - Skin Pack - Klassic Skins 2 (354426) Depot
setManifestid(354426, "7125000413805663899", 368)
-- Skin Pack - Prey Skins (AppID: 354427)
addappid(354427)
addtoken(354427, "7531775044434075858")
addappid(354427, 1, "ff20a63957fc349d3bf2ac512655b58f979e69b49d715d4a4805a25228c9b7d3") -- Skin Pack - Prey Skins - Skin Pack - Prey Skins (354427) Depot
setManifestid(354427, "7423120599132382125", 368)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(347880) -- Kombat Pack
addtoken(347880, "18019291952406674729")
addappid(524260) -- Triborg
addappid(524270) -- Alien
addappid(524280) -- BoRai Cho
addappid(524290) -- Leatherface
addappid(524300) -- Apocalypse Pack
addappid(524310) -- Cosplay Pack
addappid(524320) -- Krimson Ermac
addappid(524620) -- Kombat Pack 2
addtoken(524620, "11579146367400593429")
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MANIFEST BLACKLIST)
-- addappid(349160) -- DLC 349160 (not available to the public)
-- addappid(349170) -- DLC 349170 (not available to the public)
-- addappid(349171) -- DLC 349171 (not available to the public)
-- addappid(349172) -- DLC 349172 (not available to the public)
-- addappid(349173) -- DLC 349173 (not available to the public)
-- addappid(349174) -- DLC 349174 (not available to the public)
-- addappid(349175) -- DLC 349175 (not available to the public)
-- addappid(349176) -- DLC 349176 (not available to the public)
-- addappid(349177) -- DLC 349177 (not available to the public)
-- addappid(351557) -- DLC 351557 (not available to the public)
-- addappid(351559) -- DLC 351559 (not available to the public)
-- addappid(351560) -- DLC 351560 (not available to the public)
-- addappid(351561) -- DLC 351561 (not available to the public)
-- addappid(351562) -- DLC 351562 (not available to the public)
-- addappid(351563) -- DLC 351563 (not available to the public)
-- addappid(351564) -- DLC 351564 (not available to the public)
-- addappid(354410) -- DLC 354410 (not available to the public)
-- addappid(354411) -- DLC 354411 (not available to the public)
-- addappid(354412) -- DLC 354412 (not available to the public)
-- addappid(354414) -- DLC 354414 (not available to the public)
-- addappid(354415) -- DLC 354415 (not available to the public)
-- addappid(354416) -- DLC 354416 (not available to the public)
-- addappid(354417) -- DLC 354417 (not available to the public)
-- addappid(354418) -- DLC 354418 (not available to the public)
-- addappid(354419) -- DLC 354419 (not available to the public)
-- addappid(354420) -- DLC 354420 (not available to the public)
-- addappid(354421) -- DLC 354421 (not available to the public)
-- addappid(354428) -- DLC 354428 (not available to the public)
-- addappid(354429) -- DLC 354429 (not available to the public)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(524260) -- Depot 524260 (empty depot)
-- addappid(524270) -- Depot 524270 (empty depot)
-- addappid(524280) -- Depot 524280 (empty depot)
-- addappid(524290) -- Depot 524290 (empty depot)
-- addappid(524300) -- Depot 524300 (empty depot)
-- addappid(524310) -- Depot 524310 (empty depot)
-- addappid(524320) -- Depot 524320 (empty depot)