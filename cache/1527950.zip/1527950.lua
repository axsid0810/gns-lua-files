-- 1527950's Lua and Manifest Created by Hubcap Manifest
-- Wartales
-- Created: May 23, 2026 at 00:37:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 8
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1527950, 1, "df3fb79e39a23369ab2a734aa3168b065638b173cb7cc3842a16f676adbfbeee") -- Wartales
-- MAIN APP DEPOTS
addappid(1527951, 1, "95bd24e7b06dd6b363b41cd5735569fe66f9d030ec1b11d30e46c13171a17852") -- Wartales Content
setManifestid(1527951, "2317441591605854526", 36787330908)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2692400) -- Wartales - Expansion Pirates of Belerion
addappid(2903960) -- Wartales - Contract The Tavern Opens
addappid(3112270) -- Wartales - Contract The Pits
addappid(3335020) -- Wartales - Expansion The Skelmar Invasion
addappid(3559560) -- Wartales - Contract The Beast Hunt
addappid(3899740) -- Wartales - Contract The Fief
addappid(4165520) -- Wartales - Expansion The Curse of Rigel
addappid(4490120) -- Wartales - Contract Fires in the Capital