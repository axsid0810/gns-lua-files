-- 1240440's Lua and Manifest Created by Hubcap Manifest
-- Halo Infinite
-- Created: May 09, 2026 at 23:21:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 27
-- Total DLCs: 3
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1240440, 1, "df6670b56421a0d34de2480fb3340ffa1c09cf5dff7bb88b02c09020f72e377f") -- Halo Infinite
-- MAIN APP DEPOTS
addappid(1240441, 1, "c9057fb7f913b73308cadca3c570080625c8fae45f6c74566a09dfa53c32955d") -- MGS B Content
setManifestid(1240441, "1980983269570462659", 52901629828)
addappid(1240442, 1, "243d9c5e3471cd043ee1b68cd8f90e554d9ab609db437f8d924308b9138ecf31") -- MGS B - German
setManifestid(1240442, "3310217600695701879", 1067511801)
addappid(1240443, 1, "13d292be5865d7885f18cb099d5bcb1b04686cda1506527b8d7981037f66aef3") -- MGS B - LatAm
setManifestid(1240443, "1961174997092173120", 1078305253)
addappid(1240444, 1, "7c766c3a686dd5d78c495422079cc8b1182264ab5d20d17aa9f80078345a3cdb") -- MGS B - French
setManifestid(1240444, "2127237357151868035", 973178497)
addappid(1240445, 1, "52c69d4eb4dc7c3449a0b8cfe338e139bef9bf1b43d4a0e6b5b0d2f9bdef9d28") -- MGS B - Italian
setManifestid(1240445, "6212087839736214815", 1083182767)
addappid(1240446, 1, "601def2df97fb3bbb9e042cb35cbe7f4ecacd0b72e874dfec0f6b8e4bbda18e2") -- MGS B - Japanese
setManifestid(1240446, "5961114131542256223", 974356912)
addappid(1240447, 1, "4e26fcbe95d2092ed6d62ee9f8d44ffd4b670867da475668eff83eed204d2ca1") -- MGS B - Korean
setManifestid(1240447, "8536732866283005504", 965697022)
addappid(1240448, 1, "4085c3f1d38cddd7dfdc14271a323647e278fa0d148bb1ec76a1c20c9c80f36f") -- MGS B - Brazilian
setManifestid(1240448, "7099774409191523370", 1028898631)
addappid(1240449, 1, "a2ca5a0bc11e8e1e762847fbee7d7e42ef23a53eaebc37511e3b6ad82428287f") -- MGS B - TChinese
setManifestid(1240449, "363057356585956965", 1011724806)
addappid(1521610, 1, "c992a878945cb00883e5aa4eafd2763236a07d40a16756b94d1991cfd0fbbf5c") -- MGS B - Spanish
setManifestid(1521610, "6475830760600214425", 1097170807)
addappid(1521611, 1, "78b25a92d0f659f2f9fb9d74dd56720378bb542cba178c25028d3bcfe1ca48b2") -- MGS B - SChinese
setManifestid(1521611, "7393915373152469083", 963555085)
addappid(1521622, 1, "669c414852ee54ea00569920f9501d9dafe4afc48255999073212a05c93b141c") -- Depot 1521622
setManifestid(1521622, "3939133919175594196", 1116289359)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- Multiplayer High-Res Textures (AppID: 1708090)
addappid(1708090)
addappid(1708090, 1, "36a49d974f8aae5465b880bbdc0fe5e221d314d88c1984ef9d24013be2acf178") -- Multiplayer High-Res Textures - MGS B HD (1708090) Depot
setManifestid(1708090, "7773694383796788865", 19856846627)
-- Halo Infinite (Campaign) (AppID: 1708091)
addappid(1708091)
addappid(1708091, 1, "13689863bcd84ee19b33fe68d8b8f14ec4755230f04d108d19b9dc8d990a92ca") -- Halo Infinite (Campaign) - MGS B C1 (1708091) Depot
setManifestid(1708091, "6694441511595719145", 26875722225)
addappid(1521612, 1, "da8b25c75240b663d38dc78c908985d8610cae32268119e9b59900a42e593479") -- Halo Infinite (Campaign) - MGS B C1 - German
setManifestid(1521612, "6226236412227213094", 1453039076)
addappid(1521613, 1, "1338a735e86e43fa8af54c6e46e15f29708c08d91f0b7565f084259e295decef") -- Halo Infinite (Campaign) - MGS B C1 - LatAm
setManifestid(1521613, "2932603352733819859", 1492868157)
addappid(1521614, 1, "b0ec0322409360c0929e2c42d477414e64ec6a20224621d842931a8563187e7b") -- Halo Infinite (Campaign) - MGS B C1 - French
setManifestid(1521614, "1484258721365003910", 1387562896)
addappid(1521615, 1, "9a90eb853d305270c37d7955d146ff5fa366259a5fe900e223c6f7580da4c048") -- Halo Infinite (Campaign) - MGS B C1 - Italian
setManifestid(1521615, "5651415488847273110", 1462024841)
addappid(1521616, 1, "82f6b18ca6681acb7a2427f2c0e1fe5d9232127d28f3da4e1deae2e1cc3a4bdf") -- Halo Infinite (Campaign) - MGS B C1 - Japanese
setManifestid(1521616, "5104787929641177582", 1394512270)
addappid(1521617, 1, "4ffc4e0da16998a077b985b44194ff28ae074bf075623f08e22193f490d080fe") -- Halo Infinite (Campaign) - MGS B C1 - Korean
setManifestid(1521617, "443174564544235007", 1389454986)
addappid(1521618, 1, "0c24f8c80c757e2410b8bb471bc601c1eca6a905c7745b47bb8fe7c3716c0dc5") -- Halo Infinite (Campaign) - MGS B C1 - Brazilian
setManifestid(1521618, "7907859300157572659", 1413869868)
addappid(1521619, 1, "dfe1c1a4d023d38b94b5395e8cc03c45ae48302cf7b7ba0d2299118a85cfb94c") -- Halo Infinite (Campaign) - MGS B C1 - TChinese
setManifestid(1521619, "5318554684921636580", 1414803938)
addappid(1521620, 1, "8e7ee867468c54daccf33444f7837397cd0b961563c68216e79053f7f944678a") -- Halo Infinite (Campaign) - MGS B C1 - Spanish
setManifestid(1521620, "2496236242817095130", 1486244199)
addappid(1521621, 1, "2c764216a68d7cdea6768ab9806971a7ea2cfe039a5ffb50cdd33a5dd96fdde5") -- Halo Infinite (Campaign) - MGS B C1 - SChinese
setManifestid(1521621, "4425839573476823251", 1377006917)
addappid(1521623, 1, "e09b653715eefa5e0f1790855b54b047c294e4c0ce93e4c274709fa5503f7ebd") -- Halo Infinite (Campaign) - Depot 1521623
setManifestid(1521623, "3647146900337896843", 1437262805)
-- Campaign High-Res Textures (AppID: 1708092)
addappid(1708092)
addappid(1708092, 1, "e880614c9c86a278ef067573337c332da19d68c54babf0cf908dab55864cf3d4") -- Campaign High-Res Textures - MGS B C1 HD (1708092) Depot
setManifestid(1708092, "1762720186195751183", 6933384297)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1708120) -- Depot 1708120 (empty depot)