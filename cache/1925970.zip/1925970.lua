-- 1925970's Lua and Manifest Created by Hubcap Manifest
-- SIMULACRA 3
-- Created: September 30, 2025 at 14:18:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1925970) -- SIMULACRA 3
-- MAIN APP DEPOTS
addappid(1925971, 1, "254043307faa3213d0dfc1a82dad0cabd6e19f971124584e152c4eb447129307") -- Depot 1925971
setManifestid(1925971, "6922667797737332094", 3279325657)
-- DLCS WITH DEDICATED DEPOTS
-- The Art of Simulacra (AppID: 2197350)
addappid(2197350)
addappid(2197351, 1, "cfd7a20fcbee50784c802c28ccee79ce4e8bf3d449ea73b626fb51780c926a77") -- The Art of Simulacra - Depot 2197351
setManifestid(2197351, "1659536789600532214", 20454962)