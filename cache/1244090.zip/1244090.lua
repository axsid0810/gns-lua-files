-- 1244090's Lua and Manifest Created by Hubcap Manifest
-- Sea of Stars: Sunset Edition
-- Created: June 08, 2026 at 10:33:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1244090, 1, "59ae19b4c23acc68489b969f85a92d992b48c8b25bbbbfc210e6b4028d87de85") -- Sea of Stars: Sunset Edition
-- MAIN APP DEPOTS
addappid(1244091, 1, "1549d20da14b7d148867bd5c7ae9353bf17b61ca4b5babd432a332beb9ca8b92") -- Depot 1244091
setManifestid(1244091, "8906669486491690617", 4879401530)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Sea of Stars - Digital Artbook (AppID: 2550500)
addappid(2550500)
addappid(2550501, 1, "8b97c6e0dfb7c12208ed1fd619275b1c92564b93971477f777880be9887198ef") -- Sea of Stars - Digital Artbook - Depot 2550501
setManifestid(2550501, "4186430635673826258", 761826673)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3457510) -- Sea of Stars Throes of the Watchmaker DLC