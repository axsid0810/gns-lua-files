-- 1361510's Lua and Manifest Created by Hubcap Manifest
-- Teenage Mutant Ninja Turtles: Shredder's Revenge
-- Created: November 15, 2025 at 18:46:04 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 2
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1361510) -- Teenage Mutant Ninja Turtles: Shredder's Revenge
addtoken(1361510, "2764735786934684318")
-- MAIN APP DEPOTS
addappid(1361511, 1, "5954562e7f5260400040a818bc29b60b335bb690066ff767e20d145a3b6b4af0") -- Depot 1361511
setManifestid(1361511, "5656605350306673283", 1146277612)
addappid(1361512, 1, "9018b1f82166ad29381fd77a36a5ffe47a907a20408c0f20f74799537c9a9d11") -- Depot 1361512
setManifestid(1361512, "8870290572239451681", 61184495)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
-- DLCS WITH DEDICATED DEPOTS
-- Teenage Mutant Ninja Turtles Shredders Revenge - Dimension Shellshock (AppID: 2348930)
addappid(2348930)
addappid(2348930, 1, "cd65db36fbcdc7c86ada27a6e96064807a6576a135f2ac7a4cb204d11173ca26") -- Teenage Mutant Ninja Turtles Shredders Revenge - Dimension Shellshock - Teenage Mutant Ninja Turtles: Shredder's Revenge - Dimension Shellshock
setManifestid(2348930, "495479171435692142", 26900923)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2925190) -- Teenage Mutant Ninja Turtles Shredders Revenge - Radical Reptiles