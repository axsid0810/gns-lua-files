-- 4478640's Lua and Manifest Created by Hubcap Manifest
-- 背包地牢
-- Created: July 22, 2026 at 06:01:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4478640, 1, "a2a9f47e796a172998d1625a2a1f5e9339a21e6a3c93f3b7f19c019e7a2a1f90") -- 背包地牢
-- MAIN APP DEPOTS
addappid(4478641, 1, "0b015c9c08e3a385226039e0964365a4d632fd36ae658e75163cf01ae2e3e0c2") -- Depot 4478641
setManifestid(4478641, "4256772669390169821", 2046958185)
addappid(4478642, 1, "98ac1423bdec0df5ef47ed78c442b647db00d9342970c231caf32d9ac4615851") -- Depot 4478642
setManifestid(4478642, "6105935215879720010", 2047138484)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4478643) -- Depot 4478643 (empty depot)