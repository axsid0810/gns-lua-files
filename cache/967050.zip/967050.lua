-- 967050's Lua and Manifest Created by Hubcap Manifest
-- Pacify
-- Created: July 05, 2026 at 23:37:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(967050, 1, "0cf9b26bb60a50c3432d1102debada1717896dea8e1ba8b017cc2c0c62b1e26c") -- Pacify
-- MAIN APP DEPOTS
addappid(967051, 1, "f96aef139156453d9d43b1bcf8871a2d27acaec7129cc3270b195cddb35654fb") -- Pacify Content
setManifestid(967051, "6010066725450761904", 5973750187)
addappid(967052, 1, "a68832c81999178d3d4e7f79aae6866804866e68ec397a9cb74bb870e0083b60") -- Pacify MacOSX
setManifestid(967052, "7017982105963085031", 2552691071)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)