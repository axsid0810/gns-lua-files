-- 1088850's Lua and Manifest Created by Hubcap Manifest
-- Marvel's Guardians of the Galaxy
-- Created: September 29, 2025 at 23:50:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 22
-- Total DLCs: 5
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1088850) -- Marvel's Guardians of the Galaxy
-- MAIN APP DEPOTS
addappid(1088852, 1, "b10d42aff71758659b54a4860a4146af39a522e0eb6f8bbe4d72a2a7aaeb0aff") -- executable
setManifestid(1088852, "883883770076497119", 705485126)
addappid(1088854, 1, "e032bdc2915afe57d49115af81cece576221c646c03baaeff00200c136da364d") -- en
setManifestid(1088854, "2869030969867946936", 645009424)
addappid(1088855, 1, "fcc9bca31c271729c5e73a125935373c7f9a7792421cc98b01474f3420989b0b") -- fr
setManifestid(1088855, "3356496688599590702", 948134941)
addappid(1088856, 1, "d9a24c09f0d9a4e8571a8fd7543e5b301299b17a481e84a497344f36b894c862") -- it
setManifestid(1088856, "7495124789942393280", 1002417854)
addappid(1088857, 1, "752eab274325cab93a184f97565f4ff6a8ec99ad5f519b0441a8352fd636648a") -- de
setManifestid(1088857, "4643297027783108358", 996073908)
addappid(1088858, 1, "b7f3efcb7519a95999b49a5ca822237f516799deaf1b6001bd26af810ae081cd") -- es
setManifestid(1088858, "1098437716958632149", 1011878013)
addappid(1088859, 1, "ce30d65c86766caa0908dc7a1252246df8594f0755709948f6d23d39555018d0") -- mx
setManifestid(1088859, "4078626998302900105", 977431083)
addappid(1507730, 1, "d76061f3130dae2242fde33d4b34827916ad249a05306baab132d16d0bce170d") -- pt
setManifestid(1507730, "8804142966400379685", 987991034)
addappid(1507731, 1, "abb75fb1008798956403d391e7dce6efcd95b929354ba077e0a24fc753bdc026") -- pl
setManifestid(1507731, "5385423668488448236", 959537193)
addappid(1507732, 1, "ca458d4ecf811f3b67be7a3117150b8ac6a92a4489e20f531b75baf61ee86cab") -- ru
setManifestid(1507732, "7066285968732076610", 959334832)
addappid(1507733, 1, "aa100da1fda995cbe1521650b057d7570db46ab0bfbfd7791b5839ae7560c7d7") -- ja
setManifestid(1507733, "1825794766511732525", 948598815)
addappid(1507734, 1, "c5f5d58826f3d61c09ec0de0f7a6884a32b9177969b5ed1633652c18328811b0") -- tw
setManifestid(1507734, "836054567129931224", 645009424)
addappid(1507735, 1, "97556312e2df9cec76352a5369d93661e227d8acbe3ea031ec8579a40563e729") -- cn
setManifestid(1507735, "4377075944002457670", 645009424)
addappid(1507736, 1, "f6181a7df88ca75b2d3f18df44998c8559473b124d439e3a96b8105be4c6f2ca") -- ar
setManifestid(1507736, "774065928903829710", 645009424)
addappid(1507737, 1, "999bd82fdfe35bef37b4b18c426aa41d1c64d2825811867e0bb7279ec855c802") -- ko
setManifestid(1507737, "9076001828047499406", 645009424)
addappid(1088851, 1, "3a7287702a44ea46f54c1cf8a1f090d417fa92fbf60f092b331b0d234ba74432") -- Marvel's Guardians of the Galaxy Content
setManifestid(1088851, "6686799393439602216", 71275681971)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- Marvels Guardians of the Galaxy Throwback Guardians Outfit Pack (AppID: 1619190)
addappid(1619190)
addtoken(1619190, "9745382861964955708")
addappid(1619190, 1, "12a3f7ebbb5817c4ab754fb5169c91ff028c1cf3676d0c124500d4c8d581380b") -- Marvels Guardians of the Galaxy Throwback Guardians Outfit Pack - Marvel's Guardians of the Galaxy DLC: Pre-Order Content (1619190) Depot
setManifestid(1619190, "7239391781827319858", 6618)
-- Marvels Guardians of the Galaxy Digital Deluxe Upgrade (AppID: 1619191)
addappid(1619191)
addappid(1619191, 1, "39502ab6ec3f030b17de0167f2c4b60811e48c801f7b4ab35b1395362f762af7") -- Marvels Guardians of the Galaxy Digital Deluxe Upgrade - Marvel's Guardians of the Galaxy DLC: Deluxe Upgrade Content (1619191) Depot
setManifestid(1619191, "7733539840491623640", 6662)
-- Marvels Guardians of the Galaxy Social-Lord Outfit (AppID: 1651480)
addappid(1651480)
addtoken(1651480, "3380113388993074274")
addappid(1651480, 1, "cf4b7e755de24784bf415599301df283d57019c7b77f9c2433b47bfdcbb67c0a") -- Marvels Guardians of the Galaxy Social-Lord Outfit - Marvel's Guardians of the Galaxy DLC: Digital Stores DLC (1651480) Depot
setManifestid(1651480, "1031927654853023705", 6479)
-- Marvels Guardians of the Galaxy Sleek-Lord Outfit (AppID: 1739140)
addappid(1739140)
addtoken(1739140, "2102018810190535314")
addappid(1739140, 1, "60dcbe3e406a98f54746326405cebe41d83a2480c9d1c0fdffacb8319a278b27") -- Marvels Guardians of the Galaxy Sleek-Lord Outfit - Marvel's Guardians of the Galaxy DLC: Sleek-Lord (1739140) Depot
setManifestid(1739140, "2058567624234068976", 6443)
-- Marvels Guardians of the Galaxy The Hits - Original Video Game OST  Mini Artbook (Digital Download)  (AppID: 1802230)
addappid(1802230)
addtoken(1802230, "7955750983110720939")
addappid(1802230, 1, "92da5f31b74336c2ec2f5ba86d6a19e33ebaab540867f29ddafb008fe932ae0b") -- Marvels Guardians of the Galaxy The Hits - Original Video Game OST  Mini Artbook (Digital Download)  - Marvel's Guardians of the Galaxy: OST-Artbook (1802230) Depot
setManifestid(1802230, "4026017625854196958", 359338282)