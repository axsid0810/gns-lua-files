-- 2581950's Lua and Manifest Created by Hubcap Manifest
-- Tiny Aquarium
-- Created: June 27, 2026 at 02:50:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(2581950, 1, "7b550472762b59a1fe4bf4349c92355806102bb739d3733503d49158298de911") -- Tiny Aquarium
-- MAIN APP DEPOTS
addappid(2581952, 1, "8ed572ef0cd138022a5bec468f7e8b882ec28a56a821f5a26c0766ce76482926") -- Depot 2581952
setManifestid(2581952, "4824915111949802964", 588456696)
addappid(2581951, 1, "e8511d4f6805a7b2784f13c911e4ea56aae9abf075ecbd8e211e0cc1204761a1") -- Depot 2581951
setManifestid(2581951, "5533038204650432986", 636169088)
addappid(2581953, 1, "d7f909fd71a803094ad3d8cd020890fb283e2986a7f0016324438a4922b5e541") -- Depot 2581953
setManifestid(2581953, "5912086615017233739", 720027637)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3873570) -- Tiny Aquarium Supporters Pack
addappid(4315160) -- Tiny Aquarium Swamplands Supporters Pack