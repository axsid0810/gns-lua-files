-- 2808550's Lua and Manifest Created by Hubcap Manifest
-- Sudden Strike 5
-- Created: July 15, 2026 at 09:05:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1 (1 excluded)

-- MAIN APPLICATION
addappid(2808550) -- Sudden Strike 5
-- MAIN APP DEPOTS
addappid(2808551, 1, "6f01f75fe7246ca6d21d8cbfc7849afa96c1dc9ce12a7b4b43004e26f14ee905") -- Depot 2808551
setManifestid(2808551, "3844632680257727230", 17381646575)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4108030) -- Sudden Strike 5 - Deluxe Edition Upgrade
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4519150) -- Sudden Strike 5 - France: Road to Liberation (unreleased)