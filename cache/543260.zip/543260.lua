-- 543260's Lua and Manifest Created by Hubcap Manifest
-- Wonder Boy: The Dragon's Trap
-- Created: October 01, 2025 at 07:56:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(543260) -- Wonder Boy: The Dragon's Trap
-- MAIN APP DEPOTS
addappid(543261, 1, "8be7d52c9a7bf3194f869abb115ae09f54626a3b66ec8a241a2cf74a7efb154f") -- Wonder Boy: The Dragon's Trap - Game
setManifestid(543261, "3274044032442995862", 1080394705)
addappid(543262, 1, "beb8f036efa9a1c124619b6dba8c790b2786e6e79d0ef519fa8dc294ab457558") -- Wonder Boy: The Dragon's Trap - Linux
setManifestid(543262, "5905071087488895056", 1034985480)
addappid(543263, 1, "d6402d545e59f3d1a085f4f560829abc548f99ec853fef2334907b6f644e8828") -- Wonder Boy: The Dragon's Trap - Mac
setManifestid(543263, "3684180650374126441", 1032390009)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Wonder Boy The Dragons Trap - Soundtrack (AppID: 649330)
addappid(649330)
addappid(649331, 1, "c292030cbfa95379c9b0fd90a9389d7b7b75f054c37a444ad12035f6306c1951") -- Wonder Boy The Dragons Trap - Soundtrack - Wonder Boy: The Dragon's Trap - Soundtrack 2cd
setManifestid(649331, "8062191866051468446", 1066643602)