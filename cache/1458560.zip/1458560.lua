-- 1458560's Lua and Manifest Created by Hubcap Manifest
-- I'm on Observation Duty 3
-- Created: July 04, 2026 at 21:24:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1458560) -- I'm on Observation Duty 3
-- MAIN APP DEPOTS
addappid(1458561, 1, "66ed816de6e8e4e6a935743efc8d034882889e3a3f57503b18a45503817d9a01") -- I'm on Observation Duty 3
setManifestid(1458561, "1634308565532396321", 4348323805)
addappid(1458562, 1, "c659209d7e5195034bc1e43e3ba1523feb0cf252fd1f7022149e5b2245c1f670") -- I'm on Observation Duty 3 v1.1
setManifestid(1458562, "3197603452313491648", 2214469815)
addappid(1458563, 1, "36c3e5ec096fa476ccbbc06c015ab74a1610486ff54ff8d26a9f04e059333c37") -- I'm on Observation Duty 3 mac
setManifestid(1458563, "4003092775289655983", 2189656306)