-- 1330470's Lua and Manifest Created by Hubcap Manifest
-- F.I.S.T.: Forged In Shadow Torch
-- Created: September 29, 2025 at 11:13:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1330470) -- F.I.S.T.: Forged In Shadow Torch
-- MAIN APP DEPOTS
addappid(1330471, 1, "90bde5ea2666baa460c9476da114f0a78a6b63f314fcfb7456c0f499841e5dfb") -- 暗影火炬城 Content
setManifestid(1330471, "7692433695764366161", 23033805726)
addappid(1330472, 1, "2ee73d4dd8b85b4d1601563faf22a7a679a33f4fafe1766746e8e448e4a79bcb") -- Depot 1330472
setManifestid(1330472, "1202866964769506825", 23183559601)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)