-- 1003400's Lua and Manifest Created by Hubcap Manifest
-- The Lord of the Rings: Journeys in Middle-earth
-- Created: March 16, 2026 at 13:22:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(1003400, 1, "87bb6984228ab5e7a90345fda6ac679ddd345569cb4f8f25e910dd356bd2be84") -- The Lord of the Rings: Journeys in Middle-earth
-- MAIN APP DEPOTS
addappid(1003401, 1, "1ba7e5c64a6e397cbd8af2bf4e943562600d7efa1f535ced2366ac2f9fa6b0fb") -- The Lord of the Rings: Journeys in Middle-earth Windows Depot
setManifestid(1003401, "7964025798069977394", 621975665)
addappid(1003402, 1, "35c580aad67f4fca90002036eb2c62a2898803ead88b76746de2b7b8f6e03736") -- The Lord of the Rings: Journeys in Middle-earth OSX Depot
setManifestid(1003402, "6179076051723559005", 657937797)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1067010) -- Journeys in Middle-earth - Hunt for the Ember Crown
addappid(1436460) -- Journeys in Middle-earth - Haunting of Dale
addappid(2114780) -- Journeys in Middle-earth - Poison Promise