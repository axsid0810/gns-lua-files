-- 1257810's Lua and Manifest Created by Hubcap Manifest
-- I'm on Observation Duty 2
-- Created: July 02, 2026 at 05:46:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1257810) -- I'm on Observation Duty 2
-- MAIN APP DEPOTS
addappid(1257811, 1, "ca283519b62168c290e90922f82c8b70f8380777562c183b87c191d39a97440c") -- I'm on Observation Duty 2: Timothy's Revenge Content
setManifestid(1257811, "4119325072066060976", 1030778588)
addappid(1257812, 1, "c03f6eb51c153928d5f3aaa3d122d8e41e42c932c257b74c66654bc3c60f9013") -- I'm on Observation Duty 2: Timothy's Revenge Linux
setManifestid(1257812, "1656785001840277025", 1097714380)
addappid(1257813, 1, "fbe9cb86088e9a4a3dff2aa4dd48dd4351a4fb173f1562cd97d3c6ac89b4f3d8") -- I'm on Observation Duty 2: Timothy's Revenge mac
setManifestid(1257813, "50330623995641620", 1055962853)