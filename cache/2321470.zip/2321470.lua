-- 2321470's Lua and Manifest Created by Hubcap Manifest
-- Deep Rock Galactic: Survivor
-- Created: June 22, 2026 at 10:33:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(2321470, 1, "1b437453d839af65b6e35906a8fc5d3164e50eccfd31493fdd4868e1958c7df1") -- Deep Rock Galactic: Survivor
-- MAIN APP DEPOTS
addappid(2321471, 1, "18154d412c1c3c3719d8f05c119354536a5228cdd169ca75488708a215c1cddf") -- Depot 2321471
setManifestid(2321471, "2170332834079432460", 3431021684)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2782850) -- Deep Rock Galactic Survivor - Supporter Pack
addappid(3818560) -- Deep Rock Galactic Survivor - After Hours Pack
addappid(4395500) -- Deep Rock Galactic Survivor - Heavy Duty Expansion