-- 1250410's Lua and Manifest Created by Hubcap Manifest
-- Microsoft Flight Simulator (2020)
-- Created: March 13, 2026 at 04:11:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 2
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1250410, 1, "8a8884d351f799545f675d56310da7e1749995d652576641056ee35cba44fa4f") -- Microsoft Flight Simulator (2020)
-- MAIN APP DEPOTS
addappid(1250411, 1, "dbf9d5a5cae7eab44d452bfe53856e4b08b448ac7c224124316ca8cf3f91b3a8") -- Chucky Content
setManifestid(1250411, "4980418302200182124", 2131626194)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1265910) -- DLC2
addtoken(1265910, "14285234326855878141")
addappid(1265911) -- Microsoft Flight Simulator Deluxe
addtoken(1265911, "10866014101006598775")
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1250412) -- Depot 1250412 (empty depot)
-- addappid(1250413) -- Depot 1250413 (empty depot)
-- addappid(1250414) -- Depot 1250414 (empty depot)
-- addappid(1250415) -- Depot 1250415 (empty depot)