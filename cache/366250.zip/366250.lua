-- 366250's Lua and Manifest Created by Hubcap Manifest
-- METAL SLUG
-- Created: September 30, 2025 at 00:29:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(366250) -- METAL SLUG
-- MAIN APP DEPOTS
addappid(366251, 1, "18bc66a5022fe72217b5b96fc8037949a0c72eaa950794ea50710fb49048a126") -- METAL SLUG Content
setManifestid(366251, "2905929974020898780", 68841626)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)