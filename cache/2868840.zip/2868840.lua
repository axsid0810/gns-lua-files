-- 2868840's Lua and Manifest Created by Hubcap Manifest
-- Slay the Spire 2
-- Created: June 18, 2026 at 21:31:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2868840, 1, "efe405b7cd4ee75b6961f28ad8ba9aa57a9e57057857dbd921e56ad3b347cd3b") -- Slay the Spire 2
-- MAIN APP DEPOTS
addappid(2868843, 1, "6e4518ed758f09a3fb1c07ed1ef14a8ccfb4bac6e1fc452adc1e1d8a1c024e42") -- Depot 2868843
setManifestid(2868843, "7881097836989620034", 2096907945)
addappid(2868842, 1, "7036cfd5ff85a70ca002aeddf573311c3906b0f7d8d83d099592e759ddca5b31") -- Depot 2868842
setManifestid(2868842, "8653035385353091849", 2323747842)
addappid(2868841, 1, "ed043fd4ac0899cd0b5fc59d5407115ff4f87793b162ba16fe49c7e2893938ab") -- Depot 2868841
setManifestid(2868841, "4733892780027453168", 2909639425)