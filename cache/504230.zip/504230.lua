-- 504230's Lua and Manifest Created by Hubcap Manifest
-- Celeste
-- Created: September 29, 2025 at 03:42:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(504230) -- Celeste
-- MAIN APP DEPOTS
addappid(504231, 1, "54f178dcac153879e50ce091af232f1451898adf19d5613d4baa7d67ff7ed15e") -- Celeste Windows
setManifestid(504231, "708531128774243067", 1164449173)
addappid(504232, 1, "6ce8825ef852b78bd99df402294a5fab18cebe0d0e25eff0a1331a5e92ab8f0f") -- Celeste OSX
setManifestid(504232, "3271492884622616896", 1204558574)
addappid(504233, 1, "796b0998d2a23eb42b790804bdeaf4be91bcac473dc16634748f1cf88db8fcac") -- Celeste Linux
setManifestid(504233, "5880027853585448535", 1201840326)
-- SHARED DEPOTS (from other apps)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
addappid(229012, 1, "421e499f39a617c1a3b6baf11fbc65ffebd541d2c39c38d3bf6ffbd87919ce12") -- XNA 4.0 Redist (Shared from App 228980)
setManifestid(229012, "4353723233161159493", 7061608)