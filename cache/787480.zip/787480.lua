-- 787480's Lua and Manifest Created by Hubcap Manifest
-- Phoenix Wright: Ace Attorney Trilogy
-- Created: November 19, 2025 at 01:15:46 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(787480) -- Phoenix Wright: Ace Attorney Trilogy
-- MAIN APP DEPOTS
addappid(787481, 1, "21ec2f837fe1dfd3cb4acfb74871f9989d4d75fb292e7ab5b902cbc58f577a63") -- Phoenix Wright: Ace Attorney Trilogy / 逆転裁判123 成歩堂セレクション Content
setManifestid(787481, "4596784893399743796", 2901467035)
addappid(787482, 1, "3c49d038e4a9825a77cb8e9756d0aeb6e4971363b027c52c6477cac104710a40") -- Phoenix Wright: Ace Attorney Trilogy / 逆転裁判123 成歩堂セレクション Wallpaper
setManifestid(787482, "4929657870284100407", 5178006)