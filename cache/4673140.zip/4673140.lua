-- 4673140's Lua and Manifest Created by Hubcap Manifest
-- 67 Minutes in Heaven
-- Created: July 25, 2026 at 09:20:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4673140) -- 67 Minutes in Heaven
-- MAIN APP DEPOTS
addappid(4673141, 1, "7a37f9fa35bb6d83032ecd421ae7c75d5c07d1fdbb4078d2303a19bbdf7f4113") -- Depot 4673141
setManifestid(4673141, "8680565342519126118", 684672400)