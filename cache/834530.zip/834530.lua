-- 834530's Lua and Manifest Created by Hubcap Manifest
-- Yakuza Kiwami (Legacy)
-- Created: January 19, 2026 at 14:04:09 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 0
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(834530, 1, "1c6b37c633ad603055aa67efc1924ca9a34753b5d32af692d9a595e84f2951b1") -- Yakuza Kiwami (Legacy)
-- MAIN APP DEPOTS
addappid(834531, 1, "64ebec3e0178f27e5d27d7cc4c91382ce5653dca2966989a8ee26574a83383d5") -- Yakuza Kiwami Content
setManifestid(834531, "6343115858572417905", 12633708835)
addappid(834532, 1, "00ac0f337bbd03f1d6b4e25cbe12b68f9567b85b234bd69822a7cb22cfecb100") -- Yakuza Kiwami English Content
setManifestid(834532, "8056939067145069014", 8994851935)
addappid(834533, 1, "84c25831d0a0900169b6bd7540ec8ecb569e08ec283a37391d404c60a798d0c9") -- Yakuza Kiwami Japanese Content
setManifestid(834533, "5566686960884841902", 9355382715)
addappid(834534, 1, "39d69ecbb762ccd9af1f9bfa47aec669eb104efdb8cc6f92d263c1b6f1fe094a") -- Yakuza Kiwami Debug NOT FOR RELEASE
setManifestid(834534, "210304784564462656", 0)
addappid(834535, 1, "f9e85ff7b9d2d862bc853c14bc4e7e6773efdcdfd9028d7a196296a4926a63e0") -- Yakuza Kiwami Digital Deluxe Extra Content
setManifestid(834535, "8036566944547967721", 158867876)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)