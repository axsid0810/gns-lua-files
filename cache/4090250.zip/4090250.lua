-- 4090250's Lua and Manifest Created by Hubcap Manifest
-- The Married Woman Nextdoor
-- Created: May 25, 2026 at 08:21:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4090250, 1, "04621a9608343115468aa2f85c2624b79d99b5ad0a532b3b2d4f85a060954a3c") -- The Married Woman Nextdoor
-- MAIN APP DEPOTS
addappid(4090251, 1, "a6b5648d2b408b0daa1b2cc215679291cabd628871bc6ce6aed86dec5ead53c6") -- Depot 4090251
setManifestid(4090251, "6153473137703091315", 4614877028)