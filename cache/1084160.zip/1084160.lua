-- 1084160's Lua and Manifest Created by Hubcap Manifest
-- Jagged Alliance 3
-- Created: September 29, 2025 at 19:54:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1084160, 1, "e612678221b99a3e1c7d3b8cfd2dcf4550d8c51d13703240f4fa26ea7877c562") -- Jagged Alliance 3
-- MAIN APP DEPOTS
addappid(1084161, 1, "4f94d949152ea26f9a3c60c1a8dd75fc4ac15d586bc1fc97ce67745a3be5faee") -- Depot 1084161
setManifestid(1084161, "1864261675204967035", 16303005299)
addappid(1084162, 1, "1c73c3e64d01f3e0dd21767f188b872224a190a6a9c295bd430b8fbcbe8771cc") -- Depot 1084162
setManifestid(1084162, "5237382165839002838", 323192016)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)