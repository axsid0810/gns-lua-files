-- 339200's Lua and Manifest Created by Hubcap Manifest
-- Oceanhorn: Monster of Uncharted Seas
-- Created: September 30, 2025 at 04:23:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(339200) -- Oceanhorn: Monster of Uncharted Seas
-- MAIN APP DEPOTS
addappid(339201, 1, "6f31e2f91386aa771ee8def2025b780b72428388b01c05437468f27710072b34") -- Oceanhorn: Monster of Uncharted Seas Depot for Windows
setManifestid(339201, "3515660210405073072", 575004056)
addappid(339202, 1, "f219d7a54465dd2139f0ac46db94e675d0f73b215407046bb1332cb343103207") -- Oceanhorn: Monster of Uncharted Seas Depot for OSX
setManifestid(339202, "5452507824292489478", 582226874)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)