-- 2467880's Lua and Manifest Created by Hubcap Manifest
-- Fading Echo
-- Created: July 21, 2026 at 06:11:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2467880, 1, "93b4a2716e01210f3cdf5e4b808af43e59c33981b6084462331c8f82fc1a393e") -- Fading Echo
-- MAIN APP DEPOTS
addappid(2467881, 1, "71f3a694d0c0191f01501fccc2d0218186458c4fda5ded792c90a43af3ba5213") -- Depot 2467881
setManifestid(2467881, "5874854129064005239", 5230006440)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- The Art of Fading Echo Digital Art Book (AppID: 4814570)
addappid(4814570)
addappid(4814570, 1, "94df58e790911c7ea76f5471dc2d2cee47ce61fafd247242278dd65de0ff960a") -- The Art of Fading Echo Digital Art Book - Depot 4814570
setManifestid(4814570, "4520159339276297822", 196345809)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2467882) -- Depot 2467882 (empty depot)