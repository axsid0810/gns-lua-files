-- 4282810's Lua and Manifest Created by Hubcap Manifest
-- From Devil's Womb
-- Created: July 27, 2026 at 08:55:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4282810) -- From Devil's Womb
-- MAIN APP DEPOTS
addappid(4282811, 1, "d31bb69325ca57085797234214865f4036f1a438397ba14312fde9c24a662064") -- Depot 4282811
setManifestid(4282811, "3328611730088382177", 2639088986)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)