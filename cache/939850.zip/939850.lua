-- 939850's Lua and Manifest Created by Hubcap Manifest
-- The Dark Pictures Anthology: Man of Medan
-- Created: September 30, 2025 at 23:07:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(939850) -- The Dark Pictures Anthology: Man of Medan
-- MAIN APP DEPOTS
addappid(939851, 1, "52870eaa88e4dc0373d6136c84ca9cabfc5e45c197916e1f1a777d3aabe53e66") -- The Dark Pictures Anthology - Man of Medan Content
setManifestid(939851, "2233225956230312354", 54675420978)
addappid(939852, 1, "2daad047203d2dc13cb81e42a049520aca137a4309b78eb78b029182d5cfd1d2") -- The Dark Pictures Anthology: Man of Medan FP Depot
setManifestid(939852, "45510479311498930", 416)
addappid(939855, 1, "939fae16bccf377c3682c43e18059e7c887bd39106cec6f5fcb10228adfe4683") -- Depot 939855
setManifestid(939855, "5424050174599472496", 16)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1016230) -- The Dark Pictures Anthology Man of Medan - Curators Cut
addtoken(1016230, "14593500172016031533")