-- 1038250's Lua and Manifest Created by Hubcap Manifest
-- DIRT 5
-- Created: June 25, 2026 at 06:17:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 10
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1038250, 1, "5860dd063e97c9a3dbbabe2c63686a260f380010b33e46897c6d96b181e471d4") -- DIRT 5
-- MAIN APP DEPOTS
addappid(1038251, 1, "43d22ea77f4f8585fe8af24877fe8922406632b6508c6adf08509fdae67d2e62") -- CP 2 Content
setManifestid(1038251, "9032882404118680792", 41447785286)
addappid(1038252, 1, "8373feec31992e456a798b03476b51d4ebdb5b673a5405323ecfb1ea4dd777f8") -- CP2 exe
setManifestid(1038252, "3184626638537455302", 441400828)
addappid(1038254, 1, "de79875866cd5463f472df01afde4b40f33ba6ce9cb87ff3086abac09c37276a") -- CP2 Content (high resolution)
setManifestid(1038254, "8066688021548665389", 35499898318)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1363540) -- DIRT 5 - Gameplay Booster Pack
addappid(1363591) -- DIRT 5 - Porsche Macan T1 Rally Raid
addtoken(1363591, "9924571305392782672")
addappid(1379260) -- DIRT 5 - Year 1 Upgrade
addtoken(1379260, "13861089674455984779")
addappid(1379261) -- DIRT 5 - Ford F-150 Raptor PreRunner by Deberti Design
addappid(1469470) -- DIRT 5 - Amplified Lanyard
addtoken(1469470, "10923072610102074951")
addappid(1469471) -- DIRT 5 - Year One Lanyard
addtoken(1469471, "6668923071670464990")
addappid(1516260) -- DIRT 5 - Energy Content Pack
addappid(1517270) -- DIRT 5 - Uproar Content Pack
addappid(1633610) -- DIRT 5 - Super Size Content Pack
addappid(1690420) -- DIRT 5 - Wild Spirits Pack