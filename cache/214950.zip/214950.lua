-- 214950's Lua and Manifest Created by Hubcap Manifest
-- Total War: ROME II - Emperor Edition
-- Created: July 29, 2026 at 04:32:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 52
-- Total DLCs: 17
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(214950, 1, "322f6ccdcf65c3c66948e9f85b69f702fbfdab76e19ac937957835386dfbb908") -- Total War: ROME II - Emperor Edition
-- MAIN APP DEPOTS
addappid(214951, 1, "135848566ec944b3b8364254ba76c2352a4b0d2c9ec326d23dbecc9af7b32445") -- launcher
setManifestid(214951, "4663563745481420713", 0)
addappid(214952, 1, "cb5a19b40f95a6361bc3dcc1062a83d3700d9b4c551031ebfac0edda3be8acd4") -- exe_rome2
setManifestid(214952, "785467126386024053", 81244742)
addappid(214953, 1, "28343569c4ae04e3d1c9920603872e145d1ab066cb7ced2a9fd086005e9f16a3") -- data_shared
setManifestid(214953, "530666364908176165", 7005858185)
addappid(214954, 1, "68417e25e7bd939cada0100c52a0eb1b1b662c7ccdee8b9e574c28dbbf5cba02") -- data_rome2
setManifestid(214954, "5255561179348145785", 23666334953)
addappid(214955, 1, "e29784e601e9830f31c36951809a594e4eab073092a62e505846d6ed4b88c54f") -- english_shared
setManifestid(214955, "8099281786087946432", 0)
addappid(214956, 1, "bea3db34bd78c40edfaca5635a72a59f94ee26089779cc2898f00397a8516700") -- english_rome2
setManifestid(214956, "4041548678330785776", 1840098217)
addappid(214957, 1, "ae4443f7d5e4dc93d6fd9701d37b1461eeb886105f7f972a8fd0b4cda29529aa") -- french_shared
setManifestid(214957, "3058960453748032277", 0)
addappid(214958, 1, "26313c204839304df92f276755377155f4e186b9e2448378256933c3999b780a") -- french_rome2
setManifestid(214958, "2685130893254381103", 1822754204)
addappid(214959, 1, "e038ace6dbf0129b026e2f4fdf5367e1857aae7711718bf6802e7b6b8cb79c1d") -- italian_shared
setManifestid(214959, "2099642573363003748", 0)
addappid(214960, 1, "a88032f1d916dddfede7e8dc27781eb9c8e51daa0e84e849d96622f872e2c10a") -- italian_rome2
setManifestid(214960, "1077584929124741213", 1856777207)
addappid(214961, 1, "9b23ce597ebfbbdd747ddeb7990c28c9e8bc36ca7c820a2fe603df16de68b618") -- german_shared
setManifestid(214961, "9188747083345066398", 0)
addappid(214962, 1, "9a7446e6a136b4dbd79e801c9eac1798fca2fbd5994280e36cc3aef6933b5cf3") -- german_rome2
setManifestid(214962, "5596884122478239391", 1898811103)
addappid(214963, 1, "2cb78d2be9f844b764fd26ed226387577cf08793776dac5f9d163b6f4b59b2ec") -- spanish_shared
setManifestid(214963, "6350652302957944494", 0)
addappid(214964, 1, "0b449f0d8c464b648eb42e37ea721fbe35b2bbe94b2aee15981cb74d5a5dc641") -- spanish_rome2
setManifestid(214964, "8394358661614048811", 1850764468)
addappid(214965, 1, "055e1854447798f683a5ad2706c94f4708e0058d0c92d24f4da502faa491b90d") -- russian_shared
setManifestid(214965, "6776993759529011629", 0)
addappid(214966, 1, "2f3348a59cd5f6b1326a59f7f798cec691b750e7645d750315e7abc74265b177") -- russian_rome2
setManifestid(214966, "7913661477154750472", 2021135363)
addappid(214967, 1, "4b31bced19536fe64e6afe6ab9d82076b7b89749906e45ae9170935d87c8637f") -- czech_shared
setManifestid(214967, "4320706951529744689", 0)
addappid(214968, 1, "151f13577d0a484019ebfe431a9412c646e22c77953effce50dac67ebfe8fca6") -- czech_rome2
setManifestid(214968, "7655060412600907841", 1878135561)
addappid(243660, 1, "444bb95fc3a4ba4f049de8d90546b8e97e755c4915035dbb66f851e83b65c7fc") -- polish_shared
setManifestid(243660, "6933091523470727654", 0)
addappid(243661, 1, "c76e18c7135b6e1f08277c48e3fc2bfd4bfbfb7fbbd88a6dd31d97f76de75724") -- polish_rome2
setManifestid(243661, "3455570051123355435", 1861677048)
addappid(243662, 1, "c3383dfb668cd56ce4c2cc214913b481eaec37da5d62adbf75f0a3f5ef04663b") -- turkish_shared
setManifestid(243662, "3276765975299231612", 0)
addappid(243663, 1, "870f8f8441758dc71cd5f803b0bb315ea3ec1cb010e48c3e74f4155a82bc17ef") -- turkish_rome2
setManifestid(243663, "681027827476423069", 1872863464)
addappid(243665, 1, "2270fc716553d7eb8c74890fe28301d9b25418a81a45e95e98e1c4a3bede7fdc") -- redist_shared
setManifestid(243665, "5900761351392481546", 121407259)
addappid(214969, 1, "3c17539daa22ee41e52a58d29eb43d07920db0be411f34a713d04750573c2d76") -- exe2_rome2
setManifestid(214969, "7606730170440394369", 176602737)
addappid(258272, 1, "8b6f65f847f26256963e36c50cf82d6997bd8863bbf82761d92c526546c13192") -- data_shared_mac_linux
setManifestid(258272, "1435276400936826025", 0)
addappid(258273, 1, "6c548e7cb4f879c56ebe9d8bb364652d40a5e3af4f6088be0780410826d03587") -- data_rome2_mac_linux
setManifestid(258273, "7399525665015214769", 33068746856)
addappid(258274, 1, "00a24f0c64493c95420e8c93512c7b9d101a593318e014963b10ef945fd9e04c") -- english_rome2_mac_linux
setManifestid(258274, "6393504796498558926", 1839942509)
addappid(258275, 1, "62b3a55847e89cb5c609ba192af2066c263c6028b9df207fa3bbb8dffe72f1f1") -- french_rome2_mac_linux
setManifestid(258275, "8813001652878915457", 1822726643)
addappid(258276, 1, "9301d64507a82388c743e43fe1e8fb20e578c88e550295ee15e0e3484926569e") -- italian_rome2_mac_linux
setManifestid(258276, "5186097086310490670", 1856749740)
addappid(258277, 1, "c0b842b5a9755b018ca7c8f4b69408b05c08043ed3f362fc0a5326296d4c93ca") -- german_rome2_mac_linux
setManifestid(258277, "6883784147739945760", 1898783646)
addappid(258278, 1, "5c129c0442d6bea0300e622f679b2d74a030144e60df4f8ee88483e743215f7f") -- spanish_rome2_mac_linux
setManifestid(258278, "8219177060833455571", 1850737005)
addappid(258279, 1, "7714eaf866a82456e7cff71d14e91b647f28116f9c4a1b06f5d0627d1a17af1c") -- russian_rome2_mac_linux
setManifestid(258279, "7112880016132854208", 2021108050)
addappid(258581, 1, "304b47c81c87c9efb7a579311d8186a5799b8545517f9ef91b1f097f575aba75") -- czech_rome2_mac_linux
setManifestid(258581, "7960654724363384472", 1878108219)
addappid(258582, 1, "289029e2d3640fe08160b4f8e9bbbb1031dcd365962ec0379b9541d02da96a5d") -- polish_rome2_mac_linux
setManifestid(258582, "9038661181222858555", 1861649666)
addappid(258583, 1, "2380363f82cea9a46282da65331d00a785f285c8bcea80897293909467c7009e") -- turkish_rome2_mac_linux
setManifestid(258583, "5626550076229277694", 1872836188)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
-- DLCS WITH DEDICATED DEPOTS
-- Total War ROME II - Greek States Culture Pack (AppID: 212301)
addappid(212301)
addappid(212301, 1, "ee68bdf9607e7ee475fe8b9130618cceff777309ef9a8084ca0ac556ae81a58c") -- Total War ROME II - Greek States Culture Pack - Depot 212301
setManifestid(212301, "3492730984343187438", 0)
-- Total War ROME II - Nomadic Tribes Culture Pack (AppID: 258270)
addappid(258270)
addappid(258270, 1, "375afd7c42e648fa1b5cf56c54051bdb2f7e24e8ca413eb875e04f385e57db70") -- Total War ROME II - Nomadic Tribes Culture Pack - Total War: ROME II - Nomadic Tribes Culture Pack (258270) Depot
setManifestid(258270, "8741985695548163254", 0)
addappid(258584, 1, "5a3b1dcad9cb046c573c7bad64cf4094f41da79ac920a620c1d8fa63504cee79") -- Total War ROME II - Nomadic Tribes Culture Pack - nomadic_mac_linux
setManifestid(258584, "2604646977912533394", 0)
-- Total War ROME II - Blood  Gore (AppID: 259800)
addappid(259800)
addappid(259800, 1, "0b5c7a5e1d461f2219a2a9597a8d461e5e09aa925ef29bf20852216c0f99a713") -- Total War ROME II - Blood  Gore - Total War: ROME II - Blood & Gore (259800) Depot
setManifestid(259800, "3062140772173179235", 1570264)
addappid(258585, 1, "c8e3bc87c515e23349aae8e5ea47e960b1f599bd82bf3a4e53236c6425a96ccf") -- Total War ROME II - Blood  Gore - blood_mac_linux
setManifestid(258585, "1931154006332337147", 1570264)
-- Total War ROME II - Caesar in Gaul (AppID: 261050)
addappid(261050)
addappid(261050, 1, "6f294136a5910613a24ee20c525f74304ef3e0dde8d553e795eeac43c713b641") -- Total War ROME II - Caesar in Gaul - Total War: ROME II - Paperclip (261050) Depot
setManifestid(261050, "8824870157919960975", 680621058)
addappid(258586, 1, "cece24eaa6f8b6ae41418f1c0c5be294b5e1533a97fe7740d7b3371a4cd897c2") -- Total War ROME II - Caesar in Gaul - gaul_mac_linux
setManifestid(258586, "1927382392138356931", 680621058)
-- Total War ROME II - Hannibal at the Gates (AppID: 273380)
addappid(273380)
addappid(273380, 1, "c9cdcb696a3b31c39cff48738c30ff0a5eaf0b1bc9b39cb17363bbb61279b1b5") -- Total War ROME II - Hannibal at the Gates - Toothpick (273380) Depot
setManifestid(273380, "3665056002651076027", 1256317112)
addappid(258587, 1, "280c91d86264198e72836c12be64c55cb9bd036df0b40d2bd41d9e6b85eeb304") -- Total War ROME II - Hannibal at the Gates - punic_mac_linux
setManifestid(258587, "119809446041022408", 1256317112)
-- Total War ROME II - Wrath of Sparta DLC (AppID: 327280)
addappid(327280)
addappid(327280, 1, "55deeba9725c0e40231eb5cfa64e9b5b41c30b1c3a94af5410708eeed31d3121") -- Total War ROME II - Wrath of Sparta DLC - Total War: ROME II - Spade DLC (327280) Depot
setManifestid(327280, "7886653306044405709", 929746665)
addappid(258588, 1, "42c0265f9318f570d9d183e07d3ec54cdbd5c106cacfbe2ca852bd9cc1a99d1d") -- Total War ROME II - Wrath of Sparta DLC - greeks_mac_linux
setManifestid(258588, "3035771515844935636", 929746665)
-- Total War ROME II - Empire Divided Campaign Pack (AppID: 694880)
addappid(694880)
addappid(694880, 1, "1268ced12fa1da0faedacebf7370b0fccfa4e7a6e651d822bd2718190367544d") -- Total War ROME II - Empire Divided Campaign Pack - Miller (694880) Depot
setManifestid(694880, "2114284949770732584", 6054904)
addappid(259802, 1, "fd3e2449adb8d171d7833eb9aec348176629eeca2b1f84fa86f652895522da09") -- Total War ROME II - Empire Divided Campaign Pack - Depot 259802
setManifestid(259802, "8559985847758632299", 6054904)
-- Total War ROME II - Rise of the Republic Campaign Pack (AppID: 850010)
addappid(850010)
addappid(850010, 1, "2842a60382c1d2ce4dcef468f4f8a2755457154982ed42bedd062227b9c0006a") -- Total War ROME II - Rise of the Republic Campaign Pack - Miller 3 (850010) Depot
setManifestid(850010, "9114621701386178753", 5023440)
addappid(259801, 1, "71ed4fd640af5be2e25ed5301a9e50a7ed3210088972f48530c9d066a54793f0") -- Total War ROME II - Rise of the Republic Campaign Pack - Depot 259801
setManifestid(259801, "6705184471243170730", 5023440)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(258580) -- Total War ROME II - Seleucid Empire Faction Pack
addappid(261620) -- Total War ROME II - Baktria Faction
addappid(267630) -- Total War ROME II - Beasts of War
addappid(273381) -- Total War ROME II - Pirates  Raiders
addappid(297830) -- Total War ROME II - Daughters of Mars
addappid(297831) -- Total War ROME II - Black Sea Colonies Culture Pack
addappid(311380) -- Total War ROME II - Augustus Campaign Pack
addappid(330340) -- Total War Rome II - Massilia Faction
addappid(792520) -- Total War ROME II - Desert Kingdoms Culture Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(258271) -- Depot 258271 (empty depot)