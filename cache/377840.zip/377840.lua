-- 377840's Lua and Manifest Created by Hubcap Manifest
-- FINAL FANTASY IX
-- Created: September 29, 2025 at 12:13:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 0
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(377840) -- FINAL FANTASY IX
-- MAIN APP DEPOTS
addappid(377841, 1, "1e0f8e41510025cbe5cd9944c20057428b7724f2dafa667cbf6b30a87048e845") -- FINAL FANTASY IX Content-JP
setManifestid(377841, "5788986308821811331", 9722923800)
addappid(377842, 1, "cc04129aee7111238ca757f73754fccdde5f1626c83cda362eeab94e9cd21f65") -- FINAL FANTASY IX Depot-WW
setManifestid(377842, "5093083830915639317", 9722919948)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)