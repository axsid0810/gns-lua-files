-- 1198090's Lua and Manifest Created by Hubcap Manifest
-- The Legend of Heroes: Trails of Cold Steel IV
-- Created: October 01, 2025 at 00:07:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 24
-- Total DLCs: 19
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(1198090) -- The Legend of Heroes: Trails of Cold Steel IV
-- MAIN APP DEPOTS
addappid(1198091, 1, "c48721588f545a66858af8279bee2952b31f66135dcee997568ab854b808265c") -- The Legend of Heroes: Trails of Cold Steel IV Content
setManifestid(1198091, "6618958601736544624", 28786243190)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
-- DLCS WITH DEDICATED DEPOTS
-- The Legend of Heroes Trails of Cold Steel IV - Self-Assertion Panels Vol. 2 (AppID: 1573918)
addappid(1573918)
addappid(1573918, 1, "2bf394d404473cf81a43ca7b1b4e33f78bb20bccfce86ae58cf1d7fba287b61a") -- The Legend of Heroes Trails of Cold Steel IV - Self-Assertion Panels Vol. 2 - The Legend of Heroes: Trails of Cold Steel IV - Self-Assertion Panels Vol. 2 (1573918) Depot
setManifestid(1573918, "1025072620451860628", 3711471)
-- The Legend of Heroes Trails of Cold Steel IV - Swimsuit Bundle (AppID: 1575363)
addappid(1575363)
addappid(1575363, 1, "98a68524e57364cce7c5ebfeb68f197055115ced4b1aca1351454da1400a51df") -- The Legend of Heroes Trails of Cold Steel IV - Swimsuit Bundle - The Legend of Heroes: Trails of Cold Steel IV - Swimsuit Bundle (1575363) Depot
setManifestid(1575363, "855750931950930582", 50682799)
-- The Legend of Heroes Trails of Cold Steel IV - Magical Girl Bundle (AppID: 1575364)
addappid(1575364)
addappid(1575364, 1, "4852e1a4e4c8d9449a68e2407b2ecc0f54f93056b30355ff2fdfa0c3d48663be") -- The Legend of Heroes Trails of Cold Steel IV - Magical Girl Bundle - The Legend of Heroes: Trails of Cold Steel IV - Magical Girl Bundle (1575364) Depot
setManifestid(1575364, "8542106205035805330", 66423041)
-- The Legend of Heroes Trails of Cold Steel IV - Hair Extension Set (AppID: 1575365)
addappid(1575365)
addappid(1575365, 1, "d55baf9d3cc17eb4e3510c09459f48ff1d400d654ab9b26c302e51b0ec285567") -- The Legend of Heroes Trails of Cold Steel IV - Hair Extension Set - The Legend of Heroes: Trails of Cold Steel IV - Hair Extension Set (1575365) Depot
setManifestid(1575365, "1693447023382434660", 108459545)
-- The Legend of Heroes Trails of Cold Steel IV - Attachment Set (AppID: 1575366)
addappid(1575366)
addappid(1575366, 1, "070a064890895e1fde8012e2ac5eaa7d7dab18e56beb5201f1a53c41afaaa583") -- The Legend of Heroes Trails of Cold Steel IV - Attachment Set - The Legend of Heroes: Trails of Cold Steel IV - Attachment Set (1575366) Depot
setManifestid(1575366, "1450563512515737782", 28236622)
-- The Legend of Heroes Trails of Cold Steel IV - Ride-Along Set (AppID: 1575367)
addappid(1575367)
addappid(1575367, 1, "8be1c793780f70e799fec64e32fe65fc22e619b0e517338c2f0ac11ea95c7b14") -- The Legend of Heroes Trails of Cold Steel IV - Ride-Along Set - The Legend of Heroes: Trails of Cold Steel IV - Ride-Along Set (1575367) Depot
setManifestid(1575367, "688029093955280243", 5449345)
-- The Legend of Heroes Trails of Cold Steel IV - Standard Costume Bundle (AppID: 1575368)
addappid(1575368)
addappid(1575368, 1, "0cde8e0abba2cbfcfc24fd9adb7b1786378ec435a7c69c936d7419ff9797e518") -- The Legend of Heroes Trails of Cold Steel IV - Standard Costume Bundle - The Legend of Heroes: Trails of Cold Steel IV - Standard Costume Bundle (1575368) Depot
setManifestid(1575368, "6771052531324874950", 87604312)
-- The Legend of Heroes Trails of Cold Steel IV - Headwear Set (AppID: 1575369)
addappid(1575369)
addappid(1575369, 1, "0693979baa704bccf9d0a6f1361943657cb631c72e0308bf8c0d925f94519bfd") -- The Legend of Heroes Trails of Cold Steel IV - Headwear Set - The Legend of Heroes: Trails of Cold Steel IV - Headwear Set (1575369) Depot
setManifestid(1575369, "4320062956581364749", 10876274)
-- The Legend of Heroes Trails of Cold Steel IV - Free Sample Set A (AppID: 1575397)
addappid(1575397)
addappid(1575397, 1, "a3616c7d8901dd82ed9ad6dfe1ef9986dfe6363e06fb77c66f106fc154c0dbbc") -- The Legend of Heroes Trails of Cold Steel IV - Free Sample Set A - The Legend of Heroes: Trails of Cold Steel IV - Free Sample Set A (1575397) Depot
setManifestid(1575397, "1494738381872337654", 414)
-- The Legend of Heroes Trails of Cold Steel IV - Free Sample Set B (AppID: 1575410)
addappid(1575410)
addappid(1575410, 1, "85346f84072cd5132f658c340c5335a939c58e6c1ac402fafc60e2a5f845f3a7") -- The Legend of Heroes Trails of Cold Steel IV - Free Sample Set B - The Legend of Heroes: Trails of Cold Steel IV - Free Sample Set B (1575410) Depot
setManifestid(1575410, "437632853534790712", 372)
-- The Legend of Heroes Trails of Cold Steel IV - Free Sample Set C (AppID: 1575411)
addappid(1575411)
addappid(1575411, 1, "30f7aa88a8a8584bc892aa44fde4f44d83b43a5f62ee080ea0265a1c20300624") -- The Legend of Heroes Trails of Cold Steel IV - Free Sample Set C - The Legend of Heroes: Trails of Cold Steel IV - Free Sample Set C (1575411) Depot
setManifestid(1575411, "737423378968483021", 362)
-- The Legend of Heroes Trails of Cold Steel IV  - Echoes of Erebonia Digital Soundtrack Sampler (AppID: 1575412)
addappid(1575412)
addappid(1575412, 1, "a04f1d154d6e475d328f816418dc6f254b1bb7cc8269cc834718c57df9322f3b") -- The Legend of Heroes Trails of Cold Steel IV  - Echoes of Erebonia Digital Soundtrack Sampler - The Legend of Heroes: Trails of Cold Steel IV  - Echoes of Erebonia Digital Soundtrack Sampler (1575412) Depot
setManifestid(1575412, "3961049801362365511", 201931374)
-- The Legend of Heroes Trails of Cold Steel IV  - The Black Records Digital Mini Art Book (AppID: 1575413)
addappid(1575413)
addappid(1575413, 1, "8ad378b5d6d2c3103f0b457dcb455d2ee6f9ade853d77e45158fcfe5c9d7e313") -- The Legend of Heroes Trails of Cold Steel IV  - The Black Records Digital Mini Art Book - The Legend of Heroes: Trails of Cold Steel IV  - The Black Records Digital Mini Art Book (1575413) Depot
setManifestid(1575413, "6521173167969426987", 33168222)
-- The Legend of Heroes Trails of Cold Steel IV  - Twilight Resonance Digital Soundtrack (AppID: 1575414)
addappid(1575414)
addappid(1575414, 1, "6e16a3c047072351fa07172d56dad4bb1e3b8080eee213e6a02fb2b880b6acb3") -- The Legend of Heroes Trails of Cold Steel IV  - Twilight Resonance Digital Soundtrack - The Legend of Heroes: Trails of Cold Steel IV  - Twilight Resonance Digital Soundtrack (1575414) Depot
setManifestid(1575414, "3669183520799152905", 572075990)
-- The Legend of Heroes Trails of Cold Steel IV  - The Complete Black Records Digital Art Book (AppID: 1575415)
addappid(1575415)
addappid(1575415, 1, "9b8528148bff08b69c30d89e50973c8e9e49909ebaf2667723f09f6bcd47c65f") -- The Legend of Heroes Trails of Cold Steel IV  - The Complete Black Records Digital Art Book - The Legend of Heroes: Trails of Cold Steel IV  - The Complete Black Records Digital Art Book (1575415) Depot
setManifestid(1575415, "673182790863950377", 324097544)
-- The Legend of Heroes Trails of Cold Steel IV - Cold Steel III Costume Bundle (AppID: 1575416)
addappid(1575416)
addappid(1575416, 1, "dbf616a0472389e876db932dc24edfa9a987129d606f30152847de1ba785596d") -- The Legend of Heroes Trails of Cold Steel IV - Cold Steel III Costume Bundle - The Legend of Heroes: Trails of Cold Steel IV - "Cold Steel III" Costume Bundle (1575416) Depot
setManifestid(1575416, "568873881822990943", 189335528)
-- The Legend of Heroes Trails of Cold Steel IV - Consumable Starter Set (AppID: 1580540)
addappid(1580540)
addappid(1580540, 1, "ff55f74809c7acc9f547592d4bc671e566b6c791aaa057735d59c8f29e1aa4a7") -- The Legend of Heroes Trails of Cold Steel IV - Consumable Starter Set - The Legend of Heroes: Trails of Cold Steel IV - Consumable Starter Set (1580540) Depot
setManifestid(1580540, "1606922502898928595", 6891)
-- The Legend of Heroes Trails of Cold Steel IV - Consumable Value Set (AppID: 1580541)
addappid(1580541)
addappid(1580541, 1, "3de2e8df95e356e8cd68e4a4985b5e946724e79aacf0516e048f8f35472036db") -- The Legend of Heroes Trails of Cold Steel IV - Consumable Value Set - The Legend of Heroes: Trails of Cold Steel IV - Consumable Value Set (1580541) Depot
setManifestid(1580541, "578925644252811204", 13580)
-- The Legend of Heroes Trails of Cold Steel IV - Lossless Audio Pack (AppID: 1656320)
addappid(1656320)
addappid(1656320, 1, "fe30836b5314511100d5f94369ce4991c3009d02309aeb549ee32071d6a13f3a") -- The Legend of Heroes Trails of Cold Steel IV - Lossless Audio Pack - The Legend of Heroes: Trails of Cold Steel IV - Lossless Audio Pack (1656320) Depot
setManifestid(1656320, "8147830071725582808", 14924371880)