-- 3345760's Lua and Manifest Created by Hubcap Manifest
-- Silent Anomalies
-- Created: July 28, 2026 at 09:56:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3345760) -- Silent Anomalies
-- MAIN APP DEPOTS
addappid(3345762, 1, "57034874ae9582f1cf78048a3ddfff29ab5bc0a58c591ecfba978bcdf8dfed86") -- Depot 3345762
setManifestid(3345762, "7294578642314117800", 5283082004)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3345761) -- Depot 3345761 (empty depot)