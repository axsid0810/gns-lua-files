-- 638970's Lua and Manifest Created by Hubcap Manifest
-- Yakuza 0
-- Created: October 01, 2025 at 08:39:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 0
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(638970) -- Yakuza 0
-- MAIN APP DEPOTS
addappid(638971, 1, "ed70cc2d7c7ce6db4c6e3ccdd070786dcb37b73a0bc82825d89705311c39a100") -- Dragon Fruit Content
setManifestid(638971, "1004322381902797484", 23954947987)
addappid(638972, 1, "882baada465c2da02cf427b6e9744bb4a52e9980c6331beb97b60ad3af9fc0e0") -- Dragon Fruit English Content
setManifestid(638972, "5662079231198794978", 2328419544)
addappid(638973, 1, "be3eaf318d15138653145447fa244e0838e0c25b21f9f0b797eb1660471c5a5e") -- Dragon Fruit Japanese Content
setManifestid(638973, "5399542270646326264", 2327909428)
addappid(638975, 1, "7d2df597ac4ddc5ea945aff1ca599b6c21c6604bbb1c070f208bf49244315461") -- Dragon Fruit Digital Deluxe Extra Content
setManifestid(638975, "3296848567477597179", 202936810)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)