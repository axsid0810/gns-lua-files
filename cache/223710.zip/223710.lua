-- 223710's Lua and Manifest Created by Hubcap Manifest
-- Cry of Fear
-- Created: September 29, 2025 at 05:49:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(223710) -- Cry of Fear
-- MAIN APP DEPOTS
addappid(223711, 1, "3a01e728a9a3a805348fc7a0fb00a6e22dae50b51c4981f131a54b919e00c8ec") -- Cry of Fear Content
setManifestid(223711, "3465817078078599269", 4695601334)
-- SHARED DEPOTS (from other apps)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)