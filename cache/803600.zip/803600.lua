-- 803600's Lua and Manifest Created by Hubcap Manifest
-- Disgaea 5 Complete
-- Created: September 29, 2025 at 07:56:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(803600) -- Disgaea 5 Complete
-- MAIN APP DEPOTS
addappid(803601, 1, "43fe05a18369739b01155c0e077828682e79f87bdc198e9dc869b9383869956b") -- Disgaea 5 Complete Content
setManifestid(803601, "2485590530922474185", 8523267343)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Disgaea 5 Complete - Digital Art Book (AppID: 803610)
addappid(803610)
addappid(803610, 1, "f85198db274ff5aa83b02f72492c4f6d119bf44323b19e76f98d174295e889e6") -- Disgaea 5 Complete - Digital Art Book - Disgaea 5 Complete - Digital Art Book (803610) デポ
setManifestid(803610, "1017773779227482678", 30172364)