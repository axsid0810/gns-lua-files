-- 257420's Lua and Manifest Created by Hubcap Manifest
-- Serious Sam 4
-- Created: January 18, 2026 at 22:19:17 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(257420, 1, "ea1a08ccb18c9cae37a648cd9952fd707847031a47be5e6c9924ac9065cb26fa") -- Serious Sam 4
-- MAIN APP DEPOTS
addappid(257421, 1, "8096f8677bd37048df6dc882760cfe3acf7e8fd4bb525f250f604d2b93eac97f") -- Sam4_GameBin_Windows
setManifestid(257421, "4590363821351997440", 75913264)
addappid(257424, 1, "596feaf4a1321c2e0ba0abb60b936b3ea76d1e1eda1897ac0120b30b5e783c92") -- Sam4_GameBin_WindowsVR
setManifestid(257424, "44178437567544256", 0)
addappid(257422, 1, "2c0941675a9d9ae3ec36aa34bd79938b730049c824ebd6875dce76e18ccf5565") -- Sam4_GameBin_Linux
setManifestid(257422, "1230897594186488", 0)
addappid(257425, 1, "6e187b4fb78ace59438cd53ff8d9a06807b4c40714d2d501f0e70a074d835e23") -- Sam4_GameBin_LinuxVR
setManifestid(257425, "288142156408178103", 0)
addappid(257423, 1, "d7d458e915fc75bc05d99d96d1307c1d942f51f42dd5a88bde972cd651e9c7d3") -- Sam4_GameBin_OSX
setManifestid(257423, "221471687889953158", 0)
addappid(257426, 1, "4a353c662b034310254d9c7d00885e076d46c5990eb7d7f46e68197e50a9db1b") -- Sam4_Common_Shared
setManifestid(257426, "5285547987528508936", 46765739300)
addappid(257427, 1, "e50c354bca42cdade83dbb7b8857d9a0118284edbd368e34b7c4e98f5024e9a6") -- Sam4_Common_Windows
setManifestid(257427, "3824505940309722734", 78491099)
addappid(257429, 1, "b38d33e2489680af9754f53a515727c36d5378f046b2ac7f78de89b65a92694f") -- Sam4_Common_Linux
setManifestid(257429, "18963168999075530", 0)
-- DLCS WITH DEDICATED DEPOTS
-- Serious Sam 4 Digital Artbook (AppID: 1330602)
addappid(1330602)
addappid(1330602, 1, "6f8d624640e2eabb756241dc57f9ccd1a8d49d231ba6df818b6bec810b084e53") -- Serious Sam 4 Digital Artbook - Serious Sam 4 Digital Artbook (1330602) Depot
setManifestid(1330602, "383891755814069636", 97273678)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1330600) -- Serious Sam 4 Classic Tommy Gun