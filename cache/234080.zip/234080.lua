-- 234080's Lua and Manifest Created by Hubcap Manifest
-- Castlevania: Lords of Shadow - Ultimate Edition
-- Created: September 29, 2025 at 03:30:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(234080) -- Castlevania: Lords of Shadow - Ultimate Edition
-- MAIN APP DEPOTS
addappid(234081, 1, "ab40bf1e8f8f4e355c8bae5308935e25aab33dfa288481d8daa4a10db80794e1") -- Full Game
setManifestid(234081, "5017088970159247252", 15948229993)
addappid(234083, 1, "b87b6f66b1adb93c834b430768ddf9b1cf1457edf63f2a6235366c28cbcc711f") -- Common
setManifestid(234083, "1410852896033128696", 0)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)