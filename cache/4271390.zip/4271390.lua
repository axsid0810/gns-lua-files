-- 4271390's Lua and Manifest Created by Hubcap Manifest
-- The Asodium
-- Created: March 10, 2026 at 07:54:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4271390) -- The Asodium
-- MAIN APP DEPOTS
addappid(4271391, 1, "809acb7f06bbd9fc9a77695feef561d6e605b38980fcb3e7602ff77e9ae246cd") -- Depot 4271391
setManifestid(4271391, "2687335328627340743", 1372531556)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)