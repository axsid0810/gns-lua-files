-- 1165870's Lua and Manifest Created by Hubcap Manifest
-- Mahou Arms
-- Branch: PUBLIC
-- Created: January 07, 2026 at 08:45:51 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1165870, 1, "64085e75df053f53ff49453033168bde94a3c796973985a22d918ebe737527c8") -- Mahou Arms
-- MAIN APP DEPOTS
addappid(1165871, 1, "d9f54b16c1da7cd86fb9df6038fea5304ff0ab65adbf2e0508cab3112ada43a4") -- Windows Mahou Arms Content
setManifestid(1165871, "3995505808657105534", 13029316731)