-- 1643320's Lua and Manifest Created by Hubcap Manifest
-- S.T.A.L.K.E.R. 2: Heart of Chornobyl
-- Created: April 14, 2026 at 08:18:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 5 (1 excluded)
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1643320, 1, "b783726cbbe01aa0588ea0829164ac9b24665c7394b3d13497e62639b8c083ea") -- S.T.A.L.K.E.R. 2: Heart of Chornobyl
-- MAIN APP DEPOTS
addappid(1643321, 1, "71c29e58911c13991edea02ac06db5f5991e43e52cdcd76c19126d657c4a38e7") -- Depot 1643321
setManifestid(1643321, "4786301365643808399", 177310902311)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1661620) -- S.T.A.L.K.E.R. 2 Heart of Chornobyl - Deluxe Content
addappid(1661621) -- S.T.A.L.K.E.R. 2 Heart of Chornobyl - Ultimate Content
addappid(1661622) -- S.T.A.L.K.E.R. 2 Heart of Chornobyl - Season Pass
addappid(1661623) -- S.T.A.L.K.E.R. 2 Heart of Chornobyl - Pre-order Bonus
addappid(3399310) -- S.T.A.L.K.E.R. 2 Heart of Chornobyl - Community Items
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3765020) -- DLC 3765020 (unreleased)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1643322) -- Depot 1643322 (empty depot)
-- addappid(1643323) -- Depot 1643323 (empty depot)
-- addappid(1643324) -- Depot 1643324 (empty depot)
-- addappid(1643325) -- Depot 1643325 (empty depot)
-- addappid(1643326) -- Depot 1643326 (empty depot)
-- addappid(1643327) -- Depot 1643327 (empty depot)
-- addappid(3765021) -- Depot 3765021 (empty depot)