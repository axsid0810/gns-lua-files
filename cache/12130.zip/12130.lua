-- 12130's Lua and Manifest Created by Hubcap Manifest
-- Manhunt
-- Created: September 29, 2025 at 23:39:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(12130) -- Manhunt
-- MAIN APP DEPOTS
addappid(12132, 1, "b545c3df7ebf6d20468062d5faa869c4ec31340b523260ac5e9b931316d0ede6") -- Manhunt content 2
setManifestid(12132, "192612270653630007", 1260544788)
addappid(12131, 1, "7d982179160594794fd6947ae7585f4767f8844335209649ed3189b080f9e0fd") -- Manhunt content
setManifestid(12131, "8486237521343385769", 765071036)