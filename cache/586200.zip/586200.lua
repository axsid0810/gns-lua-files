-- 586200's Lua and Manifest Created by Hubcap Manifest
-- Street Fighter 30th Anniversary Collection
-- Created: January 19, 2026 at 12:23:44 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(586200, 1, "1cd30699210be67351917d4d497b44ba8bbfb785e610baf4adc6cfa169a95819") -- Street Fighter 30th Anniversary Collection
-- MAIN APP DEPOTS
addappid(586201, 1, "db4277b4f48376b54dad95c88fdaf5754f4b373872d0b63fcc2cba2428cb6638") -- Project WOLF Win32
setManifestid(586201, "6872899991876066797", 5307727166)
addappid(586202, 1, "bab43ae9edf922438c44acdb633b3a7458ad57742925b172e1d9c545ef8d4461") -- Project WOLF Win64
setManifestid(586202, "3960767494968070627", 5309376830)
addappid(586203, 1, "97ce5507f8e9dc8a11cf3ba6d30bd29ff2f483bb09ba7a5d3a0f21d8b1c982d2") -- Project WOLF Win64 JP
setManifestid(586203, "4689750818252803957", 5415773357)
addappid(586204, 1, "14bc5016cdb1f7d330d68032b52e48673f843562c0007722fdb3431017c6f0e7") -- Project WOLF Win32 JP
setManifestid(586204, "3246656311099709929", 5414105773)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)