-- 2475490's Lua and Manifest Created by Hubcap Manifest
-- Mouthwashing
-- Created: September 30, 2025 at 02:00:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2475490) -- Mouthwashing
-- MAIN APP DEPOTS
addappid(2475491, 1, "397ceaf971a43c7d35d5eade1443d05df02019c433895547be26e88b177d948d") -- Depot 2475491
setManifestid(2475491, "2537253174922439408", 2799318238)
-- DLCS WITH DEDICATED DEPOTS
-- Mouthwashing - Work In Progress (AppID: 4014000)
addappid(4014000)
addappid(4014000, 1, "eea7cb7344358df39b32d8f36167a652b13d54ef88ff0f16ddaba2c2ff3f30a9") -- Mouthwashing - Work In Progress - Depot 4014000
setManifestid(4014000, "7439113637495527470", 2278481994)