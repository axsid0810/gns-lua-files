-- 3717340's Lua and Manifest Created by Hubcap Manifest
-- Yakuza Kiwami 2
-- Created: January 23, 2026 at 04:51:40 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3717340) -- Yakuza Kiwami 2
-- MAIN APP DEPOTS
addappid(3717341, 1, "bac8c6f1b44d2997e2b9c459087502cf592e59908a5926914b9e2adba8e458b3") -- Depot 3717341
setManifestid(3717341, "1741333248924976451", 64838960602)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)