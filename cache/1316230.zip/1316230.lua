-- 1316230's Lua and Manifest Created by Hubcap Manifest
-- Force of Nature 2
-- Created: September 29, 2025 at 13:03:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1316230) -- Force of Nature 2
-- MAIN APP DEPOTS
addappid(1316231, 1, "ce3246d908215d22d0f2e8257a640bda867b07ebe9f233b9fc9827fc777af452") -- Force of Nature 2 Content
setManifestid(1316231, "2433302548085106292", 1279846081)
-- DLCS WITH DEDICATED DEPOTS
-- Force of Nature 2 - Collectors Pack (AppID: 2247910)
addappid(2247910)
addappid(2247910, 1, "22c5586e35a24cc20af0959e410fbe3e1e72e422d2cf2456d585a6738c6b7f96") -- Force of Nature 2 - Collectors Pack - Depot 2247910
setManifestid(2247910, "8556326073758719040", 2319707711)