-- 330020's Lua and Manifest Created by Hubcap Manifest
-- Children of Morta
-- Created: September 29, 2025 at 03:57:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(330020) -- Children of Morta
-- MAIN APP DEPOTS
addappid(330021, 1, "08ae65e452cbf086b1185be193446421485214e63e705cbc139de687c906dc15") -- Children of Morta Content
setManifestid(330021, "4606985130426915900", 1854404638)
addappid(330022, 1, "d67d4cef4af612190a78a42d3af9df70988474b78c9f1de68d65cf711cc09be4") -- Children of Morta Mac
setManifestid(330022, "4076267414139895734", 1871356768)
addappid(330023, 1, "47799065e21c92aab38943ad2b7312f5719f9b3e92bc8029e19216741a650cde") -- Children of Morta Linux
setManifestid(330023, "7753140511382431254", 1741323934)
addappid(330024, 1, "57ee867e033c4216af875908ec959e0d91ae5c1ef5493dc3a5a7c06b4a6c7317") -- Children of Morta - Tools - Windows
setManifestid(330024, "7281937126606251578", 9728)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Children of Morta Paws and Claws (AppID: 1317160)
addappid(1317160)
addappid(1317160, 1, "9977ce8fa90309f0f0c337720d0ab3ec775f1a6f02d6034e6ad8a18157e514ef") -- Children of Morta Paws and Claws - Children of Morta: P&C Windows
setManifestid(1317160, "9017478250715199651", 0)
addappid(330026, 1, "3d470a3c0b7fc703b8e780dc3f087babecd65d940c96bc92ee202f61acea9113") -- Children of Morta Paws and Claws - Children of Morta: P&C OSX
setManifestid(330026, "6822150715540450746", 0)
addappid(330027, 1, "7e53bfaacab4472e6918491409733d7490edc7f25e0797f374e498118da1e0c5") -- Children of Morta Paws and Claws - Children of Morta: P&C Linux
setManifestid(330027, "2686645784613825353", 0)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1648880) -- Children of Morta Ancient Spirits