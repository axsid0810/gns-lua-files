-- 1944430's Lua and Manifest Created by Hubcap Manifest
-- Amnesia: The Bunker
-- Created: September 28, 2025 at 22:18:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 0
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(1944430, 1, "fc4d7635b712b99e986bcf4b1877cf416c0d75c563b54258f0ce47509b90adce") -- Amnesia: The Bunker
-- MAIN APP DEPOTS
addappid(1944432, 1, "53d24d2ad4b763b59e6e9308f511aa3383912e019571d401c5bb5f8d40ad2ce0") -- Depot 1944432
setManifestid(1944432, "7744655607509449093", 16812854192)
addappid(1944433, 1, "e3c66caa20c0b0ce949af4150d408243d025c876c0527ef560b59c3a95cbb230") -- Depot 1944433
setManifestid(1944433, "4883998806228304333", 18388592)
addappid(1944434, 1, "13ef6a459072b7d6e7868e8f85170eac5fbcaab162fc97ac2848d0815d71ee01") -- Depot 1944434
setManifestid(1944434, "2126049800945663400", 930590673)
addappid(1944435, 1, "f768d94cca67686f523f605a70f3a9d84573edf287f86aa05d960949db311f44") -- Depot 1944435
setManifestid(1944435, "1407619913197510760", 106137879)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)