-- 431520's Lua and Manifest Created by Hubcap Manifest
-- Age of Fear: Total
-- Created: June 26, 2026 at 17:43:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(431520, 1, "ed405a1b1d2bd2db1a6cf4f40b3c9b1dedb8906261daf805b102f65304f16c5a") -- Age of Fear: Total
-- MAIN APP DEPOTS
addappid(431521, 1, "b28ae84e405b5f04c8694929c7a722a854cd43e7129f5b526906e0859b27a4fc") -- Depot 431521
setManifestid(431521, "5693569953294232829", 13041400640)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)