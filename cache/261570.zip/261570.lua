-- 261570's Lua and Manifest Created by Hubcap Manifest
-- Ori and the Blind Forest
-- Created: September 30, 2025 at 05:11:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(261570) -- Ori and the Blind Forest
-- MAIN APP DEPOTS
addappid(261571, 1, "7eeb593b78d5eb4db1691cef6355d28cbf59ad13ca630577f75e87a2ce4c3ed3") -- Ori and the Blind Forest
setManifestid(261571, "671912898471395619", 7934653406)
-- DLCS WITH DEDICATED DEPOTS
-- Ori and the Blind Forest (Original Soundtrack) (AppID: 378950)
addappid(378950)
addappid(378950, 1, "0a39588e113af0b41a17420aefcf4739a63350c1b3fc58609b3879f1caec4ce7") -- Ori and the Blind Forest (Original Soundtrack) - Ori and the Blind Forest (Original Soundtrack) (378950) Depot
setManifestid(378950, "1371532831001290078", 214098200)