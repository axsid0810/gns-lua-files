-- 1698690's Lua and Manifest Created by Hubcap Manifest
-- Automation
-- Created: October 02, 2025 at 00:03:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1698690) -- Automation
-- MAIN APP DEPOTS
addappid(1698691, 1, "f7b1dedf0c39402b0627ff06cd9147ba079cfb5487210908150036039941af41") -- Depot 1698691
setManifestid(1698691, "6697626712753971825", 619453280)