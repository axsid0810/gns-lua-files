-- 761600's Lua and Manifest Created by Hubcap Manifest
-- Onimusha: Warlords
-- Created: September 30, 2025 at 04:54:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(761600) -- Onimusha: Warlords
-- MAIN APP DEPOTS
addappid(761601, 1, "a9cebe81198dc3bda033a39cb706ee6de1b8e574c0ea442ec1e611e2247764de") -- Lion Game Depot
setManifestid(761601, "5936204945665114510", 15079498451)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(961480) -- Onimusha Wallpaper