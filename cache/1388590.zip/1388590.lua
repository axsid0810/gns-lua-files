-- 1388590's Lua and Manifest Created by Hubcap Manifest
-- Yakuza 6: The Song of Life
-- Created: October 01, 2025 at 08:39:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1388590) -- Yakuza 6: The Song of Life
-- MAIN APP DEPOTS
addappid(1388591, 1, "02a2c7298742e3092a66f1d6b2a6c2703b1d8452a110657633953890a89309b4") -- RINO 6 Content
setManifestid(1388591, "6145049068135492681", 41792236021)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1478720) -- Yakuza 6 The Song of Life - Clan Creator Card Bundle