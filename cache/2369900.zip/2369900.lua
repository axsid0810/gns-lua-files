-- 2369900's Lua and Manifest Created by Hubcap Manifest
-- Castlevania Dominus Collection
-- Created: November 04, 2025 at 11:11:22 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2369900) -- Castlevania Dominus Collection
-- MAIN APP DEPOTS
addappid(2369901, 1, "e043f7821044b91504ba4cf8b9a6b474a717bc0c1eb891da95b5d5b3edd95969") -- Depot 2369901
setManifestid(2369901, "766449152026478559", 1302769172)