-- 1351630's Lua and Manifest Created by Hubcap Manifest
-- Ys IX: Monstrum Nox
-- Created: October 01, 2025 at 08:52:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 12
-- Total DLCs: 8
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1351630) -- Ys IX: Monstrum Nox
-- MAIN APP DEPOTS
addappid(1351631, 1, "47bcf8eb50f2fa047d3390cf62953b1b927c5035db87ec556305013a086d7b8b") -- Ys IX: Monstrum Nox Content
setManifestid(1351631, "3164049132182838365", 9527502260)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Ys IX Monstrum Nox - Consumable Bundle (AppID: 1627580)
addappid(1627580)
addappid(1627580, 1, "66b26891e732f5c867c351811a514d6dd3d06f98cd4adc61a34c2b5b1abc15e4") -- Ys IX Monstrum Nox - Consumable Bundle - Ys IX: Monstrum Nox - Consumable Bundle (1627580) Depot
setManifestid(1627580, "9147202980883179437", 83363)
-- Ys IX Monstrum Nox - Attachments Bundle (AppID: 1627581)
addappid(1627581)
addappid(1627581, 1, "61a0f890e1bf97d3e6d2b554a429d89f6bb6f2c9e1d571c5da8e36fc7c474589") -- Ys IX Monstrum Nox - Attachments Bundle - Ys IX: Monstrum Nox - Attachments Bundle (1627581) Depot
setManifestid(1627581, "8277111982943223801", 187144193)
-- Ys IX Monstrum Nox - Monstrum Troupe Bundle (AppID: 1627582)
addappid(1627582)
addappid(1627582, 1, "48e8f595ec0deb2c92a1bda9bb18a2d7eae245ef22432be0b3cedda30ae7850c") -- Ys IX Monstrum Nox - Monstrum Troupe Bundle - Ys IX: Monstrum Nox - Monstrum Troupe Bundle (1627582) Depot
setManifestid(1627582, "8754348794421106824", 68674813)
-- Ys IX Monstrum Nox - Melodies of the Macabre  (AppID: 1627583)
addappid(1627583)
addappid(1627583, 1, "ec0920ea0c7547bb6cb646a98bb29ecb96e5d65da2ffd91e3074ea63d3c1aa84") -- Ys IX Monstrum Nox - Melodies of the Macabre  - Ys IX: Monstrum Nox - Soundtrack Sampler (1627583) Depot
setManifestid(1627583, "2978618969636615713", 166990813)
-- Ys IX Monstrum Nox - Chains and Chansons Official Digital Soundtrack (AppID: 1627584)
addappid(1627584)
addappid(1627584, 1, "3e3e4861db91a78d845834057c8d5cf9dccce012f6388f2ac76df4d54c0afb3f") -- Ys IX Monstrum Nox - Chains and Chansons Official Digital Soundtrack - Ys IX: Monstrum Nox - Soundtrack (1627584) Depot
setManifestid(1627584, "8552363550502815271", 516475807)
-- Ys IX Monstrum Nox - Monstrum Memoirs (AppID: 1627585)
addappid(1627585)
addappid(1627585, 1, "b7a3e62b91e0ea8e9d8c4c19fcd8e36dcf9681ec645df2a65e307b0f3e556fbc") -- Ys IX Monstrum Nox - Monstrum Memoirs - Ys IX: Monstrum Nox - Mini Art Book (1627585) Depot
setManifestid(1627585, "7510965904770597964", 21400675)
-- Ys IX Monstrum Nox - Nails in the Coffin Digital Art Book  Ys IX Prequel The Lost Sword Short Novel (AppID: 1627586)
addappid(1627586)
addappid(1627586, 1, "96d66ccb1b0fe2c7cca271e476a65af4a9706318498d4ce777fdfe54c383a491") -- Ys IX Monstrum Nox - Nails in the Coffin Digital Art Book  Ys IX Prequel The Lost Sword Short Novel - Ys IX: Monstrum Nox - Art Book (1627586) Depot
setManifestid(1627586, "5074920043789009636", 57509056)
-- Ys IX Monstrum Nox - Bonus Costumes and Items (AppID: 1636780)
addappid(1636780)
addappid(1636780, 1, "814be4c2816106abe13e15080ff4bdc4e645f040ee0ddbf19121347f11f49a77") -- Ys IX Monstrum Nox - Bonus Costumes and Items - Ys IX: Monstrum Nox - Bonus Costumes and Items (1636780) Depot
setManifestid(1636780, "7257166462989335151", 50175844)