-- 2353060's Lua and Manifest Created by Hubcap Manifest
-- Invincible VS
-- Created: July 09, 2026 at 13:53:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 17
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2353060) -- Invincible VS
-- MAIN APP DEPOTS
addappid(2353061, 1, "c3961a7a4786839c1bda96e5698609ac8677615ff115704a380f9a565e9f1204") -- Depot 2353061
setManifestid(2353061, "2199010963431313687", 10630926287)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4229690) -- Invincible VS - Zero Suit Mark Skin
addtoken(4229690, "12496434986396406278")
addappid(4229700) -- Invincible VS - Deluxe Edition Profile Cosmetics
addtoken(4229700, "3267554794675298766")
addappid(4439910) -- Digital Deluxe Upgrade
addappid(4439920) -- Rex Splode Towel
addappid(4439930) -- Invincible VS - Undercover and Overdressed - Skin Bundle
addappid(4439940) -- Universa - Additional Fighter
addappid(4439950) -- The Immortal - Additional Fighter
addappid(4439980) -- Conquest Breakout
addappid(4439990) -- Mark Movincihawk Atom Eve 646
addappid(4440020) -- Invincible VS - Universa - GDA Prisoner Skin
addappid(4440030) -- Invincible VS - The Immortal - Honest Abe Skin
addappid(4440050) -- Invincible VS - Dupli-Kate - Hidden Zero Skin
addappid(4440060) -- Invincible VS - Bots  Monsters - Skin Bundle
addappid(4440070) -- Ella Mental Diamond
addappid(4440100) -- Allen COP
addappid(4440110) -- Battle Beast Invincible Universe
addappid(4447740) -- Invincible VS - Titan - Streetwear Skin