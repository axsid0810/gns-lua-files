-- 3266090's Lua and Manifest Created by Hubcap Manifest
-- IT Specialist Simulator
-- Created: July 12, 2026 at 08:20:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3266090) -- IT Specialist Simulator
-- MAIN APP DEPOTS
addappid(3266091, 1, "92216a708ff2b3686451435986561ea2bc207c5efd748eaa28908263dad1b748") -- Depot 3266091
setManifestid(3266091, "2894538193999807496", 2695076473)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4322720) -- Support Pack