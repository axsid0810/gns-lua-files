-- 3647400's Lua and Manifest Created by Hubcap Manifest
-- Femtazio
-- Created: March 16, 2026 at 11:08:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3647400, 1, "1ec67d26bc3420f3bc2922a5e69070c697b8f0df4f6d8f50f020dcb412b53e93") -- Femtazio
-- MAIN APP DEPOTS
addappid(3647401, 1, "43159e26fb02ce3d28bac9b7c67d5bc6da3f79d01754f4bf09816a20696283ae") -- Depot 3647401
setManifestid(3647401, "292089662834170401", 1374637819)