-- 969990's Lua and Manifest Created by Hubcap Manifest
-- SpongeBob SquarePants: Battle for Bikini Bottom - Rehydrated
-- Created: September 30, 2025 at 19:11:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(969990) -- SpongeBob SquarePants: Battle for Bikini Bottom - Rehydrated
-- MAIN APP DEPOTS
addappid(969991, 1, "57d1e3f2c41fa70a907141460fe0aa4929500b4df7b13e24cfeca58089466401") -- SpongeBob SquarePants: Battle for Bikini Bottom - Rehydrated Content
setManifestid(969991, "6322912655307981707", 8241150435)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)