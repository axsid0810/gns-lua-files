-- 1830290's Lua and Manifest Created by Hubcap Manifest
-- Fall of an Empire
-- Created: July 19, 2026 at 19:13:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0 (1 excluded)
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1830290, 1, "eeafac21c6cb46e204166ee1a29ea23e1320c7b8f771013860faaf6cd5177570") -- Fall of an Empire
-- MAIN APP DEPOTS
addappid(1830292, 1, "ec5900c1b6d7b863356262f04f100e9a694fa170203a5e3a2e078f99826caf80") -- Depot 1830292
setManifestid(1830292, "8518699428718180185", 13551406622)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Fall of an Empire - Large Event Model (AppID: 4453450) - missing depot keys
-- addappid(4453450)