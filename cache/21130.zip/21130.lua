-- 21130's Lua and Manifest Created by Hubcap Manifest
-- LEGO® Harry Potter: Years 1-4
-- Created: September 29, 2025 at 21:50:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(21130) -- LEGO® Harry Potter: Years 1-4
-- MAIN APP DEPOTS
addappid(21131, 1, "3ea7510f6573780b2f0ea3a52aaf43c95183f877283383b9af7e65a2699c2f1f") -- lego harry potter content
setManifestid(21131, "1918178460208543378", 6333203278)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)