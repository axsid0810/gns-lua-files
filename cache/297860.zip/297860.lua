-- 297860's Lua and Manifest Created by Hubcap Manifest
-- Split/Second
-- Created: September 30, 2025 at 19:10:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(297860) -- Split/Second
-- MAIN APP DEPOTS
addappid(297861, 1, "5a323ce63fe5c987d11955152d219a21eb57be4b5760532ae617605ade3e4d8c") -- Split/Second Common Content
setManifestid(297861, "3419512658038062069", 5186526841)
addappid(297862, 1, "7cdf153935b3c649cf698936feb40d21bd4b800d10508992495c7fdf44ba5787") -- Split/Second E Depot
setManifestid(297862, "7377549898172343166", 2192262707)
addappid(297863, 1, "b89af7b2e609f51665ca3e7e5947b168a8619aca25b08715bdf05eed56fb66d7") -- Split/Second F Depot
setManifestid(297863, "1490014716780395496", 2192262707)
addappid(297864, 1, "6b56bc3e42cb9c2dd74f5409ffaa325f24bdda26278bfea6b17213370896f84e") -- Split/Second G Depot
setManifestid(297864, "2692902242601556649", 2192262707)
addappid(297865, 1, "cdfb75b982ceb4afa2414a307552c6a8fcc7c3860791c334fed683bc0b829847") -- Split/Second I Depot
setManifestid(297865, "5012021435054696198", 2192262707)
addappid(297866, 1, "f1eecfb6f5c19562352dbf6decc667bcf268aa6f3b6c7f42d73e0802cb80a353") -- Split/Second Po Depot
setManifestid(297866, "7879989922386487278", 2140931319)
addappid(297867, 1, "57d83195cf53555049ad7919c97931926ad923573b7bb13b38f73f6b784f28f2") -- Split/Second Ru Depot
setManifestid(297867, "6537947869063098587", 2136795007)
addappid(297868, 1, "52c5f420242903787930956769490346a63f06e22752446154d0412a8d8fe16a") -- Split/Second S Depot
setManifestid(297868, "9195974552867292290", 2192262707)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)