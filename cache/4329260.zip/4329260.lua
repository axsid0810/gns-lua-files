-- 4329260's Lua and Manifest Created by Hubcap Manifest
-- Substance 3D Painter 2026
-- Created: July 09, 2026 at 11:12:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4329260) -- Substance 3D Painter 2026
-- MAIN APP DEPOTS
addappid(4329262, 1, "cc202c619a64946a9e0c429e354df3ed9584bfd49b434099f84bd614d11fb0bb") -- Depot 4329262
setManifestid(4329262, "9180401305192923219", 5199259680)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)