-- 42680's Lua and Manifest Created by Hubcap Manifest
-- Call of Duty®: Modern Warfare® 3 (2011)
-- Created: July 10, 2026 at 15:21:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 19
-- Total DLCs: 1
-- Shared Depots: 17

-- MAIN APPLICATION
addappid(42680, 1, "4bf2d9294f477df1327e22e5efe65d98eca4d4592f0dc59fa451ab8ca8608fde") -- Call of Duty®: Modern Warfare® 3 (2011)
-- MAIN APP DEPOTS
addappid(42681, 1, "b7003c5ea7e370881499daaf5ba52ea4f3a1e76843fb37ab4d97753d94df8f95") -- Call of Duty Modern Warfare 3 SP Binaries
setManifestid(42681, "5651167211650965131", 5650432)
addappid(278331, 1, "0e8c2e3857ffb4d0cca47f5cf07ccbe8ee9e2ccc66be7ac744d1fa5167745310") -- Call of Duty: Modern Warfare 3 suitcase SP Binary
setManifestid(278331, "4380871370494427217", 61102059)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(42682, 1, "a7f0704e4a61083d1ef176c1efe2666a1e694ca4a2e40c17dda9f6c7a9ecceb1") -- Call of Duty Modern Warfare 3 Content (Shared from App 42690)
setManifestid(42682, "2661317971072643596", 7373987358)
addappid(42683, 1, "252c3bce60c362e7fdb65dabb24a8f0f6d3098ef341315df1a9f2208c8550c9f") -- Call of Duty Modern Warfare 3 english (Shared from App 42690)
setManifestid(42683, "1595601894688570808", 7724536563)
addappid(42684, 1, "7f904784b8e0755738fd4e3a4ade829396e449060bfd09275dd380dcff422703") -- Call of Duty Modern Warfare 3 spanish (Shared from App 42690)
setManifestid(42684, "2897345196099821819", 7950391875)
addappid(42685, 1, "55cf38352373d9669395acabad606ab665e82d0421b28dc2c39003055f91ac5f") -- Call of Duty Modern Warfare 3 german (Shared from App 42690)
setManifestid(42685, "1934757878507421371", 8014331652)
addappid(42686, 1, "1a676d3458091a765385fd997ed2171aeb13045296927c26c6a7bdebba7a3504") -- Call of Duty Modern Warfare 3 french (Shared from App 42690)
setManifestid(42686, "7270424907870526698", 7972402575)
addappid(42687, 1, "308eb88b20769f215eb317cc8cae34f4e7a4cc74d74e8a04262275dbe41f5eca") -- Call of Duty Modern Warfare 3 italian (Shared from App 42690)
setManifestid(42687, "7337464168521481857", 8012829876)
addappid(42688, 1, "a86e1ec84e71aad3a8c1b3fc2f3a237906eb6de447510da925db20173fb6b724") -- Call of Duty Modern Warfare 3 Russian (Shared from App 42690)
setManifestid(42688, "5872940112953203418", 8100213777)
addappid(42689, 1, "5562719fd8e66322c45af3e1b327211c2dd815edd340bd6969a0dac1ebad018f") -- Call of Duty Modern Warfare 3 Japanese (Shared from App 42690)
setManifestid(42689, "2918816197530142361", 7861354059)
addappid(42692, 1, "9c172487a1111e79908452b7cbbb680a070c482754b41be716278f44d681586d") -- Call of Duty Modern Warfare 3 Polish (Shared from App 42690)
setManifestid(42692, "7706916996646584447", 7724011501)
addappid(278310, 1, "c79da57207ccf933258ced455e9793b8ca10fdcd38300181226173ee705fe71b") -- Call of Duty: Modern Warfare 3 suitcase Content (Shared from App 42690)
setManifestid(278310, "4249278845652168066", 7393187949)
addappid(278312, 1, "ab950813ce8448c02aad504c486513a86c03aa55bde084c7c6be8f6ca2b71966") -- Call of Duty: Modern Warfare 3 suitcase English (Shared from App 42690)
setManifestid(278312, "5195291578372541229", 7724536449)
addappid(278313, 1, "fac16c89e3e4731296e3017b59a98ba16fa82ac1eca6b432fb0134639fbcc721") -- Call of Duty: Modern Warfare 3 suitcase Spanish (Shared from App 42690)
setManifestid(278313, "7085629571619323443", 7950391764)
addappid(278314, 1, "bba43dbf20aca5543940151e8cf815cc535967d8091a6e2a777a4486bb5410a4") -- Call of Duty: Modern Warfare 3 suitcase German (Shared from App 42690)
setManifestid(278314, "7496109829857218638", 8014331536)
addappid(278315, 1, "ab5bc1898a3c4805ce627fada0b379a4854a291ac920846e1505fcd7ace6b422") -- Call of Duty: Modern Warfare 3 suitcase French (Shared from App 42690)
setManifestid(278315, "1699434713779042015", 7972402461)
addappid(278316, 1, "654ea6858de9296fc3d260a92db3c6c51acfdda38afd672784f6b5907a2b9ab6") -- Call of Duty: Modern Warfare 3 suitcase Italian (Shared from App 42690)
setManifestid(278316, "6990762455880986012", 8012829762)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(42729) -- Call of Duty Modern Warfare Collection 1 (Preorder) DLC