-- 1543030's Lua and Manifest Created by Hubcap Manifest
-- Sword and Fairy 7
-- Created: September 30, 2025 at 21:27:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1543030) -- Sword and Fairy 7
-- MAIN APP DEPOTS
addappid(1543031, 1, "80c82f692c1dccb0e5de735f6b7513dc62421d6f9bfdf44af13992f5de4367cd") -- 仙剑奇侠传七 Content
setManifestid(1543031, "1328293710815739891", 32459173251)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Sword and Fairy 7 - Dreamlike World Expansion (AppID: 2223240)
addappid(2223240)
addappid(2223241, 1, "c7d3ba2342020f382cb7e6c7f202bbb7a136283e87870d04190562e15966f398") -- Sword and Fairy 7 - Dreamlike World Expansion - Depot 2223241
setManifestid(2223241, "8900201496308069518", 12702625858)