-- 1677110's Lua and Manifest Created by Hubcap Manifest
-- Lightyear Frontier
-- Created: April 17, 2026 at 18:17:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1677110, 1, "d560a3870531071af4983a2ae2deee9dce67dc2362b9bcc873915fe2a44c40b1") -- Lightyear Frontier
-- MAIN APP DEPOTS
addappid(1677111, 1, "5867f4cfbcf22c9f91f80049ace8660657651cbd62163e7e690b3644dbd98d8b") -- Depot 1677111
setManifestid(1677111, "5058066520825749840", 4190414867)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- PhysX System Software 9.14.0702 (Shared from App 228980)
setManifestid(229033, "2059065101492814639", 60039803)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2655090) -- Lightyear Frontier - Pioneers Bundle