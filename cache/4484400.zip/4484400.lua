-- 4484400's Lua and Manifest Created by Hubcap Manifest
-- Horny Massage Clinic
-- Created: June 16, 2026 at 20:00:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4484400, 1, "fcf0a7fbfff6214676f1f0be0da16ca767b66c79def2a60ecc0b37f0740d945e") -- Horny Massage Clinic
-- MAIN APP DEPOTS
addappid(4484401, 1, "3cee1aa8b1c1e8767fceb1b5907f518643b7d3fd1876272fcd25a5ec4189c5d0") -- Depot 4484401
setManifestid(4484401, "6155732645423312380", 1742521551)