-- 3011560's Lua and Manifest Created by Hubcap Manifest
-- City Lights Love Bites Season 0
-- Created: July 27, 2026 at 02:34:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3011560, 1, "9d8c7730b862e4fccc86b14e78f6f8079215b6ac319e8386ba5ca24a15c33069") -- City Lights Love Bites Season 0
-- MAIN APP DEPOTS
addappid(3011561, 1, "1d00e46b6cf91037e5bcc758b2e7730e71037025ab3c8af09a8a00789bac23a0") -- Depot 3011561
setManifestid(3011561, "5686419383240089988", 19689169818)