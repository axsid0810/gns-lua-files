-- 1816300's Lua and Manifest Created by Hubcap Manifest
-- HARVESTELLA
-- Created: September 29, 2025 at 16:52:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1816300) -- HARVESTELLA
-- MAIN APP DEPOTS
addappid(1816301, 1, "ee9bc17bfae12f0a3864b13ff4acdeefffb4a42d98740d738f71488009692478") -- Depot 1816301
setManifestid(1816301, "4624799595624781379", 11596556830)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)