-- 385760's Lua and Manifest Created by Hubcap Manifest
-- NBA 2K17
-- Created: September 30, 2025 at 03:00:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 3
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(385760) -- NBA 2K17
-- MAIN APP DEPOTS
addappid(385762, 1, "477799d3456bb786f58fff1c9a98606cbc55f268ba95c938ba34e7ada2845f43") -- NBA 2K17 Content
setManifestid(385762, "9000904546921305028", 69212417612)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(515640) -- NBA 2K17 - Legend Edition Gold
addappid(515641) -- NBA 2K17 - Legend Edition
addappid(515642) -- NBA 2K17 Early Tip Off