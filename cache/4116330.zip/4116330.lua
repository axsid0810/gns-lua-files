-- 4116330's Lua and Manifest Created by Hubcap Manifest
-- Kitty Witchy
-- Created: July 03, 2026 at 06:03:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4116330) -- Kitty Witchy
-- MAIN APP DEPOTS
addappid(4116331, 1, "4fdf398db1e4760b2312de0d3b86231beb3c1b3bcba0b658367d1786bbcfd6af") -- Depot 4116331
setManifestid(4116331, "7649380414955519564", 1408839954)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)