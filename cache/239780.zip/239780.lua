-- 239780's Lua and Manifest Created by Hubcap Manifest
-- Call of Duty Black Ops - OSX Remote Console
-- Created: January 20, 2026 at 07:17:12 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(239780) -- Call of Duty Black Ops - OSX Remote Console
-- MAIN APP DEPOTS
addappid(239781, 1, "90156caf5b4b2478f4197d7526d71b8144a27e329996ad4967e622f0705e491d") -- Call of Duty 4 - OSX Dedicated Server Content
setManifestid(239781, "2610831885432459732", 3477618)