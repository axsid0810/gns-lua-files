-- 2651440's Lua and Manifest Created by Hubcap Manifest
-- Fallen Elf Freya
-- Created: May 25, 2026 at 07:22:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2651440, 1, "5a6cc18e8981f0acc6ce5a648dd400db0653ae3b26969a38a15a290d09b752f1") -- Fallen Elf Freya
-- MAIN APP DEPOTS
addappid(2651441, 1, "9f20b1b76e295cdd391c66998004ddd2c8ebaa8777e96a4b5c067ef1a38bacb4") -- Depot 2651441
setManifestid(2651441, "6776615499298707681", 1443197839)