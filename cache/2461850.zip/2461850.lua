-- 2461850's Lua and Manifest Created by Hubcap Manifest
-- Senua’s Saga: Hellblade II
-- Created: December 19, 2025 at 13:48:56 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2461850) -- Senua’s Saga: Hellblade II
-- MAIN APP DEPOTS
addappid(2461851, 1, "20ebd57bddf344eb01febcbdaa20afc8b1a8fe7e4bdbeecc88ca520b0df44560") -- Depot 2461851
setManifestid(2461851, "4350341503723460090", 53042428585)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)