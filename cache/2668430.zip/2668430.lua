-- 2668430's Lua and Manifest Created by Hubcap Manifest
-- The Legend of Heroes: Trails through Daybreak II
-- Created: October 01, 2025 at 00:09:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 16
-- Total DLCs: 14
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2668430) -- The Legend of Heroes: Trails through Daybreak II
-- MAIN APP DEPOTS
addappid(2668431, 1, "d906d39dfedc6954ef12ecff143e3141f6a4761422b6a638f64835b85d464a11") -- Depot 2668431
setManifestid(2668431, "4476781295113721650", 22900575031)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- The Legend of Heroes Trails through Daybreak II - Triple Contents  Xipha Basic Quartz Pack (AppID: 3449230)
addappid(3449230)
addappid(3449230, 1, "c264dc307994fc489aa4f3283d973425d9abdb5b3229fe3634058e292a66dd79") -- The Legend of Heroes Trails through Daybreak II - Triple Contents  Xipha Basic Quartz Pack - Depot 3449230
setManifestid(3449230, "5743732319124308027", 8)
-- The Legend of Heroes Trails through Daybreak II - Shizunas Z1 Pit Girl Attire  Winning Poster Contest Art Pack (AppID: 3449240)
addappid(3449240)
addappid(3449240, 1, "23e1622d9d876eea0ec0f207b9e656d5659ae97f779874271cd40ec0a6e47080") -- The Legend of Heroes Trails through Daybreak II - Shizunas Z1 Pit Girl Attire  Winning Poster Contest Art Pack - Depot 3449240
setManifestid(3449240, "9030204939961486267", 8)
-- The Legend of Heroes Trails through Daybreak II - Agns Z1 Pit Girl Attire  The Crimson Grendel Pack (AppID: 3449250)
addappid(3449250)
addappid(3449250, 1, "77914d3a07bea410d3eea8c6f353c67b01cc8c3852bc1e45bd729acd90d8d2c5") -- The Legend of Heroes Trails through Daybreak II - Agns Z1 Pit Girl Attire  The Crimson Grendel Pack - Depot 3449250
setManifestid(3449250, "5790521294674592925", 8)
-- The Legend of Heroes Trails through Daybreak II - Elaines Z1 Pit Girl  Rennes Grimkitty Attire Pack (AppID: 3449260)
addappid(3449260)
addappid(3449260, 1, "057dcdb7e54005dd5f0a7879139f1e87d50ddc2cafbdef1874605c90ce78e3b8") -- The Legend of Heroes Trails through Daybreak II - Elaines Z1 Pit Girl  Rennes Grimkitty Attire Pack - Depot 3449260
setManifestid(3449260, "9104757049382181944", 8)
-- The Legend of Heroes Trails through Daybreak II - Accessory Pack (AppID: 3449270)
addappid(3449270)
addappid(3449270, 1, "a211e3dcf4f72630a952fbc6ded735cddd3704cc3632ab259e6b0c5359365569") -- The Legend of Heroes Trails through Daybreak II - Accessory Pack - Depot 3449270
setManifestid(3449270, "9110657327467797821", 4)
-- The Legend of Heroes Trails through Daybreak II - Holo Core Voice Pack (AppID: 3449280)
addappid(3449280)
addappid(3449280, 1, "4ccdbbdb9a29a7fb664cf4676ed48e8a88b961b1dadde3ee72a3e8106929acc0") -- The Legend of Heroes Trails through Daybreak II - Holo Core Voice Pack - Depot 3449280
setManifestid(3449280, "6357375693334375611", 4)
-- The Legend of Heroes Trails through Daybreak II - Costume Pack (AppID: 3449290)
addappid(3449290)
addappid(3449290, 1, "faef8eeee7d7ff69fced9e7c2e13e284b0790c9ddd70a325e1b46927b45f6b79") -- The Legend of Heroes Trails through Daybreak II - Costume Pack - Depot 3449290
setManifestid(3449290, "8969974942490179259", 4)
-- The Legend of Heroes Trails through Daybreak II - BGM Pack (AppID: 3449300)
addappid(3449300)
addappid(3449300, 1, "2dfdf31c5f41fec525ba10287791587715b24125581d05165dd0b228297b9cdf") -- The Legend of Heroes Trails through Daybreak II - BGM Pack - Depot 3449300
setManifestid(3449300, "7831284576376710877", 4)
-- The Legend of Heroes Trails through Daybreak II - Starter Pack (AppID: 3449310)
addappid(3449310)
addappid(3449310, 1, "7951d96f5f0fca2daba73b055dfa6b446a87d3d2a9a2a645dbe78a65dbee96e0") -- The Legend of Heroes Trails through Daybreak II - Starter Pack - Depot 3449310
setManifestid(3449310, "8161499644587117376", 4)
-- The Legend of Heroes Trails through Daybreak II - Advanced Pack (AppID: 3449320)
addappid(3449320)
addappid(3449320, 1, "08671e336223fe2b2a141104d683ad3c66b4d6a1122cce80e1e983112168d57f") -- The Legend of Heroes Trails through Daybreak II - Advanced Pack - Depot 3449320
setManifestid(3449320, "5242263999382897601", 4)
-- The Legend of Heroes Trails through Daybreak II - Free Sample Pack (AppID: 3449330)
addappid(3449330)
addappid(3449330, 1, "c1f6535eb07ff740f7c5dfbf76b2edf0eda01b8f81f505574e58b14b38bc0837") -- The Legend of Heroes Trails through Daybreak II - Free Sample Pack - Depot 3449330
setManifestid(3449330, "5022343043971794244", 12)
-- The Legend of Heroes Trails through Daybreak II - Art Book (AppID: 3449340)
addappid(3449340)
addappid(3449340, 1, "75229aaca3a8a2f2bbf601ec236cf07028ecde9488c4aca8afbd4752068d7c5b") -- The Legend of Heroes Trails through Daybreak II - Art Book - Depot 3449340
setManifestid(3449340, "3909354162339291103", 28103588)
-- The Legend of Heroes Trails through Daybreak II - Mini Art Book (AppID: 3449350)
addappid(3449350)
addappid(3449350, 1, "0e8ec13b07362113b1dd4ae9b82ba3d847c87b09dafe54a7282d587f7acb7f66") -- The Legend of Heroes Trails through Daybreak II - Mini Art Book - Depot 3449350
setManifestid(3449350, "130631155552844540", 9000310)
-- The Legend of Heroes Trails through Daybreak II - Atlas of Calvard Poster (AppID: 3449360)
addappid(3449360)
addappid(3449360, 1, "21d4bdcf13fcc683f6a49020b1a6b3ec838c933db73d82bdd666da5666a27ece") -- The Legend of Heroes Trails through Daybreak II - Atlas of Calvard Poster - Depot 3449360
setManifestid(3449360, "4560113567592389887", 24544213)