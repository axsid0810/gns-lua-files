-- 1420080's Lua and Manifest Created by Hubcap Manifest
-- Wonder Boy: Asha in monster world
-- Created: October 01, 2025 at 07:56:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1420080) -- Wonder Boy: Asha in monster world
-- MAIN APP DEPOTS
addappid(1420081, 1, "84c89f7bea7fcff461be45b60b76dcc27a5551b39dff8f718e0a52cb3523eac9") -- WONDER BOY ASHA in Monster World Content
setManifestid(1420081, "5205786393550913244", 2381195257)
-- DLCS WITH DEDICATED DEPOTS
-- WONDER BOY Asha in Monster World -EXTRA CONTENTS- (AppID: 1755160)
addappid(1755160)
addappid(1755160, 1, "a3e9fd8643bdf83c924e16784a7bfa566a990deed235cbe8e6305f20ff7778ab") -- WONDER BOY Asha in Monster World -EXTRA CONTENTS- - Depot 1755160
setManifestid(1755160, "8442333882647221758", 228563785)