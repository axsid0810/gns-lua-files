-- 2796010's Lua and Manifest Created by Hubcap Manifest
-- Party Club
-- Created: June 18, 2026 at 00:22:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2796010, 1, "e5ba5a3ec46bb3b341c4c096e62b62f3de20b6cc59b7bd8af9342ea328e9afa4") -- Party Club
-- MAIN APP DEPOTS
addappid(2796011, 1, "5ae77169c533cca90d65bf5be54cc67554c4e7e6b9f2dc23e0bf4c158e0150ee") -- Depot 2796011
setManifestid(2796011, "6351305368969441347", 5908711088)
addappid(2796012, 1, "8d9d5ca34932047596b7e438cc6e1ab794896b64808ba7c131aecbfde70769ef") -- Depot 2796012
setManifestid(2796012, "8451904875102828417", 6140366423)
addappid(2796014, 1, "31fddaa327c4054f723c5dca4c0d5d980e00348af232d741c85e7ce59ee3a9ed") -- Depot 2796014
setManifestid(2796014, "6499242367528864010", 5909186121)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3913830) -- Party Club - Mini Mayhem DLC