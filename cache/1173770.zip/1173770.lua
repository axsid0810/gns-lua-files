-- 1173770's Lua and Manifest Created by Hubcap Manifest
-- FINAL FANTASY
-- Created: October 13, 2025 at 08:51:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1173770) -- FINAL FANTASY
-- MAIN APP DEPOTS
addappid(1173771, 1, "fab6556c5fd8ece93cfb03ab4998ea82fe6290d7991bf77e7073693eed4584cf") -- LastSP1 Content
setManifestid(1173771, "7609542785729961888", 376348767)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)
-- DLCS WITH DEDICATED DEPOTS
-- FINAL FANTASY OST  Wallpaper (AppID: 1638280)
addappid(1638280)
addappid(1638280, 1, "85404e4cba508d1bed970ecdfe04c431a7889e1e20ce7e36d0f57cd98387c1b5") -- FINAL FANTASY OST  Wallpaper - FINAL FANTASY: OST & Wallpaper (1638280) Depot
setManifestid(1638280, "4770474821492259054", 47622540)