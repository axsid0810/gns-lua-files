-- 1530160's Lua and Manifest Created by Hubcap Manifest
-- Digimon World: Next Order
-- Created: December 03, 2025 at 13:21:31 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1530160, 1, "444f755fe496aed67ace6ce8d210de627fe0b4fa62fc690f9ff6d282475cc38a") -- Digimon World: Next Order
-- MAIN APP DEPOTS
addappid(1530161, 1, "79f6668266ed6a85515dbd54406ca18c6268feafc1e8f239ee78bad23087dd8d") -- Depot 1530161
setManifestid(1530161, "8662808378398768237", 7385247068)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)