-- 234670's Lua and Manifest Created by Hubcap Manifest
-- NARUTO SHIPPUDEN: Ultimate Ninja STORM 3 Full Burst
-- Created: September 30, 2025 at 02:51:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(234670) -- NARUTO SHIPPUDEN: Ultimate Ninja STORM 3 Full Burst
-- MAIN APP DEPOTS
addappid(234671, 1, "132185278774455f9ac417b8e8938131b4d9d8821ebd9c2bc0d02d9883069405") -- Naruto Shippuden Ultimate Ninja Storm 3 Content
setManifestid(234671, "284665897609485612", 0)
addappid(234672, 1, "393c2dd43be41a8598a40b492a0ad8a41baf91379b6fa948de855f7f94db31f3") -- Naruto Shippuden Ultimate Ninja Storm 3 FB EU Content
setManifestid(234672, "2059070709147005474", 7562625587)
addappid(234673, 1, "68c6e38f4e45def7ae51cb544f9d433a7c0e8a21141dfeada88fec37b5b2f462") -- Naruto Shippuden Ultimate Ninja Storm 3 FB NA Content
setManifestid(234673, "7628913490051072341", 7460862464)
addappid(234674, 1, "500459fca252625c182791972170e28807a7095bc745b9503a56cf5e5adea361") -- Naruto Shippuden Ultimate Ninja Storm 3 FB NBGI_CHECK Content
setManifestid(234674, "231737632292320580", 0)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
-- DLCS WITH DEDICATED DEPOTS
-- NARUTO SHIPPUDEN Ultimate Ninja STORM 3 Full Burst - HD - (AppID: 543890)
addappid(543890)
addappid(543890, 1, "025485ca898026fa8c5bb1088c516831d0c299276661cd847c0f8e5b8ed0bb05") -- NARUTO SHIPPUDEN Ultimate Ninja STORM 3 Full Burst - HD - - NARUTO SHIPPUDEN: Ultimate Ninja STORM 3 Full Burst - DLC1 (543890) 個のデポ
setManifestid(543890, "1432168299579796780", 9895912424)