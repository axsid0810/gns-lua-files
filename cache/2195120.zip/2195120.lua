-- 2195120's Lua and Manifest Created by Hubcap Manifest
-- Go-Go Town!
-- Created: July 21, 2026 at 23:07:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2195120, 1, "a11b317ebb377da13222e6e6ada384a8dd41fe74b8b722736e9ca7b21d15ebfd") -- Go-Go Town!
-- MAIN APP DEPOTS
addappid(2195121, 1, "94d3a57270a0d1f85e33c7108de0457196cf7b7fd4ee7c45b233972ba6d3b962") -- Depot 2195121
setManifestid(2195121, "6870159984295514894", 1463729563)