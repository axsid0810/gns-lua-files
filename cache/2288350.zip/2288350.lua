-- 2288350's Lua and Manifest Created by Hubcap Manifest
-- RAIDOU Remastered: The Mystery of the Soulless Army
-- Created: October 23, 2025 at 14:07:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 10
-- Total DLCs: 9

-- MAIN APPLICATION
addappid(2288350) -- RAIDOU Remastered: The Mystery of the Soulless Army
-- MAIN APP DEPOTS
addappid(2288351, 1, "584b8f457ad0579c460b81cc7584871d2076e59040b8e355650051f39e5509f3") -- Depot 2288351
setManifestid(2288351, "1238773109212108775", 17368901560)
-- DLCS WITH DEDICATED DEPOTS
-- RAIDOU Remastered The Mystery of the Soulless Army - Kuzunoha Village Trainings (AppID: 2486840)
addappid(2486840)
addappid(2486840, 1, "3100d6a1061f18806a2743d0062e37bceebd13f6ba7df00660b3f8f58c168dde") -- RAIDOU Remastered The Mystery of the Soulless Army - Kuzunoha Village Trainings - Depot 2486840
setManifestid(2486840, "3868473170158526313", 721030)
-- RAIDOU Remastered The Mystery of the Soulless Army - Demons of the Aril Rift (AppID: 2486841)
addappid(2486841)
addappid(2486841, 1, "af8bdb353baf46d11c1844cb1c0f62b83f474dc5e80687382efaab0dfe85eea8") -- RAIDOU Remastered The Mystery of the Soulless Army - Demons of the Aril Rift - Depot 2486841
setManifestid(2486841, "9150438052186207553", 4457150)
-- RAIDOU Remastered The Mystery of the Soulless Army - Guest Demons Pack (AppID: 2486842)
addappid(2486842)
addappid(2486842, 1, "ae67985d47bc4ec9944081c0815305b013536f555e71737e3363da0b900a0b6d") -- RAIDOU Remastered The Mystery of the Soulless Army - Guest Demons Pack - Depot 2486842
setManifestid(2486842, "5494123129689557076", 21360241)
-- RAIDOU Remastered The Mystery of the Soulless Army - Demonic Designations Summoner Titles (AppID: 2486843)
addappid(2486843)
addappid(2486843, 1, "63faa85dfe4f6e6173407edf577dd298c78cd8d9e72513a0314ddd9bb791491d") -- RAIDOU Remastered The Mystery of the Soulless Army - Demonic Designations Summoner Titles - Depot 2486843
setManifestid(2486843, "5879568682417045509", 238090)
-- RAIDOU Remastered The Mystery of the Soulless Army - A Special Briefing (AppID: 2486844)
addappid(2486844)
addappid(2486844, 1, "28fa9c69e81bed805638c5466d4f596b3f6b1ed4d4343e4cbcbfdf95722e0514") -- RAIDOU Remastered The Mystery of the Soulless Army - A Special Briefing - Depot 2486844
setManifestid(2486844, "9146745134707839547", 78811)
-- RAIDOU Remastered The Mystery of the Soulless Army - Raidou Glasses (AppID: 2486845)
addappid(2486845)
addappid(2486845, 1, "b5ec8393c1fa4a977d0dba88aff0281a930e0341190fa65158c6067f8836a309") -- RAIDOU Remastered The Mystery of the Soulless Army - Raidou Glasses - Depot 2486845
setManifestid(2486845, "9187613266433653033", 233190)
-- RAIDOU Remastered The Mystery of the Soulless Army - Skill Book Pack (AppID: 2486846)
addappid(2486846)
addappid(2486846, 1, "05b9b4483fc7d8b56cbe8f79eeafeda98a50d3d3eaeea01c3744b9f5429ac04f") -- RAIDOU Remastered The Mystery of the Soulless Army - Skill Book Pack - Depot 2486846
setManifestid(2486846, "6407885136060269582", 46623)
-- RAIDOU Remastered The Mystery of the Soulless Army - Survival Pack (AppID: 2486847)
addappid(2486847)
addappid(2486847, 1, "9ed2df163f7f297d57e121ce347f97b1ca2cb228632b7da1f7cdb997002de448") -- RAIDOU Remastered The Mystery of the Soulless Army - Survival Pack - Depot 2486847
setManifestid(2486847, "9136072776669612931", 96451)
-- RAIDOU Remastered The Mystery of the Soulless Army - Survival Pack Light Gear (AppID: 2486848)
addappid(2486848)
addappid(2486848, 1, "9daba586b900532658c4d40d60aa7d4a0f9aa2097d798b49a4c65c37d746d77c") -- RAIDOU Remastered The Mystery of the Soulless Army - Survival Pack Light Gear - Depot 2486848
setManifestid(2486848, "9177818177746597766", 96390)