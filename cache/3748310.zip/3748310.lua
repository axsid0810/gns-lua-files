-- 3748310's Lua and Manifest Created by Hubcap Manifest
-- Wanderers' Outpost
-- Created: July 22, 2026 at 06:39:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3748310) -- Wanderers' Outpost
-- MAIN APP DEPOTS
addappid(3748311, 1, "63cecb4e45c5182f478913a67f22e491fb60b945819c8a092765e20f90f5c5f4") -- Depot 3748311
setManifestid(3748311, "752671984518824312", 706793496)