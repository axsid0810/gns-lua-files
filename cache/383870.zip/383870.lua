-- 383870's Lua and Manifest Created by Hubcap Manifest
-- Firewatch
-- Created: January 19, 2026 at 17:19:35 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 11
-- Total DLCs: 0
-- Shared Depots: 7

-- MAIN APPLICATION
addappid(383870, 1, "4a62c511c151cea2dc5089e320a059f8cdfc42e32b6c3377c6e9553a06b1d318") -- Firewatch
-- MAIN APP DEPOTS
addappid(383871, 1, "1a37285423d17dfbf1e4c0f3319192c79b8a2bf6d5c861b36298bc14504faa9b") -- Firewatch Win x64
setManifestid(383871, "4327494393378246115", 4250716810)
addappid(383872, 1, "8e553fee57cb14cdc44ce815d9c1b60c9dc0d430a8170e5ad5f3fad8e62f017b") -- Firewatch Mac x64
setManifestid(383872, "6083053279432066345", 4274692637)
addappid(383874, 1, "eb74dde6a14da9a19a68950093a2357e4e2cd1523688ee3eb4b89d5b06ce62b5") -- Firewatch Linux x64
setManifestid(383874, "8136046374338142426", 4252003098)
addappid(383873, 1, "2c69dfdaea9c740afacda71fff1f956d8ef2aa5bce1861c83640525155632f04") -- Firewatch Win x32
setManifestid(383873, "858968618876836", 0)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)