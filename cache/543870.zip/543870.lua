-- 543870's Lua and Manifest Created by Hubcap Manifest
-- NARUTO SHIPPUDEN: Ultimate Ninja STORM 2
-- Created: September 30, 2025 at 02:51:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(543870) -- NARUTO SHIPPUDEN: Ultimate Ninja STORM 2
-- MAIN APP DEPOTS
addappid(543871, 1, "3c04bda9a8a328aa4d425eb8c6858a4f7b108a9fa13e390d5e628b949ecb083d") -- Qwant2 Content
setManifestid(543871, "523331981350778192", 7629328612)