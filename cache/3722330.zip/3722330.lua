-- 3722330's Lua and Manifest Created by Hubcap Manifest
-- Shift At Midnight
-- Created: July 23, 2026 at 11:23:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3722330) -- Shift At Midnight
-- MAIN APP DEPOTS
addappid(3722331, 1, "241b88aeb27a250cbfff336e4e5ec6f28a60d136f4431f8bdcbf84a0506e5ed4") -- Depot 3722331
setManifestid(3722331, "6232251891004335476", 871743884)