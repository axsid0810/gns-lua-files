-- 749960's Lua and Manifest Created by Hubcap Manifest
-- Townsmen VR
-- Created: December 18, 2025 at 18:31:41 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(749960) -- Townsmen VR
-- MAIN APP DEPOTS
addappid(749961, 1, "e99ec159a1a44ccc15c58625d0862719d2e623f9597be4b44d6607b45508a793") -- Townsmen VR Content
setManifestid(749961, "2597595643790866919", 4072290918)