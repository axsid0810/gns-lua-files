-- 220240's Lua and Manifest Created by Hubcap Manifest
-- Far Cry® 3
-- Created: July 01, 2026 at 12:15:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 21
-- Total DLCs: 6 (1 excluded)
-- Shared Depots: 1
-- Blacklisted Depots: 1
--   Depot 226458: Unavailable DLC

-- MAIN APPLICATION
addappid(220240, 1, "a61a1cf41af4730d5c90ec3a2e9d26cb20baf17def74d203c13e1a3ff685b4ea") -- Far Cry® 3
-- MAIN APP DEPOTS
addappid(220241, 1, "3dc1c40f6a253fbda33a9cef065e0df1cb4e16b53ab150559cfc67c95bdbc0aa") -- Far Cry 3 Common
setManifestid(220241, "5896142001500010150", 11924555916)
addappid(220243, 1, "103327274fff7f9d54d4fec5995dbe31d29f1ca01e1ce8d6da4bbb46a20e83c0") -- Far Cry 3 French
setManifestid(220243, "8436900324818409435", 14854858)
addappid(220244, 1, "986b445fe4b091f0728c11019f1c17e82c96e966dd2274b472148222cf564b1e") -- Far Cry 3 Italian
setManifestid(220244, "1446238701376931089", 7430319)
addappid(220245, 1, "9c76858d3b47e4f4b02c56426b76a3385aa8b20e46b3dc39d6fd0bbb8bf99e9b") -- Far Cry 3 German
setManifestid(220245, "2540975046130074424", 7435141)
addappid(220246, 1, "e2415a5c12c4a30dc2c2a931338b016cc0cb845e123574cb3f0a3e330ab2cf05") -- Far Cry 3 Portuguese
setManifestid(220246, "90934089515212202", 2044494)
addappid(220247, 1, "156f4584cf999337becb0b52fe1d153f991d54863a5a691be78b0ecd6edb1425") -- Far Cry 3 Spanish
setManifestid(220247, "3278778596397332424", 7439252)
addappid(220248, 1, "85c54a6e0950d80a075aee537af97046460aa6ec1687c86b735d60caec9fb767") -- Far Cry 3 Swedish
setManifestid(220248, "7502707974879090242", 7420681)
addappid(220249, 1, "0123b2bec7f102edbe9687d092263ca258b512f8f7f6e7086542d440fb01af80") -- Far Cry 3 Dutch
setManifestid(220249, "3443261590545127881", 7505005)
addappid(220250, 1, "4c1fb62fc31755bfb4ca6e8488488789486477910b9fdeb851474b136b4e21b6") -- Far Cry 3 Norwegian
setManifestid(220250, "6256856753241859048", 7420822)
addappid(220251, 1, "979027d6b7eb05fc2b80c377203c94ffcd2a04f316187c9d76a84424195d4935") -- Far Cry 3 Danish
setManifestid(220251, "3092477369987826489", 7421556)
addappid(220242, 1, "6ae4acd7928642d198f34b7d89a6ffa7ca0f1d41c998127c2d9ac2c8056be57d") -- Far Cry 3 English
setManifestid(220242, "668508214988670452", 14840654)
addappid(220252, 1, "a08dabf711d0dd85d278a65c29208867cc28b4324fa0f32a0d84d176385f75cb") -- Far Cry 3 Polish
setManifestid(220252, "1007747486412002922", 7457028)
addappid(226455, 1, "1f05a0a4ab5bf7a681e5903b3516eb50fa31f7ee676f3913bfd4ad7110fb82dd") -- Far Cry 3 Czech
setManifestid(226455, "2306901777804086020", 485750)
addappid(226456, 1, "d974d3b6f97b04e42ee91c19e64d3b35f1528495e864d9b8bfc34d406a6f6db7") -- Far Cry 3 Russian
setManifestid(226456, "3836955638345779953", 7447397)
addappid(220253, 1, "1a84e70789a71107cbc04f1b270421c85aa26fe217c2d7e97202d1ccd1383d1f") -- Far Cry 3 Schinese
setManifestid(220253, "3502071805828553100", 7420377)
addappid(220254, 1, "6769dd40329d22e1b37ef3cdc2893b5846ec445153160fb87b138f45bcb8b599") -- Far Cry 3 TChinese
setManifestid(220254, "1263460290778726057", 7420377)
addappid(220255, 1, "ee326194cf98b5abd347e5e16d2d4a7dea0285a9e859d6f580587b50a85fb99a") -- Far Cry 3 Korean
setManifestid(220255, "7412199545536898917", 7420377)
addappid(220256, 1, "2fc1d80bddb5da522cb2cac92f358ece42610f185ed04367ff2eb1f8f24b5ded") -- Far Cry® 3 Japanese
setManifestid(220256, "2375629037347470307", 7420377)
-- SHARED DEPOTS (from other apps)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "8936186649444731600", 264933784)
-- DLCS WITH DEDICATED DEPOTS
-- Far Cry 3 - Deluxe Edition Content (AppID: 226451)
addappid(226451)
addappid(226451, 1, "32f9d8f1f8398b650cf25ec427e88f503613111e482926a6cb8e6f20426c016c") -- Far Cry 3 - Deluxe Edition Content - Far Cry 3 - Deluxe Content
setManifestid(226451, "8532199382147047194", 176211450)
-- Far Cry 3 High Tides DLC (AppID: 226457)
addappid(226457)
addappid(226457, 1, "c59177dd49df61e1203f03d37b0227827b6209454a14baeb77bec655912927b2") -- Far Cry 3 High Tides DLC - Far Cry 3 - High Tide
setManifestid(226457, "8756461153186112053", 257886841)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(226452) -- Far Cry 3 - Standard Key
addappid(226453) -- Far Cry 3 - Standard Preorder Key
addappid(226454) -- Far Cry 3 - Deluxe Key
addappid(226459) -- Far Cry 3 - Deluxe Upgrade Key
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MANIFEST BLACKLIST)
-- addappid(226458) -- DLC 226458 (Unavailable DLC)