-- 1401590's Lua and Manifest Created by Hubcap Manifest
-- Disney Dreamlight Valley
-- Created: July 29, 2026 at 09:23:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 14
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1401590, 1, "8343743d2d37758d19926a9f0784ed3776128e4392f2e4e3e3a4f886ad421832") -- Disney Dreamlight Valley
-- MAIN APP DEPOTS
addappid(1401591, 1, "d99c609dc11544c08f0a832afd94357653d3f924cc683c27394cf548b1c3d161") -- Depot 1401591
setManifestid(1401591, "28830177964916363", 27054061134)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2061640) -- Disney Dreamlight Valley - Deluxe Edition
addappid(2061641) -- Disney Dreamlight Valley - Ultimate Edition
addappid(2632050) -- Disney Dreamlight Valley A Rift in Time
addappid(2632060) -- Disney Dreamlight Valley - Gold Edition
addappid(3259120) -- Disney Dreamlight Valley The Storybook Vale
addappid(3311890) -- Disney Dreamlight Valley - The Storybook Vale Bundle
addappid(3311900) -- Disney Dreamlight Valley The Storybook Vale  Magical Edition
addappid(3311910) -- Disney Dreamlight Valley - Enchanted Edition
addtoken(3311910, "1442963769285144513")
addappid(3979520) -- Disney Dreamlight Valley Wishblossom Ranch
addappid(3979530) -- Disney Dreamlight Valley Wishblossom Ranch  Deluxe Edition
addappid(4127920) -- Disney Dreamlight Valley  Ultimate Edition
addappid(4127930) -- Disney Dreamlight Valley  Wishblossom Ranch Edition
addappid(4376930) -- Disney Dreamlight Valley Honeyglow Woods
addappid(4941320) -- Disney Dreamlight ValleyHoneyglow Woods Edition
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1401592) -- Depot 1401592 (empty depot)
-- addappid(2086000) -- Depot 2086000 (empty depot)