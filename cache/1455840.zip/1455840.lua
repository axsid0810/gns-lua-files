-- 1455840's Lua and Manifest Created by Hubcap Manifest
-- Dorfromantik
-- Created: July 09, 2026 at 03:43:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(1455840, 1, "855cb8ab7067b07ce9e78acc592293e67d3c6490f77d4010a0f5a59c627adbac") -- Dorfromantik
-- MAIN APP DEPOTS
addappid(1455841, 1, "3e4b34c8fbc5bd37cbb53c5620a4a9dbab88e85274ffda1494d2a0ffa246d3fa") -- Depot 1455841
setManifestid(1455841, "7696298790508123439", 691079517)
addappid(1455842, 1, "33aa0d0ed605848dcdb9a205b18f4a27f8bed87d81b2d6c316b378a8c0ea223e") -- Depot 1455842
setManifestid(1455842, "4516389518392858130", 441384403)
addappid(1455844, 1, "3266a3dcaa4e16e2ff1862877d244f23e85e3c99f92e2e9c0592419f19ab0de0") -- Depot 1455844
setManifestid(1455844, "5060208295790815277", 717506156)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Dorfromantik - Medieval Biome Pack (AppID: 4511560) - missing depot keys
-- addappid(4511560)