-- 2849080's Lua and Manifest Created by Hubcap Manifest
-- Kingdom Rush 5: Alliance TD
-- Created: March 14, 2026 at 00:31:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 3
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2849080, 1, "801898d184b5ad1b3c57c07d4324e25c122aae717f42aa702b1b616396086299") -- Kingdom Rush 5: Alliance TD
-- MAIN APP DEPOTS
addappid(2849081, 1, "e00df48b38c967f303c37f758389ff8e15505ab4416c522ea62ef425884d3849") -- Depot 2849081
setManifestid(2849081, "2986433879215574901", 4090472)
addappid(2849082, 1, "4982ecd61fd529c34e6519a1a5004121f93ebb0e60d14d161fa95e4851ea8a32") -- Depot 2849082
setManifestid(2849082, "4575449103611673528", 1629563767)
addappid(2849083, 1, "3d8ca2d9a2a948ec35d8046112d2bf42f03f46ae30dae1b842c8ec4dd26d285f") -- Depot 2849083
setManifestid(2849083, "2237783188623953254", 1640364261)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3368630) -- Kingdom Rush 5 Alliance TD - Colossal Dwarfare Campaign
addappid(3732970) -- Kingdom Rush 5 Alliance TD - Wukongs Journey Campaign
addappid(4260510) -- Kingdom Rush 5 Alliance TD - Dragon Wars Campaign