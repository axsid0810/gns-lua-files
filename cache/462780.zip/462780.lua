-- 462780's Lua and Manifest Created by Hubcap Manifest
-- Darksiders Warmastered Edition
-- Created: June 05, 2026 at 13:06:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(462780, 1, "8e10cf1c4864f175263a4e5dbb2f44bf65d6dd5e47d8e0b29740d5d008b6bdbd") -- Darksiders Warmastered Edition
-- MAIN APP DEPOTS
addappid(462781, 1, "96eb6dd1c57eb2d2444bf75225a3aacd4ce143a43a111c4e0afa3b7565575e29") -- Darksiders Warmastered Edition Content
setManifestid(462781, "5349811679801842291", 23519009434)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)