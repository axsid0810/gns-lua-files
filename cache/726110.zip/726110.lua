-- 726110's Lua and Manifest Created by Hubcap Manifest
-- Overcrowd: A Commute 'Em Up
-- Created: September 30, 2025 at 05:26:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(726110) -- Overcrowd: A Commute 'Em Up
-- MAIN APP DEPOTS
addappid(726111, 1, "4845f2c6c3547897e98ffbf62233c51c623652c3f1724691bbaffedfb921b7ad") -- Overcrowd: A Commute 'Em Up Content
setManifestid(726111, "2641423508405528166", 564294171)