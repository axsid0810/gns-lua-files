-- 606880's Lua and Manifest Created by Hubcap Manifest
-- GreedFall
-- Created: September 29, 2025 at 15:28:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(606880) -- GreedFall
-- MAIN APP DEPOTS
addappid(606881, 1, "51893736990321529ecd03e59acee9a60ed5c2a53e107949debe45cef32a5a53") -- GreedFall Content
setManifestid(606881, "8874425372087683575", 21441487807)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- GreedFall - The De Vespe Conspiracy (AppID: 1468480)
addappid(1468480)
addappid(1468480, 1, "677f8e886652aeac6daa7c047778d8a7354419630229b74ae7f656c68251b8ab") -- GreedFall - The De Vespe Conspiracy - GreedFall - DLC (1468480) Depot
setManifestid(1468480, "2988375875355498171", 1157960197)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1034720) -- GreedFall - Adventurers Gear DLC 
addtoken(1034720, "7720448131971245444")