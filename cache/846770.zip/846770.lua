-- 846770's Lua and Manifest Created by Hubcap Manifest
-- DYSMANTLE
-- Created: December 02, 2025 at 00:21:19 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 3
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(846770, 1, "e62c47c969d5072004230043978c146f4b1ccfec300b7d1f73a86ab637d560d5") -- DYSMANTLE
-- MAIN APP DEPOTS
addappid(846771, 1, "c345ec3e46cd18e15a4f18b0c8e1c099ab995829330b6a66d5a8f47894be732f") -- DYSMANTLE Windows
setManifestid(846771, "5075101902608519471", 1981540187)
addappid(846772, 1, "a0fcc1b3487aacf7ed5abbd1859ee12a145b61fb902bb71961426d4921e9a0ae") -- DYSMANTLE Mac
setManifestid(846772, "8514681507973902214", 1565872968)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2004110) -- DYSMANTLE Underworld
addappid(2147250) -- DYSMANTLE Doomsday
addappid(2439690) -- DYSMANTLE Pets  Dungeons