-- 234140's Lua and Manifest Created by Hubcap Manifest
-- Mad Max
-- Created: March 14, 2026 at 16:39:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 25
-- Total DLCs: 6
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(234140, 1, "b9902fe33ae78ce25ec036f1777d239cc956b01eb281898072aa9f9ec8259cf4") -- Mad Max
-- MAIN APP DEPOTS
addappid(234141, 1, "6d11f5f66cb8c8be2c179fd4703a775f3219ae4fd8d3ad389df211221002d129") -- MM - Content
setManifestid(234141, "6004018614475068250", 34128991872)
addappid(234142, 1, "9ae3a8946436664bf386360144f68754d25810833ff4c0986752b4a58f2fe43e") -- MM - Code
setManifestid(234142, "7604024359222969141", 88920994)
addappid(234143, 1, "f06fe22027e006f729bab3d86f9899e270e5ef990c262e040ade1187fb9da653") -- MM - Content - Low Violence SKU
setManifestid(234143, "273984200055107202", 34016680336)
addappid(234144, 1, "e002d78a7b25904dab36f9f53ee926c11f0b60b1b36a9bd684717ff3455cc281") -- MM - Code - Low Violence SKU
setManifestid(234144, "7800851279563387786", 88724386)
addappid(234145, 1, "2898c7877995cb86dd3fe1b994974284b9deaa97a3ec9c9c6896222d5602cc6d") -- MM - Content: Mac
setManifestid(234145, "6871763131342962475", 34244343851)
addappid(234146, 1, "28f8684b00ebd76e4f3c8234bf760441f67756362f0937ebf0b9a44fea8c81c2") -- MM - Content: Linux
setManifestid(234146, "1437160614351829967", 300052410)
addappid(234147, 1, "b5682bb091b61ca914cbc4fe4670b8080e39f71aac3a33730d5e735140533e34") -- MM - Code: Mac
setManifestid(234147, "4452918123786175018", 85828103)
addappid(234148, 1, "1ea318c193ceb7aa820ff91992febabbce4ad0fb69721a80ba410ebe84575708") -- MM - Code: Linux
setManifestid(234148, "4911387789381725297", 34244343851)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Mad Max - The Ripper (AppID: 373550)
addappid(373550)
addtoken(373550, "17309940003545764981")
addappid(373550, 1, "b0e268a0fd5cbda4db4129079641220323895a2b98e20772accbd0bb17a30d2b") -- Mad Max - The Ripper - Max Max - The Ripper (373550) Depot
setManifestid(373550, "4932364438208165087", 183379728)
addappid(234155, 1, "94e9209b1e72f63731a4fd32e9ba667ec0bf8de7690db610cd7795cc4cb465fb") -- Mad Max - The Ripper - Mad Max - The Ripper Depot: Mac
setManifestid(234155, "6821441133654417075", 183379728)
addappid(234156, 1, "a31bd0bb824d5e9ecb9d0d1bb0ae4914e2a677742efb29fb506d502c1a90dab0") -- Mad Max - The Ripper - Mad Max - The Ripper Depot: Linux
setManifestid(234156, "3595695641508003121", 183379728)
-- Mad Max - ThirstCutter (AppID: 373551)
addappid(373551)
addtoken(373551, "9196355903797304391")
addappid(373551, 1, "b3fb2db673447dad2477c727661944b0b05e70a1d19739446620592ac4787cfb") -- Mad Max - ThirstCutter - Max Max - Rockstar Car (373551) Depot
setManifestid(373551, "820079142899659198", 37724312)
addappid(234153, 1, "68d2e8c023f676c9553ca7e3cc5abe4253cb24b2375e977fcb62791c2450231b") -- Mad Max - ThirstCutter - Mad Max - Rockstar Car Depot: Mac
setManifestid(234153, "5851192728361296415", 37724312)
addappid(234154, 1, "6b0c8edaad00a3177a07b6c0851fb807c39d5c5591f76c5a4f381a7b60c59a53") -- Mad Max - ThirstCutter - Mad Max - Rockstar Car Depot: Linux
setManifestid(234154, "110331523549270106", 37724312)
-- Mad Max - Stampeedy Knokshok (AppID: 374352)
addappid(374352)
addappid(374352, 1, "1a6ff867efd6e345e4b7f6b8ef598f289115064c36eba778ee212efc0fb71927") -- Mad Max - Stampeedy Knokshok - Mad Max - Retail Hood Ornament 2 (374352) Depot
setManifestid(374352, "989318466771708296", 1060992)
-- Mad Max - Rockmaw Brawla (AppID: 374353)
addappid(374353)
addtoken(374353, "13382791345415311098")
addappid(374353, 1, "dd2f3926b834a62bf0868d86b8bf3d1bb9482e279f3c51df2c500e4114e9e38b") -- Mad Max - Rockmaw Brawla - Mad Max - Rockstar Hood Ornament 1 (374353) Depot
setManifestid(374353, "726284545439160442", 1097856)
addappid(234159, 1, "bc9c011c0a75ae873266170607854c75e8c8fcc9546b8b8d44c38f7fe9340ce3") -- Mad Max - Rockmaw Brawla - Mad Max - Rockstar Hood Ornament 1 Depot: Mac
setManifestid(234159, "8469086995851582363", 1097856)
addappid(373552, 1, "b4ef4858dc4326a3300af20bf87b552ae2f78de7ae2ba7a65594db0301bb99a3") -- Mad Max - Rockmaw Brawla - Mad Max - Rockstar Hood Ornament 1 Depot: Linux
setManifestid(373552, "1857001457470141853", 1097856)
-- Mad Max - Pentacal GulpCut (AppID: 374354)
addappid(374354)
addtoken(374354, "10453245579322634552")
addappid(374354, 1, "1a0ba01c8e56c463b3b716a4d4bb3fe0b21a47583d889bacf3025d13c2887d31") -- Mad Max - Pentacal GulpCut - Mad Max - Rockstar Hood Ornament 2 (374354) Depot
setManifestid(374354, "177057563991069594", 1116288)
addappid(373553, 1, "27918eab11e5d22371f7a52f5cf08e7aae788e7b54b4db01cec66cfa8bd1dde1") -- Mad Max - Pentacal GulpCut - Mad Max - Rockstar Hood Ornament 2 Depot: Mac
setManifestid(373553, "5140022686851769258", 1116288)
addappid(373554, 1, "708f07628590ae504857d5fb5c66c435589b09ae8421718cfa2688fa2ecea307") -- Mad Max - Pentacal GulpCut - Mad Max - Rockstar Hood Ornament 2 Depot: Linux
setManifestid(373554, "1798513877711301960", 1116288)
-- Mad Max - Circa Blades (AppID: 374355)
addappid(374355)
addappid(374355, 1, "dac4a123f065e77bfaa1d7ecb3a04cbc632c80887c601bd14c468fa277b5fce5") -- Mad Max - Circa Blades - Mad Max - Rockstar Hood Ornament 3 (374355) Depot
setManifestid(374355, "700117122979318819", 960640)