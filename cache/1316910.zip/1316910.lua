-- 1316910's Lua and Manifest Created by Hubcap Manifest
-- Super Monkey Ball Banana Mania
-- Created: May 04, 2026 at 14:48:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 12
-- Total DLCs: 10
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1316910, 1, "44507ac86e9fdefaa9f61cd8a06e876547d2ce3bb18798025b6676c8f5028086") -- Super Monkey Ball Banana Mania
-- MAIN APP DEPOTS
addappid(1316911, 1, "aad865dab6c37bdbed493330e094d5fb2e79311f10a554d9397df1afea88108c") -- Flash 2 Content
setManifestid(1316911, "5218175071740918679", 3239907334)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- Super Monkey Ball Banana Mania - Hello Kitty (AppID: 1550410)
addappid(1550410)
addappid(1550410, 1, "816787573db8304ef2296c2a108233dffcf653cbaff6ea0cd7152e3c1379c1ce") -- Super Monkey Ball Banana Mania - Hello Kitty - Flash2 - Character01 (1550410) デポ
setManifestid(1550410, "6599618225923356826", 4760214)
-- Super Monkey Ball Banana Mania - Morgana (AppID: 1604970)
addappid(1604970)
addappid(1604970, 1, "4d66cb31cbf09fdb81eaf1c95b0e28ee27e9479c51c963bdcaea106877666ced") -- Super Monkey Ball Banana Mania - Morgana - Flash2 - Character02 Content
setManifestid(1604970, "7390914323099904074", 4465813)
-- Super Monkey Ball Banana Mania - Suezo (AppID: 1604971)
addappid(1604971)
addappid(1604971, 1, "536fa3ea964dbba35ce7c864404bba6059fef48966b4970611da6427989fbe1c") -- Super Monkey Ball Banana Mania - Suezo - Flash2 - Character03 (1604971) デポ
setManifestid(1604971, "8213327549008318864", 6001428)
-- Super Monkey Ball Banana Mania - Classic Soundtrack (AppID: 1606090)
addappid(1606090)
addappid(1606090, 1, "17925957871208773963046c1148072abe2a8c624fe49f455bf7b7050b224a35") -- Super Monkey Ball Banana Mania - Classic Soundtrack - Flash2 - DxOriginalBgm (1606090) デポ
setManifestid(1606090, "7550058531622895124", 96343711)
-- Super Monkey Ball Banana Mania - Customization Pack (AppID: 1606252)
addappid(1606252)
addappid(1606252, 1, "b4e5a48e7557ab9d781184aae3141bc0f5e33d8dd927270c58e2148be719973d") -- Super Monkey Ball Banana Mania - Customization Pack - Flash2 - DxCostumes (1606252) デポ
setManifestid(1606252, "9196657188636087915", 11250486)
-- Super Monkey Ball Banana Mania - Classic Character Pack (AppID: 1606253)
addappid(1606253)
addappid(1606253, 1, "3797f16bb3e6d54a6939fd86187ccb9ef2f58da6950b5028cf69828b1ebcc336") -- Super Monkey Ball Banana Mania - Classic Character Pack - Flash2 - DxClassicCharacter (1606253) デポ
setManifestid(1606253, "2555346570186835751", 11124342)
-- Super Monkey Ball Banana Mania - SEGA Legends Pack (AppID: 1606254)
addappid(1606254)
addappid(1606254, 1, "ddb36b9de118b7e87e878eb94c1640cd907e350cafd8ea9ca90b9fe268580dd3") -- Super Monkey Ball Banana Mania - SEGA Legends Pack - Flash2 - DxHardCharacter (1606254) デポ
setManifestid(1606254, "1050261671587355861", 4499194)
-- Super Monkey Ball Banana Mania - Golden Banana (AppID: 1606255)
addappid(1606255)
addappid(1606255, 1, "5ac0b3de688161e8560e6f024758f3fdb4eee6c752a19cf1a18115f3188857ec") -- Super Monkey Ball Banana Mania - Golden Banana - Flash2 - DxGoldenBanana (1606255) デポ
setManifestid(1606255, "8540358675627835938", 1819)
-- Super Monkey Ball Banana Mania - Bonus Cosmetic Pack (AppID: 1606256)
addappid(1606256)
addappid(1606256, 1, "a0b5cd77c6ee18c16259a9b8aa0a3b0440b92f1a7f3837f78f57453df339e63b") -- Super Monkey Ball Banana Mania - Bonus Cosmetic Pack - Flash2 - PreOrderCostumes (1606256) デポ
setManifestid(1606256, "6623824723059762608", 14294030)
-- Super Monkey Ball Banana Mania - Headwear Pack (AppID: 1647320)
addappid(1647320)
addtoken(1647320, "487133043600111643")
addappid(1647320, 1, "d482f543f2fd45f238bd47e3218b74c0270e82d7e662414f26d9ee2db0ff24cf") -- Super Monkey Ball Banana Mania - Headwear Pack - Flash2 - Benefits03 (1647320) デポ
setManifestid(1647320, "7505097874532522676", 401651)