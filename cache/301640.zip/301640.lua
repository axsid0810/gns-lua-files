-- 301640's Lua and Manifest Created by Hubcap Manifest
-- Zombie Army Trilogy
-- Created: October 01, 2025 at 09:11:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 21
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(301640) -- Zombie Army Trilogy
-- MAIN APP DEPOTS
addappid(301641, 1, "550204c5e1c64a694d1452d5290bdc5aa4fd6f553204efbfc2daa43063b1927e") -- Zombie Army Trilogy Exe
setManifestid(301641, "2645768744049394218", 9625440)
addappid(301642, 1, "fc92c06a03000c5b9e43cabcd680f0bb7d31cc47b53c5bcace13ed471bdfc349") -- Zombie Army Trilogy Shared
setManifestid(301642, "7218416939251580222", 0)
addappid(301643, 1, "9121a06f2dbb3e4ba8acb556357cc26ac8361526a4430f8f8f8c410cd0816c4e") -- Zombie Army Trilogy English
setManifestid(301643, "8446901549704368218", 109457941)
addappid(301644, 1, "0b6cff7dc2454494d8194f1748e5e0aa69f11e4793ee4fbf6a5f36a2f825631e") -- Zombie Army Trilogy French
setManifestid(301644, "6972015510605659542", 109094894)
addappid(301645, 1, "117a6f3bf468c644662086b03be84c1d261d05627eaafa077776cf3d5a507708") -- Zombie Army Trilogy German
setManifestid(301645, "8518208942256569172", 109095486)
addappid(301646, 1, "4fac840cb7f9f94e866839c5038822ebc97a25603a228af4791cbdae65cee82f") -- Zombie Army Trilogy Italian
setManifestid(301646, "718902021122217225", 109087532)
addappid(301647, 1, "b40feb34bb9dc2734621107d878010bded38a948830fc669aabe95dd10bb9602") -- Zombie Army Trilogy Spanish
setManifestid(301647, "1770727325585529333", 109097110)
addappid(301648, 1, "eb307050659919f5d6f06e6d43d6f830ed7d577a83629f647dc7fb63b388553d") -- Zombie Army Trilogy Polish
setManifestid(301648, "2622718477007953629", 109453314)
addappid(301649, 1, "b5966c5b79722af27f1203fc33bad122858c372828bbf51c51f8f0380d8193d8") -- Zombie Army Trilogy Russian
setManifestid(301649, "9055412374246968548", 109446228)
addappid(350350, 1, "d29150a79821258cf0d58fe4243767bf6f9309d3ac8482e11b5a149f5789a5ee") -- Zombie Army Trilogy Brazilian Portuguese
setManifestid(350350, "4431114700816209547", 109020931)
addappid(350351, 1, "3ff3e69e43200c80a698bc4022eee75a387716ea516186c3e9efa8daf5ba47aa") -- Zombie Army Trilogy Simplified Chinese
setManifestid(350351, "2488557444616293419", 109291631)
addappid(350352, 1, "baac96e5a543a966de1ab8913b10f86570bf142bd381716927a6eae4c935ba96") -- Zombie Army Trilogy Japanese
setManifestid(350352, "2184998934591897282", 109320728)
addappid(350353, 1, "2f1b2877dd5c38ed8f807f51d764805d524f0a5a5c13074b90ab21898acf2777") -- Zombie Army Trilogy Korean
setManifestid(350353, "4931658970056569572", 109343627)
addappid(350354, 1, "68518fe71ab809807043315532f7eaf2df615af49792679c648658f4a5647d21") -- Zombie Army Trilogy Base
setManifestid(350354, "3489031477280955180", 456559066)
addappid(350355, 1, "e54bfdcf4cb3934afd8864bd2a5927b231683c79a312432d1e8b011a3a794a32") -- Zombie Army Trilogy Levels
setManifestid(350355, "2622447744127956008", 2920294341)
addappid(350356, 1, "089fb68dad0484b31152e79d45aa50d958783cdb9efb2f0e4476acc8cddc25ac") -- Zombie Army Trilogy Textures
setManifestid(350356, "1032179419647441099", 6366271249)
addappid(350357, 1, "9fcc72da0a1e0bff6c4bd382d6fe91b2fefbb91feb2f92d2c46312d101867333") -- Zombie Army Trilogy Base (Germany)
setManifestid(350357, "5553284230915669580", 455943479)
addappid(350358, 1, "aa570cf6abc73181de72aac059d7aa5028005277eb8d157a67bde6e5534b2100") -- Zombie Army Trilogy Levels (Germany)
setManifestid(350358, "8869681891059620166", 2916649960)
addappid(350359, 1, "40ed63e2bf3f79c424f805a0ce4e7e8e9681f687227de564fe5f024d28494517") -- Zombie Army Trilogy Textures (Germany)
setManifestid(350359, "4798984787030030407", 6191436349)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)