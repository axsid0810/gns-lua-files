-- 3581940's Lua and Manifest Created by Hubcap Manifest
-- Deja View - A Spot The Difference Game
-- Created: February 17, 2026 at 19:06:17 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3581940) -- Deja View - A Spot The Difference Game
-- MAIN APP DEPOTS
addappid(3581941, 1, "fdb6eb73a05e7361ed1486577b5d0733dddb72656021a88b9f32a0b5538e8451") -- Depot 3581941
setManifestid(3581941, "5382553967884551761", 923224500)