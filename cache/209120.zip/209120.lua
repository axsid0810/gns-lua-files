-- 209120's Lua and Manifest Created by Hubcap Manifest
-- Street Fighter X Tekken
-- Created: September 30, 2025 at 20:25:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 61

-- MAIN APPLICATION
addappid(209120) -- Street Fighter X Tekken
-- MAIN APP DEPOTS
addappid(209122, 1, "183cc3173c5be7b4d01e77957a10b812250a9c40722c05b807f5487c9570bc01") -- tekken_sf_temp
setManifestid(209122, "7964058802342521888", 91921)
addappid(209121, 1, "0638bdee8eeb485748b2dbf5d588ccaa81c4b28aebfb0bf1ed90f09ac6d4908d") -- Street Fighter X Tekken Depot
setManifestid(209121, "6410272633068620019", 6441873163)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(210030) -- Street Fighter X Tekken DLC - Ryu (Swap Costume)
addappid(210031) -- Street Fighter X Tekken DLC - Ken (Swap Costume)
addappid(210032) -- Street Fighter X Tekken DLC - Chun-Li (Swap Costume)
addappid(210033) -- Street Fighter X Tekken DLC - Cammy (Swap Costume)
addappid(210034) -- Street Fighter X Tekken DLC - Guile (Swap Costume)
addappid(210035) -- Street Fighter X Tekken DLC - Abel (Swap Costume)
addappid(210036) -- Street Fighter X Tekken DLC - Dhalsim (Swap Costume)
addappid(210037) -- Street Fighter X Tekken DLC - Sagat (Swap Costume)
addappid(210038) -- Street Fighter X Tekken DLC - Rolento (Swap Costume)
addappid(210039) -- Street Fighter X Tekken DLC - Ibuki (Swap Costume)
addappid(210040) -- Street Fighter X Tekken DLC - Poison (Swap Costume)
addappid(210041) -- Street Fighter X Tekken DLC - Hugo (Swap Costume)
addappid(210042) -- Street Fighter X Tekken DLC - Rufus (Swap Costume)
addappid(210043) -- Street Fighter X Tekken DLC - Zangief (Swap Costume)
addappid(210044) -- Street Fighter X Tekken DLC - Vega (Swap Costume)
addappid(210045) -- Street Fighter X Tekken DLC - Balrog (Swap Costume)
addappid(210046) -- Street Fighter X Tekken DLC - M.Bison (Swap Costume)
addappid(210047) -- Street Fighter X Tekken DLC - Juri (Swap Costume)
addappid(210048) -- Street Fighter X Tekken DLC - Akuma (Swap Costume)
addappid(210049) -- Street Fighter X Tekken DLC - Kazuya (Swap Costume)
addappid(210050) -- Street Fighter X Tekken DLC - Nina (Swap Costume)
addappid(210051) -- Street Fighter X Tekken DLC - Asuka (Swap Costume)
addappid(210052) -- Street Fighter X Tekken DLC - Lili (Swap Costume)
addappid(210053) -- Street Fighter X Tekken DLC - Heihachi (Swap Costume)
addappid(210054) -- Street Fighter X Tekken DLC - Kuma (Swap Costume)
addappid(210055) -- Street Fighter X Tekken DLC - Paul (Swap Costume)
addappid(210056) -- Street Fighter X Tekken DLC - Law (Swap Costume)
addappid(210057) -- Street Fighter X Tekken DLC - King (Swap Costume)
addappid(210058) -- Street Fighter X Tekken DLC - Marduk (Swap Costume)
addappid(210059) -- Street Fighter X Tekken DLC - Hwoarang (Swap Costume)
addappid(210060) -- Street Fighter X Tekken DLC - Steve (Swap Costume)
addappid(210061) -- Street Fighter X Tekken DLC - Bob (Swap Costume)
addappid(210062) -- Street Fighter X Tekken DLC - Julia (Swap Costume)
addappid(210063) -- Street Fighter X Tekken DLC - Yoshimitsu (Swap Costume)
addappid(210064) -- Street Fighter X Tekken DLC - Raven (Swap Costume)
addappid(210065) -- Street Fighter X Tekken DLC - Jin (Swap Costume)
addappid(210066) -- Street Fighter X Tekken DLC - Xiaoyu (Swap Costume)
addappid(210067) -- Street Fighter X Tekken DLC - Ogre (Swap Costume)
addappid(210072) -- Street Fighter X Tekken DLC - SFTK Shared Assist Gem Pack 1
addappid(210073) -- Street Fighter X Tekken DLC - SFTK Shared Assist Gem Pack 2
addappid(210074) -- Street Fighter X Tekken DLC - SF Boost Gem Pack 1
addappid(210075) -- Street Fighter X Tekken DLC - SF Boost Gem Pack 2
addappid(210076) -- Street Fighter X Tekken DLC - TK Boost Gem Pack 1
addappid(210077) -- Street Fighter X Tekken DLC - TK Boost Gem Pack 2
addappid(210083) -- Street Fighter X Tekken DLC - Booster Pack 3
addappid(210084) -- Street Fighter X Tekken SF Booster Pack 4
addappid(210085) -- Street Fighter X Tekken DLC - SF Boost Gem Pack 5
addappid(210086) -- Street Fighter X Tekken DLC - SF Boost Gem Pack 6
addappid(210087) -- Street Fighter X Tekken DLC - SF Boost Gem Pack 7
addtoken(210087, "8896136342859422637")
addappid(210088) -- Street Fighter X Tekken DLC - SF Boost Gem Pack 8
addappid(210089) -- Street Fighter X Tekken TK Booster Pack 3
addappid(210090) -- Street Fighter X Tekken DLC - TK Boost Gem Pack 4
addappid(210091) -- Street Fighter X Tekken DLC - TK Boost Gem Pack 5
addappid(210092) -- Street Fighter X Tekken DLC - TK Boost Gem Pack 6
addappid(210093) -- Street Fighter X Tekken DLC - TK Boost Gem Pack 7
addappid(210094) -- Street Fighter X Tekken DLC - TK Boost Gem Pack 8
addappid(210095) -- Street Fighter X Tekken DLC - SFTK Shared Assist Gem Pack 3
addappid(210096) -- Street Fighter X Tekken DLC - SFTK Shared Assist Gem Pack 4
addappid(210097) -- Street Fighter X Tekken Gems Assist 5
addappid(210098) -- Street Fighter X Tekken DLC - SFTK Shared Assist Gem Pack 6
addappid(210113) -- Street Fighter X Tekken DLC - Additional Characters Pack (12 Chars)