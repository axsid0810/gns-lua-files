-- 2104890's Lua and Manifest Created by Hubcap Manifest
-- RoadCraft
-- Created: June 30, 2026 at 09:57:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 8

-- MAIN APPLICATION
addappid(2104890, 1, "b07e322e1f1bc0a15e4d7abe0e9abd0a04f22ffbf084774a1a252bf455048388") -- RoadCraft
-- MAIN APP DEPOTS
addappid(2104891, 1, "7aae8e21e13a76d7d261e23592399805131dbb2dc4678b5c40b335e6f131b3a7") -- Depot 2104891
setManifestid(2104891, "1124223706563311062", 46449981211)
-- DLCS WITH DEDICATED DEPOTS
-- RoadCraft - 4K Texture Pack (AppID: 3510890)
addappid(3510890)
addappid(3510890, 1, "fed6ac5a7ee3d94e10e924fe19f30acfcbcfdb56a5835b080efede124d44b8a0") -- RoadCraft - 4K Texture Pack - Depot 3510890
setManifestid(3510890, "2073998869291552446", 35125154080)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2806770) -- RoadCraft  Aramatsu Bowhead 30T
addappid(3470710) -- RoadCraft  Invictus Type A Scout
addappid(3470720) -- RoadCraft - Rebuild DLC
addappid(3470730) -- RoadCraft - Rebuild Expansion
addappid(4124160) -- RoadCraft  Timberworks Pack
addappid(4159460) -- RoadCraft - Reclaim Expansion
addappid(4511610) -- RoadCraft  Crawler Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2104899) -- Depot 2104899 (empty depot)