-- 1328350's Lua and Manifest Created by Hubcap Manifest
-- Turbo Overkill
-- Created: March 31, 2026 at 02:00:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1 (1 excluded)

-- MAIN APPLICATION
addappid(1328350, 1, "f3150af85768541df981f170727d647ebf35938e658da631991907cf22c02292") -- Turbo Overkill
-- MAIN APP DEPOTS
addappid(1328351, 1, "8e7760ee0bd1834f2a2c1caebe0df6cb68d95b39db83171f57d85fc4708bc14b") -- Turbo Overkill Content
setManifestid(1328351, "1158215864037425794", 7548580882)
-- DLCS WITH DEDICATED DEPOTS
-- Turbo Overkill - Original Syn Prequel Comic (AppID: 4038350)
addappid(4038350)
addappid(4038350, 1, "0d097ee3cd873ca0dbc4e4048d2153a2e6ee0a2f5860b57bc3a3ef2ffc577d1d") -- Turbo Overkill - Original Syn Prequel Comic - Depot 4038350
setManifestid(4038350, "5743524213395756841", 52038587)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Turbo Overkill Digital Art Book (AppID: 4038230) - missing depot keys
-- addappid(4038230)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1328352) -- Depot 1328352 (empty depot)