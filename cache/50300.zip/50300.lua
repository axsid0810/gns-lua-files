-- 50300's Lua and Manifest Created by Hubcap Manifest
-- Spec Ops: The Line
-- Created: September 30, 2025 at 18:56:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 13
-- Total DLCs: 5 (3 excluded)

-- MAIN APPLICATION
addappid(50300) -- Spec Ops: The Line
-- MAIN APP DEPOTS
addappid(203185, 1, "ebd77b785fc186b312bedc5446eb955196b866e14a60c8a8c6ab723765232a7c") -- SO_Exe
setManifestid(203185, "639786781359251113", 58328184)
addappid(50302, 1, "86c7acfb6722cdec82871283c49a16a74b63cf1d6d1ab821557f4b2c6cf47941") -- SpecOps_install
setManifestid(50302, "5946848598332555109", 110092605)
addappid(50301, 1, "183bb5015eea47ed29938bfbbc83fe3697775fdc1529a7e8e1634c883960a7c8") -- SO_Main
setManifestid(50301, "2372113813127878946", 7082718468)
addappid(50303, 1, "787e8423199e3889c4fa6edfd848ea0a9fe138e0d5b73f971ba1b204e6c5d56f") -- SpecOps_TheLine French
setManifestid(50303, "5345503164779846521", 157554009)
addappid(50304, 1, "0436e7aff84b7bb74b492123db22a0358de0e2b184ca0fe1c0c2bb838d3549ef") -- SpecOps_TheLine Spanish
setManifestid(50304, "6063442997036875742", 157706826)
addappid(50306, 1, "96e139ddaac3c8aea5fc2dc7d75055926f6c222d5a5a753cb5e5655455d1b92c") -- SpecOps_TheLine German
setManifestid(50306, "2541342117890400708", 155123054)
addappid(50307, 1, "28e4e0a171b728a6eb38f87b631be1702784b0479496acfc03bfc333525a4680") -- SpecOps_TheLine Italian
setManifestid(50307, "4664700318163526270", 157541659)
addappid(50308, 1, "a9069aa0ea66fd5952d78661254de0591d1e947c98fb9bd9f20c5234ffd81158") -- SpecOps_TheLine Japanese
setManifestid(50308, "9057803672398366587", 163280868)
addappid(50309, 1, "8ef85a17066ec6e667cecc26c4f43cdef8b53546346378cb5187c11a682c36a4") -- SpecOps_TheLine Russian
setManifestid(50309, "5504647633938545005", 155846543)
addappid(50305, 1, "10931a8f64e4fa5afc9d2c496b30961dd73c93567bb7ed7a22a4cbe7af7492c5") -- Spec Ops: The Line MacOS
setManifestid(50305, "9214662830167284564", 67606713)
addappid(203189, 1, "c38ce46581e6a705af9777c0138e51d51a153b18022d1d02bc1ba3a8718b45c0") -- Spec Ops: The Line Linux
setManifestid(203189, "8677438475479253711", 51969192)
-- DLCS WITH DEDICATED DEPOTS
-- Coop Challenge Mode (AppID: 203180)
addappid(203180)
addappid(203180, 1, "3399e4fe5f7ce92a9a9fc69b121708268dce78c0f52b3b1a890f2c668a757fb7") -- Coop Challenge Mode - SO_DLC1
setManifestid(203180, "8422320613423646775", 325360981)
-- FUBAR Pack (AppID: 203181)
addappid(203181)
addappid(203181, 1, "cb7b9bf90aa7ba18b34476de13c9467edbc4527468fe4ed5eae40be8d2055a13") -- FUBAR Pack - SO_PreorderDLC
setManifestid(203181, "4438741608192439708", 112)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(203182) -- ValveTestApp203182
addappid(203183) -- ValveTestApp203183
addappid(203184) -- ValveTestApp203184
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Devastation Multiplayer Pack  (AppID: 203186) - missing depot keys
-- addappid(203186)
-- Sand Blasted Multiplayer Pack  (AppID: 203187) - missing depot keys
-- addappid(203187)
-- Single Player DLC (AppID: 203188) - missing depot keys
-- addappid(203188)