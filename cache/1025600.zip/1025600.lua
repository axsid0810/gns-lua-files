-- 1025600's Lua and Manifest Created by Hubcap Manifest
-- Battle Realms: Zen Edition
-- Created: July 21, 2026 at 01:41:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1025600, 1, "98c18ee51b2c5fbf4797819b10a91f80c3ac10086f67d036d7f12f425ffebd9d") -- Battle Realms: Zen Edition
-- MAIN APP DEPOTS
addappid(1025601, 1, "4fcdfcbad24c7f621af25f25edd05bfd7d5061b6b698e3b4634b53f7003f1341") -- Battle Realms Content
setManifestid(1025601, "5254311253371808999", 2640784590)