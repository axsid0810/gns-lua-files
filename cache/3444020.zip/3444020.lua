-- 3444020's Lua and Manifest Created by Hubcap Manifest
-- 我在地府打麻将
-- Created: March 29, 2026 at 03:12:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3444020, 1, "4bf7c24f3401a258a3191843cd2890ce58ac47bc5f3dc1b388be9645e2e31a77") -- 我在地府打麻将
-- MAIN APP DEPOTS
addappid(3444021, 1, "390479eb93dcb5aa47faa126ba19b7b0db80bb304eeaedc192215c05deb69b8e") -- Depot 3444021
setManifestid(3444021, "2343382760741265603", 6715954426)
addappid(3444022, 1, "c7d881f2483c870330dfc2b85e02394b14b6257070a99cbe010f2ad1db2b98ba") -- Depot 3444022
setManifestid(3444022, "8233714147270854431", 6823981162)