-- 50120's Lua and Manifest Created by Hubcap Manifest
-- MLB 2K10
-- Created: October 02, 2025 at 10:18:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(50120) -- MLB 2K10
-- MAIN APP DEPOTS
addappid(50121, 1, "e252d197a0d09e64451ee5e4a63566b1c2567b97677ef784c74fc86f3bc6874b") -- mlb2k10_content
setManifestid(50121, "7020398248394167598", 9128539170)