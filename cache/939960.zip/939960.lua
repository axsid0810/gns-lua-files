-- 939960's Lua and Manifest Created by Hubcap Manifest
-- Far Cry New Dawn
-- Created: July 01, 2026 at 08:45:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 17
-- Total DLCs: 15
-- Shared Depots: 7

-- MAIN APPLICATION
addappid(939960, 1, "8a51a80bcee0835ab845ecb5a8827b398027a7f02a78273c575bcad09a4681bf") -- Far Cry New Dawn
-- MAIN APP DEPOTS
addappid(939961, 1, "88845aed0d769fc02f05c0a9c295a01ed524a32bd113350bb8e3c43d17cdbb1d") -- Bowmore Content
setManifestid(939961, "7305824767802991088", 20339260842)
addappid(939962, 1, "87109a483a0905b5dea2962248892c68c6f61b48a8efbb3384e2ab312c3294ea") -- Bowmore - English
setManifestid(939962, "2541041874356438434", 753827765)
addappid(939963, 1, "153f8b8e69aea229d2b1571f0c840f9adeb2b6f9ccb3caaf315802bb1bbd47f5") -- Bowmore - French
setManifestid(939963, "8415750840864874031", 763913577)
addappid(939964, 1, "ffc2a37f41d3002147bf3401c286df22e3fa4fec6c49fe83c2fb04ec9b46932b") -- Bowmore - Italian
setManifestid(939964, "8941130594844356180", 817401255)
addappid(939965, 1, "e5773c92e8a81d6bd72945202a619fe9638afdbd952a4f772daedec4f1129efd") -- Bowmore - German
setManifestid(939965, "3748177826769538242", 752892578)
addappid(939966, 1, "53d01ef80943cd8a431040ee772dc02fc49090fa50be4f59980f70affb1ddc8d") -- Bowmore - Spanish
setManifestid(939966, "3612550719594251760", 834343311)
addappid(939967, 1, "a216dd8d2a4539df618435a0dd99f6386435fe7d724c0fd2f845b78607ef5120") -- Bowmore - Russian
setManifestid(939967, "4979989929102189933", 770352911)
addappid(939968, 1, "2b9606a0243678f3c4cbe6a521c08d936a6f7dc538a3911c737211483c11d106") -- Bowmore - Brazil
setManifestid(939968, "3851229191392906390", 1322813408)
addappid(939969, 1, "b27d04a8ce1cc6e608d4b2924e6036a022eb6dfe8edafe6b22d01e8721ecce88") -- Bowmore - Japan
setManifestid(939969, "3600239354209454019", 760111400)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "8936186649444731600", 264933784)
-- DLCS WITH DEDICATED DEPOTS
-- Far Cry New Dawn - HD Textures Pack (AppID: 996970)
addappid(996970)
addappid(996970, 1, "6515432309a59f7f6397d9a4a527b1fced0c1c98160d7036bc412751a5227f1c") -- Far Cry New Dawn - HD Textures Pack - Far Cry New Dawn - HD Textures Pack (996970) Depot
setManifestid(996970, "9006765081226229638", 21393684307)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(995530) -- Far Cry New Dawn - Standard Preorder Uplay Activation
addtoken(995530, "11402523800759818340")
addappid(995531) -- Far Cry New Dawn - Deluxe Preorder Uplay Activation
addtoken(995531, "13494507965165270184")
addappid(1019480) -- Far Cry New Dawn - Standard Uplay Activation
addtoken(1019480, "4969856164635458594")
addappid(1019481) -- Far Cry New Dawn - Deluxe Uplay Activation
addtoken(1019481, "16090072699928660746")
addappid(1019490) -- Far Cry New Dawn - Complete Uplay Activation
addtoken(1019490, "4957554953299584076")
addappid(1019491) -- Far Cry New Dawn - Ultimate Uplay Activation
addtoken(1019491, "9366163911075946111")
addappid(1019510) -- Far Cry New Dawn - Unicorn Trike
addappid(1019511) -- Far Cry New Dawn - Hurk Legacy Pack
addappid(1019512) -- Far Cry New Dawn - Knight Pack
addappid(1019513) -- Far Cry New Dawn - Retro Weapon Pack
addappid(1019514) -- Far Cry New Dawn - Unicorn Trike Uplay Activation
addtoken(1019514, "10818553932989008240")
addappid(1019515) -- Far Cry New Dawn - Hurk Legacy Pack Uplay Activation
addtoken(1019515, "7108056891515433168")
addappid(1019520) -- Far Cry New Dawn - Knight Pack Uplay Activation
addtoken(1019520, "6932307190549762984")
addappid(1019521) -- Far Cry New Dawn - Retro Weapon Pack Uplay Activation
addtoken(1019521, "3424464728488667009")