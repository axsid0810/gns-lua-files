-- 1069660's Lua and Manifest Created by Hubcap Manifest
-- Ultimate Admiral: Dreadnoughts
-- Created: March 16, 2026 at 15:03:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1069660, 1, "177600fab7c3d001277db4703562079a2ee390716288f8a4f3415ac8e6a83a07") -- Ultimate Admiral: Dreadnoughts
-- MAIN APP DEPOTS
addappid(1069661, 1, "2ac313c2c0171e5f729d2433e47d343eba402d3d3440484e74b2731db0368126") -- Ultimate Admiral: Dreadnoughts Content
setManifestid(1069661, "1760617317470836861", 4186707261)
-- DLCS WITH DEDICATED DEPOTS
-- Ultimate Admiral Dreadnoughts Multiplayer (AppID: 2672570)
addappid(2672570)
addappid(2672570, 1, "21b720441f5fccf705c1bd037a0bbd0b8c817964c20bd281dbda5bb74dc173f0") -- Ultimate Admiral Dreadnoughts Multiplayer - Depot 2672570
setManifestid(2672570, "4178806643713751686", 4442685870)