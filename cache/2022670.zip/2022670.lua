-- 2022670's Lua and Manifest Created by Hubcap Manifest
-- Sonic Superstars
-- Created: October 25, 2025 at 09:33:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 13
-- Total DLCs: 10
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2022670) -- Sonic Superstars
-- MAIN APP DEPOTS
addappid(2022671, 1, "f2c1f41d9127af994a3cd878921ff5b89db85334ee15711d98ecac202e0b2c54") -- Depot 2022671
setManifestid(2022671, "7909756545997353030", 12459266055)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)
-- DLCS WITH DEDICATED DEPOTS
-- SONIC SUPERSTARS - Shadow Costume for Sonic (AppID: 2376680)
addappid(2376680)
addappid(2376680, 1, "6730eaccec954f07d577f306eb359a3f71288e5b3059632a7ce9b8d85a986c50") -- SONIC SUPERSTARS - Shadow Costume for Sonic - Depot 2376680
setManifestid(2376680, "3173335243830424535", 44654203)
-- Sonic Superstars - LEGO Fun Pack (AppID: 2376681)
addappid(2376681)
addappid(2376681, 1, "0c92a1adfef01e648935444d21387d4210e9f8f9e44ce9540dd74fc366520cce") -- Sonic Superstars - LEGO Fun Pack - Depot 2376681
setManifestid(2376681, "1536858451744743258", 210242229)
-- Sonic Superstars - LEGO Eggman (AppID: 2376682)
addappid(2376682)
addappid(2376682, 1, "d6cda1ed45d3181f448124fafa140b64a9b3980145720d0b44d98abd4da5df7d") -- Sonic Superstars - LEGO Eggman - Depot 2376682
setManifestid(2376682, "2167741500057019530", 2166855)
-- Sonic Superstars - LEGO Sonic (AppID: 2376683)
addappid(2376683)
addappid(2376683, 1, "4341168c3fe2c4ba640375fa50482728135b6fcf4c92d7563fc21753355ddd2d") -- Sonic Superstars - LEGO Sonic - Depot 2376683
setManifestid(2376683, "1226875788894383256", 65855414)
-- SONIC SUPERSTARS  Retro Diner Style Amy Costume (AppID: 2376684)
addappid(2376684)
addappid(2376684, 1, "6e52b3de3a359892d79332af8f7a699108a53088cbd5a4bedbc73c3e13fbd3b9") -- SONIC SUPERSTARS  Retro Diner Style Amy Costume - Depot 2376684
setManifestid(2376684, "46072427903571440", 29405974)
-- SONIC SUPERSTARS - Sonic Holiday Costume (AppID: 2376685)
addappid(2376685)
addappid(2376685, 1, "505e7d01852a3491ba27f47a39654981b5d226637188c38cc6ab624441e74e09") -- SONIC SUPERSTARS - Sonic Holiday Costume - Depot 2376685
setManifestid(2376685, "1841909521232151900", 80934405)
-- Sonic Superstars - Digital Artbook and mini-OS (AppID: 2376686)
addappid(2376686)
addappid(2376686, 1, "5966b1059b51f7a0848e75844f5bf15635d7add8d093eeb9f8a8c1e10c2a1465") -- Sonic Superstars - Digital Artbook and mini-OS - Depot 2376686
setManifestid(2376686, "8865037080950302454", 953485072)
-- Sonic Superstars - Comic Book Skin Pack  (AppID: 2378680)
addappid(2378680)
addappid(2378680, 1, "ceb1ec12c9e4865ad35f179ba80e76726cac61d5b9b47c7aa40c2209575e76e3") -- Sonic Superstars - Comic Book Skin Pack  - Depot 2378680
setManifestid(2378680, "8828860786451589385", 89480148)
-- SONIC SUPERSTARS - Modern Amy Costume (AppID: 2504600)
addappid(2504600)
addappid(2504601, 1, "748a138e138f241d762920fadfcc7161080d43c424d5c0aed4a5232b366db48a") -- SONIC SUPERSTARS - Modern Amy Costume - Depot 2504601
setManifestid(2504601, "5130416525580453851", 31300259)
-- Sonic Superstars - Extra Content Pack (AppID: 2549530)
addappid(2549530)
addappid(2549530, 1, "1df5d5fc27599c6099bf21263adf57547fa1e3bd827da9094e8d40210599d386") -- Sonic Superstars - Extra Content Pack - Depot 2549530
setManifestid(2549530, "6651777336508063901", 52283329)