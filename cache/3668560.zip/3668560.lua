-- 3668560's Lua and Manifest Created by Hubcap Manifest
-- Happy Island Fantasy
-- Created: July 10, 2026 at 09:28:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(3668560, 1, "b8ef045400b51d405e25654062870d7f44851d5fcbe1bc5c1e097c84215c4997") -- Happy Island Fantasy
-- MAIN APP DEPOTS
addappid(3668561, 1, "2fba95b2f05878acc5d5b57f1429cc236645a6aed513ae6d733ed589422235ec") -- Depot 3668561
setManifestid(3668561, "3286017332291051475", 9007812933)
addappid(3668562, 1, "4e174fc55441d6c22cea85197ccc692e37ce48737a3cd8c00858a45439e02dbe") -- Depot 3668562
setManifestid(3668562, "5905347203176948914", 9014425487)
-- DLCS WITH DEDICATED DEPOTS
-- Happy Island Fantasy - OliviaSophia (AppID: 4306470)
addappid(4306470)
addappid(4306470, 1, "91e409e2d7a38234508c772677400d2c3b4a9669b5e575ec2de3e00a04b836a7") -- Happy Island Fantasy - OliviaSophia - Depot 4306470
setManifestid(4306470, "6867262603850589435", 1539)
addappid(4306471, 1, "492c0ed40c8f106f540608640a47e1c5710e89bbac411d82251d5a5fe2b74526") -- Happy Island Fantasy - OliviaSophia - Depot 4306471
setManifestid(4306471, "2114830450670775927", 1537)
-- Happy Island Fantasy - Sexual Bliss (AppID: 4603500)
addappid(4603500)
addappid(4603500, 1, "3651a8c1f7e94be15db12a30553a774d8b526a7787544dce0e27cc2b651f94b2") -- Happy Island Fantasy - Sexual Bliss - Depot 4603500
setManifestid(4603500, "7959890016306506922", 1546)
addappid(4603501, 1, "fbb92f95587a59063770534a59572b96fd088cfd985808e18fd0212f78d238b2") -- Happy Island Fantasy - Sexual Bliss - Depot 4603501
setManifestid(4603501, "3323827336338836456", 1544)