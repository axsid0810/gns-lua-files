-- 1520's Lua and Manifest Created by Hubcap Manifest
-- DEFCON
-- Created: September 29, 2025 at 07:12:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(1520) -- DEFCON
-- MAIN APP DEPOTS
addappid(1527, 1, "eda1c9403d5431539e1245cdc6f080b89e539c53d97eaa0fb76f735b418ef036") -- defcon mac content
setManifestid(1527, "7266397871459375812", 138168197)
addappid(1521, 1, "c3d037dde2d61d13f18390480d788d37b51e6970543e8142cb05d284bec37f0e") -- Defcon Content
setManifestid(1521, "6898858218219951821", 62690551)
addappid(1523, 1, "251fc988abdc830d11c03c40efa19601b729e6b333463cc21d025d1d1c1a48a4") -- defcon linux
setManifestid(1523, "9138795537938386515", 65920016)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1528) -- ValveTestApp1528-do-not-use
addappid(1535) -- DEFCON Soundtrack DLC