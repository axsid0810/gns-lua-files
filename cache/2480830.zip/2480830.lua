-- 2480830's Lua and Manifest Created by Hubcap Manifest
-- Voronica Goes to Town: a Vore Adventure
-- Created: January 23, 2026 at 15:17:59 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2480830) -- Voronica Goes to Town: a Vore Adventure
-- MAIN APP DEPOTS
addappid(2480831, 1, "8d3b5745cceeb41732f49d7e75d3838ae837f5cd81a33a3cf23215c9d7ccf0f6") -- Depot 2480831
setManifestid(2480831, "2644373498617663918", 4839449577)