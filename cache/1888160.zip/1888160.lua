-- 1888160's Lua and Manifest Created by Hubcap Manifest
-- ARMORED CORE™ VI FIRES OF RUBICON™
-- Created: December 16, 2025 at 14:11:18 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1888160) -- ARMORED CORE™ VI FIRES OF RUBICON™
-- MAIN APP DEPOTS
addappid(1888161, 1, "2cbbae38e8fbb1cffbba8ca059d96e8b2ee29f77fdce9a9f47e666d333366341") -- Depot 1888161
setManifestid(1888161, "582364468276298215", 64859467399)
addappid(1888163, 1, "62410873212f70aa077827699bc4f786c4eefdd31e94201dfc9de87a63d491b8") -- Depot 1888163
setManifestid(1888163, "5961840280188243652", 111413272)
addappid(1888164, 1, "347a0ccf0383122fcfc3fc32a9e06d397e3b39da49a87e3404dae449bac0b8bf") -- Depot 1888164
setManifestid(1888164, "7986486217946675284", 111413272)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- ARMORED CORE VI FIRES OF RUBICON Digital Artbook  Original Soundtrack (AppID: 2308563)
addappid(2308563)
addappid(2308563, 1, "153004e3a9c40c3aece51551c6ffce884a22228a32c036de74ade86eb0be6576") -- ARMORED CORE VI FIRES OF RUBICON Digital Artbook  Original Soundtrack - Depot 2308563
setManifestid(2308563, "7372163286103826580", 656674471)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2308560) -- ARMORED CORE VI FIRES OF RUBICON MELANDER C3 G13 Special Customization TENDERFOOT