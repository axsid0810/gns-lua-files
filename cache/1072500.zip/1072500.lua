-- 1072500's Lua and Manifest Created by Hubcap Manifest
-- AO Tennis 2
-- Created: September 28, 2025 at 22:44:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1072500) -- AO Tennis 2
-- MAIN APP DEPOTS
addappid(1072501, 1, "c1863dc4796bd607579ff60541fa593f1e5dffd8fc97da6c2f74ac3240cc966f") -- savecancel
setManifestid(1072501, "3727922909753034941", 16072299840)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)