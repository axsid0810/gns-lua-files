-- 4616160's Lua and Manifest Created by Hubcap Manifest
-- Vellar
-- Created: July 15, 2026 at 08:22:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4616160, 1, "eaa40b776f00a189e4936a68dbb1634e1e4eaa628b148d72b49cbfbe43a33e8e") -- Vellar
-- MAIN APP DEPOTS
addappid(4616161, 1, "daca0fd0acfe18dde2148ce9897e122355be6e6b7dcdec18df1df350ff18f220") -- Depot 4616161
setManifestid(4616161, "2641232783705495348", 3050882140)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)