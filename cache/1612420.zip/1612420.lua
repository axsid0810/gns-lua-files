-- 1612420's Lua and Manifest Created by Hubcap Manifest
-- Suit for Hire
-- Created: February 13, 2026 at 15:14:00 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1612420, 1, "fe424418c5edee5762d3a3eb9c00a2d42602e2a8a01195848e5b01925113aae4") -- Suit for Hire
-- MAIN APP DEPOTS
addappid(1612421, 1, "94247ea5c273f90c20d1c1269b4a3591ef8b2bca05db931d4c5e42774cf2ab30") -- Thin Wick Content
setManifestid(1612421, "4515482939388620402", 3912645430)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)