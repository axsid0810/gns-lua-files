-- 312540's Lua and Manifest Created by Hubcap Manifest
-- Ys VI: The Ark of Napishtim
-- Created: October 01, 2025 at 08:53:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(312540) -- Ys VI: The Ark of Napishtim
-- MAIN APP DEPOTS
addappid(312541, 1, "dd9c05ef0f0bb0d596e0e5c0313f1b9893cd5529688ac1e26ad5f24938f6c334") -- Ys VI Content
setManifestid(312541, "5596211738946874128", 1142652838)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Ys VI - Material Collection (AppID: 365010)
addappid(365010)
addtoken(365010, "8506119904138910264")
addappid(365010, 1, "0e8a316b2725564fc35ddc0e6d1c6f562bc057471214f232f3f6b4f3d5d79aec") -- Ys VI - Material Collection - Ys VI Material Collection
setManifestid(365010, "4953391986894256472", 2524847829)