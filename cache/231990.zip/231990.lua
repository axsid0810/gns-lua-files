-- 231990's Lua and Manifest Created by Hubcap Manifest
-- Spider-Man: Shattered Dimensions
-- Created: September 30, 2025 at 19:04:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(231990) -- Spider-Man: Shattered Dimensions
-- MAIN APP DEPOTS
addappid(231991, 1, "6eb27d443e7f71d13d72d72e4d1b70d239aca096e3c1e0ec521b8904c2925442") -- Binaries
setManifestid(231991, "1277516675795566277", 6726672)
addappid(231992, 1, "c8b26cc81ebf003144fb17bcc8968413c1d16aa29ab1d2eb74aaf53096fed255") -- Content
setManifestid(231992, "1810190275689254860", 14406701331)