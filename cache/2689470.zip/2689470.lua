-- 2689470's Lua and Manifest Created by Hubcap Manifest
-- CRUEL
-- Created: January 28, 2026 at 19:50:23 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2689470, 1, "4b625b38588d556f1510393e442771defdf526bb8565f9d9884e1db71aa77fab") -- CRUEL
-- MAIN APP DEPOTS
addappid(2689471, 1, "bf7dfabb9ffa695bfb5f72b1d1ecadae3ef1752843c38ad898ec38f72273dcaf") -- Depot 2689471
setManifestid(2689471, "3050207317557199790", 418244340)