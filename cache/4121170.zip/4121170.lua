-- 4121170's Lua and Manifest Created by Hubcap Manifest
-- Fears to Fathom - Scratch Creek
-- Created: July 05, 2026 at 20:42:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4121170, 1, "c3d258a70358329034d886d79fa4a102c3c9d9bec1038f6eb2a81266a0d99769") -- Fears to Fathom - Scratch Creek
-- MAIN APP DEPOTS
addappid(4121171, 1, "039dd5543221c7529bdaf1452fbb32fae552d67e608265c9cf39dc1b787ae6da") -- Depot 4121171
setManifestid(4121171, "5089717844646392459", 12923196197)