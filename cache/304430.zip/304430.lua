-- 304430's Lua and Manifest Created by Hubcap Manifest
-- INSIDE
-- Created: January 18, 2026 at 13:43:47 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(304430, 1, "3e8f1cf1c63b79d50f25cf98413930be598bb4a454b056857431a31d624e90db") -- INSIDE
-- MAIN APP DEPOTS
addappid(304431, 1, "6505225d0d3ec3bb62f8de3a8218cbb12fbc3e4e3f2d4181509a59454b7f5ce3") -- Project 2 Content
setManifestid(304431, "2904632601412719297", 2354874418)
addappid(304432, 1, "69afabd5b5e1e1ae7314fc1e2082761fbf63d59c300fb084a8a14883fedaab3c") -- INSIDE Depot
setManifestid(304432, "7346583495260906811", 2316493716)
addappid(304433, 1, "af643fa842538225f1d40cb8a110e90bdd4538e83dc63d5caad477c3360204fe") -- INSIDE Depot (MacOS)
setManifestid(304433, "2327740499464381760", 2271309714)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)