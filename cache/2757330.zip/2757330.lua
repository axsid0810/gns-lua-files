-- 2757330's Lua and Manifest Created by Hubcap Manifest
-- Class of '09: The Flip Side
-- Created: September 29, 2025 at 04:27:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2757330) -- Class of '09: The Flip Side
-- MAIN APP DEPOTS
addappid(2757331, 1, "d946e6c07a904fab0e7e0edfc2d127ec160c81f34924f2609896c23f4707b2a1") -- Depot 2757331
setManifestid(2757331, "4449397953951958165", 1261288349)