-- 4286120's Lua and Manifest Created by Hubcap Manifest
-- Photomaly
-- Created: July 23, 2026 at 09:08:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4286120) -- Photomaly
-- MAIN APP DEPOTS
addappid(4286121, 1, "8ba184028e7c93e71bf1be655408324148b30e3f1201b728dc7dbac93a581fe1") -- Depot 4286121
setManifestid(4286121, "6248936632666998733", 1892126063)