-- 3819640's Lua and Manifest Created by Hubcap Manifest
-- Megastore Simulator
-- Created: July 17, 2026 at 13:56:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3819640, 1, "c5ca5045f5114cca24f02d4de5da563ad6097c7bfb1dd698c0be703c24c47be9") -- Megastore Simulator
-- MAIN APP DEPOTS
addappid(3819641, 1, "cd3a3b0b3ca76fc3fd11c8c5426cc433df4d406d30e4d4fce18621a4742cdd64") -- Depot 3819641
setManifestid(3819641, "6052603184629719394", 6624146127)