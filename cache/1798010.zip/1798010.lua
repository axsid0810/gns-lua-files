-- 1798010's Lua and Manifest Created by Hubcap Manifest
-- Mega Man Battle Network Legacy Collection Vol. 1
-- Created: September 30, 2025 at 00:13:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1798010) -- Mega Man Battle Network Legacy Collection Vol. 1
-- MAIN APP DEPOTS
addappid(1798011, 1, "f335202577fd5aab93465e55b2615c01d000af76e2c0abe8cbf3e332a5b7144f") -- Depot 1798011
setManifestid(1798011, "6583874429443952093", 1203941205)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Mega Man Battle Network Legacy Collection Vol. 1 - Custom PET Pack Vol.1 (AppID: 1981410)
addappid(1981410)
addappid(1981411, 1, "0781ec8d271e9fd1566848a58458231722c5675f354a1438e6819013bf4282cc") -- Mega Man Battle Network Legacy Collection Vol. 1 - Custom PET Pack Vol.1 - Depot 1981411
setManifestid(1981411, "5139369073864091056", 14556214)