-- 968620's Lua and Manifest Created by Hubcap Manifest
-- Bomb N' Bats
-- Created: October 02, 2025 at 08:57:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(968620) -- Bomb N' Bats
-- MAIN APP DEPOTS
addappid(968621, 1, "777ec6a113763025dbd3ba0bb6eff6ee121fc89121d7d4743d4d7ac467231c56") -- Bomb N' Bats Content
setManifestid(968621, "1498301442589595138", 680365350)