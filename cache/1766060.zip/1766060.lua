-- 1766060's Lua and Manifest Created by Hubcap Manifest
-- HumanitZ
-- Created: June 26, 2026 at 21:21:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1766060, 1, "5cbf8f8183b3149283ad4cc821a3e2b3217df1616e4c407f7d9bb9d7dad9b4c3") -- HumanitZ
-- MAIN APP DEPOTS
addappid(1766061, 1, "33229ac4689c705f913fd8f448d3f896fe128255629ad018dca089578dbf85c3") -- Depot 1766061
setManifestid(1766061, "5261030028036824135", 24555455619)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)