-- 393080's Lua and Manifest Created by Hubcap Manifest
-- Call of Duty: Modern Warfare Remastered (2017)
-- Created: September 29, 2025 at 02:57:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 19
-- Total DLCs: 0
-- Shared Depots: 17

-- MAIN APPLICATION
addappid(393080) -- Call of Duty: Modern Warfare Remastered (2017)
-- MAIN APP DEPOTS
addappid(393081, 1, "f53e66dd3c1efcb6f0c8f80eb82ed7b4c0038fe2627cf47433afe7bcb902abc7") -- Call of Duty: Modern Warfare Remastered - Single Player Binary
setManifestid(393081, "2030128057851411344", 20213541)
addappid(393082, 1, "d6d8b672150cf319317dfe2d925f8fb0dcb3c8c598089bd71aa13728011087bb") -- Call of Duty: Modern Warfare Remastered - Single Player Common
setManifestid(393082, "7585958111912015831", 22447224793)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(393103, 1, "c7ba51e9981a5569ce0d6e72982334e1e6c1560bac2ad8506b8585f7b9ee5f4d") -- Call of Duty: Modern Warfare Remastered - Shared Common (Shared from App 393100)
setManifestid(393103, "1429964059283546846", 4937672992)
addappid(393104, 1, "530702b7b0ed2412f80d0a37ef7a15b12f76e952d783f41a325cfc9bb07b26ef") -- Call of Duty: Modern Warfare Remastered - Shared English (Shared from App 393100)
setManifestid(393104, "8805163845944786067", 1854129391)
addappid(393105, 1, "df07bbeae361c5771e1b7d40aa924c1ced3ca6e83f22c60641866980f191453e") -- Call of Duty: Modern Warfare Remastered - Shared French (Shared from App 393100)
setManifestid(393105, "5929245059728647144", 1864896123)
addappid(393106, 1, "cb900c0b8049a7a278b98a98c8c547beb32be7e8ce86b3371a05cb238c0fe9cb") -- Call of Duty: Modern Warfare Remastered - Shared Italian (Shared from App 393100)
setManifestid(393106, "8033419381899622415", 1699573132)
addappid(393107, 1, "4047d560be8aef21c98925763e7bf7b951e2f74a7332dd6ad9451a5c3bf8dc11") -- Call of Duty: Modern Warfare Remastered - Shared German (Shared from App 393100)
setManifestid(393107, "3475794641296279075", 1581211268)
addappid(393108, 1, "5b9305367f45d2a1b3fc4952f501adddb96318cb81b75dbf63925c8d4a292452") -- Call of Duty: Modern Warfare Remastered - Shared Spanish (Shared from App 393100)
setManifestid(393108, "7283339273049152144", 1653865117)
addappid(393109, 1, "4a46cf5dbee29cfe31fdddbeb3eb79909c63c3ccc6ff84f2e64fda49bafcb195") -- Call of Duty: Modern Warfare Remastered - Shared Russian (Shared from App 393100)
setManifestid(393109, "5107716374364859359", 2137095392)
addappid(393110, 1, "1430ee874eb359920903f85ca15cf17bb03124b8ca6cd98904b5022c1f73fd0e") -- Call of Duty: Modern Warfare Remastered - Shared Polish (Shared from App 393100)
setManifestid(393110, "2273522330360619691", 1908105295)
addappid(393111, 1, "2ea7e2dd95d0a77f94d7b57e23d1c51d13e5e07c7791070e91caf1a5a1b1a03c") -- Call of Duty: Modern Warfare Remastered - Shared Japanese (Shared from App 393100)
setManifestid(393111, "6087861589832864163", 1866330471)
addappid(393112, 1, "9d821220dde42fa071bb94d6f9a8b712a797c1333629735d3b21f5ee3ed49ded") -- Call of Duty: Modern Warfare Remastered - Shared Korean (Shared from App 393100)
setManifestid(393112, "5821795526868659881", 1908026023)
addappid(393113, 1, "e9f99c9f3880ae662e2c2e9ddcb84b1642c829c4fbc69d6cd679ea1692b4ac44") -- Call of Duty: Modern Warfare Remastered - Shared Simplified Chinese (Shared from App 393100)
setManifestid(393113, "2850926059030587533", 1880830311)
addappid(393114, 1, "1b1ec4f29ecfe152291df2fa08adbdf03e2c3664f63a4ff37dc2cac51a0bde84") -- Call of Duty: Modern Warfare Remastered - Shared Traditional Chinese (Shared from App 393100)
setManifestid(393114, "4538521803897168337", 1881244727)
addappid(393115, 1, "da2d3970fa3c7e1e12c53c18b60156f414f10715a17bb82c60d90fdede4b0397") -- Call of Duty: Modern Warfare Remastered - Shared Arabic-English (Shared from App 393100)
setManifestid(393115, "7611916803754667047", 1845388651)
addappid(393116, 1, "b1f8c5b303ceefd4fa23e2a436bf4d9c3ad7114e1089a6f0e1de49115d139477") -- Call of Duty: Modern Warfare Remastered - Shared Brazilian Portuguese (Shared from App 393100)
setManifestid(393116, "6984835660407597078", 1854202043)
addappid(393117, 1, "6f8d3cae2d0fbca84148779ce9cdcbf60f35512cf3d10b929813138f16d0e418") -- Call of Duty: Modern Warfare Remastered - Shared Imagefiles (Shared from App 393100)
setManifestid(393117, "1793383041649694918", 37508329112)