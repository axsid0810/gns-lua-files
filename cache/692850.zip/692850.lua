-- 692850's Lua and Manifest Created by Hubcap Manifest
-- Bloodstained: Ritual of the Night
-- Created: December 23, 2025 at 19:45:53 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 5
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(692850) -- Bloodstained: Ritual of the Night
-- MAIN APP DEPOTS
addappid(692852, 1, "54869b8458af02610a6a5a992b8d846c785caebecb4022511caffab33ce69250") -- Bloodstained:  Ritual of the Night Base Content
setManifestid(692852, "175497718091106726", 11933285904)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Bloodstained Ritual of the Night - Igas Back Pack DLC (AppID: 1041460)
addappid(1041460)
addappid(1041460, 1, "2c19abb45d89483fe9c472010021ec0c562d84d899c95ddec3c790be5b38a5dd") -- Bloodstained Ritual of the Night - Igas Back Pack DLC - Bloodstained: Ritual of the Night - Backer Exclusive Content (1041460) Depot
setManifestid(1041460, "6917231298397093594", 9235484)
-- Bloodstained Ritual of the Night - Succubus Costume (AppID: 2380800)
addappid(2380800)
addappid(2380800, 1, "ea34e52a8ed5dd5224ebc4fc59b61ac0e039e99814be125d48ac84445301784a") -- Bloodstained Ritual of the Night - Succubus Costume - Depot 2380800
setManifestid(2380800, "9190326705966676533", 0)
-- Bloodstained Ritual of the Night - Magical Girl Costume (AppID: 2380801)
addappid(2380801)
addappid(2380801, 1, "53471e1a66ed778aec25e1d97bb5984842ceaea23e626815dea9a5e444db91fd") -- Bloodstained Ritual of the Night - Magical Girl Costume - Depot 2380801
setManifestid(2380801, "9204683312804049523", 0)
-- Bloodstained Ritual of the Night - Japanesque Cosmetic Pack (AppID: 2380802)
addappid(2380802)
addappid(2380802, 1, "7edcfc402e1ec88ddfa6d6980e93b542bb1e44d25b7c91ede8a5bc2fdba6fe54") -- Bloodstained Ritual of the Night - Japanesque Cosmetic Pack - Depot 2380802
setManifestid(2380802, "9182152905113627336", 0)
-- Bloodstained Ritual of the Night - Classic II Dominiques Curse (AppID: 2380803)
addappid(2380803)
addappid(2380803, 1, "0eed91ff956f249361d9daa24928e52fec0a6f789680cb1a166b78482bb404b6") -- Bloodstained Ritual of the Night - Classic II Dominiques Curse - Depot 2380803
setManifestid(2380803, "7520478914054263220", 3989488623)