-- 740130's Lua and Manifest Created by Hubcap Manifest
-- Tales of Arise
-- Created: September 30, 2025 at 21:48:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 31
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(740130) -- Tales of Arise
-- MAIN APP DEPOTS
addappid(740131, 1, "53bd94c3766f7bed57c085db01225225321c8f56f7f7455beeb783b19d4c5f35") -- Onix Content
setManifestid(740131, "3961675521159090268", 52214400799)
addappid(740133, 1, "d567daa6083fc8d7def267e5a2234477b78c924d3858154bbd538d8e8e930072") -- Depot 740133
setManifestid(740133, "5745203256394229", 0)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1109050) -- Tales of Arise - Pre-Order Bonus Pack
addappid(1202030) -- Tales of Arise - Premium Item Pack
addappid(1202031) -- Tales of Arise - Premium Costume Pack
addappid(1202032) -- Tales of Arise - 5 Level Up 1
addappid(1202033) -- Tales of Arise - 5 Level Up 2
addappid(1202034) -- Tales of Arise - 5 Level Up 3
addappid(1202035) -- Tales of Arise - 5 Level Up 4
addappid(1202036) -- Tales of Arise - 10 Level Up 1
addappid(1202037) -- Tales of Arise - 10 Level Up 2
addappid(1202040) -- Tales of Arise - Beach Time Triple Pack (Male)
addappid(1202041) -- Tales of Arise - Beach Time Triple Pack (Female)
addappid(1202042) -- Tales of Arise - School Life Triple Pack (Male)
addappid(1202043) -- Tales of Arise - School Life Triple Pack (Female)
addappid(1202044) -- Tales of Arise - Warring States Outfits Triple Pack (Male)
addappid(1202045) -- Tales of Arise - Warring States Outfits Triple Pack (Female)
addappid(1202050) -- Tales of Arise - Starter Pack
addappid(1202051) -- Tales of Arise - Relief Support Pack
addappid(1202052) -- Tales of Arise - Growth Boost Pack
addappid(1202053) -- Tales of Arise - Premium Travel Pack
addappid(1202055) -- Tales of Arise - Tales of Series Battle BGM Pack
addappid(1202060) -- Tales of Arise - Hootle Attachment Pack
addappid(1202061) -- Tales of Arise - SAO Collaboration Pack
addappid(1202062) -- Tales of Arise - Collaboration Costume Pack
addappid(1202063) -- Tales of Arise - 100,000 Gald 1
addappid(1202064) -- Tales of Arise - 100,000 Gald 2
addappid(1202065) -- Tales of Arise - 100,000 Gald 3
addappid(1310370) -- Tales of Arise - 100,000 Gald 4
addappid(2391960) -- Tales of Arise - Beyond the Dawn Expansion
addappid(2391961) -- Tales of Arise - Classic Characters Costume  Arranged BGM Pack
addappid(2474000) -- Tales of Arise - Elegant Costume Pack
addappid(2474002) -- Tales of Arise - Beyond the Dawn Attachment Pack