-- 3962750's Lua and Manifest Created by Hubcap Manifest
-- Towers of Scale
-- Created: July 27, 2026 at 22:32:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3962750) -- Towers of Scale
-- MAIN APP DEPOTS
addappid(3962751, 1, "b4decc3d55856ed38e8e8a6bd923a14bc3e1bb669361ce96fdbe0bf027a5fbe0") -- Depot 3962751
setManifestid(3962751, "4177277508183859710", 53597113)
addappid(3962752, 1, "a68c0d5f46d6774d7f489e3d17b8fb09668c4d06224c3da958725ec5ae1c949e") -- Depot 3962752
setManifestid(3962752, "9214109652628913622", 54562246)