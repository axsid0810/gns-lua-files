-- 4761320's Lua and Manifest Created by Hubcap Manifest
-- MEGABOOBS 🔞
-- Created: July 17, 2026 at 07:57:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4761320, 1, "a163b7659f265e5bc1a3eddebc7394781146185e827dde832bb23dbfe26a315f") -- MEGABOOBS 🔞
-- MAIN APP DEPOTS
addappid(4761321, 1, "9455b0a87787b06ebf5a75e6bf8022728be742673dd52fe8c8cb672e89f2cd4f") -- Depot 4761321
setManifestid(4761321, "8489621080874994833", 3619318499)