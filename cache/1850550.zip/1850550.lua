-- 1850550's Lua and Manifest Created by Hubcap Manifest
-- I'm on Observation Duty 5
-- Created: July 04, 2026 at 21:24:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1850550, 1, "7f51f0b62057714907283173d79396b48fb57b149c2138b8b16a1a316abd896d") -- I'm on Observation Duty 5
-- MAIN APP DEPOTS
addappid(1850551, 1, "f1500874439fe839ef88213e995a26676f3e3a1101598ea605aaae95432c7582") -- Depot 1850551
setManifestid(1850551, "5853639604606692963", 10421282290)
addappid(1850552, 1, "d2065b8dcb4edf64caf597170309532412ae8bd25f689172c765777dd12fcb3c") -- Depot 1850552
setManifestid(1850552, "8000159155576842015", 10420780016)
addappid(1850553, 1, "b5e5243e926cca28d8ba014056793d5321ddd763ac81e18e5c948f53f2575f0d") -- Depot 1850553
setManifestid(1850553, "7621673310005421755", 10473749823)