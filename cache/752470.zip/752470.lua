-- 752470's Lua and Manifest Created by Hubcap Manifest
-- CINERIS SOMNIA
-- Created: October 01, 2025 at 14:00:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(752470) -- CINERIS SOMNIA
-- MAIN APP DEPOTS
addappid(752473, 1, "d82d8139d856e529e6a7d15d35941eecb6f95dac52fe1142680a019102c2fef9") -- CINERIS SOMNIA
setManifestid(752473, "6345946265388625058", 3184257145)
addappid(903610, 1, "b8e8bfb3acdbeae530c346e8ef0289552c8b428b186cdd3d6e20df16d0770b9c") -- Converted Soundtrack Depot (903610)
setManifestid(903610, "8641642615869053410", 554652746)