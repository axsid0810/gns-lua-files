-- 3843270's Lua and Manifest Created by Hubcap Manifest
-- Silent Watcher
-- Created: October 03, 2025 at 06:09:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3843270) -- Silent Watcher
-- MAIN APP DEPOTS
addappid(3843271, 1, "f7b8c055ad871145e5a000789e93c1ce9f3e4a0313d5e9c2c5d2e179ebdf969f") -- Depot 3843271
setManifestid(3843271, "5064632362632513067", 590999188)