-- 4594150's Lua and Manifest Created by Hubcap Manifest
-- Sir, We Have an Orc Problem
-- Created: July 28, 2026 at 11:19:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4594150, 1, "0df8142d0840043ae65894ba46cb56230d091dbdf6f5ff9f2c9754b4f45714b4") -- Sir, We Have an Orc Problem
-- MAIN APP DEPOTS
addappid(4594151, 1, "c74b45ac41a8b5814d4d694ded55996d3c4f6b501588b45aad45423a14d9310b") -- Depot 4594151
setManifestid(4594151, "5793031054739060329", 129056288)
addappid(4594152, 1, "fff07e1f430224e7b5d87d982ce52757ab3709c786566131d71e6a0daa915e0e") -- Depot 4594152
setManifestid(4594152, "1125342064696966679", 96179480)