-- 1262350's Lua and Manifest Created by Hubcap Manifest
-- SIGNALIS
-- Created: October 30, 2025 at 12:51:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1262350) -- SIGNALIS
-- MAIN APP DEPOTS
addappid(1262351, 1, "854de643819bf303b7475a341b497bcccc2fe1f609f65ccf8b5fb38ce8bd76f8") -- Depot 1262351
setManifestid(1262351, "6323355527625119871", 1015427028)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)