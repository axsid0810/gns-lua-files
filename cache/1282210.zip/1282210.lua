-- 1282210's Lua and Manifest Created by Hubcap Manifest
-- DEEMO -Reborn-
-- Created: September 29, 2025 at 07:09:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 12
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(1282210) -- DEEMO -Reborn-
-- MAIN APP DEPOTS
addappid(1282212, 1, "846bdee8e19907273928653d7d236e876b0cc55cf3a6e4833e5b3e30a8bcafd2") -- DEEMO -Reborn- game app
setManifestid(1282212, "7190674072837493504", 7902216769)
addappid(1282211, 1, "87b70e59bb345b1a37c8e83083cf172190b287e0e03c1e8da21ffba9d11514d1") -- DEEMO -Reborn- game app II
setManifestid(1282211, "8631664385588301650", 7372616491)
-- DLCS WITH DEDICATED DEPOTS
-- DEEMO -Reborn- Prime Pack I (AppID: 1299090)
addappid(1299090)
addappid(1299091, 1, "8770bcbd1a726ee1214b675723010b0de4de0208cc217de705967ee3bae2f091") -- DEEMO -Reborn- Prime Pack I - DEEMO -Reborn- Prime Pack I Depot
setManifestid(1299091, "5482189630123454173", 148985281)
addappid(1299092, 1, "434616267002059d021073d8e7ddbc9ac51be14ee99be754fdb22392ff39ed93") -- DEEMO -Reborn- Prime Pack I - DEEMO -Reborn- Prime Pack I Depot II
setManifestid(1299092, "3629005302153416630", 148985281)
-- DEEMO -Reborn- Prime Pack II (AppID: 1307540)
addappid(1307540)
addappid(1307543, 1, "424f412e729cf2b6569a22934d6b8ee6a40d77f62c07dcf35aa6525084052cce") -- DEEMO -Reborn- Prime Pack II - DEEMO -Reborn- Prime Pack II Depot
setManifestid(1307543, "8985993415378584728", 163071090)
addappid(1307544, 1, "17e383027d6ca624452a9f3d23d98ecac1d3bb6cbdfafc52ccae6b01f108d729") -- DEEMO -Reborn- Prime Pack II - DEEMO -Reborn- Prime Pack II Depot II
setManifestid(1307544, "9063929655977097111", 163071090)
-- DEEMO -Reborn- Prime Pack III (AppID: 1333390)
addappid(1333390)
addappid(1333391, 1, "53c111b2479c047c07720cfa43751b50693ef9c27b0125dc29e0d0c60c6dd09d") -- DEEMO -Reborn- Prime Pack III - DEEMO -Reborn- Prime Pack III Depot
setManifestid(1333391, "4872302500243025027", 153106039)
addappid(1333392, 1, "872ee8a9e6325264ea9397a28fe7c2f908dade86e802690310618b8d2e7cc082") -- DEEMO -Reborn- Prime Pack III - DEEMO -Reborn- Prime Pack III Depot II
setManifestid(1333392, "344122194746091421", 153106039)
-- DEEMO -Reborn- Prime Pack IV (AppID: 1459820)
addappid(1459820)
addappid(1459821, 1, "873e8b85a8cb00e7874017482fc9c71709bf8b815cd5ec6b6ace204efb220e10") -- DEEMO -Reborn- Prime Pack IV - DEEMO -Reborn- Prime Pack IV (new) Depot
setManifestid(1459821, "900753409262557659", 108020532)
addappid(1459822, 1, "5654d07c5fc1a25297b7d606e7c566f183157fa70ccf2b3cad8ec305f7c15d10") -- DEEMO -Reborn- Prime Pack IV - DEEMO -Reborn- Prime Pack IV (new) Depot II
setManifestid(1459822, "8437104842149935012", 108020532)
-- DEEMO -Reborn- Taiko no Tatsujin Collaboration Collection (AppID: 1460620)
addappid(1460620)
addappid(1460621, 1, "a1e6639b8d3bc5e0934f952aef5c6674e5aeb6ff9a57ac4b2f6fef4c5fc3d174") -- DEEMO -Reborn- Taiko no Tatsujin Collaboration Collection - Taiko no Tatsujin Collaboration Collection Depot
setManifestid(1460621, "340570679260599457", 64538229)
addappid(1460622, 1, "d895162216656daefd5a0a4c04642242b7199b358665f827e2f6d5b76b65ba66") -- DEEMO -Reborn- Taiko no Tatsujin Collaboration Collection - Taiko no Tatsujin Collaboration Collection Depot II
setManifestid(1460622, "3690545453266981465", 64538229)