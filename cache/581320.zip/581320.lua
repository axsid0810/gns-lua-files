-- 581320's Lua and Manifest Created by Hubcap Manifest
-- Insurgency: Sandstorm
-- Created: July 15, 2026 at 18:15:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 64
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(581320, 1, "51f0814199b00735b3d635cacbb0ed5441072fc99db1083b2738f7e54db01b6a") -- Insurgency: Sandstorm
-- MAIN APP DEPOTS
addappid(581322, 1, "1cf7a7b78cda78f21064d61cbb2ac22836872b85b7dc263a8bd13ca32e17a814") -- Insurgency: Sandstorm - Windows
setManifestid(581322, "4267157659164256387", 33326975234)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Insurgency Sandstorm - High Resolution Texture Pack (AppID: 1575020)
addappid(1575020)
addappid(1575020, 1, "8d80c42ad2d2240671b19cde2cd7f80e7109c5403ed0373b6d0e84999ddc808c") -- Insurgency Sandstorm - High Resolution Texture Pack - Insurgency: Sandstorm - High Resolution Texture Pack (1575020) Depot
setManifestid(1575020, "7529054639636037665", 10034381923)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1308180) -- Insurgency Sandstorm - Red Dark Weapon Skin Set
addappid(1308181) -- Insurgency Sandstorm - Midnight Blue Weapon Skin Set
addappid(1308182) -- Insurgency Sandstorm - Nightstalker Set
addappid(1308183) -- Insurgency Sandstorm - Ghillie Gear Set
addappid(1409140) -- Insurgency Sandstorm - Desert Hex Weapon Skin Set
addappid(1409141) -- Insurgency Sandstorm - Urban Digital Weapon Skin Set
addappid(1409142) -- Insurgency Sandstorm - Rogue Spec Ops Gear Set
addappid(1409143) -- Insurgency Sandstorm - Urban Warden Gear Set
addappid(1481110) -- Insurgency Sandstorm - Sasquatch Gear Set
addappid(1481111) -- Insurgency Sandstorm - Yeti Gear Set
addappid(1481112) -- Insurgency Sandstorm - Hunter Weapon Skin Set
addappid(1481113) -- Insurgency Sandstorm - Whiteout Weapon Skin Set
addappid(1590710) -- Insurgency Sandstorm - Upriser Gear Set
addappid(1590711) -- Insurgency Sandstorm - Bad Day Gear Set
addappid(1590712) -- Insurgency Sandstorm - True Grit Weapon Skin Set
addappid(1590713) -- Insurgency Sandstorm - Bear Claw Weapon Skin Set
addappid(1711180) -- Insurgency Sandstorm - Chrome Weapon Skin Set
addappid(1711181) -- Insurgency Sandstorm - Two-Tone Weapon Skin Set
addappid(1711182) -- Insurgency Sandstorm - PMC Gear Set
addappid(1711183) -- Insurgency Sandstorm - Gray Man Gear Set
addappid(1759140) -- Insurgency Sandstorm - The Peacemaker Gear Set
addappid(1760280) -- Insurgency Sandstorm - Warlord Gear Set
addappid(1763080) -- Insurgency Sandstorm - The Assault Pack
addappid(1763081) -- Insurgency Sandstorm - Carbon Fiber Weapon Skin Set
addappid(1763082) -- Insurgency Sandstorm - Woodland Weapon Skin Set
addappid(1763083) -- Insurgency Sandstorm - Brute Gear Set
addappid(1836470) -- Insurgency Sandstorm - S.O.R.T. Gear Set
addappid(2062370) -- Insurgency Sandstorm - Damascus Weapon Skin Set
addappid(2062371) -- Insurgency Sandstorm - Black Powder Weapon Skin Set
addappid(2062372) -- Insurgency Sandstorm - Dealer Gear Set
addappid(2062373) -- Insurgency Sandstorm - Technician Gear Set
addappid(2062374) -- Insurgency Sandstorm - Biker Gear Set
addappid(2062375) -- Insurgency Sandstorm - Pilot Gear Set
addappid(2062376) -- Insurgency Sandstorm - Rust  Wrap Weapon Skin Set
addappid(2062377) -- Insurgency Sandstorm - Worn Veteran Weapon Skin Set
addappid(2432520) -- Insurgency Sandstorm - Mountain Tactical Gear Set
addappid(2432521) -- Insurgency Sandstorm - Mountain Nomad Gear Set
addappid(2432522) -- Insurgency Sandstorm - Digital Splatter Weapon Skin Set
addappid(2432523) -- Insurgency Sandstorm - Woodburn Weapon Skin Set
addappid(2606030) -- Insurgency Sandstorm - Chemical Combat Gear Set
addappid(2606040) -- Insurgency Sandstorm - Protective Gear Set
addappid(2606050) -- Insurgency Sandstorm - Desert Veteran Weapon Skin Set
addappid(2606060) -- Insurgency Sandstorm - Dusty Weapon Skin Set
addappid(2606070) -- Insurgency Sandstorm - Tactical Doc Gear Set
addappid(2606080) -- Insurgency Sandstorm - Desert Corpsman Gear Set
addappid(2606090) -- Insurgency Sandstorm - Night Raven Weapon Skin Set
addappid(2606100) -- Insurgency Sandstorm - Duct Taped Weapon Skin Set
addappid(2606110) -- Insurgency Sandstorm - Phantom Gear Set
addappid(2606120) -- Insurgency Sandstorm - Forest Warden Gear Set
addappid(2606130) -- Insurgency Sandstorm - Green Recon Weapon Skin Set
addappid(2606140) -- Insurgency Sandstorm - Bloodwood Weapon Skin Set
addappid(3801220) -- Insurgency Sandstorm - Vandal Gear Set
addappid(3801230) -- Insurgency Sandstorm - Climber Gear Set
addappid(3801240) -- Insurgency Sandstorm -  Dragon Skin Weapon Skin Set
addappid(3801250) -- Insurgency Sandstorm -  Wheat Weapon Skin Set
addappid(3951900) -- Insurgency Sandstorm - The Jackal Gear Set
addappid(3951910) -- Insurgency Sandstorm - GRS Operator Gear Set
addappid(3951920) -- Insurgency Sandstorm - Jezzail Weapon Skin Set
addappid(3951930) -- Insurgency Sandstorm - Canyon Weapon Skin Set
addappid(4210880) -- Insurgency Sandstorm - Rapid Assault Gear Set
addappid(4210890) -- Insurgency Sandstorm - Scavenger Gear Set
addappid(4210900) -- Insurgency Sandstorm - Endurance Weapon Skin Set
addappid(4210910) -- Insurgency Sandstorm - War Torn Weapon Skin Set
-- EMPTY DEPOTS (no content on any branch)
-- addappid(581321) -- Depot 581321 (empty depot)
-- addappid(581325) -- Depot 581325 (empty depot)
-- addappid(581326) -- Depot 581326 (empty depot)
-- addappid(581327) -- Depot 581327 (empty depot)
-- addappid(581328) -- Depot 581328 (empty depot)
-- addappid(581329) -- Depot 581329 (empty depot)
-- addappid(679894) -- Depot 679894 (empty depot)
-- addappid(679895) -- Depot 679895 (empty depot)
-- addappid(679896) -- Depot 679896 (empty depot)
-- addappid(679897) -- Depot 679897 (empty depot)
-- addappid(679898) -- Depot 679898 (empty depot)
-- addappid(679899) -- Depot 679899 (empty depot)
-- addappid(915621) -- Depot 915621 (empty depot)
-- addappid(915622) -- Depot 915622 (empty depot)
-- addappid(915623) -- Depot 915623 (empty depot)
-- addappid(915624) -- Depot 915624 (empty depot)
-- addappid(915625) -- Depot 915625 (empty depot)
-- addappid(915626) -- Depot 915626 (empty depot)
-- addappid(915627) -- Depot 915627 (empty depot)
-- addappid(915628) -- Depot 915628 (empty depot)
-- addappid(915629) -- Depot 915629 (empty depot)
-- addappid(917181) -- Depot 917181 (empty depot)
-- addappid(917182) -- Depot 917182 (empty depot)