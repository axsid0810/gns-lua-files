-- 2133760's Lua and Manifest Created by Hubcap Manifest
-- Tiny Bookshop
-- Created: May 11, 2026 at 05:37:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2133760, 1, "b0ec9edd1ff972f233fa94bae5a224bb85edd86b9fa836d28a92d61a19a635d5") -- Tiny Bookshop
-- MAIN APP DEPOTS
addappid(2133762, 1, "d52e06a500706a15e7821f6a7c3e30d1a2bce0ea65b784d6a387cdadef756a78") -- Depot 2133762
setManifestid(2133762, "5690522717994080743", 1409747540)
addappid(2133763, 1, "788e7476ac625a7a50f7add2445dc120f1524ee6dc56b8f14edec6a2f954474a") -- Depot 2133763
setManifestid(2133763, "7512256554580907461", 1471946835)
addappid(2133764, 1, "1ebff4822d7fe419fe87324ea8a05d3dc5b985322407afcd0ad15c10f340eba7") -- Depot 2133764
setManifestid(2133764, "3022886248417013003", 1519554800)
-- DLCS WITH DEDICATED DEPOTS
-- Tiny Bookshop Digital Artbook (AppID: 3933690)
addappid(3933690)
addappid(3933690, 1, "afe1f7e926f8475241aa36f1c0c4df701ea991827e6844cb852793bf539277ab") -- Tiny Bookshop Digital Artbook - Depot 3933690
setManifestid(3933690, "1526406310571522558", 304054069)