-- 2131640's Lua and Manifest Created by Hubcap Manifest
-- METAL GEAR SOLID 2: Sons of Liberty - Master Collection Version
-- Created: July 21, 2026 at 12:54:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2131640, 1, "e7914a828f64008e9922eb2098fd352fefebf021c3392cc6500e532618456f6c") -- METAL GEAR SOLID 2: Sons of Liberty - Master Collection Version
-- MAIN APP DEPOTS
addappid(2131642, 1, "a454a9a487006c18009feb3a699f51d070728520c70ad6d82b3946268926e00e") -- Depot 2131642
setManifestid(2131642, "6534155900624658606", 19580986191)
addappid(2131641, 1, "9e0f2cb55b09888aff90e9aade07595c51381b2dd13720057b88e569fc795868") -- Depot 2131641
setManifestid(2131641, "4626135309493798288", 19477752163)
addappid(2131643, 1, "7058fc565e93c914b384654ea68c1c84012102b3e1ab121a43923c8328da348f") -- Depot 2131643
setManifestid(2131643, "2273750301403852854", 19478721311)
addappid(2131644, 1, "ed0021ded7e9812a517fa945eb64e5816b7385e8d895fc389c2db15daa466770") -- Depot 2131644
setManifestid(2131644, "4370148963514409199", 19581955339)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- METAL GEAR SOLID 2 Sons of Liberty - Master Collection Version Japanese Language Pack (AppID: 2314260)
addappid(2314260)
addappid(2314260, 1, "9eea628721d13db63c23c3818238e17b8ce84693d659577fcb951ec4fb35110f") -- METAL GEAR SOLID 2 Sons of Liberty - Master Collection Version Japanese Language Pack - Depot 2314260
setManifestid(2314260, "7562505140636859611", 7713778001)
-- METAL GEAR SOLID 2 Sons of Liberty - Master Collection Version International Language Pack (AppID: 2314261)
addappid(2314261)
addappid(2314261, 1, "39588cf7f429a47c8ebafcd19084333ca255a9e983122f3b329bb57e00661727") -- METAL GEAR SOLID 2 Sons of Liberty - Master Collection Version International Language Pack - Depot 2314261
setManifestid(2314261, "1038044913448868335", 7817012029)