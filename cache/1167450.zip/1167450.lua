-- 1167450's Lua and Manifest Created by Hubcap Manifest
-- DAEMON X MACHINA
-- Created: September 29, 2025 at 06:16:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 15
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1167450) -- DAEMON X MACHINA
-- MAIN APP DEPOTS
addappid(1167451, 1, "3dc4397d4f94a640043bea785c35492e0b1bfc7e8d08d9f1a1f708f9eab47991") -- DAEMON X MACHINA Content
setManifestid(1167451, "5557761116931964144", 13131848094)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1211671) -- DAEMON X MACHINA - Arsenal - Crusader
addappid(1211672) -- DAEMON X MACHINA - Arsenal - Muramasa
addappid(1211673) -- DAEMON X MACHINA - Arsenal - Rabbit 11
addappid(1211674) -- DAEMON X MACHINA - Arsenal Patterns Bundle
addappid(1211675) -- DAEMON X MACHINA - Outer Suit - Camouflage Plugsuit
addappid(1211676) -- DAEMON X MACHINA - Outer Suit - Formal Attire
addappid(1211677) -- DAEMON X MACHINA - Outer Hairstyles Bundle 1
addappid(1211678) -- DAEMON X MACHINA - Outer Hairstyles Bundle 2
addappid(1211679) -- DAEMON X MACHINA - Outer Facial Features Bundle 1
addappid(1211680) -- DAEMON X MACHINA - Outer Facial Features Bundle 2
addappid(1211681) -- DAEMON X MACHINA - Arsenal Decals Bundle
addappid(1211682) --  DAEMON X MACHINA - Outer Emotes Set
addappid(1211683) -- DAEMON X MACHINA - Arsenal Decals Bundle - The Brushstrokes of Souun Takeda
addappid(1237630) -- DAEMON X MACHINA - Prototype Arsenal Set
addappid(3749840) -- DAEMON X MACHINA - Complete DLC Bundle