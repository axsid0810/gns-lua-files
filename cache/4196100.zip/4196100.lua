-- 4196100's Lua and Manifest Created by Hubcap Manifest
-- Onimusha: Way of the Sword Benchmark
-- Created: July 16, 2026 at 10:10:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4196100) -- Onimusha: Way of the Sword Benchmark
-- MAIN APP DEPOTS
addappid(4196101, 1, "78cf03a578abce61f0484139c66999741e738aa90f21d72705c8a58f54699597") -- Depot 4196101
setManifestid(4196101, "4667928182384153701", 16103007352)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)