-- 2322380's Lua and Manifest Created by Hubcap Manifest
-- SpongeBob SquarePants™: The Patrick Star Game
-- Created: September 30, 2025 at 19:11:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2322380) -- SpongeBob SquarePants™: The Patrick Star Game
-- MAIN APP DEPOTS
addappid(2322381, 1, "9efe8fb3f3b218efa48040eccf7d8318e888c265da84563cbb343ce6c34b4fd9") -- Depot 2322381
setManifestid(2322381, "8035552452540536946", 5315947711)