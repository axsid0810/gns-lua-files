-- 4178020's Lua and Manifest Created by Hubcap Manifest
-- Lured In
-- Created: July 19, 2026 at 15:00:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4178020) -- Lured In
-- MAIN APP DEPOTS
addappid(4178021, 1, "8aa7259f4e5ad93ae23720866c396d11e9ce275de733b6789d9738f8d4b1b31c") -- Depot 4178021
setManifestid(4178021, "8157967781783010412", 193547088)
addappid(4178022, 1, "fc1c4c3dd53fc5024ec8a9a9cd843aded8da0c91e7d25773caf278d575942059") -- Depot 4178022
setManifestid(4178022, "53518020519531086", 157023436)