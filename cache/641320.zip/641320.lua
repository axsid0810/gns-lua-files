-- 641320's Lua and Manifest Created by Hubcap Manifest
-- Cooking Simulator
-- Created: July 02, 2026 at 08:16:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 11
-- Total DLCs: 7
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(641320, 1, "912bc4f94e3d67a2a743f119671c2a79276143a2225a17f63104518281b48f5a") -- Cooking Simulator
-- MAIN APP DEPOTS
addappid(641321, 1, "693af0f9d3395af0e1b880807b3b8b17e6391a03fc860c96b19ed41405f60b47") -- Cooking Simulator Windows
setManifestid(641321, "2023215034779070089", 5347998429)
addappid(641322, 1, "db47cd4de11025ce2760303af3fd623baa4f940a1d4abade766929e6fdea5773") -- Depot 641322
setManifestid(641322, "1461777323593563761", 4408337740)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
-- DLCS WITH DEDICATED DEPOTS
-- Cooking Simulator - Cooking with Food Network (AppID: 1168680)
addappid(1168680)
addappid(1168680, 1, "797b64d673b14e960e7038223232c095037fffe4c87d0a5df408038992d80277") -- Cooking Simulator - Cooking with Food Network - Cooking Simulator - Cooking with Food Network (1168680) Depot
setManifestid(1168680, "5029999101667136966", 326658465)
-- Cooking Simulator - Cakes and Cookies (AppID: 1227350)
addappid(1227350)
addtoken(1227350, "15373622832412143610")
addappid(1227350, 1, "95e78a282673605fd207d57e859d2ebfad79b7e109bf46948174367912417ea4") -- Cooking Simulator - Cakes and Cookies - Cooking Simulator - Cakes and Cookies (1227350) Depot
setManifestid(1227350, "422823060929718685", 1967711437)
-- Cooking Simulator - Pizza (AppID: 1400460)
addappid(1400460)
addtoken(1400460, "136279524345860603")
addappid(1400460, 1, "0b0a23c7ebe1db10757fd3fe167ad02d5a24d30b85ea6204aa955224a82deb4f") -- Cooking Simulator - Pizza - Cooking Simulator - Pizza (1400460) Depot
setManifestid(1400460, "2973171070090234539", 1688507798)
-- Cooking Simulator - Shelter (AppID: 1575660)
addappid(1575660)
addappid(1575660, 1, "3da4fdcde0a30525db779f45c19281032e80bdf2174c17b75edae1ff9892c4ac") -- Cooking Simulator - Shelter - Cooking Simulator - Shelter (1575660) Depot
setManifestid(1575660, "245436263803496412", 2292247684)
-- Cooking Simulator - Sushi (AppID: 2655000)
addappid(2655000)
addappid(2655000, 1, "2f18b51f4778cff77849ba20d5641847ce0ee6d1695ca634a6ba22af6482b01d") -- Cooking Simulator - Sushi - Depot 2655000
setManifestid(2655000, "5841927821808309351", 2703004989)
-- Cooking Simulator - BBQ (AppID: 3218770)
addappid(3218770)
addappid(3218770, 1, "f2d2f9ff253a1e7ed06d0d59f5d03863020e157383253b934dddec3b9263b0ce") -- Cooking Simulator - BBQ - Depot 3218770
setManifestid(3218770, "8134003251125187080", 1045830700)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1357180) -- Cooking Simulator - Chaos Tool
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1357180) -- Depot 1357180 (empty depot)