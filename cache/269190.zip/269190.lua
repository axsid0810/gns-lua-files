-- 269190's Lua and Manifest Created by Hubcap Manifest
-- Edge Of Eternity
-- Created: January 19, 2026 at 10:15:32 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 19
-- Total DLCs: 3
-- Shared Depots: 11

-- MAIN APPLICATION
addappid(269190, 1, "f8c86ed813b10c6d6fafd1fd3d8481fd645a30448cfa1582636130072d0ef568") -- Edge Of Eternity
-- MAIN APP DEPOTS
addappid(269192, 1, "3be0d693bfabadf5da3ba2ddd078734d8e96f14a208a4d09c6badce98ab4eaa3") -- Edge Of Eternity - Core Game  (win-x64)
setManifestid(269192, "2758073014903745129", 21571238066)
addappid(269193, 1, "30c612fb3378af1e486efc2f83629dfe36a6c8df3c5ed694871008381ffc5641") -- Edge Of Eternity - Full Game Content  (win-x64)
setManifestid(269193, "3619009461444481293", 0)
addappid(269195, 1, "be39943c02a3e2a5c0c845f18ca875c13aebeb28dc5ce0eb6fd3e6fe0a1a044f") -- Edge Of Eternity - Demo Content (win-x64)
setManifestid(269195, "182009893296040574", 0)
addappid(1000409, 1, "7ffc6771f82f1536e873b7da59cc4cb4d5d9c1adfb2a0c77540cb4e347175bdd") -- Depot 1000409
setManifestid(1000409, "2885094711891174145", 19968879291)
addappid(1000407, 1, "9b2a21f1cf04ff47ab7b6cf569025417edc66c0c78660fbb4d351b77e348da0f") -- Depot 1000407
setManifestid(1000407, "4862690938913766055", 19287063450)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
-- DLCS WITH DEDICATED DEPOTS
-- Edge Of Eternity - War Nekaroo Skin (AppID: 1000400)
addappid(1000400)
addappid(1000400, 1, "855ef54a7c25583a5447a17b1c1ed5589e09965d94ccb9cf68e2b228b721bcf9") -- Edge Of Eternity - War Nekaroo Skin - Nekaroo Skin I Depot
setManifestid(1000400, "1264044946462218305", 27030840)
-- Edge Of Eternity - Goodies Pack (AppID: 1654380)
addappid(1654380)
addappid(1654380, 1, "7f703297aa111ea8c0c382121509b176b30848d102fa258c78880287d6f86397") -- Edge Of Eternity - Goodies Pack - Edge Of Eternity - Goodies Pack Depot
setManifestid(1654380, "43094114224181497", 36925997)
-- Edge Of Eternity - Artbook (AppID: 1654381)
addappid(1654381)
addappid(1654381, 1, "37ce013b723ae53a5d1ed1c2c6eb2e34df4fead677daac43e6436fdbeb937339") -- Edge Of Eternity - Artbook - Edge Of Eternity - Artbook Depot
setManifestid(1654381, "3177268181409974815", 17001738)