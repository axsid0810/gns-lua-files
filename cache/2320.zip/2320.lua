-- 2320's Lua and Manifest Created by Hubcap Manifest
-- Quake II
-- Created: November 23, 2025 at 11:05:54 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2320, 1, "e762b5d0ca48a0bd050a14d4cc1b8033b5a62be5a8d81d7b58fe9bcc312b0f27") -- Quake II
-- MAIN APP DEPOTS
addappid(2321, 1, "80fd8cab8082e032fd0702129b1a0e1d57ecedf155f5e6cfd3c8e1591bf18dc1") -- Quake 2 content
setManifestid(2321, "197921167251316881", 5627104463)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)