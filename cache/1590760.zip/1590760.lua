-- 1590760's Lua and Manifest Created by Hubcap Manifest
-- Metal Slug Tactics
-- Created: November 15, 2025 at 11:21:17 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1590760) -- Metal Slug Tactics
-- MAIN APP DEPOTS
addappid(1590761, 1, "582787963ed712941b80876d6bf558142ecd14682722438b0b64d3bfe68be66d") -- Depot 1590761
setManifestid(1590761, "7527873141324418590", 1636861694)