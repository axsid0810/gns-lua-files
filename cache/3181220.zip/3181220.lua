-- 3181220's Lua and Manifest Created by Hubcap Manifest
-- AV Director Life!
-- Created: June 03, 2026 at 11:52:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3181220, 1, "85434bba5eb3fd06d1e51affc0ee05bea485cb3ab812319b91c7c2b949796105") -- AV Director Life!
-- MAIN APP DEPOTS
addappid(3181222, 1, "5961bc414641c16c702484d3f4cf3766cf313190006888cd9b8e1896f174c2f0") -- Depot 3181222
setManifestid(3181222, "6258463783727347341", 3862031513)
addappid(3181221, 1, "4568d834b5706f7dbb46e9c2962f9b2fd643d8709ebda0e428c84b83d7757356") -- Depot 3181221
setManifestid(3181221, "3471053361802884981", 3862070433)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)