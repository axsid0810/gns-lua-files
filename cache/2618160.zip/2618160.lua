-- 2618160's Lua and Manifest Created by Hubcap Manifest
-- Legends of Starkadia
-- Created: July 07, 2026 at 10:03:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2618160) -- Legends of Starkadia
-- MAIN APP DEPOTS
addappid(2618163, 1, "8ede607843bff1ee36eb633d1da3bda7280cf51cba23e5dc1b7811e9263c147d") -- Depot 2618163
setManifestid(2618163, "167974595660658954", 5744450701)
addappid(2618161, 1, "4e7028cf4d6b27b3dd6a6e21ca0e60c1f5c769bfeb0eded2fff5bb3c1a012d12") -- Depot 2618161
setManifestid(2618161, "2478282663782678762", 0)