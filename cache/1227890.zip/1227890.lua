-- 1227890's Lua and Manifest Created by Hubcap Manifest
-- Summer Memories
-- Created: September 30, 2025 at 20:46:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1227890) -- Summer Memories
-- MAIN APP DEPOTS
addappid(1227891, 1, "2e2a6b921fea7098aab8c03d4a70aca9e6fae899b964523f7facd4756ab77567") -- Summer Memories Content
setManifestid(1227891, "2973056220810366993", 812201152)
addappid(1227892, 1, "d44403a5f1de2fc5dfa7d8b11f80764f066518f373c1740f71453b796343688d") -- Summer Memories Chinese
setManifestid(1227892, "5641962359534525607", 80413357)
addappid(1227893, 1, "ece222869909275dbc208a0825925b4b79126b1c16980f4852ac7e0e423221ba") -- Summer Memories Japanese
setManifestid(1227893, "2521754645270273491", 57728651)
-- DLCS WITH DEDICATED DEPOTS
-- Summer Memories - Expansion DLC (AppID: 1390150)
addappid(1390150)
addappid(1390151, 1, "609fc609a8f7331a13bd828804e541b1d1828a0bb17be063ce45b4e609a4d07c") -- Summer Memories - Expansion DLC - SM+ English
setManifestid(1390151, "3301250508211564818", 17854157)
addappid(1390152, 1, "21326afe0d63411f4d163d64e57458dc1f85ee06da2043a310985ad856d049e6") -- Summer Memories - Expansion DLC - SM+ Chinese
setManifestid(1390152, "1992105448028326267", 709363068)
addappid(1390153, 1, "0afc28edbdc9fc9e6d5af5c2b52ad5b45e202ac8845aecf4a7e54c99b455bed4") -- Summer Memories - Expansion DLC - SM+ Japanese
setManifestid(1390153, "4641570236997998332", 674943475)