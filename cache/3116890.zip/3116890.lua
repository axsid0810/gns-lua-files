-- 3116890's Lua and Manifest Created by Hubcap Manifest
-- Out of the Park Baseball 26
-- Created: November 23, 2025 at 03:21:16 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3116890, 1, "a79f78ebd6e370c8f8a04eb6e3091de029f4bd117293a9d0210697c124c28b3a") -- Out of the Park Baseball 26
-- MAIN APP DEPOTS
addappid(3116891, 1, "959bcb6ea420ef72dc6f06becae7c7fb9b7240facb2b08c492b00bf124d6ae12") -- Depot 3116891
setManifestid(3116891, "7360838169390955421", 65783927)
addappid(3116894, 1, "313f36e0178314b9c3a0063d40768105b88d90b089edf304993e7d7af58cdc67") -- Depot 3116894
setManifestid(3116894, "6561639012570421859", 42317)
addappid(3116895, 1, "5f30ee764d3a5cd57945bbef62716582941bd9ebfea21becbad501aaef7c3f45") -- Depot 3116895
setManifestid(3116895, "857655653409272558", 490597283)
addappid(3116896, 1, "941823d772f3efc669051f4ed37677e61ec7b4aa650520c06fa1ecc8ce23870e") -- Depot 3116896
setManifestid(3116896, "6748549860926973698", 4324489967)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)