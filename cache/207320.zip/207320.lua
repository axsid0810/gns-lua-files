-- 207320's Lua and Manifest Created by Hubcap Manifest
-- Ys: The Oath in Felghana
-- Created: October 01, 2025 at 08:53:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(207320) -- Ys: The Oath in Felghana
-- MAIN APP DEPOTS
addappid(207321, 1, "debd8d5675f7e8478017cd8809ea239b5257f2b2b04ddbe4c732910bd6d7f096") -- Ys The Oath in Felghana Content
setManifestid(207321, "8280061726252529755", 1822775610)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)