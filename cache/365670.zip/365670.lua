-- 365670's Lua and Manifest Created by Hubcap Manifest
-- Blender
-- Created: July 21, 2026 at 02:53:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(365670, 1, "1c0c08c918b4faaee80c539afe1ce13f22d01f127e354640c30570faf4281b1b") -- Blender
-- MAIN APP DEPOTS
addappid(365671, 1, "3bcd911c4f9e082c16c2a4e96913365715af1b26e8b430a8faeac2894284d583") -- Blender Windows x86_64
setManifestid(365671, "4149252491978535939", 944682178)
addappid(365672, 1, "f59c4e0e5d62e286c04d3db911de1f89045bc1a895a3a3927b5862022a36338e") -- Blender Windows x86_32
setManifestid(365672, "7178515723770090470", 247223701)
addappid(365673, 1, "b91e163f3def1db387d9c81b4f74195f9f4d2e0ecc5c8539bc5ce4dfaa570896") -- Blender Linux x86_64
setManifestid(365673, "497817028871638021", 1238222253)
addappid(365674, 1, "8b37753ef5d0dddc890ec24276139b3b291f5ab111fd287edc13f20df427be39") -- Blender Mac
setManifestid(365674, "5647740196906700538", 934330035)