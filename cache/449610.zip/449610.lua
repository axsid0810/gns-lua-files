-- 449610's Lua and Manifest Created by Hubcap Manifest
-- Monster Boy And The Cursed Kingdom
-- Created: September 30, 2025 at 01:30:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(449610) -- Monster Boy And The Cursed Kingdom
-- MAIN APP DEPOTS
addappid(449611, 1, "24d7750e30b9a220ce28b6f1a9844204d2b2387402eebb565b0034a39f512879") -- Flying Hamster II Content
setManifestid(449611, "4722404584848159695", 5465756621)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)