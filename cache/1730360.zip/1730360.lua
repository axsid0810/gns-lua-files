-- 1730360's Lua and Manifest Created by Hubcap Manifest
-- I'm on Observation Duty 4
-- Created: July 04, 2026 at 21:24:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1730360, 1, "7fe2d8843b18e7e8c0a9833ebd8af85d1459bfd63f7b24f5172535d4c27d3320") -- I'm on Observation Duty 4
-- MAIN APP DEPOTS
addappid(1730361, 1, "1cf4dfd291f64e5e08d612a227905871f739559261b727d0ebbb1f034cff525b") -- Depot 1730361
setManifestid(1730361, "488264448338675276", 4600590284)
addappid(1730362, 1, "98d1a1ec7705838315705599999ce5ded5dd1db93d34bea045a8bf38501d8d17") -- Depot 1730362
setManifestid(1730362, "7513048679377955668", 4620181342)
addappid(1730363, 1, "25b5b2409d75cb855ad8bc49e17d908764dde3a7b5fb75257f1d4e18d16418c1") -- Depot 1730363
setManifestid(1730363, "5213713445778454962", 4649922564)