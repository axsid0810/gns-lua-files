-- 3980800's Lua and Manifest Created by Hubcap Manifest
-- Everything Invades
-- Created: June 03, 2026 at 16:53:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3980800) -- Everything Invades
-- MAIN APP DEPOTS
addappid(3980801, 1, "12b75288691a3ac8fe059a055c3a6b7f9c063722aeff2dc27614c64fdc372e91") -- Depot 3980801
setManifestid(3980801, "5042814615269950349", 450186144)