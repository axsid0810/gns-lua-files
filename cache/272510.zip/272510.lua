-- 272510's Lua and Manifest Created by Hubcap Manifest
-- NARUTO SHIPPUDEN: Ultimate Ninja STORM Revolution
-- Created: September 30, 2025 at 02:52:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 10
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(272510) -- NARUTO SHIPPUDEN: Ultimate Ninja STORM Revolution
-- MAIN APP DEPOTS
addappid(272511, 1, "932caa02917545e704d495fd2f676f374ffe636bc90d9107abed070afe4a91f7") -- NARUTO SHIPPUDEN: ULTIMATE NINJA STORM REVOLUTION
setManifestid(272511, "1864331916573681369", 8067557893)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(301890) -- NARUTO SHIPPUDEN Ultimate Ninja STORM Revolution - DLC 1 Samurai Armor Pack
addappid(301891) -- NARUTO SHIPPUDEN Ultimate Ninja STORM Revolution  - DLC 2 Naruto  Sasuke  Itachi (Apron) Pack
addappid(301892) -- NARUTO SHIPPUDEN Ultimate Ninja STORM Revolution- DLC3 Summer Cloth Pack
addappid(301893) -- NARUTO SHIPPUDEN Ultimate Ninja STORM Revolution - DLC4 Jinchuriki Pack 1
addappid(301894) -- NARUTO SHIPPUDEN Ultimate Ninja STORM Revolution - DLC5 Jinchuriki Pack 2
addappid(301895) -- NARUTO SHIPPUDEN Ultimate Ninja STORM Revolution - DLC6 Suit Pack
addappid(301896) -- NARUTO SHIPPUDEN Ultimate Ninja STORM Revolution - DLC7 Variety Pack 1
addappid(301897) -- NARUTO SHIPPUDEN Ultimate Ninja STORM Revolution - DLC8 Variety Pack 2
addappid(316060) -- NARUTO SHIPPUDEN Ultimate Ninja STORM Revolution - DLC9 Variety Pack 3
addappid(318710) -- NARUTO SHIPPUDEN Ultimate Ninja STORM Revolution - DLC10 Reanimation-Before Death Pack