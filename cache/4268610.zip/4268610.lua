-- 4268610's Lua and Manifest Created by Hubcap Manifest
-- Isekai Sex Kingdom 👑
-- Created: February 25, 2026 at 04:10:11 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4268610) -- Isekai Sex Kingdom 👑
-- MAIN APP DEPOTS
addappid(4268611, 1, "ca7db71da3b576c19dfd7a0f540da183b8d84c7572464a177d4833a2ca7df13f") -- Depot 4268611
setManifestid(4268611, "1956274669734002233", 1562988730)
-- SHARED DEPOTS (from other apps)
addappid(4417780, 1, "29c54cb0124ae18323a08c819e6d6042a1a4ead8db98d20cdc1d8e42dc07fa92") -- Depot 4417780 (Shared from App 4417780)
setManifestid(4417780, "3948004746359759096", 282457528)