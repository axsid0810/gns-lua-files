-- 1937500's Lua and Manifest Created by Hubcap Manifest
-- Let's School
-- Created: July 17, 2026 at 14:28:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(1937500, 1, "554b64fb08e6e1e962d242a0227acad43b08eef3762a6b85c42c81b311ae97e0") -- Let's School
addtoken(1937500, "16533363693476501394")
-- MAIN APP DEPOTS
addappid(1937501, 1, "88b023a604b78607ab4a19ae2c69a3067612b1293aa6b9411294c80b2adcde37") -- Depot 1937501
setManifestid(1937501, "7172727564563361972", 2102495599)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2802470) -- Lets School - Water Towns Furniture Pack
addappid(2901410) -- Lets School - Magical Castles Furniture Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1937502) -- Depot 1937502 (empty depot)