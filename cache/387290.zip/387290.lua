-- 387290's Lua and Manifest Created by Hubcap Manifest
-- Ori and the Blind Forest: Definitive Edition
-- Created: September 30, 2025 at 05:11:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(387290) -- Ori and the Blind Forest: Definitive Edition
-- MAIN APP DEPOTS
addappid(387291, 1, "e3379e56401649f05bf54aa6ef2b7e61b9603a14484529d84daa9f07ba0b24c5") -- Nightberry Content
setManifestid(387291, "8629676443251475535", 11058189790)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)