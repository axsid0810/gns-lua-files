-- 13500's Lua and Manifest Created by Hubcap Manifest
-- Prince of Persia: Warrior Within
-- Created: September 30, 2025 at 07:52:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(13500) -- Prince of Persia: Warrior Within
-- MAIN APP DEPOTS
addappid(13501, 1, "1927562a78578b21ac7eb2a7ff202060c71870d222e56e4ff4a64eb19c153c85") -- prince of persia warrior within content
setManifestid(13501, "5941015487132604059", 3475265993)
addappid(13502, 1, "7426889bbf0b87c1c3c474ebb8f385eefdc881a1674c88eece8e00fbb7061411") -- Prince of Persia: Warrior Within Spanish
setManifestid(13502, "8157882244001950031", 230281237)
addappid(13503, 1, "0fb111f81f635102b0391af2c60de348a5937b49dd08c5f2a95a87df40859d10") -- Prince of Persia: Warrior Within German
setManifestid(13503, "7860987930863725762", 234937151)
addappid(13504, 1, "bc2d9c3220d89b05dd7b7b02c242e4d2052beaa4222fd764010728a6dc748f12") -- Prince of Persia: Warrior Within French
setManifestid(13504, "5998576978956074664", 231961905)
addappid(13505, 1, "d27bd3aaf7ac1b585adc89df17f6c758eec4bebc2e9dd28ac2f829138cc0a1f0") -- Prince of Persia: Warrior Within Italian
setManifestid(13505, "4654705708861862723", 229922661)
addappid(13506, 1, "41cd6f351ef5ff9d7ce832cae75d0bb6d502f6f0101fcfe1c160b325e399baed") -- Prince of Persia: Warrior Within Dutch
setManifestid(13506, "8925745147734781774", 234115336)