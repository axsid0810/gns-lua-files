-- 205930's Lua and Manifest Created by Hubcap Manifest
-- Hitman: Sniper Challenge
-- Created: September 29, 2025 at 17:54:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 20
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(205930) -- Hitman: Sniper Challenge
-- MAIN APP DEPOTS
addappid(205941, 1, "183adb34345a563e5a397cee87c8dbeb7dd305b6e834b54a46fefcdaa772c675") -- HitmanSC_JapaneseData
setManifestid(205941, "7324669648172654647", 1024)
addappid(205932, 1, "8c3dbe75491569c43f56ccb1559b2aa36ec56ac7a519b6b2d90c20f8783fb1c9") -- HitmanSC_Executable
setManifestid(205932, "8683534462282157722", 35155456)
addappid(205931, 1, "ecb7c313d9a6a5557300a6f222307c23096aa726e69e4868c266d627b45e0824") -- HitmanSC_ContentDepot
setManifestid(205931, "6156562966530113062", 1721578995)
addappid(205933, 1, "237675aece77d0f079d8b57baead45227cd7354b74da9d336601c91650eb88a5") -- Hitman: Sniper Challenge english
setManifestid(205933, "7785644675735775353", 5)
addappid(205934, 1, "661a9ffc84ae9418087eb800464caaeeccdd6e1ba5a8d036c76d145e56f5372c") -- Hitman: Sniper Challenge french
setManifestid(205934, "3462993462422109426", 5)
addappid(205935, 1, "a1045020c55d1c740116e1b8db4a4a02a97341371f60a0ead4b793e589770217") -- Hitman: Sniper Challenge italian
setManifestid(205935, "3062987029316401302", 5)
addappid(205936, 1, "d5bb7332bae5223b15b335a07f11dbe04b58c637b3754bf93a118bfab6ec0124") -- Hitman: Sniper Challenge german
setManifestid(205936, "5315769843788520259", 5)
addappid(205937, 1, "a2023c20eed89e52884d41fd26cbe431a5c7245c6a70c76e73d3fc7db3fe7cb5") -- Hitman: Sniper Challenge spanish
setManifestid(205937, "5088367406203695197", 5)
addappid(205938, 1, "ea230a2e02ec0d5fb14a709e1875af13f4b2c84d26faa10810243645b9e548e8") -- Hitman: Sniper Challenge Polish
setManifestid(205938, "8264353225798300288", 5)
addappid(205939, 1, "076629f806bca67ff9e85a9298fb745562064ffb6f0367f434671b9df3346426") -- Hitman: Sniper Challenge Russian
setManifestid(205939, "6931118874489951312", 5)
addappid(205940, 1, "c9e7751a12a27823290f21efc7d4566b2ce4ee4bc17c1c132e46e74640d7605d") -- Hitman: Sniper Challenge Japanese
setManifestid(205940, "3316755994953984808", 5)
addappid(205942, 1, "e3738b42bfd5aa7de9fe3aca1548a60a71eaadca19d39f795f506ea2d7195065") -- Hitman Sniper Challenge Data
setManifestid(205942, "1380743748835493548", 1521740067)
addappid(205943, 1, "a5e315ed32da2e99c202d8c847c7d4855e8baeeea438c2612056a5c629591d15") -- Hitman: Sniper Challenge App
setManifestid(205943, "9180521999622610342", 68221577)
addappid(205944, 1, "4e0828cc7c936101aecdc190fed0e358f5efc2aaf355ba78bf0bb44d8e99994f") -- Hitman: Sniper Challenge English
setManifestid(205944, "3643747162637208615", 2)
addappid(205945, 1, "3e2f982e90de7da826a68c1bd8af5869558b089540e9eed7925d83248ab53bda") -- Hitman: Sniper Challenge French
setManifestid(205945, "422713214965456499", 2)
addappid(205946, 1, "311d8b3bbf8823ce6b2d3f66b2360a89d19212ea4792e8c7ecc8a7d724872d78") -- Hitman: Sniper Challenge Italian
setManifestid(205946, "2678108113121697648", 2)
addappid(205947, 1, "70e04ddde0936d1c7faa07c3bf3b4620186b1e715b661b26fcd6606efaa78bf9") -- Hitman: Sniper Challenge German
setManifestid(205947, "2524535265176222698", 2)
addappid(205948, 1, "0a02b22485dc7bb6b280646f8a8b094db75d9b6c953266336b598ed2bc456d27") -- Hitman: Sniper Challenge Spanish
setManifestid(205948, "8002320530617454734", 2)
addappid(205949, 1, "c8fc5f99f2021b381ffcbc5ee413b4f8c1e8a4f18abd27628ed9de1d8328d0f1") -- Hitman: Sniper Challenge Polish
setManifestid(205949, "1937518936664479601", 2)
addappid(296130, 1, "2bbc01aa8ef2933354bcf7aaa02030019675f5830e2802991695a41f8a6fb65d") -- Hitman: Sniper Challenge Russian
setManifestid(296130, "305530892838937500", 2)