-- 400's Lua and Manifest Created by Hubcap Manifest
-- Portal
-- Created: April 12, 2026 at 19:27:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 10
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(400, 1, "3c3c47f502a7d112bfb98a81c469df7add3b758b225b28310b1b0a8c9b255454") -- Portal
-- MAIN APP DEPOTS
addappid(402, 1, "1d9699c90f13a7549a97e5935b9eb152502aa664ce6944a56573c5f9a5c6d2f1") -- Portal Windows client
setManifestid(402, "7655374749121348667", 163282082)
addappid(403, 1, "1349997dfe5e13cb91d43d7076e499e92da34710020fb4d3d58c385e5092c837") -- Portal OSX client
setManifestid(403, "8974907495363134881", 109896571)
addappid(404, 1, "552f270a24f114f8eb9ccaad3502d0f30f8950c67fcb62b2752f1ae5bd9eb2e1") -- Portal Linux client
setManifestid(404, "1961797017312074949", 150226490)
addappid(405, 1, "a727634c8c0d6f750077fb397fb5d4848b1a31f7cefcb0e3295bbbed05af1b6a") -- Portal Russian
setManifestid(405, "453200351187428393", 85905720)
addappid(406, 1, "3bfe4846e06d664c531bb61e2f35737653d9099497522b38fd15a355acd5339c") -- Portal Spanish
setManifestid(406, "8904830885129684315", 147473667)
addappid(407, 1, "e9eafe69caa4384a1b69193f12c7f4dbbe65a71a76e178b988260524b2a4c3ba") -- Portal French
setManifestid(407, "8242589767738537927", 146568277)
addappid(408, 1, "a6254ee5cef5797432b6ae404018d028c955596cbfa5ff3fece97a9cd6534d1b") -- Portal German
setManifestid(408, "8794244784218856360", 145521369)
addappid(409, 1, "28cf5b133c63b6f5f1fab9d376b3ce35c7dd327505459288ae8d772a262c48f4") -- Portal Demo Base
setManifestid(409, "5466869569815608374", 3847178360)
addappid(410, 1, "6bb84a4ff29b21f5f3e52a121c1293ad75c92ba8ad0b050fa691a9c15164a5e9") -- Portal Demo
setManifestid(410, "106212190778449766", 8574)
addappid(401, 1, "3ed55d26ffdf7f6c5e228ec60127ddc1712f341cfb082cadb9cebbd0f64d0d7d") -- Portal
setManifestid(401, "3169084482272098670", 4183764392)