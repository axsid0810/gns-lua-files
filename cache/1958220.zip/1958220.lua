-- 1958220's Lua and Manifest Created by Hubcap Manifest
-- WitchSpring R - The Story of Pieberry
-- Created: October 01, 2025 at 07:49:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(1958220) -- WitchSpring R - The Story of Pieberry
-- MAIN APP DEPOTS
addappid(1958221, 1, "f4ac13aa686b816d6d28b882d301090c4eb3b9aa14c6802a398402367dc1f612") -- Depot 1958221
setManifestid(1958221, "7941803587227338199", 14937238409)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2666040) -- WitchSpring R - Costume - Red Berry Set
addappid(2666050) -- WitchSpring R - Costume - Black Pearl Set 
addappid(3228130) -- WitchSpring R - Costume - Silver Rose Set
addappid(3228140) -- WitchSpring R - Costume - Shining Dawn Set
addappid(3899110) -- WitchSpring R - Costume - Fluffy Peach Set