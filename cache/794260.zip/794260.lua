-- 794260's Lua and Manifest Created by Hubcap Manifest
-- Outward
-- Created: November 03, 2025 at 06:25:32 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 4
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(794260) -- Outward
-- MAIN APP DEPOTS
addappid(794261, 1, "3f18330383bb1114b2b441b1210330982391a628280c3f939fbe0cc87199c43a") -- Outward Content
setManifestid(794261, "8025650059259595794", 26595184142)
addappid(794262, 1, "895161984f32645d5fe8df66df022cd757ac6b01dfd3f130ab12f3454db95a82") -- Outward Binaries
setManifestid(794262, "1287221689985224905", 650752)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Outward - The Soroboreans (AppID: 1194010)
addappid(1194010)
addappid(1194010, 1, "237d1b0bb3b5cf6563c9474101d3ca739fb65eabf65a4f5e591b9778e84b2f54") -- Outward - The Soroboreans - Outward - Soroborean DLC (1194010) Depot
setManifestid(1194010, "9142907302734050289", 250660632)
-- Outward The Three Brothers (AppID: 1437000)
addappid(1437000)
addappid(1437000, 1, "9b328bda139022075145e332de76227d8b304d12d739e6daa742323dada6c958") -- Outward The Three Brothers - Outward: The Three Brothers (1437000) Depot
setManifestid(1437000, "4492222352218486062", 410424005)
-- Outward - DEFED DLC (AppID: 1758860)
addappid(1758860)
addtoken(1758860, "16452668070665870131")
addappid(1758860, 1, "371f8672896a082beafdd045e8cc4597a01003c0812c78fb94092af4d380cf77") -- Outward - DEFED DLC - Outward - DEFED DLC (1758860) Depot
setManifestid(1758860, "7554802635241960073", 28062993605)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(983420) -- Outward - Pearl Bird Pet - Firework Skill PreOrder