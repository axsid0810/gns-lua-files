-- 242050's Lua and Manifest Created by Hubcap Manifest
-- Assassin's Creed IV Black Flag
-- Created: July 01, 2026 at 04:53:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 22
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(242050, 1, "cafa8e00c75d44d7e693fab3646f3e5803ada60a2dd26534ead5874dccdc4869") -- Assassin's Creed IV Black Flag
-- MAIN APP DEPOTS
addappid(242051, 1, "6b4004c38a5c8c1a869d90c381726c7d5651f578753c316c2dcd372fa13ef609") -- Assassin’s Creed IV Black Flag Content
setManifestid(242051, "30755846185611447", 31276454056)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "8936186649444731600", 264933784)
-- DLCS WITH DEDICATED DEPOTS
-- Assassins Creed Black Flag - Freedom Cry (SP) (AppID: 260476)
addappid(260476)
addappid(260476, 1, "c6245eb9d4c77c2f2204ab40754a0d50402bb78f9de10b495e2f9df94d0c051d") -- Assassins Creed Black Flag - Freedom Cry (SP) - Assassin's Creed Black Flag - Freedom Cry (SP) (260476) Depot
setManifestid(260476, "3697863006561544635", 3824242950)
-- Assassins Creed Black Flag - Freedom Cry Pack Activation Key (AppID: 264803)
addappid(264803)
addtoken(264803, "7841055440138038446")
addappid(264803, 1, "28fe23f7e6ef14d6190c4b1646a87d9d7aa6d22d7a0f89936abfe3ebd293fd80") -- Assassins Creed Black Flag - Freedom Cry Pack Activation Key - Assassin's Creed Black Flag - Freedom Cry Pack Activation Key (264803) Depot
setManifestid(264803, "6005226780702341878", 3824242950)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(260470) -- Assassins Creed Black Flag - Resources Pack
addtoken(260470, "18445699559667956713")
addappid(260471) -- Assassins Creed Black Flag - Collectibles Pack
addappid(260472) -- Assassins Creed Black Flag - Activities Pack
addappid(260473) -- Assassins Creed Black Flag - Death Vessel Pack (SP)
addtoken(260473, "303721168538640280")
addappid(260474) -- Assassins Creed Black Flag - Crusader  Florentine Pack (SP)
addtoken(260474, "16547570126041288549")
addappid(260477) -- Assassins Creed Black Flag - Illustrious Pirates Pack (SP)
addappid(260478) -- Assassins Creed Black Flag - Guild of Rogues (SP)
addappid(260950) -- Assassins Creed Black Flag - Season Pass
addtoken(260950, "4004010671453213299")
addappid(264750) -- Assassins Creed Black Flag - Technology Pack
addappid(264800) -- Assassins Creed Black Flag - Death Vessel Pack Activation Key
addappid(264801) -- Assassins Creed Black Flag - Crusader  Florentine Pack Activation Key
addtoken(264801, "7991568246044981123")
addappid(264802) -- Assassins Creed Black Flag - Blackbeards Wrath Pack Activation Key
addappid(264804) -- Assassins Creed Black Flag - Illustrious Pirates Pack Activation Key
addappid(264805) -- Assassins Creed Black Flag - Guild of Rogues Pack Activation Key
addappid(264810) -- Assassins Creed IV Black Flag - Standard Edition Activation Key
addtoken(264810, "9041864999908290061")
addappid(264811) -- Assassins Creed IV Black Flag - Standard Edition Pre-Order Activation Key
addtoken(264811, "308158585488475138")
addappid(264812) -- Assassins Creed IV Black Flag - Gold Edition Activation Key
addtoken(264812, "3422936916222565870")
addappid(264813) -- Assassins Creed IV Black Flag - Deluxe Edition Activation Key
addtoken(264813, "1017937411464545343")
addappid(265320) -- Assassins Creed IV Black Flag - Deluxe Edition Pre-Order Activation Key
addtoken(265320, "9693741348087304153")
addappid(1650420) -- Assassins Creed IV Black Flag - Gold Uplay activation