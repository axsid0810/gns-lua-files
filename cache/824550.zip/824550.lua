-- 824550's Lua and Manifest Created by Hubcap Manifest
-- SD GUNDAM BATTLE ALLIANCE
-- Created: September 30, 2025 at 12:45:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 15
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(824550) -- SD GUNDAM BATTLE ALLIANCE
-- MAIN APP DEPOTS
addappid(824551, 1, "d7322acca8725452a82e5121292fd903e830f8a91921e30a735b09ec79c9df51") -- Depot 824551
setManifestid(824551, "3110662896725176459", 26748626432)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1938440) -- SD GUNDAM BATTLE ALLIANCE - MS Development Aid Start Dash Pack and Early Unlock Gundam
addappid(1938441) -- SD GUNDAM BATTLE ALLIANCE - Early Unlock Knight Gundam
addappid(1938442) -- SD GUNDAM BATTLE ALLIANCE - Early Unlock Musha Gundam
addappid(1938443) -- SD GUNDAM BATTLE ALLIANCE - SD Gundam World Sangoku Soketsuden Pack
addappid(1938444) -- SD GUNDAM BATTLE ALLIANCE - Early Unlock Command Gundam
addappid(1938445) -- SD GUNDAM BATTLE ALLIANCE MS Development - Super Pack Lv1
addappid(1938446) -- SD GUNDAM BATTLE ALLIANCE MS Development - Super Pack Lv2
addappid(1938450) -- SD GUNDAM BATTLE ALLIANCE MS Development - Super Pack Lv3
addappid(1938451) -- SD GUNDAM BATTLE ALLIANCE - Season Pass
addappid(1938452) -- SD GUNDAM BATTLE ALLIANCE Unit and Scenario Pack 1 Legend  Succession
addappid(1938453) -- SD GUNDAM BATTLE ALLIANCE Unit and Scenario Pack 2 Knights of Moon  Light
addappid(1938454) -- SD GUNDAM BATTLE ALLIANCE Unit and Scenario Pack 3 Flash  Rebirth
addappid(1938456) -- SD GUNDAM BATTLE ALLIANCE - Limit Break Materials Pack 1
addappid(2231720) -- SD GUNDAM BATTLE ALLIANCE Bonus Pack
addappid(2291030) -- SD GUNDAM BATTLE ALLIANCE - Mobile Suit Gundam The Witch from Mercury Pack