-- 5418's Lua and Manifest Created by Hubcap Manifest
-- NBA 2K10
-- Created: July 05, 2026 at 10:42:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(5418) -- NBA 2K10
-- MAIN APP DEPOTS
addappid(910, 1, "168405455442eaf4e8e75a13b5914f35d7be54b0cdc4220ea1dc464f79711248") -- Media Player
setManifestid(910, "1332084816209327708", 266240)