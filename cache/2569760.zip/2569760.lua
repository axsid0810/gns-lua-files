-- 2569760's Lua and Manifest Created by Hubcap Manifest
-- The Mound: Omen of Cthulhu
-- Created: July 29, 2026 at 04:37:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 3
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2569760) -- The Mound: Omen of Cthulhu
-- MAIN APP DEPOTS
addappid(2569761, 1, "6fa06cc8ae41964f038a2f87b9961db2ca8d9316e83bc372ae328cf5adb8fe0b") -- Depot 2569761
setManifestid(2569761, "6331464658807192273", 25231433925)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4630450) -- The Mound Omen of Cthulhu  Lost Explorers Swords Pack
addappid(4630460) -- The Mound Omen of Cthulhu - Characters  Items Pack 
addappid(4925780) -- The Mound Omen of Cthulhu - Temple of Yig Exclusive Mission