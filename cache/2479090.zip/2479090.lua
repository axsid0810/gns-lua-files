-- 2479090's Lua and Manifest Created by Hubcap Manifest
-- PRELUDE Dark Pain
-- Created: July 27, 2026 at 14:35:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2479090) -- PRELUDE Dark Pain
-- MAIN APP DEPOTS
addappid(2479091, 1, "26a62123b4a61ed7c710b99db8663955862618d6fecd41ac245a45fd766f0fe4") -- Depot 2479091
setManifestid(2479091, "7238586488455413411", 5964041398)