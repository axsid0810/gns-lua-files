-- 2239710's Lua and Manifest Created by Hubcap Manifest
-- Into the Dead: Our Darkest Days
-- Created: June 25, 2026 at 01:18:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2239710, 1, "192d13d4409e134db6f89c69d5f462dcc008b0201e188777f656137dcc0df831") -- Into the Dead: Our Darkest Days
-- MAIN APP DEPOTS
addappid(2239711, 1, "b157624d7bd77e603f16902ecbb3c59596e83a552e4089ce119057efa9d2f0b4") -- Depot 2239711
setManifestid(2239711, "3049367709946964874", 8226734592)
addappid(2239712, 1, "713b1f42f286d0647a93eb4b1ce92343c3294fbb200f2f937fa695d914c2d66b") -- Depot 2239712
setManifestid(2239712, "8707965777819569872", 8476556955)