-- 265630's Lua and Manifest Created by Hubcap Manifest
-- Fistful of Frags
-- Created: July 22, 2026 at 08:26:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(265630, 1, "ee06f80227d9fccd61fdd5363e526d33ca78791ff60317ed4c68c72f0bbd9a52") -- Fistful of Frags
-- MAIN APP DEPOTS
addappid(265631, 1, "d5929b331956ac73c8670705f40aa2938e7f787a38c045d7de53cb07e27132cf") -- os neutral
setManifestid(265631, "3792942789043315430", 5513793435)
addappid(265632, 1, "588c298f865b9327928c6171fbc24213d4dd9c5270e29fe87c40029d69cf7a9c") -- win
setManifestid(265632, "336890644442124158", 178840286)
addappid(265633, 1, "1e1a56c4ec2835530fcfb334de733ccebefb092e47c80951ec34844dfd491e9f") -- linux
setManifestid(265633, "3907493676266032065", 123135676)
addappid(265634, 1, "82d76800f06c223448e48d218fc340a356d08e18d38eb8852f5a15b1700943b4") -- mac
setManifestid(265634, "4837764018515664438", 72080191)
addappid(265635, 1, "3b1ec85b0c8551667c1f459b43e53e32b1b5cc0c55365b8e57e742074912eb23") -- os neutral ru
setManifestid(265635, "3764320124277869433", 123189)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(1965121, 1, "a2d0082e7ffd3c91abf9cd3e232149c52b35b1927f91aba3b48d9efa4848d59f") -- Depot 1965121 (Shared from App 1965120)
setManifestid(1965121, "7685338798082101128", 612540409)