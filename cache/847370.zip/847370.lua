-- 847370's Lua and Manifest Created by Hubcap Manifest
-- Sunset Overdrive
-- Created: September 30, 2025 at 20:50:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(847370) -- Sunset Overdrive
-- MAIN APP DEPOTS
addappid(847371, 1, "d05c427fd369235384c4b3d6de5431f6103a8cb8dbc4518c43d5fd059dd46d8b") -- Sunflower Content
setManifestid(847371, "2745499824144496649", 29893020870)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)