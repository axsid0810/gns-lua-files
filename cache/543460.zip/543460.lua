-- 543460's Lua and Manifest Created by Hubcap Manifest
-- Dead Rising 4
-- Created: April 05, 2026 at 09:21:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 9
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(543460, 1, "1a628065f3fa89c772fdceb6df73710fce5541b16b6f32add42c93679f99c7c9") -- Dead Rising 4
-- MAIN APP DEPOTS
addappid(543461, 1, "fd710d4ae9142dd7e6f3edc29645cbb95e8f50eac5f28840ecdf6558f5bb7404") -- Dead Rising 4 ROW
setManifestid(543461, "7972939603429050654", 74148764013)
addappid(543464, 1, "7e9abdd73d4685c62108621fe954c39de62c9f785638a2267853d237f1c41a2b") -- Dead Rising 4 JP
setManifestid(543464, "7983883844493416714", 74136680913)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(592700) -- Dead Rising 4 - Season Pass
addappid(593050) -- Dead Rising 4 - Candy Cane Crossbow
addappid(593051) -- Dead Rising 4 - Frank Rising
addappid(593052) -- Dead Rising 4 - Holiday Stocking Stuffer Pack
addappid(593053) -- Dead Rising 4 - Sir-Ice-A-Lot
addappid(593054) -- Dead Rising 4 - Slicecycle
addappid(593055) -- Dead Rising 4 - Super Ultra Dead Rising 4 Mini Golf
addappid(593056) -- Dead Rising 4 - Ugly Winter Sweater
addappid(593057) -- Dead Rising 4 - X-Fists
-- EMPTY DEPOTS (no content on any branch)
-- addappid(543463) -- Depot 543463 (empty depot)