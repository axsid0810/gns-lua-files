-- 265550's Lua and Manifest Created by Hubcap Manifest
-- Dead Rising 3
-- Created: March 14, 2026 at 16:48:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 11
-- Total DLCs: 4
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(265550, 1, "6d1184145f7945f7a4eb4ce6ad1ba089fd609ab96ef533c41e69ba0a14ecacdb") -- Dead Rising 3
-- MAIN APP DEPOTS
addappid(265551, 1, "3b1663434bdcb2dc139e0a48c954ed4de6dc3805011678d53226bedcd1faf6c9") -- Walking Content
setManifestid(265551, "2156020084728399680", 33689336790)
addappid(265553, 1, "abe620009de60821dc809c267e3e61608c7431a50659ad7a8e593cccfba6e3f4") -- Dead Rising 3 JP
setManifestid(265553, "4214359349980181997", 35287875746)
addappid(265552, 1, "90a6686bb14ffd51ad40e620c66751695e7f27baf591752b26a66ba93f57fdc1") -- Dead Rising 3 ROW
setManifestid(265552, "1491270682358049290", 1636043084)
addappid(265554, 1, "236544cc056a3d8363b38697d6713b5b0a3b3f98632324a219f97a380509ecef") -- Dead Rising 3 Digital Extras
setManifestid(265554, "6581835786989277397", 49739006)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Dead Rising 3 DLC1 (AppID: 274110)
addappid(274110)
addappid(274110, 1, "c8eb772507c220d39605368974b5af392a62a83a8828ba5ec36d90eeaa415867") -- Dead Rising 3 DLC1 - Walking DLC1 (274110) Depot
setManifestid(274110, "8114897424869582548", 0)
-- Dead Rising 3 DLC2 (AppID: 274111)
addappid(274111)
addappid(274111, 1, "25497a53f2ad2727f6738f11dfbb9c7fe6b764e021939c5759a0b78c845f6e68") -- Dead Rising 3 DLC2 - Walking DLC2 (274111) Depot
setManifestid(274111, "5261805151556622202", 0)
-- Dead Rising 3 DLC3 (AppID: 274112)
addappid(274112)
addappid(274112, 1, "cf9e6ac0cbb6c2e2e487efaff6d2e4ed9ce4f9337de755e57301a63fcaeac122") -- Dead Rising 3 DLC3 - Walking DLC3 (274112) Depot
setManifestid(274112, "338860370970731445", 0)
-- Dead Rising 3 DLC4 (AppID: 278140)
addappid(278140)
addappid(278140, 1, "8286b20af13ed015faa8e8431a6cf8371d041f5498245b39c03fc906358c20e4") -- Dead Rising 3 DLC4 - Walking DLC4 (278140) Depot
setManifestid(278140, "5538128077113190254", 0)