-- 223850's Lua and Manifest Created by Hubcap Manifest
-- 3DMark
-- Created: June 15, 2026 at 14:26:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 39
-- Total DLCs: 22 (1 excluded)
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(223850, 1, "c5a9de8a18176731ca393f952157a77a577a2648a185a4343070c4d26b7da3e4") -- 3DMark
addtoken(223850, "8515154216568685441")
-- MAIN APP DEPOTS
addappid(223851, 1, "3de227c648bb03f2e1c49c79d24114cec185486be4058e6f76eb4175b5c8ee1c") -- 3DMark Content
setManifestid(223851, "6755079532802782971", 574580009)
addappid(223857, 1, "3b9c04fda6f4eec1130cfadfa5524ed579db2b1a2ea05e642b589fdbd22d154e") -- 3DMark FireStrike Depot
setManifestid(223857, "8010588214735581753", 740754175)
addappid(223858, 1, "a149d2384c242a0f24db11102ba5192e6be5b24e4e9f5478d6f81715e1be2600") -- 3DMark CloudGate Depot
setManifestid(223858, "4288125963042803502", 235988525)
addappid(223859, 1, "7ba109e7f86954b3752a77be9bcf62ac11fca73888fd16451324d316a8a648c7") -- 3DMark SkyDiver Depot
setManifestid(223859, "6646684782746287281", 565691357)
addappid(223860, 1, "34c1fa8d4ac0296046d8b013606ccd07dabafc06f5fd315998163a027ad36570") -- 3DMark TimeSpy Depot
setManifestid(223860, "6561610102331963776", 1934670306)
addappid(496106, 1, "6ea0283e4e59b867500f3a10bffbf76ddc462694f60eec5c36a701679f60afbf") -- 3DMark Night Raid Depot
setManifestid(496106, "5328519819212543753", 741350148)
addappid(223853, 1, "b891cf73a4f710c4d361a757912867ddea5cb77f8cdc2520e1bd9c64aefeb43d") -- 3DMark SI
setManifestid(223853, "5225642702742533072", 3711788)
addappid(223854, 1, "300dd5b8d611c9c32c245106d9b3536c2662a9904bf26457b5c456ed3a8cb52a") -- Depot 223854
setManifestid(223854, "6832321780387839886", 29175972)
addappid(223855, 1, "6dcde23dd4a79de2f94c31253c4e03d58ab1321af3740f962efdb97151f704c7") -- 3DMark IceStorm Depot
setManifestid(223855, "7529388162664818502", 1374275432)
addappid(223856, 1, "c597efcdf5cf687d07b63f3521b6c1bdba41bcf0a2d3e3656d74a80425b08e06") -- Depot 223856
setManifestid(223856, "921540222814698373", 1414348041)
addappid(223861, 1, "5cf5b12f619d1e15213bcc636dafdf59b35a8391e13c5f69be47b6803f6c375e") -- Depot 223861
setManifestid(223861, "6373367933311603109", 408302360)
addappid(223862, 1, "97be9f16311756a713ef1ccb4ed6474c80414f4825d9f467c3a26c6b45be2707") -- Depot 223862
setManifestid(223862, "1404432785719678122", 280675719)
addappid(223865, 1, "a822346e2247e1c08733a5f616070ddf47647d6163fa54ddc37807e925d300ab") -- Depot 223865
setManifestid(223865, "8316660869639719619", 152128308)
addappid(223866, 1, "01c0e07642fb745696fb2466743e4764a5a43b5a3890e9a5d79b4dd86b130826") -- Depot 223866
setManifestid(223866, "67764373383108962", 294795685)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
-- DLCS WITH DEDICATED DEPOTS
-- 3DMark Sky Diver benchmark (AppID: 393480)
addappid(393480)
addtoken(393480, "14888844216902740007")
addappid(393480, 1, "c3550e6d933b4a183a9f3f604638fafefb64b7b105f2111b060823596eacaf64") -- 3DMark Sky Diver benchmark - 3DMark-SkyDiver-DLC (393480) Depot
setManifestid(393480, "4854111626390849935", 565691357)
-- 3DMark Fire Strike benchmark (AppID: 402290)
addappid(402290)
addtoken(402290, "5311523970535186631")
addappid(402290, 1, "1fe33d8c74ed80a81458f6fc33ad1fe0fb8fe9526edca06d81430e27c244046b") -- 3DMark Fire Strike benchmark - 3DMark Fire Strike benchmarks (402290) Depot
setManifestid(402290, "3393334588219593742", 740754175)
-- 3DMark Ice Storm benchmark (AppID: 406950)
addappid(406950)
addtoken(406950, "6864278577956563749")
addappid(406950, 1, "252809724b9c3d9075d416cf4fe6f100e90458fad45396119e5c187f1105e661") -- 3DMark Ice Storm benchmark - 3DMark-IceStorm-DLC (406950) Depot
setManifestid(406950, "5138617316346193451", 237899956)
-- 3DMark Cloud Gate benchmark (AppID: 406960)
addappid(406960)
addtoken(406960, "12058300902969881074")
addappid(406960, 1, "14a176432e1ecb34459e0d00d9b17b001daf85b8e32970b5383d43745d783162") -- 3DMark Cloud Gate benchmark - 3DMark-CloudGate-DLC (406960) Depot
setManifestid(406960, "3790262270949171570", 235988525)
-- 3DMark API Overhead feature test (AppID: 407080)
addappid(407080)
addtoken(407080, "17968455478461266808")
addappid(407080, 1, "cb852843188f2536c49af5f1a77e857337bb75b3f56e6a67c1584e27d99b4722") -- 3DMark API Overhead feature test - 3DMark-ApiOverhead-DLC (407080) Depot
setManifestid(407080, "29961312658214504", 40098298)
-- VRMark Preview (AppID: 428810)
addappid(428810)
addtoken(428810, "2913836294321501734")
addappid(428810, 1, "0ce01c29936d37ddd83183ae0ac89edbb057a40cc698554d2bd834919f322631") -- VRMark Preview - VRMark Preview (428810) Depot
setManifestid(428810, "1229190928172659417", 1073291627)
-- 3DMark Time Spy benchmark (AppID: 496100)
addappid(496100)
addtoken(496100, "15737651592625568692")
addappid(496100, 1, "16bea254da7ea9191674fa5403323d624cce90ca341ea14c0f975898b0edd695") -- 3DMark Time Spy benchmark - 3DMark DLC 11 (496100) Depot
setManifestid(496100, "7583476012096146266", 1934670306)
-- 3DMark Time Spy upgrade (AppID: 496101)
addappid(496101)
addtoken(496101, "16896246439669095714")
addappid(496101, 1, "33ec17a5fda46cbd261a47fee164003fb6fab797d23398586b222942e7cab5f6") -- 3DMark Time Spy upgrade - 3DMark renamed DLC 12 (496101) Depot
setManifestid(496101, "5703321063452596321", 1934670306)
-- 3DMark Night Raid benchmark (AppID: 496102)
addappid(496102)
addtoken(496102, "2539719626947500236")
addappid(496102, 1, "cd6c50c4691a2ac78dd97810cf868ad8db54645239261e364a75ccd202d472b6") -- 3DMark Night Raid benchmark - 3DMark DLC 13 (496102) Depot
setManifestid(496102, "8674370747924414523", 741350148)
-- 3DMark Port Royal upgrade (AppID: 496103)
addappid(496103)
addtoken(496103, "16854353521133773894")
addappid(496103, 1, "ee4ceb05728cd661a1f9734074d8fb44e54f6f31fa4ec6812de010e2bf6a8737") -- 3DMark Port Royal upgrade - 3DMark DLC 14 (496103) Depot
setManifestid(496103, "3950143110521258349", 1827988591)
-- 3DMark PCI Express feature test (AppID: 496104)
addappid(496104)
addtoken(496104, "18132660433758355258")
addappid(496104, 1, "07ce096cd01dc58a2dcf68b6401677c7c5192148fbd91c17a107a78d12d2cdd3") -- 3DMark PCI Express feature test - 3DMark DLC 15 (496104) Depot
setManifestid(496104, "5539713522631299933", 204629215)
-- 3DMark VRS feature test (AppID: 556150)
addappid(556150)
addtoken(556150, "8088996255729084501")
addappid(556150, 1, "317650061c749c25d333bbe42a2e1dd692d77f435a969dbf81d982ad8ff68c8d") -- 3DMark VRS feature test - 3DMark Sling Shot Extreme benchmark - NOT USED (556150) Depot
setManifestid(556150, "4173703279781492962", 801564041)
-- 3DMark Wild Life benchmark (AppID: 1276160)
addappid(1276160)
addtoken(1276160, "3808557813810670641")
addappid(1276160, 1, "a8f16b3e90baa937cb50d0a8f6f625fc96b03d9baa648a62d464217f8beec048") -- 3DMark Wild Life benchmark - 3DMark Wild Life benchmark (1276160) Depot
setManifestid(1276160, "8215949335091262124", 412115023)
-- 3DMark Storage Benchmark (AppID: 1322770)
addappid(1322770)
addtoken(1322770, "16580875652134393799")
addappid(1322770, 1, "c93b724e0351757bfc92c09728880219af36fbec2f03a375471a4125bb537af9") -- 3DMark Storage Benchmark - 3DMark Storage Test (1322770) Depot
setManifestid(1322770, "6472910614640873893", 1830140068)
-- 3DMark Mesh Shader feature test (AppID: 1498800)
addappid(1498800)
addtoken(1498800, "7564764810534107591")
addappid(1498800, 1, "c91b5b7276242058d9268997c26d46e68e767b2ad1834ef9ba3c033f0b8262ab") -- 3DMark Mesh Shader feature test - 3DMark Mesh Shader feature test (1498800) Depot
setManifestid(1498800, "2442159730561729614", 204858781)
-- 3DMark Sampler Feedback feature test (AppID: 1498801)
addappid(1498801)
addtoken(1498801, "15263340711464891012")
addappid(1498801, 1, "f3523fbbdddc65bee537e1d0e876edce5b25fdb11c8697178bd36e8041fb0377") -- 3DMark Sampler Feedback feature test - 3DMark Sampler Feedback feature test (1498801) Depot
setManifestid(1498801, "3249001846606523341", 436015083)
-- 3DMark CPU Profile benchmarks (AppID: 1654370)
addappid(1654370)
addtoken(1654370, "7178677053256432987")
addappid(1654370, 1, "4c5954d4d6275950b676fff756b359ea589adf594309ad9e724fd47d3345f886") -- 3DMark CPU Profile benchmarks - Ceroc (1654370) Depot
setManifestid(1654370, "431732157372319965", 57181374)
-- 3DMark Speed Way upgrade (AppID: 2019730)
addappid(2019730)
addtoken(2019730, "1766783152026947845")
addappid(2019730, 1, "aaa632673c67a246329d3ac900fb4619a250adef52219dfee9a37498d4337acd") -- 3DMark Speed Way upgrade - Depot 2019730
setManifestid(2019730, "1010350227387367401", 1843203966)
-- 3DMark Solar Bay (AppID: 2313300)
addappid(2313300)
addtoken(2313300, "4026694693912140758")
addappid(2313300, 1, "0967c1e1a31aee44ccf8e1af64012d56de566e0db5f89ef87cb1357b923fc33f") -- 3DMark Solar Bay - Depot 2313300
setManifestid(2313300, "2194691387120551436", 152128308)
-- 3DMark Steel Nomad (AppID: 2695340)
addappid(2695340)
addtoken(2695340, "9593131367516828000")
addappid(2695340, 1, "1aa25cffbc68de1b6ff945372f0db71c72958d952519a9ecab370230e57ca3e0") -- 3DMark Steel Nomad - Depot 2695340
setManifestid(2695340, "8518068741402017845", 1414348041)
-- 3DMark Solar Bay Extreme (AppID: 3941790)
addappid(3941790)
addappid(3941790, 1, "b060ca9c30dcf63525aef1eeaa91bbf6fc082c9ed904b1c4f13c3780258d0230") -- 3DMark Solar Bay Extreme - Depot 3941790
setManifestid(3941790, "6670025621800504617", 294795685)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(223852) -- 3DMark Advanced
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(487680) -- 3DMark Time Spy benchmark (Basic Edition OLD) (unreleased)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(223864) -- Depot 223864 (empty depot)
-- addappid(223867) -- Depot 223867 (empty depot)
-- addappid(425830) -- Depot 425830 (empty depot)
-- addappid(1448370) -- Depot 1448370 (empty depot)
-- addappid(2019720) -- Depot 2019720 (empty depot)
-- addappid(2783060) -- Depot 2783060 (empty depot)
-- addappid(4751810) -- Depot 4751810 (empty depot)