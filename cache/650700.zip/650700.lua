-- 650700's Lua and Manifest Created by Hubcap Manifest
-- Yume Nikki
-- Created: October 01, 2025 at 08:55:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(650700) -- Yume Nikki
-- MAIN APP DEPOTS
addappid(650702, 1, "f924dd669189e67637b1c6a5063d474f90f4b9c8b78799ed45e3c05537c3206e") -- Yume Nikki EN
setManifestid(650702, "8519013993702567900", 98230191)
addappid(650703, 1, "a6bae1b261377525d487d7c35b625bdea2dc66af5e3b2b6affa91eb6e87568e4") -- Yume Nikki JP
setManifestid(650703, "5823751714269365707", 62385664)