-- 2207980's Lua and Manifest Created by Hubcap Manifest
-- House of Ghosts
-- Created: July 05, 2026 at 11:04:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2207980) -- House of Ghosts
-- MAIN APP DEPOTS
addappid(2207981, 1, "ccb257ed1ccf25d52fd37ace21fa5bc3c00d487dbfb37221a57b8150bc961513") -- Depot 2207981
setManifestid(2207981, "4380711441353036669", 2550311297)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)