-- 2963870's Lua and Manifest Created by Hubcap Manifest
-- Metal Slug: Awakening
-- Created: July 24, 2026 at 12:01:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2963870, 1, "84215d7ec69b5fedc2df2a95c173722b6b8ae2fe8c61910f5f8279e33b993a2f") -- Metal Slug: Awakening
-- MAIN APP DEPOTS
addappid(2963871, 1, "d9d37ba599e18f1a9f535214896754232ecaebbb0438ff8516aa3d8eae599d8e") -- Depot 2963871
setManifestid(2963871, "2223510864936216042", 16057516814)