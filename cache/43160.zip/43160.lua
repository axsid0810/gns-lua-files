-- 43160's Lua and Manifest Created by Hubcap Manifest
-- Metro: Last Light Complete Edition
-- Created: September 30, 2025 at 00:34:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 12
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(43160) -- Metro: Last Light Complete Edition
-- MAIN APP DEPOTS
addappid(43161, 1, "aaa7d8fa6a079dfa9f4539d14ad5d597ae9eaea8d1b47df83d83e7b5b3735f73") -- MetroLL Content
setManifestid(43161, "172735055028682614", 9978747300)
addappid(43162, 1, "049f4d43c02d5084bb366177de273ba7a8e1dce19581d7bd3af8fe888398d6dc") -- MetroLL Binaries
setManifestid(43162, "8931438170091183706", 24044152)
addappid(43164, 1, "cd11061b5f7840e14afa95c8878820a0bd412d720206309b18fd76fec9b70eaf") -- MetroLL OSX
setManifestid(43164, "8074282923124235513", 9614286648)
addappid(43165, 1, "899b0ea7f2617c62d551e2e9b8697e5b80f07a8623b588347d3ad2cfa510a2a0") -- MetroLL Linux
setManifestid(43165, "1924185578284204221", 9582603657)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- PhysX System Software 9.13.1220 (Shared from App 228980)
setManifestid(229032, "3616495131483866412", 41178235)
-- DLCS WITH DEDICATED DEPOTS
-- Metro Last Light - Novel (AppID: 43163)
addappid(43163)
addtoken(43163, "13226051512553002615")
addappid(43163, 1, "1717ae799dd8bf33e09cdd588c55bb1d8fcad96f404a07eafa1dc31e4581d0bb") -- Metro Last Light - Novel - MetroLL Novel
setManifestid(43163, "26228404254479279", 6183226)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(222801) -- Metro Last Light - Ranger Mode
addappid(222802) -- Metro Last Light - RPK
addappid(222803) -- Metro Last Light DLC_3
addappid(222804) -- Metro Last Light - Factions DLC
addappid(222805) -- Metro Last Light - Tower Pack
addappid(222806) -- Metro Last Light - Developer DLC
addappid(222807) -- Metro Last Light - Chronicles Pack DLC
addappid(238340) -- Metro Last Light Season Pass
addappid(239180) -- Metro Last Light Comic ENG
addappid(239181) -- Metro Last Light Comic DE
addappid(239182) -- Metro Last Light Comic RU