-- 2315690's Lua and Manifest Created by Hubcap Manifest
-- WWE 2K24
-- Created: October 01, 2025 at 08:17:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 12
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2315690) -- WWE 2K24
-- MAIN APP DEPOTS
addappid(2315691, 1, "23e097a5dcfd505419d23c66434881e466ae025183332849a90469800dd3d074") -- Depot 2315691
setManifestid(2315691, "1030431831166830840", 101499571728)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2528460) -- WWE 2K24 ECW Punk Pack
addappid(2544390) -- WWE 2K24 SuperCharger
addappid(2584660) -- WWE 2K24 MyRISE Mega-Boost
addappid(2768160) -- WWE 2K24 40 years of WrestleMania Pack
addappid(2768170) -- WWE 2K24 Nightmare Family Pack
addappid(2768180) -- WWE 2K24 Deluxe Content Pack
addappid(2768190) -- WWE 2K24 Season Pass
addappid(2855610) -- WWE 2K24 Post Malone  Friends Pack
addappid(2855620) -- WWE 2K24 Pat McAfee Show Pack
addappid(2855630) -- WWE 2K24 Global Superstars Pack
addappid(2855640) -- WWE 2K24 WCW Pack
addappid(3180050) -- WWE 2K24 Bray Wyatt Edition Pack