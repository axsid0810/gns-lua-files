-- 3809110's Lua and Manifest Created by Hubcap Manifest
-- 日本事故物件監視協会 -Japan Stigmatized Property-
-- Created: May 07, 2026 at 12:26:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3809110) -- 日本事故物件監視協会 -Japan Stigmatized Property-
-- MAIN APP DEPOTS
addappid(3809111, 1, "2e17755ea4a2836a0d38a614a7686c6c77f4c392cbd35ae322035ab1bee06d45") -- Depot 3809111
setManifestid(3809111, "1437354914791807753", 2009139672)
addappid(3809112, 1, "f4b2a0b4e85671c0b19503b47f4176c983102c878927e507c6cead7efb5c2857") -- Depot 3809112
setManifestid(3809112, "4107959135355534373", 3320808056)