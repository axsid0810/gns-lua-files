-- 4249110's Lua and Manifest Created by Hubcap Manifest
-- Resident Evil 2 (1998)
-- Created: June 03, 2026 at 16:36:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4249110, 1, "a8e900f4baf3013dff3c9f9402e8ae4377ed148df2dfc4ebf6f3f54496c75c86") -- Resident Evil 2 (1998)
-- MAIN APP DEPOTS
addappid(4249111, 1, "7e6d6cb1a6e136160805cc707943680e3b949fcd4614a89874f8f9005c22f69f") -- Depot 4249111
setManifestid(4249111, "4162242548040861635", 1612083)
addappid(4249112, 1, "f311e48330d6eb5320456deb32ff0dfc4afa77462ab3ef4f03c712976fd27013") -- Depot 4249112
setManifestid(4249112, "2015999630805652938", 39668096)
addappid(4249113, 1, "4e7a4a237210d1cd940175c55d7e47eed5cd69489edafba115a6477d2f15123b") -- Depot 4249113
setManifestid(4249113, "733389168188405052", 5646161564)