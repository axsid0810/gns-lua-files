-- 609150's Lua and Manifest Created by Hubcap Manifest
-- STAR OCEAN™ - THE LAST HOPE™ - 4K & Full HD Remaster
-- Created: September 30, 2025 at 19:25:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(609150) -- STAR OCEAN™ - THE LAST HOPE™ - 4K & Full HD Remaster
-- MAIN APP DEPOTS
addappid(609152, 1, "7d2a7f3e6f4fe1d149fb986d089a11d32c4563c2ce7eae5370503968961929ad") -- BaseContents
setManifestid(609152, "8816463828272157039", 54777947624)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- DLC_STAR OCEAN - THE LAST HOPE - 4K  Full HD Remaster  MINI-SOUNDTRACK (AppID: 665130)
addappid(665130)
addtoken(665130, "1756411868132797766")
addappid(665130, 1, "de4696e59c44d2339a8ed9f8001c4b6d4fd393127158220ccf3acae81d8220ae") -- DLC_STAR OCEAN - THE LAST HOPE - 4K  Full HD Remaster  MINI-SOUNDTRACK - DLC_STAR OCEAN- THE LAST HOPE - 4K & Full HD Remaster  MINI-SOUNDTRACK (665130) 個のデポ
setManifestid(665130, "7347322203676789582", 24722186)