-- 658260's Lua and Manifest Created by Hubcap Manifest
-- BLUE REFLECTION
-- Created: September 29, 2025 at 01:41:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 26
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(658260) -- BLUE REFLECTION
-- MAIN APP DEPOTS
addappid(658261, 1, "bc8db29f4ace088199b4a7707a605213d76c51412d5c2507cd6cf1bb78c153c8") -- BLUE REFLECTION Content
setManifestid(658261, "3242650588155784855", 25468338766)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(688240) -- BLUE REFLECTION - Bonus DLC
addappid(688241) -- BLUE REFLECTION - Sailor Swimsuit Set A (HinakoSarasaMao)
addappid(688242) -- BLUE REFLECTION - Sailor Swimsuit Set B (YuzukiShihoriKei)
addappid(688243) -- BLUE REFLECTION - Sailor Swimsuit Set C (LimeFumioChihiro)
addappid(688244) -- BLUE REFLECTION - Sailor Swimsuit Set D (SanaeAkoYuri)
addappid(688245) -- BLUE REFLECTION - Sailor Swimsuit Set E (RinKaoriRika)
addappid(688246) -- BLUE REFLECTION - Arland Maid Costumes (Yuzuki)
addappid(688247) -- BLUE REFLECTION - Arland Maid Costumes (Lime)
addappid(688248) -- BLUE REFLECTION - Summer Clothes Set A (Hinako, Sarasa, Mao)
addappid(688249) -- BLUE REFLECTION - Summer Clothes Set B (Yuzu, Shihori, Kei)
addappid(688250) -- BLUE REFLECTION - Summer Clothes Set C (Lime, Fumio, Chihiro)
addappid(688251) -- BLUE REFLECTION - Summer Clothes Set D (Sanae, Ako, Yuri)
addappid(688252) -- BLUE REFLECTION - Summer Clothes Set E (Rin, Kaori, Rika)
addappid(688253) -- BLUE REFLECTION - Bath Towels Set A (Hinako, Sarasa, Mao)
addappid(688254) -- BLUE REFLECTION - Bath Towels Set B (Yuzu, Shihori, Kei)
addappid(688255) -- BLUE REFLECTION - Bath Towels Set C (Lime, Fumio, Chihiro)
addappid(688256) -- BLUE REFLECTION - Bath Towels Set D (Sanae, Ako, Yuri)
addappid(688257) -- BLUE REFLECTION - Bath Towels Set E (Rin, Kaori, Rika)
addappid(688258) -- BLUE REFLECTION - Vacation Style Set A (Hinako, Sarasa, Mao)
addappid(688259) -- BLUE REFLECTION - Vacation Style Set B (Yuzu, Shihori, Kei)
addappid(688270) -- BLUE REFLECTION - Vacation Style Set C (Lime, Fumio, Chihiro)
addappid(688271) -- BLUE REFLECTION - Vacation Style Set D (Sanae, Ako, Yuri)
addappid(688272) -- BLUE REFLECTION - Vacation Style Set E (Rin, Kaori, Rika)
addappid(688273) -- BLUE REFLECTION - Special Event
addappid(688274) -- BLUE REFLECTION - Bonus Costume, Nightless Saber
addappid(704150) -- BLUE REFLECTION Season Pass