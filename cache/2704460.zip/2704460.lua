-- 2704460's Lua and Manifest Created by Hubcap Manifest
-- Neon Geometry Dash
-- Created: September 30, 2025 at 03:16:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2704460) -- Neon Geometry Dash
-- MAIN APP DEPOTS
addappid(2704461, 1, "062a17ce1c50639c46f5836622735ee0a838fd1d811068c4fa0c8f87c9c63a14") -- Depot 2704461
setManifestid(2704461, "9071615291828093988", 239012190)