-- 1611600's Lua and Manifest Created by Hubcap Manifest
-- WARNO
-- Created: July 13, 2026 at 13:44:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 24
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1611600, 1, "d053a11e0ae8b1c11883882bf55f125055e5965c6c57c0a35774f33ee51114d8") -- WARNO
-- MAIN APP DEPOTS
addappid(1611601, 1, "4f4f2eafce1c568afab8d453340193eeec38f656303f6aca28a1ba4e806204ea") -- WARNO Content
setManifestid(1611601, "2339879992219687491", 79704291841)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- DLCS WITH DEDICATED DEPOTS
-- WARNO - Digital Guides (AppID: 2981540)
addappid(2981540)
addappid(2981540, 1, "9ccfc15aa1a5e2cadfbf80f7cad47232df810b4ecd7b5e5f3ae709cc36aca605") -- WARNO - Digital Guides - Depot 2981540
setManifestid(2981540, "4201596155495234698", 38294872)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2978610) -- WARNO - Early Access Pack
addappid(2978620) -- WARNO - NORTHAG
addappid(2978630) -- WARNO - SOUTHAG
addappid(2978640) -- WARNO - Nemesis 1 - Air Assault
addappid(2978650) -- WARNO - Nemesis 2
addappid(3017370) -- WARNO - Expansion Pass
addappid(3025400) -- WARNO - Reinforcement Pack 1
addappid(3261230) -- WARNO - Reinforcement Pack 2 - Railway
addappid(3309840) -- Reinforcement Pack 3 - Stoneware
addappid(3333260) -- WARNO - Nemesis 3 - Homefront
addappid(3333270) -- WARNO -RP 4 - Albion map
addappid(3363540) -- WARNO -RP 5 - Valley map
addappid(3484700) -- WARNO - RP 6 - Kreide map
addappid(3594460) -- WARNO - LANDJUT
addappid(3601220) -- WARNO - RP 7 - Cliff
addappid(3628420) -- WARNO - Nemesis 5 - Low Countries Lions
addappid(3690960) -- WARNO - RP 8 - Ohmen
addappid(3746630) -- WARNO - RP 9 - Surrounded
addappid(3828990) -- WARNO - RP 10 - Eiche
addappid(4030770) -- WARNO - Nemesis 4 - Capital Defence
addappid(4100510) -- WARNO - Nemesis 5 - Southern Flank
addappid(4341720) -- WARNO - Nemesis 6 - The Magdeburg Counterstrike
addappid(4579490) -- WARNO - Nemesis 7 - State of Emergency