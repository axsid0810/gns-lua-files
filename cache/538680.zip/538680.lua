-- 538680's Lua and Manifest Created by Hubcap Manifest
-- The Legend of Heroes: Trails of Cold Steel
-- Created: October 01, 2025 at 00:07:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 24
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(538680) -- The Legend of Heroes: Trails of Cold Steel
-- MAIN APP DEPOTS
addappid(538683, 1, "9b949fb015a0af07d1c6ab9dc9cb02eb237524510d9fce197e1ddd57d35c57a5") -- The Legend of Heroes: Trails of Cold Steel Binaries
setManifestid(538683, "1551266340175150539", 28845898)
addappid(538682, 1, "56c145c4ef0c13fae87ed6fd963957233f34e4fd02f2156cecbf9660053b4988") -- The Legend of Heroes: Trails of Cold Steel DX11 Assets
setManifestid(538682, "3478918062859066401", 20266284882)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(605270) -- The Legend of Heroes Trails of Cold Steel - Reans Casuals
addappid(605280) -- The Legend of Heroes Trails of Cold Steel - Alisas Casuals
addappid(605320) -- The Legend of Heroes Trails of Cold Steel - Elliots Casuals
addappid(605321) -- The Legend of Heroes Trails of Cold Steel - Lauras Casuals
addappid(605322) -- The Legend of Heroes Trails of Cold Steel - Machias Casuals
addappid(605323) -- The Legend of Heroes Trails of Cold Steel - Emmas Casuals
addappid(605324) -- The Legend of Heroes Trails of Cold Steel - Jusis Casuals
addappid(605325) -- The Legend of Heroes Trails of Cold Steel - Fies Casuals
addappid(605326) -- The Legend of Heroes Trails of Cold Steel - Gaius Casuals
addappid(605327) -- The Legend of Heroes Trails of Cold Steel - Milliums Casuals
addappid(605328) -- The Legend of Heroes Trails of Cold Steel - Crows Casuals
addappid(605330) -- The Legend of Heroes Trails of Cold Steel - Sepith Pack
addappid(605331) -- The Legend of Heroes Trails of Cold Steel - Handy Accessories Pack
addappid(605332) -- The Legend of Heroes Trails of Cold Steel - Monstrous Ingredients Pack
addappid(605333) -- The Legend of Heroes Trails of Cold Steel - Valuable Healing Items Pack
addappid(605334) -- The Legend of Heroes Trails of Cold Steel - Zeram Powder Pack
addappid(605335) -- The Legend of Heroes Trails of Cold Steel - Zeram Capsule Pack
addappid(605350) -- The Legend of Heroes Trails of Cold Steel - Shining Pom Bait Pack 1
addappid(605351) -- The Legend of Heroes Trails of Cold Steel - Shining Pom Bait Pack 2
addappid(605352) -- The Legend of Heroes Trails of Cold Steel - Shining Pom Bait Pack 3
addappid(605353) -- The Legend of Heroes Trails of Cold Steel - Shining Pom Bait Pack 4
addappid(605354) -- The Legend of Heroes Trails of Cold Steel - Shining Pom Bait Pack 5
addappid(605360) -- The Legend of Heroes Trails of Cold Steel - Shining Pom Bait Value Pack 1
addappid(605361) -- The Legend of Heroes Trails of Cold Steel - Shining Pom Bait Value Pack 2