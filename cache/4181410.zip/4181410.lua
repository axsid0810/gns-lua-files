-- 4181410's Lua and Manifest Created by Hubcap Manifest
-- The Alley
-- Created: July 24, 2026 at 11:42:15 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4181410, 1, "1f1535030588a139cc034e8234c260fc0d87dff5d8dbd69fc21a7e3427786d94") -- The Alley
-- MAIN APP DEPOTS
addappid(4181411, 1, "a5f40763fbaba977a7db86b6111486094f613084a07e94b226db0a6ec09be368") -- Depot 4181411
setManifestid(4181411, "4965641928828075765", 7387217207)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)