-- 1651560's Lua and Manifest Created by Hubcap Manifest
-- Fabledom
-- Created: February 12, 2026 at 03:17:26 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1651560, 1, "c6329467bff9d2906cce3e97340d0e18525fc2cc4b69cbf65fd3dcbcaf9692b3") -- Fabledom
addtoken(1651560, "4483984494128195992")
-- MAIN APP DEPOTS
addappid(1651561, 1, "dbaf69374e2fa99d18be9c0ee9b803630ac5fdb318fff5a83637397db2576b99") -- Depot 1651561
setManifestid(1651561, "1652247544136243138", 4001887841)