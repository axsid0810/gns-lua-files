-- 1238080's Lua and Manifest Created by Hubcap Manifest
-- Burnout™ Paradise Remastered
-- Created: July 02, 2026 at 18:18:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 12
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1238080, 1, "d08ee5bc02f170fb806818bc8343ff098b1269da8d9bf0de8f20dee419263f42") -- Burnout™ Paradise Remastered
-- MAIN APP DEPOTS
addappid(1238081, 1, "ea90067517b10ddd6f338d6af29013a0c2be3aeeabeac0bceb1f245be114897e") -- Burnout Paradise - Content
setManifestid(1238081, "6052234672890207163", 7753000094)
addappid(1238082, 1, "84a20cd45e038c3b0dc53ff2b954ce5aa8b3af23954aa9e7917f9731c004f2eb") -- Burnout Paradise - en_US
setManifestid(1238082, "9127419540029028402", 144971)
addappid(1238083, 1, "600ddf65fa51b74b35d9566e22e89fd11b730bca5daaebaa3ad59a2c1d700766") -- Burnout Paradise - fr_FR
setManifestid(1238083, "2395968831831547638", 158208)
addappid(1238084, 1, "cf30121f859ccc908de5b957ea36beb283661cb9a6031a5e3647ff2315d82548") -- Burnout Paradise - it_IT
setManifestid(1238084, "2460919538076271355", 152740)
addappid(1238085, 1, "f68ccfb4586a9404a2b00c5d8703835c2801eee044b0320921c78a8ca90e6626") -- Burnout Paradise - de_DE
setManifestid(1238085, "9156785583163775532", 145576)
addappid(1238086, 1, "d12a797e4bc8538647cfe6be4b1c8193b67c796160fe3a322462415339bcfb3c") -- Burnout Paradise - es_ES
setManifestid(1238086, "4418045210597571772", 165014)
addappid(1238087, 1, "399233433396006f010ccc768dcc897f2c7cbdd39c0257564e8f728092bf527e") -- Burnout Paradise - ru_RU
setManifestid(1238087, "798720946443993544", 243749)
addappid(1238088, 1, "bb14d8cea6cf36a9c0256b13b44b6394e3949d92561f3f553e72f332f5dcf8d8") -- Burnout Paradise - pl_PL
setManifestid(1238088, "4326036204053801536", 159106)
addappid(1238089, 1, "6de5c0798901524abd7e7e4c9ad8f5e4797b9538833e9aacc8151c82171d530b") -- Burnout Paradise - ja_JP
setManifestid(1238089, "140140040726616148", 241603)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
setManifestid(3340991, "2155225770093841476", 239536599)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1302010) -- Burnout Paradise Remastered - Key