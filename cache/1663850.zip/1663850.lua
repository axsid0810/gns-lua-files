-- 1663850's Lua and Manifest Created by Hubcap Manifest
-- REPLACED
-- Created: June 26, 2026 at 10:45:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1663850, 1, "a2dc4252dac9904d2353cbd1667abb1e5fbd5fc2ffa952037daf8a1d3dead0e3") -- REPLACED
-- MAIN APP DEPOTS
addappid(1663851, 1, "6c5ad07d24ba971709a2773ed2263ddc46bf21f9a2608989ef9438668db72760") -- Depot 1663851
setManifestid(1663851, "3597756146950805562", 5985532721)