-- 387990's Lua and Manifest Created by Hubcap Manifest
-- Scrap Mechanic
-- Created: July 29, 2026 at 19:27:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(387990, 1, "0187df8e448332ced59790fcebde38720853500b8af881c5490a5ed379265508") -- Scrap Mechanic
-- MAIN APP DEPOTS
addappid(387992, 1, "a2b344f494b0b5375bf3c405e8b3de97923659c663d583eee57993952d363761") -- Scrap Mechanic Data
setManifestid(387992, "1754316370188389222", 15404419064)
addappid(387993, 1, "93137be5385ff98af9981124f0adeb9e8d55b91d0eab1c8a2f9ab417034a3243") -- Scrap Mechanic Win64
setManifestid(387993, "8038485311616492814", 5378528920)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4857560) -- Scrap Mechanic - Fan Pack