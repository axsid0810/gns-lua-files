-- 1599660's Lua and Manifest Created by Hubcap Manifest
-- Sackboy™: A Big Adventure
-- Created: September 30, 2025 at 11:54:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 23
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1599660) -- Sackboy™: A Big Adventure
-- MAIN APP DEPOTS
addappid(1599661, 1, "d759c1903ae656936c6564d2148c69c553fb408d0234a6604c01916699b2b482") -- Depot 1599661
setManifestid(1599661, "5076959587775286666", 57006801055)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2131310) -- Sackboy Pre-Purchase Entitlements
addappid(2193240) -- Sackboy A Big Adventure  Nathan Drake Costume
addappid(2193241) -- Sackboy A Big Adventure  Chloe Frazer Costume
addappid(2206300) -- Sackboy A Big Adventure - Kratos Costume
addappid(2206301) -- Sackboy A Big Adventure - Atreus Costume
addappid(2206302) -- Sackboy A Big Adventure - Freya Costume
addappid(2216230) -- Sackboy A Big Adventure - Football Costume
addappid(2228240) -- Sackboy A Big Adventure - Emote Pack
addappid(2228241) -- Sackboy A Big Adventure - New Years Eve Costume
addappid(2232410) -- Sackboy A Big Adventure - Monkey King Costume
addappid(2232470) -- Sackboy A Big Adventure - Fancy Clothing Pack
addappid(2232480) -- Sackboy A Big Adventure - Celebrations Emote Pack
addappid(2232490) -- Sackboy A Big Adventure  Gran Turismo Racing Suit Costume
addappid(2232500) -- Sackboy A Big Adventure - Video Game Costume
addappid(2232501) -- Sackboy A Big Adventure - Chinese New Year Costume
addappid(2232502) -- Sackboy A Big Adventure - Valentines Costume
addappid(2232510) -- Sackboy A Big Adventure - Emotions Emote Pack
addappid(2232520) -- Sackboy A Big Adventure - ASTRO BOT Costume
addappid(2232530) -- Sackboy A Big Adventure - Sporty Clothing Pack
addappid(2232540) -- Sackboy A Big Adventure - Matte Paint Pack
addappid(2232550) -- Sackboy A Big Adventure - Jellybean Paint Pack
addappid(2232560) -- Sackboy A Big Adventure - Daisy Costume
addappid(2232580) -- Sackboy A Big Adventure - Casual Clothing Pack