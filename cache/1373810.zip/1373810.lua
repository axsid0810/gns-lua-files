-- 1373810's Lua and Manifest Created by Hubcap Manifest
-- Orlando Theme Park VR - Roller Coaster and Rides
-- Created: September 30, 2025 at 05:13:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 6

-- MAIN APPLICATION
addappid(1373810) -- Orlando Theme Park VR - Roller Coaster and Rides
-- MAIN APP DEPOTS
addappid(1373811, 1, "76f0fae51f0887fac10a900f6a72110b35bb0aa91d64737b0d0be2a0c6d5f71b") -- Orlando Theme Park VR - Roller Coaster and Rides Content
setManifestid(1373811, "1503245697526382973", 3517068391)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1374730) -- Ikarus Ride - Orlando Theme Park VR
addappid(1374731) -- Booster Ride - Orlando Theme Park VR
addappid(1374732) -- Roller Coaster - Orlando Theme Park VR
addappid(1374733) -- Pirate Adventure - Orlando Theme Park VR
addappid(1374734) -- Top Spin Ride - Orlando Theme Park VR
addappid(1374735) -- Crazy Elevator - Orlando Theme Park VR