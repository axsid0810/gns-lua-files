-- 1574820's Lua and Manifest Created by Hubcap Manifest
-- Until Then
-- Created: June 18, 2026 at 12:01:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1574820, 1, "5bad1437b0d4dccaa29f118522ae30aa964f4a70664250e8fd15a27ed2bd9b7f") -- Until Then
-- MAIN APP DEPOTS
addappid(1574821, 1, "a195ac176ad8fdc6cae6bceff829cc13231f258d8c2379b96016589c4843d290") -- Depot 1574821
setManifestid(1574821, "451620367062350262", 3581855625)
addappid(1574822, 1, "f2fabb0a6a9c7117f184eeeefd4a73b6471fbefa9c15eb62dd036458885a72ea") -- Depot 1574822
setManifestid(1574822, "3011357795575069835", 3610368703)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3902750) -- Until Then - Afterimages