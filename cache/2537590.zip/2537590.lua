-- 2537590's Lua and Manifest Created by Hubcap Manifest
-- Microsoft Flight Simulator 2024
-- Created: June 29, 2026 at 17:19:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 5
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2537590, 1, "f264fcd2580ab71934f29046dc415c3a83163882e768246533ed1f20f1730835") -- Microsoft Flight Simulator 2024
-- MAIN APP DEPOTS
addappid(2537591, 1, "a149759cc259406fd0f2255297e089d9deb63fb59c263b7f2d1b7fcd7aded1a4") -- Depot 2537591
setManifestid(2537591, "1785542634196301496", 9449436474)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3227340) -- Limitless - Preorder Bonus
addappid(3245690) -- Microsoft Flight Simulator 2024 - Aviator
addappid(3245700) -- Microsoft Flight Simulator 2024 Deluxe
addappid(3245710) -- Microsoft Flight Simulator 2024 - Premium Deluxe
addappid(3341960) -- Microsoft Flight Simulator 2024 - Premium Deluxe Upgrade