-- 3326230's Lua and Manifest Created by Hubcap Manifest
-- Hozy
-- Created: June 29, 2026 at 15:48:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3326230, 1, "3108881c488b2e58e6e31b1c7670dab98347aed7296a9e8d9b0885c46f6f6064") -- Hozy
-- MAIN APP DEPOTS
addappid(3326231, 1, "f18e6e61bbba466e4f42d2c89e1eeacdd7b8b7431b642e32db491ebe514cc98c") -- Depot 3326231
setManifestid(3326231, "8095649011966879882", 5916255508)
addappid(3326232, 1, "d1f1320e659b50efd8f03262370feda79680b5649e25bbe7b091399106b624e4") -- Depot 3326232
setManifestid(3326232, "2895140420130344767", 6376548232)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)