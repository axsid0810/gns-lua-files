-- 239820's Lua and Manifest Created by Hubcap Manifest
-- Game Dev Tycoon
-- Created: April 01, 2026 at 16:00:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(239820, 1, "1e8e88cf4692922b5622fbc1d1e5a99cabeee44094d6301407598fd2dae95e9f") -- Game Dev Tycoon
-- MAIN APP DEPOTS
addappid(239821, 1, "5c590b0d0e5b292ede17d5bd6b6eb1a2b75487771e3465047c2a9829839ba8e6") -- Game Dev Tycoon Content
setManifestid(239821, "6817447801175830636", 168863527)
addappid(239822, 1, "23040406b451286e94316d8a9900e469006f1686acc2cab20694bdef7493d030") -- Game Dev Tycoon Mac
setManifestid(239822, "3689855375203705079", 180871883)
addappid(239823, 1, "3ab68bf206c3bdfd4a021f2c0b57ef302989056158f4a56e5c2604fd7b62bf1c") -- Game Dev Tycoon Linux 32bit
setManifestid(239823, "5567149145642665508", 274012332)
addappid(239824, 1, "f2beb41ca28321d3d22aa023d3c31695c85177ef8ff435324a42b8aa95036111") -- Game Dev Tycoon Depot Mac 64
setManifestid(239824, "7798044368897817013", 451538406)