-- 500's Lua and Manifest Created by Hubcap Manifest
-- Left 4 Dead
-- Created: June 29, 2026 at 15:35:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 0 (1 excluded)
-- Blacklisted Depots: 1
--   Depot 509: Blacklisted

-- MAIN APPLICATION
addappid(500, 1, "b17ac8c5e383af45264bd21caaac5f45e1f40e9883bbef39cb25d308b4083ab7") -- Left 4 Dead
-- MAIN APP DEPOTS
addappid(501, 1, "7a0b21eed084464fd2efb03ecc44116224b150f9377551ca7901ead966f21c26") -- Left 4 Dead binaries
setManifestid(501, "1832333851347898090", 317876522)
addappid(502, 1, "54d51378fea25647cfe0c7d77804f29abd538c2606e4bf27b972d02816f34487") -- Left 4 Dead base
setManifestid(502, "1346199116149879810", 3975129367)
addappid(503, 1, "81d91ffef65bb0b38b50fe8ba06fe690aae9a0afd2c65c3bbc9ec55ba5a203c4") -- Left 4 Dead client binary
setManifestid(503, "5156732173895269546", 6634648)
addappid(504, 1, "f7671db1d3c622e18dd1245e2d3f173e8ea71ad425f82e37f5d4027a60416c1a") -- Left 4 Dead sound
setManifestid(504, "8212197441078172924", 2190485123)
addappid(515, 1, "f09a2fa191a845e1274cf6abb8e5bc7d6ffd6c04cb4a114ddf6a98f8967877e0") -- left 4 dead mac content
setManifestid(515, "2369701142506601604", 648929337)
addappid(505, 1, "606977fdfcd55d1a781656ef5db7811bc9ab107d7604c68291a971aaa2a8c5b9") -- Left 4 Dead french
setManifestid(505, "5045000053553889222", 1428902685)
addappid(506, 1, "ff83a268db47060bbe676d22168de551715015faa70d962f3aa46368bb083bf8") -- Left 4 Dead german
setManifestid(506, "3612476309264296188", 1427836411)
addappid(507, 1, "d3a82b031014aa7c72b7c9ce029b2a15d8bfbcbb52ca29a56ac212f5bf1653db") -- Left 4 Dead russian
setManifestid(507, "3651932563014144986", 1622547072)
addappid(508, 1, "1f37e4f4b59d43a25a36ab2b174899f36a063cd7a80b743604d71f1c7c61015c") -- Left 4 Dead spanish
setManifestid(508, "3774429000353462406", 1422581523)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MANIFEST BLACKLIST)
-- addappid(1660740) -- DLC 1660740 (LV version only)