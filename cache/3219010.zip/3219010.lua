-- 3219010's Lua and Manifest Created by Hubcap Manifest
-- Fogpiercer
-- Created: July 20, 2026 at 18:26:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3219010, 1, "b25e8978a94e4363855ca56734d665058c2f1dacfa5aa25016fc844ecb54f386") -- Fogpiercer
-- MAIN APP DEPOTS
addappid(3219012, 1, "784ebb50ee11128058b612078b1799f7d1e8ca4e310a877e023764d3b8c295aa") -- Depot 3219012
setManifestid(3219012, "2807699668939670579", 1388766800)
addappid(3219013, 1, "d314e58c68fd9f19958c0ab1a403711d13736c0b31bf6e8c5d5849cc895b2489") -- Depot 3219013
setManifestid(3219013, "396605698904625196", 1111223824)
addappid(3219014, 1, "994ab87da599801f3c2203808c823df4d160003152d02925668435eaa2cc6566") -- Depot 3219014
setManifestid(3219014, "6618147576809473608", 1247847382)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3219011) -- Depot 3219011 (empty depot)