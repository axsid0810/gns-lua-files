-- 3169520's Lua and Manifest Created by Hubcap Manifest
-- Warhammer 40,000: Space Marine - Master Crafted Edition
-- Created: October 01, 2025 at 13:30:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3169520) -- Warhammer 40,000: Space Marine - Master Crafted Edition
-- MAIN APP DEPOTS
addappid(3169521, 1, "9c327e47da8ad83eb864ec73bad3a78e2f7ff2844fd4cc6c3ed89e72725e9217") -- Depot 3169521
setManifestid(3169521, "2033765880680946954", 46823409641)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)