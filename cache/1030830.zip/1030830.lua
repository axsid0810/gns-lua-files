-- 1030830's Lua and Manifest Created by Hubcap Manifest
-- Mafia II: Definitive Edition
-- Created: July 24, 2026 at 08:20:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1030830, 1, "66e03a662a0c337dbdb51349f55fb773c592ad0db801ad39254af1cb6c603c18") -- Mafia II: Definitive Edition
-- MAIN APP DEPOTS
addappid(1030831, 1, "32530b6455aff62129bdca96b7eade4476d7d5aa76a6233563dca1ccad754475") -- RYE Content
setManifestid(1030831, "7075325167535131973", 47163510770)