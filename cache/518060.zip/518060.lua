-- 518060's Lua and Manifest Created by Hubcap Manifest
-- Chess Ultra
-- Created: September 29, 2025 at 03:54:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 13
-- Total DLCs: 10
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(518060) -- Chess Ultra
-- MAIN APP DEPOTS
addappid(518061, 1, "c6167664a8aef8b3f883170f6286025585a0a4aca24a3605a74b25ee0defa80b") -- Chess Ultra Content
setManifestid(518061, "2930919823492767506", 11180347947)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Chess Ultra Pantheon game pack (AppID: 638010)
addappid(638010)
addappid(638010, 1, "42b0e9c77c25411b7b7b4d38d1f52b43bd296711d5536504534c783d5a92f61c") -- Chess Ultra Pantheon game pack - Temple
setManifestid(638010, "7770352433031069514", 1080338477)
-- Chess Ultra Santa Monica game pack (AppID: 638011)
addappid(638011)
addappid(638011, 1, "740526a24d1f13c0c0c0239b9ad584230dd1dd7de2a0550e2c50011879c1d00d") -- Chess Ultra Santa Monica game pack - Beach
setManifestid(638011, "1505802112459631137", 928300147)
-- Chess Ultra Academy game pack (AppID: 638980)
addappid(638980)
addappid(638980, 1, "3d23ec491adc1e81b8c3c4303dd3e68c531408fe7e7f185b87af518c2cd249ba") -- Chess Ultra Academy game pack - Hall
setManifestid(638980, "1370360606941385064", 572543014)
-- Chess Ultra Isle of Lewis chess set (AppID: 638981)
addappid(638981)
addappid(638981, 1, "efbf480a6f62e9035cff9f22fa2b4645a07fd65608455b39b2cab3acdb148ec3") -- Chess Ultra Isle of Lewis chess set - Lewis
setManifestid(638981, "7134381003797481733", 448397959)
-- Chess Ultra Easter Island chess set (AppID: 639000)
addappid(639000)
addappid(639000, 1, "f7a6750047752c98ae059424edd8ae95d126d3acf724573e7c48ee2078407c13") -- Chess Ultra Easter Island chess set - Easter
setManifestid(639000, "3407736518161520380", 695975298)
-- Chess Ultra Imperial chess set (AppID: 639001)
addappid(639001)
addappid(639001, 1, "99d947a33a301a7bb5ff8554cc3ace9137afb0e4d862d7fc903c7a74487829cd") -- Chess Ultra Imperial chess set - Bling
setManifestid(639001, "1669463595677698811", 201532520)
-- Chess Ultra Purling London - Bold chess set (AppID: 813380)
addappid(813380)
addappid(813380, 1, "a6e41d360360e5a25f4475bb270896dfa56ab9df02573d4bc61caa134f2fc33b") -- Chess Ultra Purling London - Bold chess set - Purling
setManifestid(813380, "1807951215727655168", 178612095)
-- Chess Ultra Purling London - Mr. Jiver chess set (AppID: 816980)
addappid(816980)
addappid(816980, 1, "5015058b8ae7442aaf3a305928ab9454f4513b0ca034dc90ea6f50400b5f1914") -- Chess Ultra Purling London - Mr. Jiver chess set - Purling2
setManifestid(816980, "1366959027057368627", 211209506)
-- Chess Ultra Purling London - Nette Robinson chess set (AppID: 816981)
addappid(816981)
addappid(816981, 1, "13e8541aca7422582288568d91218bd6747a73fadb28091365a13428a403bcbe") -- Chess Ultra Purling London - Nette Robinson chess set - Purling3
setManifestid(816981, "8366881499539052536", 174570740)
-- Chess Ultra Purling London - Olivia Pilling chess set (AppID: 816982)
addappid(816982)
addappid(816982, 1, "c671df468744c9c3c0aaa555ba7af29448feb75c41915ddaba703d6ae941b9ca") -- Chess Ultra Purling London - Olivia Pilling chess set - Purling4
setManifestid(816982, "8536791212329236619", 193985178)