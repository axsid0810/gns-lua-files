-- 2131630's Lua and Manifest Created by Hubcap Manifest
-- METAL GEAR SOLID - Master Collection Version
-- Created: February 12, 2026 at 22:45:14 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 3
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(2131630) -- METAL GEAR SOLID - Master Collection Version
-- MAIN APP DEPOTS
addappid(2131633, 1, "b5534a1dc315beefb2031cfeda2b76f2602e42fcf1556dcd08b36ff166823513") -- Depot 2131633
setManifestid(2131633, "6062097622870190229", 11329670786)
addappid(2131631, 1, "5611f7eca8917daa3b4503c93aecc8ca3970b442be9d89b2b6e90ef16de6264b") -- Depot 2131631
setManifestid(2131631, "7339216024084706552", 7261218054)
addappid(2131632, 1, "06990dbaa532ef23fc9c5b67dd9f0183e01ad29486b0ed6b7000b5d7e529786e") -- Depot 2131632
setManifestid(2131632, "7713525600005167712", 5798272136)
-- SHARED DEPOTS (from other apps)
addappid(2314212, 1, "c2905c5640fde8855cb314b8a55650eb6625c631a1047fca98dff7a43125b691") -- Depot 2314212 (Shared from App 2314212)
setManifestid(2314212, "3092029632321159821", 7461415796)
addappid(2314210, 1, "e068c94228149aa99007649f734b768c4ab7a51d4513556df1cf33ee1c2a0126") -- Depot 2314210 (Shared from App 2314210)
setManifestid(2314210, "9135189822400605037", 3392963059)
addappid(2314211, 1, "db3ba13aeb08c580831ddae67b40c2e92853f73a5e8f88b8a196d1a9d0703959") -- Depot 2314211 (Shared from App 2314211)
setManifestid(2314211, "6106653665695138588", 1930017184)