-- 2827200's Lua and Manifest Created by Hubcap Manifest
-- MIMESIS
-- Created: June 25, 2026 at 08:27:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2827200, 1, "bd4b5a23168ddb944d4c0db74138a01da33e097e0872b086d4e66b6f4a0d5f6b") -- MIMESIS
-- MAIN APP DEPOTS
addappid(2827201, 1, "016eb6cc0350a518395d00970f93f8381c6ca25e40f75b822439a64d2b550d9f") -- Depot 2827201
setManifestid(2827201, "2718939710982784931", 3741263865)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)