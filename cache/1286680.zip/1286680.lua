-- 1286680's Lua and Manifest Created by Hubcap Manifest
-- Tiny Tina's Wonderlands
-- Created: October 01, 2025 at 01:58:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 8
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1286680) -- Tiny Tina's Wonderlands
-- MAIN APP DEPOTS
addappid(1286681, 1, "9fc3a420ac82d1a5db76b0eb7fb49dcb9beddd0843042254f712b3bec3975496") -- Depot 1286681
setManifestid(1286681, "1177491222246009560", 52245041381)
addappid(1286682, 1, "e8012a88d38526c88c0319f71dc6361fb9d774bd84985a7f128a2ede140f7bcd") -- Depot 1286682
setManifestid(1286682, "7148413644585661403", 115648224)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- PhysX System Software 9.14.0702 (Shared from App 228980)
setManifestid(229033, "2059065101492814639", 60039803)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1621030) -- Tiny Tinas Wonderlands Golden Hero Armor Pack
addtoken(1621030, "8239617618311782527")
addappid(1621031) -- Tiny Tinas Wonderlands Season Pass
addappid(1621032) -- Tiny Tinas Wonderlands Butt Stallion Pack
addtoken(1621032, "9120841886648182979")
addappid(1622260) -- Tiny Tinas Wonderlands Dragon Lord Pack
addtoken(1622260, "8656412379065430903")
addappid(1769530) -- Tiny Tinas Wonderlands Coiled Captors
addappid(1769531) -- Tiny Tinas Wonderlands Gluttons Gamble
addappid(1769532) -- Tiny Tinas Wonderlands Molten Mirrors
addappid(1769533) -- Tiny Tinas Wonderlands Shattering Spectreglass