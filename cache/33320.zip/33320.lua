-- 33320's Lua and Manifest Created by Hubcap Manifest
-- Prince of Persia: The Forgotten Sands
-- Created: July 02, 2026 at 05:24:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(33320, 1, "b41e60de07d40a04787e4159e3a62a3a5f43168de13534b439c6624c6cd319e7") -- Prince of Persia: The Forgotten Sands
-- MAIN APP DEPOTS
addappid(33322, 1, "f3ba72f4a9067c90953dde471bb8b48547fe609799f35ac14b23fd6d6b067086") -- prince of persia forgotten sands deluxe content
setManifestid(33322, "3521615088174605371", 343827072)
addappid(33321, 1, "ce398c4390cf88380278389c8cf0354b7e63b1f268a78acdf79f293ed1098a5e") -- prince of persia forgotten sands content
setManifestid(33321, "3081572943546153599", 6682220119)
-- SHARED DEPOTS (from other apps)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "8936186649444731600", 264933784)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(33325) -- Prince of Persia The Forgotten Sands - Deluxe CD Key
addappid(33326) -- Prince of Persia The Forgotten Sands - Standard CD Key