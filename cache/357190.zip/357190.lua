-- 357190's Lua and Manifest Created by Hubcap Manifest
-- Ultimate Marvel vs. Capcom 3
-- Created: June 17, 2026 at 04:04:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(357190, 1, "97b2d3cc9da0f8851f848372d620a023fd2ea96d856f5e83e83153119c87941c") -- Ultimate Marvel vs. Capcom 3
-- MAIN APP DEPOTS
addappid(357191, 1, "c855d2a2a022b2f35add948a015356e8fe3c3802195b5507e2bedc3acab1c6bb") -- umvc3
setManifestid(357191, "7549865494669531118", 3783602430)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)