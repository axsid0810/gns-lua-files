-- 2238900's Lua and Manifest Created by Hubcap Manifest
-- STAR OCEAN THE SECOND STORY R
-- Created: November 10, 2025 at 03:40:48 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 4
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2238900) -- STAR OCEAN THE SECOND STORY R
-- MAIN APP DEPOTS
addappid(2238901, 1, "67cb73b183e7b5251669ae7065e69ae7e541ae57d56e19105e12323adcc2f42e") -- Depot 2238901
setManifestid(2238901, "2326349097900874324", 18412630476)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2428850) -- STAR OCEAN THE SECOND STORY R - Pangalactic Federation Longsword
addappid(2428851) -- STAR OCEAN THE SECOND STORY R - Forest Knuckles
addappid(2428852) -- STAR OCEAN THE SECOND STORY R - Set of recovery items
addappid(2428853) -- STAR OCEAN THE SECOND STORY R - Sunrise Ring