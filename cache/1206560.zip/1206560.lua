-- 1206560's Lua and Manifest Created by Hubcap Manifest
-- WorldBox - God Simulator
-- Created: October 01, 2025 at 08:08:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1206560, 1, "bc4a616c22736f244adab2bf84e39ac6a3b332aee5024f19644e363dda04739e") -- WorldBox - God Simulator
-- MAIN APP DEPOTS
addappid(1206561, 1, "cba01e9f6c75a6b26fe978e7179476176b3a191358379fcd3727d4fdaef5d2b6") -- WB Windows
setManifestid(1206561, "275499322938599766", 717871121)
addappid(1206562, 1, "2acab5beee720ed79f9dd82af12b58b6f26da5a338108137bb3fc3a9ebb9e2d1") -- WB Linux
setManifestid(1206562, "8253564855964330400", 813355412)
addappid(1206563, 1, "a8274d9f4b7eb9fef72ff6c6f15ab8913f473de3e6dee34f77c85a0134884bc1") -- WB macOS
setManifestid(1206563, "2328332092819105166", 876702219)