-- 366260's Lua and Manifest Created by Hubcap Manifest
-- METAL SLUG 2
-- Created: September 30, 2025 at 00:29:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(366260) -- METAL SLUG 2
-- MAIN APP DEPOTS
addappid(366261, 1, "69b8102179125157d9dcb8e8877acff2c4b338ea684fe60fae1d6039c800dbb6") -- METAL SLUG 2 Content
setManifestid(366261, "1979623860533635830", 97347256)