-- 1101190's Lua and Manifest Created by Hubcap Manifest
-- Dungeon Defenders: Awakened
-- Created: July 20, 2026 at 02:43:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 8
-- Shared Depots: 7

-- MAIN APPLICATION
addappid(1101190, 1, "76b2616edf69eab3b778e3d7e80871c6d843c9d3a9dc11281db2560107573d7d") -- Dungeon Defenders: Awakened
-- MAIN APP DEPOTS
addappid(1101191, 1, "6a43114e90d71b1716d5395bd8413a6239add746332f4fc11290d8c4d1e80b0c") -- Dungeon Defenders Awakened Content
setManifestid(1101191, "5522950726507553846", 14400407460)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- PhysX System Software 9.14.0702 (Shared from App 228980)
setManifestid(229033, "2059065101492814639", 60039803)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1668430) -- Dungeon Defenders Awakened - Gator Gear
addappid(1692610) -- Dungeon Defenders Awakened - Original Hero Paper Masks
addappid(1703400) -- Dungeon Defenders Awakened - Chromatic Costumes
addappid(1847620) -- Dungeon Defenders Awakened - Winter Defenderland
addappid(2253000) -- Dungeon Defenders Awakened - Yuletide Defender
addappid(2331670) -- Dungeon Defenders Awakened - Galaxy Costumes
addappid(2396790) -- Dungeon Defenders Awakened - Egyptian Costumes
addappid(4611330) -- Dungeon Defenders Awakened - Crystal Core Relics Unsealed