-- 1830630's Lua and Manifest Created by Hubcap Manifest
-- Overpass 2
-- Created: September 30, 2025 at 05:28:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 3
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1830630) -- Overpass 2
-- MAIN APP DEPOTS
addappid(1830631, 1, "bcdd613d7c66aee792689b500e53e07d58c7d49a49f1d5bbf858fb6bde8f9ff6") -- Depot 1830631
setManifestid(1830631, "1275872209052593167", 17382637666)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2432400) -- Overpass 2 - Polaris Vehicles Pack
addappid(2432401) -- Overpass 2 - Career Starter Pack
addappid(2461590) -- Overpass 2 - Ford Play Rock Bouncer