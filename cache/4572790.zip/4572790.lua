-- 4572790's Lua and Manifest Created by Hubcap Manifest
-- Suika Game
-- Created: July 26, 2026 at 13:01:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4572790) -- Suika Game
-- MAIN APP DEPOTS
addappid(4572791, 1, "aec04c234f0ebf85820bce8c31368b7a619dc4a1f74d138b511a8176b07a9ce2") -- Depot 4572791
setManifestid(4572791, "220385141695401478", 1331739742)