-- 3538250's Lua and Manifest Created by Hubcap Manifest
-- The Book of Plagues
-- Created: July 19, 2026 at 11:37:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3538250) -- The Book of Plagues
-- MAIN APP DEPOTS
addappid(3538251, 1, "422a4c42f706cc3d307f02746f943197dbba3167aa4eb5634a043b746c3009ca") -- Depot 3538251
setManifestid(3538251, "3696613739493136096", 414248834)