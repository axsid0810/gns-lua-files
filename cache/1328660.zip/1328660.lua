-- 1328660's Lua and Manifest Created by Hubcap Manifest
-- Need for Speed™ Hot Pursuit Remastered
-- Created: July 23, 2026 at 18:26:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 14
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1328660, 1, "7b8cbfbeace5ba7f9c8d8b58633dca7fda899e253c80a71c291d3068efbb086b") -- Need for Speed™ Hot Pursuit Remastered
-- MAIN APP DEPOTS
addappid(1328661, 1, "352894f27be6a4ac21ac6f2ee821bb07e969fbff77460f1d75958c2a03c1e097") -- Need For Speed Hot Pursuit Remastered - Content
setManifestid(1328661, "1795149217869958414", 37367486265)
addappid(1328662, 1, "bf55ab0596078c7dbcf3d210aaa944f07443b0dd087919e19255cd0d74c555eb") -- Need For Speed Hot Pursuit Remastered - en_US
setManifestid(1328662, "5399930349333788374", 107889)
addappid(1328663, 1, "dd17dee6e6adca063fac5d7dd7b8887ff045615dc291f43e60c66f2d784f1ede") -- Need For Speed Hot Pursuit Remastered - fr_FR
setManifestid(1328663, "5564295092168545973", 115275)
addappid(1328664, 1, "ff60f9f857207404386c355fd8ef3c3ded3ff4f8d02d2116491e653b42792f25") -- Need For Speed Hot Pursuit Remastered - de_DE
setManifestid(1328664, "1857053761179923453", 105370)
addappid(1328665, 1, "d301691944dcc891ff06689ce7be7f1c814012bff19a4d468a5d21aa36e37d13") -- Need For Speed Hot Pursuit Remastered - it_IT
setManifestid(1328665, "5051859565786030120", 110868)
addappid(1328666, 1, "940d6904a17d7e6cc2b11a6ec2081114ecfec5b231cdf215a414468b748aca83") -- Need For Speed Hot Pursuit Remastered - es_ES
setManifestid(1328666, "5576382549429743094", 263)
addappid(1328667, 1, "8984a118acd7ad88e8e4e8c6d5f34456328e3ad4cd44d96453f769ec49969a8c") -- Need For Speed Hot Pursuit Remastered - ja_JP
setManifestid(1328667, "3510907265985237962", 193212)
addappid(1328668, 1, "5551b293541f6c2ce9d514d303467fab8fd1a85d2791685b9dd77fc8c024d38a") -- Need For Speed Hot Pursuit Remastered - ru_RU
setManifestid(1328668, "5362433048273529538", 263)
addappid(1328669, 1, "fd8ffe56602361f32878ffbf6fed8180cf148d17f0b78adb6856759a94f7b3ba") -- Need For Speed Hot Pursuit Remastered - pl_PL
setManifestid(1328669, "7276448625923999031", 263)
addappid(1378951, 1, "397141eca6997832db1ad1b4aee57661d380f51e95934aa7f22c9e1f3736347b") -- Need For Speed Hot Pursuit Remastered - nl_NL
setManifestid(1378951, "2104016530536753344", 108667)
addappid(1378952, 1, "88dcd0c470ccf3fea446b2985a175204aa6e6655aacec31000e023828efc9c75") -- Need For Speed Hot Pursuit Remastered - zh_TW
setManifestid(1378952, "975490320310877421", 162268)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
setManifestid(3340991, "6717304605949129056", 240979991)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1378950) -- Need for Speed Hot Pursuit Remastered - Key
addtoken(1378950, "11381758596347542120")