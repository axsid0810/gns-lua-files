-- 3914860's Lua and Manifest Created by Hubcap Manifest
-- Moss: The Forgotten Relic
-- Created: July 24, 2026 at 19:04:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3914860) -- Moss: The Forgotten Relic
-- MAIN APP DEPOTS
addappid(3914861, 1, "ee3869a7b86bd4d780a45ca23577849e3c1931b9262f30174950d52c630927d2") -- Depot 3914861
setManifestid(3914861, "1185623109829346848", 12185159784)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)