-- 1468720's Lua and Manifest Created by Hubcap Manifest
-- Ultimate Epic Battle Simulator 2
-- Created: October 01, 2025 at 04:30:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1468720, 1, "e3d692fff3d469ed527f9f3075cee042c0159185255f3c1635c1bc052872ba03") -- Ultimate Epic Battle Simulator 2
-- MAIN APP DEPOTS
addappid(1468721, 1, "c0d10ec1395dc0ba8f71593641ac527d1770463e9788a1f0e4a2b27f14dda7f6") -- Depot 1468721
setManifestid(1468721, "4718792453129053613", 41457501817)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)