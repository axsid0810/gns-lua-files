-- 4451830's Lua and Manifest Created by Hubcap Manifest
-- 황구 키우기
-- Created: July 23, 2026 at 16:29:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4451830) -- 황구 키우기
-- MAIN APP DEPOTS
addappid(4451831, 1, "0f7226b1be1dc8e37e1e53c02aa6ec62ad513b8e7a3e945450ec98fa7a32d3d2") -- Depot 4451831
setManifestid(4451831, "3007039930414540778", 357245424)