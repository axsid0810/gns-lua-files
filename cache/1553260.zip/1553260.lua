-- 1553260's Lua and Manifest Created by Hubcap Manifest
-- Scarlet Deer Inn
-- Created: July 28, 2026 at 10:57:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1553260, 1, "b0699b8875a94dd5f0518569b629c0dc8b969252727a4251e2f39374928a6822") -- Scarlet Deer Inn
-- MAIN APP DEPOTS
addappid(1553261, 1, "f77870e3cd6bcbc1807373a9949d308ea1e4d11e9f66addb37f4575b343ad4b8") -- Depot 1553261
setManifestid(1553261, "7888066782255629213", 4286430661)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1553262) -- Depot 1553262 (empty depot)