-- 212680's Lua and Manifest Created by Hubcap Manifest
-- FTL: Faster Than Light
-- Created: September 29, 2025 at 13:37:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(212680) -- FTL: Faster Than Light
-- MAIN APP DEPOTS
addappid(212681, 1, "1d2c7c92ca9160c354942c3046435ebbc754d38a3c21c2f381f5811fbcdbd983") -- FTL Faster Than Light Content
setManifestid(212681, "7129506338464639292", 286586003)
addappid(212682, 1, "a1bee0011fce8ad5500a891dd24de5637061b3d22fc0b52b08ae84c29d68b1cf") -- Depot 212682
setManifestid(212682, "7312309456845465813", 284228511)
addappid(221001, 1, "45274bfd49c3b586f89ab2ea236455b4479d781bf2a869c7e1b4add2766c5798") -- 
setManifestid(221001, "5441929488168425361", 242028760)
addappid(221002, 1, "14070786d2a9c15a8f02de492517a8d629a7b06858e59a7875d06e8834afdc33") -- Linux Depot
setManifestid(221002, "3440314484012853994", 413405254)
addappid(221003, 1, "0df28650bad61991577ff2885d26e1cb3fae79ed1bd75156fd5a3950ea5fbf6f") -- Depot 221003
setManifestid(221003, "3757286283369338501", 13)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(221000) -- FTL Faster than Light DLC Range