-- 1604030's Lua and Manifest Created by Hubcap Manifest
-- V Rising
-- Created: June 02, 2026 at 10:59:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 7
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1604030, 1, "56c40ea98866f38fd5632717e524396c74c9764a7daeaf525d71ba5539e1bd0a") -- V Rising
-- MAIN APP DEPOTS
addappid(1604031, 1, "e51d4f407e118a5477cab33cf9cd3340057f5aa111772951f47d76b05b594606") -- Depot 1604031
setManifestid(1604031, "2621767958913415677", 9909193555)
addappid(1604032, 1, "05dc87d45e23f53bfdc06512480bf3a8d84941a929034772fba892bf252d9587") -- Depot 1604032
setManifestid(1604032, "8225175356744277948", 8855690009)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1983900) -- V Rising - Draculas Relics Pack
addappid(1983901) -- V Rising - Founders Pack Eldest Bloodline
addappid(1997210) -- V Rising - Razer Night Serpent Pack
addtoken(1997210, "15813987473860297923")
addappid(2169180) -- V Rising - Haunted Nights Castle Pack
addappid(2358430) -- V Rising - Sinister Evolution Pack
addappid(2833600) -- V Rising - Legacy of Castlevania Premium Pack
addappid(3604340) -- V Rising - Eternal Dominance Pack