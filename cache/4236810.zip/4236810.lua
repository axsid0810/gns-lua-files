-- 4236810's Lua and Manifest Created by Hubcap Manifest
-- Halu - The Fish
-- Created: July 25, 2026 at 09:15:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4236810) -- Halu - The Fish
-- MAIN APP DEPOTS
addappid(4236811, 1, "0b298a191db916026f165e26e7146ce262846dbdd19b4b28fcbb848de7218cbe") -- Depot 4236811
setManifestid(4236811, "6325245749943911925", 2353397232)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)