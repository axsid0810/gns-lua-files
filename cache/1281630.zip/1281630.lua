-- 1281630's Lua and Manifest Created by Hubcap Manifest
-- Anno 1404 - History Edition
-- Created: July 05, 2026 at 15:03:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 10
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1281630, 1, "db3274501bdb832ae74344fb47671befb71d13b157c33044202b28d9793b6390") -- Anno 1404 - History Edition
-- MAIN APP DEPOTS
addappid(1281631, 1, "9f805805e6e5a894dcc2c78170ca6fc1fe819816e6af05c4e7103266b9b5699f") -- Anno 1404 - History Edition Content
setManifestid(1281631, "8839328866469126381", 3826417924)
addappid(1281632, 1, "82a1b7266410c551e3a620c847fb634b920b0e5125459441c047740cf81a8204") -- Anno 1404 - History Edition German
setManifestid(1281632, "4055106327396643371", 535218786)
addappid(1281633, 1, "a7d68cbf9408d7f43eb9d3aa7a0de2845d73662f1f45c5dea8c00ee608285936") -- Anno 1404 - History Edition French
setManifestid(1281633, "5775984646690616804", 541497596)
addappid(1281634, 1, "3c4aa66e83e0c73f5803ac18094bd9aea7711fa9ded6c838f8639e012343ad19") -- Anno 1404 - History Edition Spanish
setManifestid(1281634, "7523445510786285690", 528875919)
addappid(1281635, 1, "b3c1dfebe10067b81bbba2c991ab3d396e22a453d7200cf6e35979ff7497d8f8") -- Anno 1404 - History Edition Italian
setManifestid(1281635, "7889097616143283726", 580535073)
addappid(1281636, 1, "916e2c905f2de71eeed6ac5709a5bd3f63a21f2fcef81381b91231726cb01994") -- Anno 1404 - History Edition Russian
setManifestid(1281636, "2941858388966158261", 563645802)
addappid(1281637, 1, "952dec50ed321aaf424a26ab6b163c4879ba984b35fe251312b31aecf8368476") -- Anno 1404 - History Edition Polish
setManifestid(1281637, "4223197148381860556", 571206604)
addappid(1281638, 1, "00c2a223da7842fcd778a02d4c59ac3f6076f2d37dee6d4ef721d233b98988fc") -- Anno 1404 - History Edition Czech
setManifestid(1281638, "8267469590916821993", 573009625)
addappid(1281639, 1, "38aca21e13f6109800733ba9069881a7db5bdea3f9bc52990a034010772cfec1") -- Anno 1404 - History Edition Bonus Content
setManifestid(1281639, "6175931598011393314", 76889811)
-- SHARED DEPOTS (from other apps)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "8936186649444731600", 264933784)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1321790) -- Anno 1404 - History Edition - Uplay Activation
addtoken(1321790, "10686110836563317566")