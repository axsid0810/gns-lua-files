-- 2634890's Lua and Manifest Created by Hubcap Manifest
-- MARVEL vs. CAPCOM Fighting Collection: Arcade Classics
-- Created: September 29, 2025 at 23:49:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2634890) -- MARVEL vs. CAPCOM Fighting Collection: Arcade Classics
-- MAIN APP DEPOTS
addappid(2634891, 1, "4c7a817aabbebeea28ec8bb1971e5e91a388c7b617485eb2cf399d782c4124eb") -- Depot 2634891
setManifestid(2634891, "5391351782055600685", 3618702772)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)