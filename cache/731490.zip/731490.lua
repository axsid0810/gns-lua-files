-- 731490's Lua and Manifest Created by Hubcap Manifest
-- Crash Bandicoot™ N. Sane Trilogy
-- Created: September 29, 2025 at 05:29:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(731490) -- Crash Bandicoot™ N. Sane Trilogy
-- MAIN APP DEPOTS
addappid(731491, 1, "66bc6c9ffa8740c78dfc58ecf2a422883a6a3a30031fe52641f0060903610ab8") -- Binaries
setManifestid(731491, "7366270915149281636", 29922392)
addappid(731492, 1, "ca39fb3667416ca9ec3ac95ecb8fdfe1a11fc5bb2e9c2a429be87eb476df46d1") -- Content
setManifestid(731492, "6184157323779267805", 31171821699)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)