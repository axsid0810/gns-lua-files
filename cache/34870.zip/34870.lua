-- 34870's Lua and Manifest Created by Hubcap Manifest
-- Sniper Ghost Warrior 2
-- Created: September 30, 2025 at 17:59:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 19
-- Total DLCs: 8
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(34870) -- Sniper Ghost Warrior 2
-- MAIN APP DEPOTS
addappid(34871, 1, "e731ebfc5c430be534a670d72b6fc77a44230bfea937b3f03b3ff2488bcd1f47") -- Sniper Ghost Warrior 2 Content
setManifestid(34871, "2499303160946976315", 6377231805)
addappid(34872, 1, "b800c1e9a21b8566318c4b1364835262cb0befb68a010da2e4608cfe8217158f") -- Sniper Ghost Warrior 2 English
setManifestid(34872, "5562038627156527607", 1805604)
addappid(34873, 1, "c90a03e7e97731f347fa7367f808a1f0c77f558b31846baa5b60bebc7a327fff") -- Sniper Ghost Warrior 2 Polish
setManifestid(34873, "7408200566272385341", 1835871)
addappid(34874, 1, "b3a1f3472252c4d44af9b78a4fdb030ad83c36aa593edd1fe5d612c00affa49f") -- Sniper Ghost Warrior 2 German
setManifestid(34874, "5650681716907950008", 432537166)
addappid(34875, 1, "41f46637747218a4ecfe4d24e08da9e21bb4db20574005f75bee571dc977fd96") -- Sniper Ghost Warrior 2 Spanish
setManifestid(34875, "6776562095319901656", 1846627)
addappid(34876, 1, "4bd769ae1418307aa1257ff411c2e00597a9bc4ca4f94707791ef6eb46f97533") -- Sniper Ghost Warrior 2 Russian
setManifestid(34876, "573273591914316648", 472874154)
addappid(34877, 1, "6dc24c358517bfa36cbe8e3721a31a4a251e96443202681a52f7442ba254647e") -- Sniper Ghost Warrior 2 Japanese
setManifestid(34877, "2642969923384583673", 2027977)
addappid(34878, 1, "05c0d909107bfc32b2ee33fd87ac01f91a9c80a7c04fa67330aa179edbc98f69") -- Sniper Ghost Warrior 2 Italian
setManifestid(34878, "3150700440195344419", 1828715)
addappid(34879, 1, "a28b78e0058d77ed7c0e31ff9ae85b9d54755c5280c8a2994ad012b39eea80f9") -- Sniper Ghost Warrior 2 French
setManifestid(34879, "5996972809753086753", 418880701)
addappid(231871, 1, "b88ac15928ac3aaa8fb0d72472bd0cea0795aff0cacd75135f66c5ff9b52ba9c") -- Sniper Ghost Warrior 2 Czech
setManifestid(231871, "854055681513706858", 1630051)
addappid(231873, 1, "508f4934a664eb08ea622e848a81231481daebdaa14f0c313ca619b03fca2d2d") -- SGW2 China
setManifestid(231873, "8068792794781059861", 6585574163)
addappid(231874, 1, "6f6b273b08d759f44204a8ecf46726dbf13355f54a8fc92881c8f42894239ec9") -- Sniper Ghost Warrior 2 Korean
setManifestid(231874, "4721129114766831499", 9813052)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Sniper Ghost Warrior 2 Siberian Strike (AppID: 232634)
addappid(232634)
addappid(232634, 1, "2e894d88739bd0880e5228d4e30a336123cad4e1e0c967bdcd4f2dcc93068d8b") -- Sniper Ghost Warrior 2 Siberian Strike - Sniper Ghost Warrior 2: Siberian Strike
setManifestid(232634, "3586914899907292941", 1666513877)
-- Sniper Ghost Warrior 2 Multiplayer Expansion Pack (AppID: 232644)
addappid(232644)
addappid(232644, 1, "be4c023d306c16afdd4276d20e7bf576e2c7070b89355861e5ef250be23edec0") -- Sniper Ghost Warrior 2 Multiplayer Expansion Pack - Sniper Ghost Warrior 2: Multiplayer Expansion Pack
setManifestid(232644, "4054226459307968258", 137395332)
-- Sniper Ghost Warrior 2 Soundtrack (AppID: 232646)
addappid(232646)
addappid(232646, 1, "b8d550e21c10f84d2fcacd1bbbd21c0f88401bff24b0f989f9ca5f24367f2ea1") -- Sniper Ghost Warrior 2 Soundtrack - Sniper Ghost Warrior 2: Soundtrack
setManifestid(232646, "4799229057766057480", 449936865)
-- Sniper Ghost Warrior 2 World Hunter Pack (AppID: 232647)
addappid(232647)
addappid(232647, 1, "b213d3b91a342e1910912177fc1915c707dc1f39ac1aef9f0c3e6f4e8f127488") -- Sniper Ghost Warrior 2 World Hunter Pack - Sniper Ghost Warrior 2: World Hunter Pack
setManifestid(232647, "736095319478678593", 182099053)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(217940) -- Sniper Ghost Warrior 2 Promo DLC
addappid(217941) -- Sniper Ghost Warrior 2 Digital Extras
addappid(217942) -- Sniper Ghost Warrior 2 M14 Gun DLC 
addappid(232640) -- Sniper Ghost Warrior 2 Limited Pack 1