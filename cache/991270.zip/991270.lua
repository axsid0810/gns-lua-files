-- 991270's Lua and Manifest Created by Hubcap Manifest
-- The Legend of Heroes: Trails of Cold Steel III
-- Created: April 05, 2026 at 09:38:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 87
-- Total DLCs: 79
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(991270, 1, "8c0d19ea6a9b99f9a1701d93e1956e8a0ca0c19e1acdce42e48149645de1a824") -- The Legend of Heroes: Trails of Cold Steel III
-- MAIN APP DEPOTS
addappid(991271, 1, "530e6974f3f10c1262b0cbf97f11e6b233cf940e855ab7b19147c6ebdcca1dfb") -- The Legend of Heroes: Trails of Cold Steel III Content
setManifestid(991271, "3631129077322616883", 22248171805)
addappid(1261710, 1, "7ff5358a5302c45d2772500ab3d272cab7c9cd41b3ee2409dc6d73a3e4c914d5") -- The Legend of Heroes: Trails of Cold Steel III  - Branch Campus Student Directory Digital Mini Art Book (1261710) Depot
setManifestid(1261710, "350179170716147002", 20233948)
addappid(1255960, 1, "34d05996cbdce90ee1d1ee16d8f8233850d2e224d67c4af97bbbe1a87324e737") -- The Legend of Heroes: Trails of Cold Steel III  - Anthems of the Thors Branch Campus Digital Soundtrack Sampler (1255960) Depot
setManifestid(1255960, "3772717746507831333", 187231570)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
-- DLCS WITH DEDICATED DEPOTS
-- The Legend of Heroes Trails of Cold Steel III  - Angel Set (AppID: 1261690)
addappid(1261690)
addappid(1261690, 1, "7cfc36d910167b07d4abf20a7597568a077723fe34f9b7c349e94314eaf660cf") -- The Legend of Heroes Trails of Cold Steel III  - Angel Set - The Legend of Heroes: Trails of Cold Steel III  - Angel Set (1261690) Depot
setManifestid(1261690, "1680379035653519140", 11997036)
-- The Legend of Heroes Trails of Cold Steel III  - Advanced Medicine Set 1 (AppID: 1261691)
addappid(1261691)
addappid(1261691, 1, "d504325c2f92af757b97eef65fe5ca3b90e94a1a33a1668d96c0d005444c336b") -- The Legend of Heroes Trails of Cold Steel III  - Advanced Medicine Set 1 - The Legend of Heroes: Trails of Cold Steel III  - Advanced Medicine Set 1 (1261691) Depot
setManifestid(1261691, "5570870855461323289", 579)
-- The Legend of Heroes Trails of Cold Steel III  - Altinas Kitty Noir Costume (AppID: 1261692)
addappid(1261692)
addappid(1261692, 1, "6e44d2a6dbe5df908bb171b3cf7d0ca9db883067cba41e35f62b00abcda0f768") -- The Legend of Heroes Trails of Cold Steel III  - Altinas Kitty Noir Costume - The Legend of Heroes: Trails of Cold Steel III  - Altina's "Kitty Noir" Costume (1261692) Depot
setManifestid(1261692, "9013201715614283277", 18322471)
-- The Legend of Heroes Trails of Cold Steel III  - Advanced Medicine Set 2 (AppID: 1261693)
addappid(1261693)
addappid(1261693, 1, "e64bd79a320dc6c492c0f0ee84a4f45e370b8dccb9bfaf1b6773861bcbb9bed4") -- The Legend of Heroes Trails of Cold Steel III  - Advanced Medicine Set 2 - The Legend of Heroes: Trails of Cold Steel III  - Advanced Medicine Set 2 (1261693) Depot
setManifestid(1261693, "4860998100823508266", 579)
-- The Legend of Heroes Trails of Cold Steel III  - Free Sample Set A (AppID: 1261713)
addappid(1261713)
addappid(1261713, 1, "febd2b8c3b5895615bc5bae67b0d1c82856c43310ce6471fcb349e21ba203274") -- The Legend of Heroes Trails of Cold Steel III  - Free Sample Set A - The Legend of Heroes: Trails of Cold Steel III  - Free Sample Set A (1261713) Depot
setManifestid(1261713, "4371517345237621647", 595)
-- The Legend of Heroes Trails of Cold Steel III  - Free Sample Set B (AppID: 1261714)
addappid(1261714)
addappid(1261714, 1, "ef921adf0a541d4c617ad1c5dd84a7f1f2d0f34445232a0cf7c9dcede640165a") -- The Legend of Heroes Trails of Cold Steel III  - Free Sample Set B - The Legend of Heroes: Trails of Cold Steel III  - Free Sample Set B (1261714) Depot
setManifestid(1261714, "7466304154306911710", 528)
-- The Legend of Heroes Trails of Cold Steel III  - Faculty Swimsuit Set (AppID: 1261715)
addappid(1261715)
addappid(1261715, 1, "97d55caea432322d1b1d7b91159ab40b500cd7d2b8d03af2a297d9be39f54d84") -- The Legend of Heroes Trails of Cold Steel III  - Faculty Swimsuit Set - The Legend of Heroes: Trails of Cold Steel III  - Faculty Swimsuit Set (1261715) Depot
setManifestid(1261715, "6138237455957378782", 41603751)
-- The Legend of Heroes Trails of Cold Steel III  - Junas Lloyd Bannings Costume (AppID: 1261716)
addappid(1261716)
addappid(1261716, 1, "d3975e2996d531e76bbe6fff509bd555775c9b567a3229ef0d7590808ae1f5de") -- The Legend of Heroes Trails of Cold Steel III  - Junas Lloyd Bannings Costume - The Legend of Heroes: Trails of Cold Steel III  - Juna's "Lloyd Bannings" Costume (1261716) Depot
setManifestid(1261716, "1561889391648904998", 17199448)
-- The Legend of Heroes Trails of Cold Steel III  - Reans Unspeakable Costume (AppID: 1261717)
addappid(1261717)
addappid(1261717, 1, "bb977cb8c2fdb695a769b5bcecc98e25a69760819523c7712c58c6307fd1b195") -- The Legend of Heroes Trails of Cold Steel III  - Reans Unspeakable Costume - The Legend of Heroes: Trails of Cold Steel III  - Rean's "Unspeakable" Costume (1261717) Depot
setManifestid(1261717, "1843350724213862464", 21300437)
-- The Legend of Heroes Trails of Cold Steel III  - Advanced Medicine Set 3 (AppID: 1262340)
addappid(1262340)
addappid(1262340, 1, "1ae7a6df7d531ce2413b4930779a23979b72b570c9ada3bbc9eb002841d2720e") -- The Legend of Heroes Trails of Cold Steel III  - Advanced Medicine Set 3 - The Legend of Heroes: Trails of Cold Steel III  - Advanced Medicine Set 3 (1262340) Depot
setManifestid(1262340, "6621936894242992220", 579)
-- The Legend of Heroes Trails of Cold Steel III  - Dragon Incense Set 1 (AppID: 1262341)
addappid(1262341)
addappid(1262341, 1, "7f8abd4f2ed8748ce0d0bd9871af0ab82d6af615a1a8fda91a7dad0fcb40ea36") -- The Legend of Heroes Trails of Cold Steel III  - Dragon Incense Set 1 - The Legend of Heroes: Trails of Cold Steel III  - Dragon Incense Set 1 (1262341) Depot
setManifestid(1262341, "6392043976060299140", 571)
-- The Legend of Heroes Trails of Cold Steel III  - Dragon Incense Set 2 (AppID: 1262342)
addappid(1262342)
addappid(1262342, 1, "433abf137d95ea4dd62544065eb265c83313be5e0930613fdd0d1a277285390e") -- The Legend of Heroes Trails of Cold Steel III  - Dragon Incense Set 2 - The Legend of Heroes: Trails of Cold Steel III  - Dragon Incense Set 2 (1262342) Depot
setManifestid(1262342, "9134893027033677174", 581)
-- The Legend of Heroes Trails of Cold Steel III  - Droplet Set 1 (AppID: 1262343)
addappid(1262343)
addappid(1262343, 1, "9559bed23001dbc60a1193ce2e68484dee10aaf0b83d14e8ec329c9c23554645") -- The Legend of Heroes Trails of Cold Steel III  - Droplet Set 1 - The Legend of Heroes: Trails of Cold Steel III  - Droplet Set 1 (1262343) Depot
setManifestid(1262343, "297891257461490524", 518)
-- The Legend of Heroes Trails of Cold Steel III  - Droplet Set 2 (AppID: 1262344)
addappid(1262344)
addappid(1262344, 1, "02e9763e7ee9cc71391806b5c04b475b457ca43f01ed6f4b7d6c12f0eac0e8cf") -- The Legend of Heroes Trails of Cold Steel III  - Droplet Set 2 - The Legend of Heroes: Trails of Cold Steel III  - Droplet Set 2 (1262344) Depot
setManifestid(1262344, "542092081717260922", 518)
-- The Legend of Heroes Trails of Cold Steel III  - Droplet Set 3 (AppID: 1262345)
addappid(1262345)
addappid(1262345, 1, "d71b9c883ea5640dff24e82d9a856b986c96095ade97f72a05266feec0056568") -- The Legend of Heroes Trails of Cold Steel III  - Droplet Set 3 - The Legend of Heroes: Trails of Cold Steel III  - Droplet Set 3 (1262345) Depot
setManifestid(1262345, "6678231824188613534", 518)
-- The Legend of Heroes Trails of Cold Steel III  - Droplet Set 4 (AppID: 1262346)
addappid(1262346)
addappid(1262346, 1, "7746eb098f2a9d1c3ba891fe1b219dcbcfdee0cec6c81d9f266b48f78379e8bf") -- The Legend of Heroes Trails of Cold Steel III  - Droplet Set 4 - The Legend of Heroes: Trails of Cold Steel III  - Droplet Set 4 (1262346) Depot
setManifestid(1262346, "6540748707136416530", 518)
-- The Legend of Heroes Trails of Cold Steel III  - Droplet Set 5 (AppID: 1262347)
addappid(1262347)
addappid(1262347, 1, "6da9e3ef7d413cd661be6bffb8da90d8edf803ea5107c24f30bff44928ed28d8") -- The Legend of Heroes Trails of Cold Steel III  - Droplet Set 5 - The Legend of Heroes: Trails of Cold Steel III  - Droplet Set 5 (1262347) Depot
setManifestid(1262347, "7877055177026210818", 518)
-- The Legend of Heroes Trails of Cold Steel III  - Monster Ingredients Set 1 (AppID: 1262348)
addappid(1262348)
addappid(1262348, 1, "3151e90ec7317c79189d6ac00d97e836cc246914143dda449c4b12ba9cec53b5") -- The Legend of Heroes Trails of Cold Steel III  - Monster Ingredients Set 1 - The Legend of Heroes: Trails of Cold Steel III  - Monster Ingredients Set 1 (1262348) Depot
setManifestid(1262348, "4317376008089604387", 577)
-- The Legend of Heroes Trails of Cold Steel III  - Monster Ingredients Set 2 (AppID: 1262349)
addappid(1262349)
addappid(1262349, 1, "cd3b0cf8b54aa41ec72b2965134e1561ad9e31ba8fcb604fcc3cd8660711640f") -- The Legend of Heroes Trails of Cold Steel III  - Monster Ingredients Set 2 - The Legend of Heroes: Trails of Cold Steel III  - Monster Ingredients Set 2 (1262349) Depot
setManifestid(1262349, "1203965579172096895", 577)
-- The Legend of Heroes Trails of Cold Steel III  - Monster Ingredients Set 3 (AppID: 1262370)
addappid(1262370)
addappid(1262370, 1, "d4f9c5f1aea15ad32c2fa43acee11f9a021bdb2ab77a28f33ad1d20fcbd2039c") -- The Legend of Heroes Trails of Cold Steel III  - Monster Ingredients Set 3 - The Legend of Heroes: Trails of Cold Steel III  - Monster Ingredients Set 3 (1262370) Depot
setManifestid(1262370, "3900051920911880111", 577)
-- The Legend of Heroes Trails of Cold Steel III  - Sepith Set 1 (AppID: 1262371)
addappid(1262371)
addappid(1262371, 1, "155f3305d8665cdfbadd61c5504535211fe8008ce46db1c8b63ae16087dcc56c") -- The Legend of Heroes Trails of Cold Steel III  - Sepith Set 1 - The Legend of Heroes: Trails of Cold Steel III  - Sepith Set 1 (1262371) Depot
setManifestid(1262371, "1064102260769233279", 518)
-- The Legend of Heroes Trails of Cold Steel III  - Sepith Set 2 (AppID: 1262372)
addappid(1262372)
addappid(1262372, 1, "45938fff215a955c402b26f3c55b895f36291f3dea2fdc0945bc8c902d5b6597") -- The Legend of Heroes Trails of Cold Steel III  - Sepith Set 2 - The Legend of Heroes: Trails of Cold Steel III  - Sepith Set 2 (1262372) Depot
setManifestid(1262372, "1539215852736779688", 518)
-- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Set 1 (AppID: 1262373)
addappid(1262373)
addappid(1262373, 1, "afc805abd6aed000542c136fc3f8dc333ccbde32555a9a8fdc67a8ed1389ba06") -- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Set 1 - The Legend of Heroes: Trails of Cold Steel III  - Shining Pom Droplet Set 1 (1262373) Depot
setManifestid(1262373, "2086096755903133038", 529)
-- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Set 2 (AppID: 1262374)
addappid(1262374)
addappid(1262374, 1, "26317777bd93391d9f37bb8d27b450bf87a1a7e19e389a61c217f7d713086c41") -- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Set 2 - The Legend of Heroes: Trails of Cold Steel III  - Shining Pom Droplet Set 2 (1262374) Depot
setManifestid(1262374, "5021863193525560868", 529)
-- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Set 3 (AppID: 1262375)
addappid(1262375)
addappid(1262375, 1, "cc28d8e717c205e51dd2296b55e3d264bd5cde3d2992d1fbfa03d5e0a30ba1c1") -- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Set 3 - The Legend of Heroes: Trails of Cold Steel III  - Shining Pom Droplet Set 3 (1262375) Depot
setManifestid(1262375, "7557176202731811618", 529)
-- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Set 4 (AppID: 1262376)
addappid(1262376)
addappid(1262376, 1, "d6f39bd79fe261d01c42fdfed41195380df609c0171d04aa007e1b3889875e3c") -- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Set 4 - The Legend of Heroes: Trails of Cold Steel III  - Shining Pom Droplet Set 4 (1262376) Depot
setManifestid(1262376, "2269358069361127676", 529)
-- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Set 5 (AppID: 1262377)
addappid(1262377)
addappid(1262377, 1, "d33d85719885c7abd20993a17bce487436ba2dd486ea357660785c3f0581a2d5") -- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Set 5 - The Legend of Heroes: Trails of Cold Steel III  - Shining Pom Droplet Set 5 (1262377) Depot
setManifestid(1262377, "234609578875200541", 529)
-- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Value Set 1 (AppID: 1262378)
addappid(1262378)
addappid(1262378, 1, "d42e67d2e9533019cc2b9f38363edd9461e6896f72129a3856dffae420a8ec13") -- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Value Set 1 - The Legend of Heroes: Trails of Cold Steel III  - Shining Pom Droplet Value Set 1 (1262378) Depot
setManifestid(1262378, "2739322204864555399", 541)
-- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Value Set 2 (AppID: 1262379)
addappid(1262379)
addappid(1262379, 1, "6fc3c6d77ab7eb4154387a3f1d9665d3408b23273ab82c7592b0efa6d216ff65") -- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Value Set 2 - The Legend of Heroes: Trails of Cold Steel III  - Shining Pom Droplet Value Set 2 (1262379) Depot
setManifestid(1262379, "1477074439034362181", 541)
-- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Value Set 3 (AppID: 1262390)
addappid(1262390)
addappid(1262390, 1, "c8c644673ee8bf5b9205b2073441420dabd273895e996a3b3342492931d7140a") -- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Value Set 3 - The Legend of Heroes: Trails of Cold Steel III  - Shining Pom Droplet Value Set 3 (1262390) Depot
setManifestid(1262390, "6376298741880606150", 541)
-- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Value Set 4 (AppID: 1262391)
addappid(1262391)
addappid(1262391, 1, "a6953686e37b576c89e8b7f192ea34b37cbec9380bf720b158bb8cc513cddc3c") -- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Value Set 4 - The Legend of Heroes: Trails of Cold Steel III  - Shining Pom Droplet Value Set 4 (1262391) Depot
setManifestid(1262391, "791401046471172847", 541)
-- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Value Set 5 (AppID: 1262392)
addappid(1262392)
addappid(1262392, 1, "e1e2cdb92d8eea3541eb8284248a720ce090cbc0e19de9bc8eeb550444d4342c") -- The Legend of Heroes Trails of Cold Steel III  - Shining Pom Droplet Value Set 5 - The Legend of Heroes: Trails of Cold Steel III  - Shining Pom Droplet Value Set 5 (1262392) Depot
setManifestid(1262392, "1913951212439116994", 541)
-- The Legend of Heroes Trails of Cold Steel III  - Spirit Incense Set 1 (AppID: 1262393)
addappid(1262393)
addappid(1262393, 1, "0d3c3400c7b1629479262c47943e914991c696db94c9119c85556f31b0befcc4") -- The Legend of Heroes Trails of Cold Steel III  - Spirit Incense Set 1 - The Legend of Heroes: Trails of Cold Steel III  - Spirit Incense Set 1 (1262393) Depot
setManifestid(1262393, "6562371349446114259", 573)
-- The Legend of Heroes Trails of Cold Steel III  - Spirit Incense Set 2 (AppID: 1262394)
addappid(1262394)
addappid(1262394, 1, "3fc918a40b833e3ddcc19e4ecae06d1cfe30a02f89fbff58958d8da4af67622c") -- The Legend of Heroes Trails of Cold Steel III  - Spirit Incense Set 2 - The Legend of Heroes: Trails of Cold Steel III  - Spirit Incense Set 2 (1262394) Depot
setManifestid(1262394, "1678998736962069772", 573)
-- The Legend of Heroes Trails of Cold Steel III  - Spirit Incense Set 3 (AppID: 1262395)
addappid(1262395)
addappid(1262395, 1, "512321adbcceb04c83c07c4e6314f5397ea2cf2e56a07f66e923fff8e398f502") -- The Legend of Heroes Trails of Cold Steel III  - Spirit Incense Set 3 - The Legend of Heroes: Trails of Cold Steel III  - Spirit Incense Set 3 (1262395) Depot
setManifestid(1262395, "8082693382469858790", 573)
-- The Legend of Heroes Trails of Cold Steel III  - U-Material Set 1 (AppID: 1262396)
addappid(1262396)
addappid(1262396, 1, "67b87417a6fa5215e821c3ded46c883d7e7b9076f9fe4372595ac8b1674bcefc") -- The Legend of Heroes Trails of Cold Steel III  - U-Material Set 1 - The Legend of Heroes: Trails of Cold Steel III  - U-Material Set 1 (1262396) Depot
setManifestid(1262396, "1424532801889456470", 511)
-- The Legend of Heroes Trails of Cold Steel III  - U-Material Set 2 (AppID: 1262397)
addappid(1262397)
addappid(1262397, 1, "caffd972bde70a387fd0cec702f23fa7b2648cce418bd6950d2122e6fb68f2d5") -- The Legend of Heroes Trails of Cold Steel III  - U-Material Set 2 - The Legend of Heroes: Trails of Cold Steel III  - U-Material Set 2 (1262397) Depot
setManifestid(1262397, "2245370846447893753", 511)
-- The Legend of Heroes Trails of Cold Steel III  - U-Material Set 3 (AppID: 1262398)
addappid(1262398)
addappid(1262398, 1, "3c4df7d611a7176cfb69d50daf76029cee55a1348cdddb2430fc2e44288e1644") -- The Legend of Heroes Trails of Cold Steel III  - U-Material Set 3 - The Legend of Heroes: Trails of Cold Steel III  - U-Material Set 3 (1262398) Depot
setManifestid(1262398, "6570356152977012555", 511)
-- The Legend of Heroes Trails of Cold Steel III  - Useful Accessories Set (AppID: 1262399)
addappid(1262399)
addappid(1262399, 1, "eba03a673b7223238511b6e8ae24885881097356c5be04c4d6871732b6eb0c4e") -- The Legend of Heroes Trails of Cold Steel III  - Useful Accessories Set - The Legend of Heroes: Trails of Cold Steel III  - Useful Accessories Set (1262399) Depot
setManifestid(1262399, "4799781742341013154", 523)
-- The Legend of Heroes Trails of Cold Steel III  - Zeram Capsule Set 1 (AppID: 1262400)
addappid(1262400)
addappid(1262400, 1, "ee40c5d19c048544e66d337e301ce3691768bfa64043c8de1c51206f1f245719") -- The Legend of Heroes Trails of Cold Steel III  - Zeram Capsule Set 1 - The Legend of Heroes: Trails of Cold Steel III  - Zeram Capsule Set 1 (1262400) Depot
setManifestid(1262400, "3416678118086640918", 532)
-- The Legend of Heroes Trails of Cold Steel III  - Zeram Capsule Set 2 (AppID: 1262401)
addappid(1262401)
addappid(1262401, 1, "5090197fe0e6a74d72e1d957d38aa5694d2a9c7b0c6cab44677fc1eaf9bc3484") -- The Legend of Heroes Trails of Cold Steel III  - Zeram Capsule Set 2 - The Legend of Heroes: Trails of Cold Steel III  - Zeram Capsule Set 2 (1262401) Depot
setManifestid(1262401, "5709775049107270954", 532)
-- The Legend of Heroes Trails of Cold Steel III  - Zeram Powder Set 1 (AppID: 1262402)
addappid(1262402)
addappid(1262402, 1, "6974b34c09adc16afb68cf5a04428ea5ab4ea08b51d4dae16d40c5c7a3509095") -- The Legend of Heroes Trails of Cold Steel III  - Zeram Powder Set 1 - The Legend of Heroes: Trails of Cold Steel III  - Zeram Powder Set 1 (1262402) Depot
setManifestid(1262402, "8547116521676984267", 528)
-- The Legend of Heroes Trails of Cold Steel III  - Zeram Powder Set 2 (AppID: 1262403)
addappid(1262403)
addappid(1262403, 1, "866d5dd40012e372c421251a8aa967627320ec6f643da0e7deb976e533f82805") -- The Legend of Heroes Trails of Cold Steel III  - Zeram Powder Set 2 - The Legend of Heroes: Trails of Cold Steel III  - Zeram Powder Set 2 (1262403) Depot
setManifestid(1262403, "7677100669647233860", 528)
-- The Legend of Heroes Trails of Cold Steel III  - Zeram Powder Set 3 (AppID: 1262404)
addappid(1262404)
addappid(1262404, 1, "b4b084e4e940a37f29c973021c1a5dc17211c0acdd2be6e388f830834a998048") -- The Legend of Heroes Trails of Cold Steel III  - Zeram Powder Set 3 - The Legend of Heroes: Trails of Cold Steel III  - Zeram Powder Set 3 (1262404) Depot
setManifestid(1262404, "1711147757012306724", 528)
-- The Legend of Heroes Trails of Cold Steel III  - Altinas Casual Clothes (AppID: 1262405)
addappid(1262405)
addappid(1262405, 1, "889aded6717219e6630b8c7a50efbac4811fb02a81f52f87e25f5f79b3d387f3") -- The Legend of Heroes Trails of Cold Steel III  - Altinas Casual Clothes - The Legend of Heroes: Trails of Cold Steel III  - Altina's Casual Clothes (1262405) Depot
setManifestid(1262405, "2027790706126987698", 16726254)
-- The Legend of Heroes Trails of Cold Steel III  - ARCUS Cover Set A (AppID: 1262406)
addappid(1262406)
addappid(1262406, 1, "c6a908dc09741bf2a8013edc0799e6b210b0c544c53ff806d9d18ac0115f6aec") -- The Legend of Heroes Trails of Cold Steel III  - ARCUS Cover Set A - The Legend of Heroes: Trails of Cold Steel III  - ARCUS Cover Set A (1262406) Depot
setManifestid(1262406, "5855092268029941163", 6313666)
-- The Legend of Heroes Trails of Cold Steel III  - ARCUS Cover Set B (AppID: 1262407)
addappid(1262407)
addappid(1262407, 1, "859cd42b1f11cc1e9e694e51bdf5bbd221f40b83ef31e839b558241018bfc95d") -- The Legend of Heroes Trails of Cold Steel III  - ARCUS Cover Set B - The Legend of Heroes: Trails of Cold Steel III  - ARCUS Cover Set B (1262407) Depot
setManifestid(1262407, "3182014736193812854", 6313689)
-- The Legend of Heroes Trails of Cold Steel III  - ARCUS Cover Set C (AppID: 1262408)
addappid(1262408)
addappid(1262408, 1, "b57321dec55751cadcc7927a0441313cfa71e429923290b821f65ba4b136f7c0") -- The Legend of Heroes Trails of Cold Steel III  - ARCUS Cover Set C - The Legend of Heroes: Trails of Cold Steel III  - ARCUS Cover Set C (1262408) Depot
setManifestid(1262408, "5588484594934745765", 8416666)
-- The Legend of Heroes Trails of Cold Steel III  - ARCUS Cover Set D (AppID: 1262409)
addappid(1262409)
addappid(1262409, 1, "98dc0d712cc2a420f6b0c6681331076d88db1548722e66c8bd0df068dc39d04a") -- The Legend of Heroes Trails of Cold Steel III  - ARCUS Cover Set D - The Legend of Heroes: Trails of Cold Steel III  - ARCUS Cover Set D (1262409) Depot
setManifestid(1262409, "2408964960341377427", 6313711)
-- The Legend of Heroes Trails of Cold Steel III  - Ashen Knight Set (AppID: 1262410)
addappid(1262410)
addappid(1262410, 1, "ff52e0ed18a2708c784de05232cbeb2becfb4a13b2212ecd1a71ab484ba4b86a") -- The Legend of Heroes Trails of Cold Steel III  - Ashen Knight Set - The Legend of Heroes: Trails of Cold Steel III  - Ashen Knight Set (1262410) Depot
setManifestid(1262410, "3464150696860340440", 10878677)
-- The Legend of Heroes Trails of Cold Steel III  - Ashs Casual Clothes (AppID: 1262411)
addappid(1262411)
addappid(1262411, 1, "4b11f71069b28e85877899894777a3613c4fe94eb43d5ccb23432c35462171d7") -- The Legend of Heroes Trails of Cold Steel III  - Ashs Casual Clothes - The Legend of Heroes: Trails of Cold Steel III  - Ash's Casual Clothes (1262411) Depot
setManifestid(1262411, "5119079228948672668", 17037192)
-- The Legend of Heroes Trails of Cold Steel III  - Bunny Set (AppID: 1262412)
addappid(1262412)
addappid(1262412, 1, "0e5d53e3fa32dfcad062b04950a257fd5fb7baab5587542a9a6aa547733cb3bd") -- The Legend of Heroes Trails of Cold Steel III  - Bunny Set - The Legend of Heroes: Trails of Cold Steel III  - Bunny Set (1262412) Depot
setManifestid(1262412, "7967279242202846974", 9416382)
-- The Legend of Heroes Trails of Cold Steel III  - Cool Hair Extension Set (AppID: 1262413)
addappid(1262413)
addappid(1262413, 1, "29362bd388e782f8a1d8849ba7d6def55df18d84c92683fece1d90cefbb82c75") -- The Legend of Heroes Trails of Cold Steel III  - Cool Hair Extension Set - The Legend of Heroes: Trails of Cold Steel III  - Cool Hair Extension Set (1262413) Depot
setManifestid(1262413, "8393484040871292806", 50004756)
-- The Legend of Heroes Trails of Cold Steel III  - Cute Hair Extension Set (AppID: 1262414)
addappid(1262414)
addappid(1262414, 1, "055335ac2c6384c3661072c66dccf30fb579143a8a6f932018ce23492f5e2598") -- The Legend of Heroes Trails of Cold Steel III  - Cute Hair Extension Set - The Legend of Heroes: Trails of Cold Steel III  - Cute Hair Extension Set (1262414) Depot
setManifestid(1262414, "7606227044148040506", 42621658)
-- The Legend of Heroes Trails of Cold Steel III  - Devil Set (AppID: 1262415)
addappid(1262415)
addappid(1262415, 1, "16d1048400d509be6e182675a1f55afd509ce8e6ed4713de07a8df7969e3db91") -- The Legend of Heroes Trails of Cold Steel III  - Devil Set - The Legend of Heroes: Trails of Cold Steel III  - Devil Set (1262415) Depot
setManifestid(1262415, "1429525645068964850", 2901784)
-- The Legend of Heroes Trails of Cold Steel III  - Hardcore Set (AppID: 1262416)
addappid(1262416)
addappid(1262416, 1, "ec51f680820fbd13793f0dd0b9f9e8aa4654f22aeabad8e573593637ebaf973f") -- The Legend of Heroes Trails of Cold Steel III  - Hardcore Set - The Legend of Heroes: Trails of Cold Steel III  - Hardcore Set (1262416) Depot
setManifestid(1262416, "7437850208473387021", 22340686)
-- The Legend of Heroes Trails of Cold Steel III  - Junas Active Red Costume (AppID: 1262417)
addappid(1262417)
addappid(1262417, 1, "0039ba5f3dceb49b88a51612a1f920330826f053829d54e652c2575e73a30423") -- The Legend of Heroes Trails of Cold Steel III  - Junas Active Red Costume - The Legend of Heroes: Trails of Cold Steel III  - Juna's "Active Red" Costume (1262417) Depot
setManifestid(1262417, "4290645289264812519", 17214412)
-- The Legend of Heroes Trails of Cold Steel III  - Junas Crossbell Cheer Costume (AppID: 1262418)
addappid(1262418)
addappid(1262418, 1, "79b2504ce6ab158e4abff3457e01c51f4b8cebc22c08fb413fd91699f0a70f6a") -- The Legend of Heroes Trails of Cold Steel III  - Junas Crossbell Cheer Costume - The Legend of Heroes: Trails of Cold Steel III  - Juna's "Crossbell Cheer!" Costume (1262418) Depot
setManifestid(1262418, "3686312977400416262", 16287470)
-- The Legend of Heroes Trails of Cold Steel III  - Junas Casual Clothes (AppID: 1262419)
addappid(1262419)
addappid(1262419, 1, "02d7173d10537781b75f82ad8cc03c680daa3e7da1c176775e5e56de270413b1") -- The Legend of Heroes Trails of Cold Steel III  - Junas Casual Clothes - The Legend of Heroes: Trails of Cold Steel III  - Juna's Casual Clothes (1262419) Depot
setManifestid(1262419, "947683102481252865", 19919650)
-- The Legend of Heroes Trails of Cold Steel III  - Kurts Casual Clothes (AppID: 1262420)
addappid(1262420)
addappid(1262420, 1, "a637c2f3bd83071b6cd4045eae3f0528b251c622a4045c62051357121591e322") -- The Legend of Heroes Trails of Cold Steel III  - Kurts Casual Clothes - The Legend of Heroes: Trails of Cold Steel III  - Kurt's Casual Clothes (1262420) Depot
setManifestid(1262420, "4782495395947227862", 17912451)
-- The Legend of Heroes Trails of Cold Steel III  - Mascot Headgear Set (AppID: 1262421)
addappid(1262421)
addappid(1262421, 1, "3e1cd0b1df635aa145f9b17c9a3c9d87549b6be2cc656d5240a6b74803b8441a") -- The Legend of Heroes Trails of Cold Steel III  - Mascot Headgear Set - The Legend of Heroes: Trails of Cold Steel III  - Mascot Headgear Set (1262421) Depot
setManifestid(1262421, "2803823099236929715", 5998516)
-- The Legend of Heroes Trails of Cold Steel III  - Mask Set (AppID: 1262422)
addappid(1262422)
addappid(1262422, 1, "499a86d4116c6cb8ba3c2f831277a97c712b2572afa8840263dd82e85d014e1c") -- The Legend of Heroes Trails of Cold Steel III  - Mask Set - The Legend of Heroes: Trails of Cold Steel III  - Mask Set (1262422) Depot
setManifestid(1262422, "8201087538239408148", 9026740)
-- The Legend of Heroes Trails of Cold Steel III  - Musses Coquettish Blue Costume (AppID: 1262423)
addappid(1262423)
addappid(1262423, 1, "d5ee8e9ede11edb21c0f6e645a7c7b1325ddc6d027b5164ace2f8c317c207ee7") -- The Legend of Heroes Trails of Cold Steel III  - Musses Coquettish Blue Costume - The Legend of Heroes: Trails of Cold Steel III  - Musse's "Coquettish Blue" Costume (1262423) Depot
setManifestid(1262423, "7530114419550044861", 20039113)
-- The Legend of Heroes Trails of Cold Steel III  - Musses Casual Clothes (AppID: 1262424)
addappid(1262424)
addappid(1262424, 1, "0231765609dd6aba43b8668f948aecc30ff36281244b08f83ea6c002440596f7") -- The Legend of Heroes Trails of Cold Steel III  - Musses Casual Clothes - The Legend of Heroes: Trails of Cold Steel III  - Musse's Casual Clothes (1262424) Depot
setManifestid(1262424, "3875750139931790067", 16330296)
-- The Legend of Heroes Trails of Cold Steel III  - Raccoon Set (AppID: 1262425)
addappid(1262425)
addappid(1262425, 1, "92061a4cc52ca69626c9592adce1637fa6cd5dab78d54f7652b0a20a422cd384") -- The Legend of Heroes Trails of Cold Steel III  - Raccoon Set - The Legend of Heroes: Trails of Cold Steel III  - Raccoon Set (1262425) Depot
setManifestid(1262425, "6836038143447017887", 3824954)
-- The Legend of Heroes Trails of Cold Steel III  - Rainbow Hair Set (AppID: 1262426)
addappid(1262426)
addappid(1262426, 1, "2f4e78383c414b2d361ab103f6d869b4d2804894ab64f0ce6345925a621d8be5") -- The Legend of Heroes Trails of Cold Steel III  - Rainbow Hair Set - The Legend of Heroes: Trails of Cold Steel III  - Rainbow Hair Set (1262426) Depot
setManifestid(1262426, "9133976658488271751", 8774791)
-- The Legend of Heroes Trails of Cold Steel III  - Rare Eyewear (AppID: 1262427)
addappid(1262427)
addappid(1262427, 1, "70fb4bfb5f7c18c8524c5dde8aa3dc1330eeeed737e54f58ef6e89f4e0f72edb") -- The Legend of Heroes Trails of Cold Steel III  - Rare Eyewear - The Legend of Heroes: Trails of Cold Steel III  - Rare Eyewear (1262427) Depot
setManifestid(1262427, "4483586213180325071", 11572464)
-- The Legend of Heroes Trails of Cold Steel III  - Reans Casual Clothes (AppID: 1262428)
addappid(1262428)
addappid(1262428, 1, "9a0a278e9e70600e9f43900647db3794dc42b3b50fda70e14b63565d71ca8a10") -- The Legend of Heroes Trails of Cold Steel III  - Reans Casual Clothes - The Legend of Heroes: Trails of Cold Steel III  - Rean's Casual Clothes (1262428) Depot
setManifestid(1262428, "4351509610258356329", 15708387)
-- The Legend of Heroes Trails of Cold Steel III  - Reans Traveling Outfit (Cold Steel II) (AppID: 1262429)
addappid(1262429)
addappid(1262429, 1, "6f4d341f8a2ed38f8f793e9128c49aad5f4292bfac8dfe0240f0d42bd137bc11") -- The Legend of Heroes Trails of Cold Steel III  - Reans Traveling Outfit (Cold Steel II) - The Legend of Heroes: Trails of Cold Steel III  - Rean's Traveling Outfit (Cold Steel II) (1262429) Depot
setManifestid(1262429, "3402881778466838801", 18861377)
-- The Legend of Heroes Trails of Cold Steel III  - Ride-Along Black Rabbit (AppID: 1262430)
addappid(1262430)
addappid(1262430, 1, "71b277ca096d27feb2bdd79e0cecd9ca15297de930ea27633b6b76edd7cc51df") -- The Legend of Heroes Trails of Cold Steel III  - Ride-Along Black Rabbit - The Legend of Heroes: Trails of Cold Steel III  - Ride-Along Black Rabbit (1262430) Depot
setManifestid(1262430, "7596826109190867113", 4438973)
-- The Legend of Heroes Trails of Cold Steel III  - Ride-Along Dana (AppID: 1262431)
addappid(1262431)
addappid(1262431, 1, "2c134baba96c4ede0d5c427577f8632e108a756d62b75e8b96252a105d0a2877") -- The Legend of Heroes Trails of Cold Steel III  - Ride-Along Dana - The Legend of Heroes: Trails of Cold Steel III  - Ride-Along Dana (1262431) Depot
setManifestid(1262431, "6015149404177080258", 5123041)
-- The Legend of Heroes Trails of Cold Steel III  - Ride-Along Elie (AppID: 1262432)
addappid(1262432)
addappid(1262432, 1, "0ba2366037af64a49bb865fff8dba8ac0c89c5ab6aac3b7a8df779c504bb6335") -- The Legend of Heroes Trails of Cold Steel III  - Ride-Along Elie - The Legend of Heroes: Trails of Cold Steel III  - Ride-Along Elie (1262432) Depot
setManifestid(1262432, "578521992798197270", 5727675)
-- The Legend of Heroes Trails of Cold Steel III  - Ride-Along Ozzie (AppID: 1262433)
addappid(1262433)
addappid(1262433, 1, "a2ce4014a0d86dba8a08642a821035cfe746ebfef75e3f33553ea71704fd3b47") -- The Legend of Heroes Trails of Cold Steel III  - Ride-Along Ozzie - The Legend of Heroes: Trails of Cold Steel III  - Ride-Along Ozzie (1262433) Depot
setManifestid(1262433, "155360055541753569", 4013994)
-- The Legend of Heroes Trails of Cold Steel III  - Ride-Along School Renne (AppID: 1262434)
addappid(1262434)
addappid(1262434, 1, "f1bee1915269706edaec63fac85589165053a47b9f6987c159aefff9e936983f") -- The Legend of Heroes Trails of Cold Steel III  - Ride-Along School Renne - The Legend of Heroes: Trails of Cold Steel III  - Ride-Along School Renne (1262434) Depot
setManifestid(1262434, "1816398452734658957", 4335506)
-- The Legend of Heroes Trails of Cold Steel III  - Self-assertion Panels (AppID: 1262435)
addappid(1262435)
addappid(1262435, 1, "887839106fe2e2a1d8bca54fd6cb65b0b7d8368f8f3e3d34327e629df8867e86") -- The Legend of Heroes Trails of Cold Steel III  - Self-assertion Panels - The Legend of Heroes: Trails of Cold Steel III  - Self-assertion Panels (1262435) Depot
setManifestid(1262435, "2630047699735361813", 20729552)
-- The Legend of Heroes Trails of Cold Steel III  - Snow Leopard Set (AppID: 1262436)
addappid(1262436)
addappid(1262436, 1, "d727c834268648eb8a187c95dd1237e839d7d0674acea258c65eaa1efb38200e") -- The Legend of Heroes Trails of Cold Steel III  - Snow Leopard Set - The Legend of Heroes: Trails of Cold Steel III  - Snow Leopard Set (1262436) Depot
setManifestid(1262436, "7788603132736202394", 5293498)
-- The Legend of Heroes Trails of Cold Steel III  - Standard Glasses Set (AppID: 1262437)
addappid(1262437)
addappid(1262437, 1, "84a2cbf5fec9dd7a86b11932fb60689c83c86063cc9e8a57c026fb36297f7f74") -- The Legend of Heroes Trails of Cold Steel III  - Standard Glasses Set - The Legend of Heroes: Trails of Cold Steel III  - Standard Glasses Set (1262437) Depot
setManifestid(1262437, "8696167706909559649", 2468574)
-- The Legend of Heroes Trails of Cold Steel III  - Stylish Sunglasses Set (AppID: 1262438)
addappid(1262438)
addappid(1262438, 1, "5d2c1c7bcb334c923225e3205b3f62bb29bd080be3e21f692d50e1b192523525") -- The Legend of Heroes Trails of Cold Steel III  - Stylish Sunglasses Set - The Legend of Heroes: Trails of Cold Steel III  - Stylish Sunglasses Set (1262438) Depot
setManifestid(1262438, "8380743797665612449", 5725185)
-- The Legend of Heroes Trails of Cold Steel III  - Thors Main Campus Uniforms (AppID: 1262439)
addappid(1262439)
addappid(1262439, 1, "6c9999685863b1fe73bd5a91649deed63191e5fc226862ed2e1d9f33984448f3") -- The Legend of Heroes Trails of Cold Steel III  - Thors Main Campus Uniforms - The Legend of Heroes: Trails of Cold Steel III  - Thors Main Campus Uniforms (1262439) Depot
setManifestid(1262439, "8481428953466509935", 79053802)