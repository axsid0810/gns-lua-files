-- 742300's Lua and Manifest Created by Hubcap Manifest
-- Mega Man 11
-- Created: December 12, 2025 at 09:29:39 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(742300) -- Mega Man 11
-- MAIN APP DEPOTS
addappid(742301, 1, "ec5fcfee2030231a6c7994967b36b24d8b3ecd1194310c1acc0a984b3a404787") -- SPIKE Content
setManifestid(742301, "5231587232494577491", 2224851187)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Wily Numbers Instrumental Stage Tracks (AppID: 861200)
addappid(861200)
addappid(861200, 1, "82a79626f8c6bf28e07682a92a8effaab043b7aa9396f87d7ecb63ebff5f3fbc") -- Wily Numbers Instrumental Stage Tracks - Wily Numbers: Instrumental Stage Tracks (861200) デポ
setManifestid(861200, "1353041788169668102", 16444413)