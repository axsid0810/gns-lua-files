-- 666140's Lua and Manifest Created by Hubcap Manifest
-- My Time at Portia
-- Created: September 30, 2025 at 02:37:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 10

-- MAIN APPLICATION
addappid(666140) -- My Time at Portia
-- MAIN APP DEPOTS
addappid(666141, 1, "caba4d1fb75ba07e16c9cf25312648ff7d37f77df1b30238f5e069d54257b9d5") -- My Time At Portia For Win
setManifestid(666141, "505910649525385526", 10327126958)
addappid(666142, 1, "061eb1a76e81ff214a863af97636561615e4efa1d4f37bde4a4b155a2d19c9f9") -- My Time At Portia For Mac
setManifestid(666142, "2575947428129196803", 9973829675)
addappid(666143, 1, "2619a8a0873ecdbe14188c37a5bfb0541460c5c54a5c13872b44e756fbb7ac1c") -- Depot 666143
setManifestid(666143, "7491349219066139121", 10293028169)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(921820) -- My Time At Portia - Kickstarter reward 1 DLC
addtoken(921820, "7023027244082381067")
addappid(995390) -- My Time At Portia - Kickstarter reward 2 DLC
addappid(995400) -- My Time At Portia - Kickstarter reward 3 DLC
addappid(1014410) -- My Time At Portia - Kickstarter reward 4 DLC
addappid(1025030) -- My Time At Portia - Kickstarter reward 5 DLC Pet
addappid(1075040) -- My Time At Portia - Player Attire Package
addappid(1075041) -- My Time At Portia - NPC Attire Package
addappid(1134460) -- My Time At Portia - Bikini
addappid(1968910) -- My Time At Portia - Player Costume Package
addappid(1968911) -- My Time At Portia - NPC Eveningwear Package