-- 554620's Lua and Manifest Created by Hubcap Manifest
-- Life is Strange: Before the Storm
-- Created: January 20, 2026 at 11:12:20 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 22
-- Total DLCs: 8

-- MAIN APPLICATION
addappid(554620, 1, "6004918ac41c9ce0f99efd00f6e32f1b136c84a1ba916dac651d6cb79b8d7016") -- Life is Strange: Before the Storm
-- MAIN APP DEPOTS
addappid(554621, 1, "bf7c00ecf8223084d6ee55244636f6cfc4d0656e9a345f57284835d6cd1c41f2") -- Life is Strange: Before the Storm Episode 1
setManifestid(554621, "3842926583703835149", 6963943817)
addappid(554622, 1, "2856671ac38200cfcc4f707adc25b23d4a53bd62ec5f2b52115ae3bf6094f11b") -- Mac - Life is Strange: Before the Storm Episode 1 (554621)
setManifestid(554622, "4896947406976753276", 7036778388)
addappid(642082, 1, "fed93d7dff346707911ac5df2ba93feac14d0cb343ce9de95505f8051b23d33d") -- Linux - Life is Strange: Before the Storm Episode 1 (554621)
setManifestid(642082, "343652295143889094", 7343872272)
-- DLCS WITH DEDICATED DEPOTS
-- Life is Strange Before the Storm Episode 2 (AppID: 642080)
addappid(642080)
addappid(642080, 1, "e8b5002b8c8e5c26d81df9bd279ffc3d39a090c0f02be0e6da7a8259246977cb") -- Life is Strange Before the Storm Episode 2 - Life is Strange: Before the Storm Episode 2 (642080) Depot
setManifestid(642080, "2142056837812233767", 6290358046)
addappid(554623, 1, "5d6c094286fc3d61d2e0d45e718ed520a9132a5bba6fa5b69f4aa71f76da16d6") -- Life is Strange Before the Storm Episode 2 - Mac - Life is Strange: Before the Storm Episode 2 (642080)
setManifestid(554623, "8764745407512180858", 6755111708)
addappid(642083, 1, "a07a790088d3e28418b1d680e84cdcbef8ec7fa51d83c881a23f8116ccc3105e") -- Life is Strange Before the Storm Episode 2 - Linux - Life is Strange: Before the Storm Episode 2 (642080)
setManifestid(642083, "295185726663312294", 6808453381)
-- Life is Strange Before the Storm Chloe Outfit Pack (AppID: 642900)
addappid(642900)
addtoken(642900, "8315808137713263779")
addappid(642900, 1, "4948a2594b79ee4144466582c968b0d65d3b5b2924fc87a3ffcf3765c389254e") -- Life is Strange Before the Storm Chloe Outfit Pack - Life is Strange: Before the Storm Chloe Outfit Pack (642900) Depot
setManifestid(642900, "7746276353636318323", 176840289)
addappid(554625, 1, "853932356dec23a9e7bb79b123c25c2007ced889d8124ec98bcf618dfe18c529") -- Life is Strange Before the Storm Chloe Outfit Pack - Mac - Life is Strange: Before the Storm Chloe Outfit Pack (642900)
setManifestid(554625, "3019962548072839427", 178168552)
addappid(642085, 1, "c460862b07ee051a714e1f665908e7398fd2c1f5d0c51bac0891a25e93fffe7e") -- Life is Strange Before the Storm Chloe Outfit Pack - Linux - Life is Strange: Before the Storm Chloe Outfit Pack (642900)
setManifestid(642085, "61249927249108554", 181334120)
-- Life is Strange Before the Storm Classic Chloe Outfit Pack (AppID: 644900)
addappid(644900)
addtoken(644900, "11089201658444025032")
addappid(644900, 1, "31d89ec8abe9c809e145ed597d7dc2186c9b9abb0cf6b56fbcf5c457d7efc53c") -- Life is Strange Before the Storm Classic Chloe Outfit Pack - Life is Strange: Before the Storm Pre-Order Outfit Pack (644900) Depot
setManifestid(644900, "7305688122242482952", 66862152)
addappid(554626, 1, "0be6399623b2d8b1a2020325b7b83dac65395a8c79fd4e88e200b5509cab399d") -- Life is Strange Before the Storm Classic Chloe Outfit Pack - Mac - Life is Strange: Before the Storm Classic Chloe Pre-Order Outfit Pack (644900)
setManifestid(554626, "6271809889830985291", 67290559)
addappid(642086, 1, "e03ae12288eed763c3a5de14186b4ade2d518e2093ecb3f6bc19ec1c642f7f5f") -- Life is Strange Before the Storm Classic Chloe Outfit Pack - Linux - Life is Strange: Before the Storm Classic Chloe Pre-Order Outfit Pack (644900)
setManifestid(642086, "149232412393519220", 68296767)
-- Life is Strange Before the Storm Mixtape Zen Mode (AppID: 648010)
addappid(648010)
addtoken(648010, "5163480587947814753")
addappid(648010, 1, "6dce63a54b9fa35941920219d17ca9904e1cdcf09c12bbf6cb7806b578e3290b") -- Life is Strange Before the Storm Mixtape Zen Mode - Life is Strange: Before the Storm Mixtape Zen Mode (648010) Depot
setManifestid(648010, "7865017878271804819", 152620061)
addappid(554627, 1, "fa7fd8afe629286eb331880349c612c6dbe43244f86fbc32a95c8dfaf7eae361") -- Life is Strange Before the Storm Mixtape Zen Mode - Mac - Life is Strange: Before the Storm Mixtape Zen Mode (648010)
setManifestid(554627, "1759132568514324276", 155169876)
addappid(642087, 1, "21bac26335d7f7fc6b1de71353be6c14ecf936120f20a98a6d413b148f7e949d") -- Life is Strange Before the Storm Mixtape Zen Mode - Linux - Life is Strange: Before the Storm Mixtape Zen Mode (648010)
setManifestid(642087, "87208832348967306", 158789156)
-- Life is Strange Before the Storm Episode 3 (AppID: 704740)
addappid(704740)
addappid(704740, 1, "2c8cc34d83f8ae3ee5e4d22984d212d41ea5e3ddd305e55d28e538bb8459b80f") -- Life is Strange Before the Storm Episode 3 - Life is Strange: Before the Storm Episode 3 (704740) Depot
setManifestid(704740, "8414419118833463437", 6290390233)
addappid(554624, 1, "45ede4973574e735b1f3142eaf616c0f2d10fcca40a880fc073c5b9acb4f806b") -- Life is Strange Before the Storm Episode 3 - Mac - Life is Strange: Before the Storm Episode 3 (704740)
setManifestid(554624, "7319172655189446478", 6303329614)
addappid(642084, 1, "19b0c71ed7e86130d8e3e8ea01939c06e5233cc5d2bd25d2b22b508445ee961b") -- Life is Strange Before the Storm Episode 3 - Linux - Life is Strange: Before the Storm Episode 3 (704740)
setManifestid(642084, "133187279751698193", 6346584187)
-- Life is Strange Before the Storm Farewell (AppID: 763780)
addappid(763780)
addappid(763780, 1, "213e19167a5d53724b9fcb7c8c2d674bf6ab91aeaf8f86d209fc59f0dafdd2e9") -- Life is Strange Before the Storm Farewell - Life is Strange: Before the Storm Farewell (763780) Depot
setManifestid(763780, "3032337262623843605", 2872714090)
addappid(554629, 1, "d86462d1b0542557d92c9e60edc0115baa7c18c07cb8d1cb38affcc8d88f57a1") -- Life is Strange Before the Storm Farewell - Mac - Life is Strange: Before the Storm Farewell (763780)
setManifestid(554629, "586911973003421800", 2903574477)
addappid(642089, 1, "833574335caf705c55d33417242b3e6a7b3eb38a8654687dd301f07a54814ec6") -- Life is Strange Before the Storm Farewell - Linux - Life is Strange: Before the Storm Farewell (763780)
setManifestid(642089, "70297320445523753", 2922843700)
-- Life is Strange Before the Storm Japanese Language Pack (AppID: 824500)
addappid(824500)
addappid(824500, 1, "a5e4c765ce0dad8f2495da34a985175689017efe2e89cb388352193a917c052d") -- Life is Strange Before the Storm Japanese Language Pack - Life is Strange: Before the Storm Japanese (824500) Depot
setManifestid(824500, "4624250803866131630", 4028105964)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(652960) -- Life is Strange Before the Storm DLC - Deluxe Upgrade
-- EMPTY DEPOTS (no content on any branch)
-- addappid(554628) -- Depot 554628 (empty depot)
-- addappid(642088) -- Depot 642088 (empty depot)
-- addappid(642902) -- Depot 642902 (empty depot)