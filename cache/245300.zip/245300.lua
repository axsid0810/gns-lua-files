-- 245300's Lua and Manifest Created by Hubcap Manifest
-- Disney Epic Mickey 2
-- Created: September 29, 2025 at 07:57:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 13
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(245300) -- Disney Epic Mickey 2
-- MAIN APP DEPOTS
addappid(245301, 1, "87ea80e4349933db5545ae53cd3e8b10f652f69adbc7c5d60b225d4e367b8ef5") -- Depot 245301
setManifestid(245301, "5620192114644511610", 7636957424)
addappid(245302, 1, "9bd33d7aea605ce3a71620d46bfc427d760a23fee3457858c6f1a6ee22f982cb") -- Disney Epic Mickey 2 Polish Depot
setManifestid(245302, "4663958832663239932", 5646993805)
addappid(245303, 1, "4631e282b8c71f9c735a4db177f871132c5eb5872b2004941cd4de67dbf32294") -- Disney Epic Mickey 2 Czech Depot
setManifestid(245303, "6570762000028259729", 5646993805)
addappid(245304, 1, "10f7c34d446c66cac1de6c9b0efc78440583a75d84dc0668236054f30baf9b4b") -- Disney Epic Mickey 2 Greek Depot
setManifestid(245304, "3247982746952879157", 5646993805)
addappid(245305, 1, "750ce15e1230a4afd0b5333e5382c5becf22efc4b9bf4157d022bb7e76d42156") -- Disney Epic Mickey 2 Hungarian Depot
setManifestid(245305, "1041679507056829690", 5646993805)
addappid(245306, 1, "e00c50485ca0b3c29b7225684902ba69aee5c27a24a00f59d1f59ad01a9a0419") -- Disney Epic Mickey 2 Latin American Spanish Depot
setManifestid(245306, "8903828024437448156", 5780555726)
addappid(245307, 1, "63ecf7a0dd8b8038c75a17167d8d70223f2f41383aa298991ca407a17e215eba") -- Disney Epic Mickey 2 Portuguese Depot
setManifestid(245307, "1824008368870153198", 5780555726)
addappid(245308, 1, "e2b5fb0e6503435107c2d00fdec6a4eff2210be3e7d9c2a75a01ac16b319dc17") -- Disney Epic Mickey 2 Portuguese - Brazil Depot
setManifestid(245308, "1093710907528215330", 5780555726)
addappid(245309, 1, "a57a18d865500be01c36ed47471913a2f1b8ae53960f44641143d75e47b54cdc") -- Disney Epic Mickey 2 Dutch Depot
setManifestid(245309, "2522666737861713129", 5780555726)
addappid(245310, 1, "5505ce473e2e866ae22b9b18c7fc933d73ea31f1edff0cf5385df2f821cc4aa1") -- Disney Epic Mickey 2 Russian Depot
setManifestid(245310, "3873765018529461494", 5646993805)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)