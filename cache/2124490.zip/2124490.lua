-- 2124490's Lua and Manifest Created by Hubcap Manifest
-- SILENT HILL 2
-- Created: September 30, 2025 at 14:12:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 3
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2124490) -- SILENT HILL 2
addtoken(2124490, "2486523437417765568")
-- MAIN APP DEPOTS
addappid(2124491, 1, "1a14569bdc22983489a37bb81ed420c6230f43e84548d0ec0d4a3e9687861955") -- Depot 2124491
setManifestid(2124491, "4138456104249046245", 36320370348)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- SILENT HILL 2 - Artbook (AppID: 2951540)
addappid(2951540)
addtoken(2951540, "3447079396028723161")
addappid(2951541, 1, "e089852efbe924984e137b7c02cf0f4d4481f091625dd22b61be2e5ffd02b994") -- SILENT HILL 2 - Artbook - Depot 2951541
setManifestid(2951541, "4181790107554818304", 395073872)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3097490) -- SILENT HILL 2 - Mira Mask
addappid(3097500) -- SILENT HILL 2 - Pyramid Head Mask