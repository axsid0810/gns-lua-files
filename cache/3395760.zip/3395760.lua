-- 3395760's Lua and Manifest Created by Hubcap Manifest
-- With Me: Aquatic Time
-- Created: July 26, 2026 at 14:41:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3395760) -- With Me: Aquatic Time
-- MAIN APP DEPOTS
addappid(3395762, 1, "d84793ecd8b3d3b05c27fb8a2aaff698e810c7d46bc5274fec7acede353ac610") -- Depot 3395762
setManifestid(3395762, "2834895237636027541", 1500078788)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3395761) -- Depot 3395761 (empty depot)