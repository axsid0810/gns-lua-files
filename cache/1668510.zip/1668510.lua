-- 1668510's Lua and Manifest Created by Hubcap Manifest
-- The Legend of Heroes: Trails from Zero
-- Created: October 01, 2025 at 00:06:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1668510) -- The Legend of Heroes: Trails from Zero
-- MAIN APP DEPOTS
addappid(1668511, 1, "4dc7ce12681ff9fa9563d3ca8ab00f4da2c966d5b3d8973d37f1518080a8ae18") -- Depot 1668511
setManifestid(1668511, "1638008263236308289", 3908656278)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(2098610, 1, "221110e4ec72b935c1482c20763910e118019c0e7368284a8185cb11352f4644") -- Depot 2098610 (Shared from App 2098610)
setManifestid(2098610, "430895301975231520", 51956529)