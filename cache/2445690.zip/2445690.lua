-- 2445690's Lua and Manifest Created by Hubcap Manifest
-- Lost Castle 2
-- Created: July 22, 2026 at 02:29:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2445690, 1, "6e39d0da9d7ac3fbc396e7db8e789a71a59d33412790e89ff97fbf608ee82cae") -- Lost Castle 2
addtoken(2445690, "12154854772648009173")
-- MAIN APP DEPOTS
addappid(2445691, 1, "58aa213ce335109a11490383c49a406f0bb7a5c68f2844e33e7883c4e70dc1b3") -- Depot 2445691
setManifestid(2445691, "5646240053749413518", 1734049901)
addappid(2445695, 1, "91b6b4a727098238ce348dc1f01e054f447397b059c1523e79f9ebf765484d74") -- Depot 2445695
setManifestid(2445695, "5146805868056158134", 1734049901)
addappid(2445692, 1, "58dbbc802b67fc0b3afdbf2a15ca8c437ac3a2360fc39b5f8843ccd3df398229") -- Depot 2445692
setManifestid(2445692, "439689718053442064", 5110410396)