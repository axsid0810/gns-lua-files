-- 1696770's Lua and Manifest Created by Hubcap Manifest
-- The Mermaid Mask
-- Created: July 19, 2026 at 02:37:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1696770) -- The Mermaid Mask
-- MAIN APP DEPOTS
addappid(1696771, 1, "fe8c394e5098e92dd1509eb8ae1ffd5b8e70342a8362c81de25ca78ba6337164") -- Depot 1696771
setManifestid(1696771, "6103184600054159614", 1673780724)
addappid(1696772, 1, "5d8b7581bb9b5267ab2356a672d20806db442a01c03bc9d1270f29bdcea35557") -- Depot 1696772
setManifestid(1696772, "7855891727059641215", 1691903839)