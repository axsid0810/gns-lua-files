-- 298110's Lua and Manifest Created by Hubcap Manifest
-- Far Cry 4
-- Created: July 28, 2026 at 00:23:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 10
-- Total DLCs: 22 (1 excluded)
-- Shared Depots: 4
-- Blacklisted Depots: 1
--   Depot 298114: Blacklisted

-- MAIN APPLICATION
addappid(298110, 1, "86b92bbc40842cc480a3a99d81c185a4c05b1c15e0837a4cf7ee3ff79a9570a1") -- Far Cry 4
-- MAIN APP DEPOTS
addappid(298111, 1, "90765df7a812f66db8794bd7b41b398e9b12fe77ec22caaff1442644d2c2c91d") -- Far Cry 4 Content
setManifestid(298111, "1142172031228046975", 28906507623)
addappid(298112, 1, "4f2126199ab0506f24ed8517d6b0e0c2ecf3a5cf4adbb2e5b32efbf21f3bb2e8") -- Far Cry4 RUS
setManifestid(298112, "6331152839583468439", 7468794443)
addappid(298113, 1, "e524b5855fe79757f864359e1de9606d4a0ab23ecd59b79f2af270bd97f497c8") -- Far Cry4 WW
setManifestid(298113, "5328801845298185678", 7468794443)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "8936186649444731600", 264933784)
-- DLCS WITH DEDICATED DEPOTS
-- Far Cry 4 - Escape From Durgesh Prison - Content (AppID: 324341)
addappid(324341)
addappid(324341, 1, "0a4894abdd94b40c7464d6beced29025b9b2c3b1476d44fdff2697e82edb34a9") -- Far Cry 4 - Escape From Durgesh Prison - Content - Survivor Stories (324341) Depot
setManifestid(324341, "3810704983363922262", 2257196082)
-- Far Cry 4  Overrun (AppID: 324343)
addappid(324343)
addappid(324343, 1, "8bcb7ae406c8a5325315decbe096d6b0afecf265d66514a10a1fe242be970690") -- Far Cry 4  Overrun - PVP & Mode Pack (324343) Depot
setManifestid(324343, "8840893055567759529", 1120627795)
-- Far Cry 4 - Valley of the Yetis  (AppID: 324344)
addappid(324344)
addappid(324344, 1, "47c247776a41ae1192804e89b02b35c7567a9f87b280d3e49bab395db669e1da") -- Far Cry 4 - Valley of the Yetis  - Far Cry 4 - Valley of the Yetis  (324344) Depot
setManifestid(324344, "5351965743619922824", 2438744511)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(324342) -- Far Cry 4 - The Hurk Deluxe Pack
addtoken(324342, "8735670379144936627")
addappid(332220) -- Far Cry 4 Preorder (RoW) - Uplay Activation
addappid(332221) -- Far Cry 4 (RoW) - Uplay Activation
addappid(332222) -- Far Cry 4 Gold (RoW) - Uplay Activation
addappid(332223) -- Far Cry 4 Preorder (RU) - Uplay Activation
addappid(332224) -- Far Cry 4 (RU) - Uplay Activation
addappid(332225) -- Far Cry 4 Gold (RU) - Uplay Activation
addappid(332226) -- Far Cry 4 Preorder (JP) - Uplay Activation
addappid(332227) -- Far Cry 4  (JP) - Uplay Activation
addappid(332228) -- Far Cry 4 Gold (JP) - Uplay Activation
addappid(332229) -- Far Cry 4 Season Pass - Uplay Activation
addappid(332230) -- Far Cry 4 Preorder (IN) - Uplay Activation
addappid(332231) -- Far Cry 4 (IN) - Uplay Activation
addappid(332232) -- Far Cry 4 Gold (IN) - Uplay Activation
addappid(338620) -- Far Cry 4 - Escape From Durgesh Prison
addappid(343700) -- Far Cry 4 - Escape From Durgesh Prison - Uplay activation
addappid(345910) -- Far Cry 4 - The Hurk Deluxe Pack - Uplay Activation
addtoken(345910, "1406313721972257350")
addappid(348080) -- Far Cry 4 - overrun - Uplay activation
addappid(353870) -- Far Cry 4 - Valley of the Yetis - Uplay Activation
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(324340) -- DLC 324340 (unreleased)
-- addtoken(324340, "15952514768522473497")