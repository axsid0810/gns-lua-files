-- 3375780's Lua and Manifest Created by Hubcap Manifest
-- Trails in the Sky 1st Chapter
-- Created: July 10, 2026 at 03:35:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 68
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3375780, 1, "bb69428a93f3a7b88b803606d3061e0173fd3df42eaefa124db7523106f43120") -- Trails in the Sky 1st Chapter
-- MAIN APP DEPOTS
addappid(3375781, 1, "0f58b913db9e8303b7b0c78189e19de2f24e51201fc03f457c0f0901c17db7e6") -- Depot 3375781
setManifestid(3375781, "9142270500245299906", 34636359834)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3888320) -- Trails in the Sky 1st Chapter - Resort Style Swimsuits (Estelle  Joshua)
addappid(3888330) -- Trails in the Sky 1st Chapter - Jenis Royal Academy Uniform Set
addappid(3888340) -- Trails in the Sky 1st Chapter - Fine Red Diner Costume Set Vol. 1
addappid(3888350) -- Trails in the Sky 1st Chapter - Fine Red Diner Costume Set Vol. 2
addappid(3888360) -- Trails in the Sky 1st Chapter - Fine Red Diner Costume Set Vol. 3
addappid(3888370) -- Trails in the Sky 1st Chapter - Original Diner Costume Set Vol. 1
addappid(3888380) -- Trails in the Sky 1st Chapter - Original Diner Costume Set Vol. 2
addappid(3888390) -- Trails in the Sky 1st Chapter - Original Diner Costume Set Vol. 3
addappid(3888630) -- Trails in the Sky 1st Chapter - Glasses Set A
addappid(3888640) -- Trails in the Sky 1st Chapter - Glasses Set B
addappid(3888650) -- Trails in the Sky 1st Chapter - Trendy Headgear Set
addappid(3888670) -- Trails in the Sky 1st Chapter - Pom Pom Pal Set A
addappid(3888680) -- Trails in the Sky 1st Chapter - Pom Pom Pal Set B
addappid(3888690) -- Trails in the Sky 1st Chapter - Character Stand Set
addappid(3888700) -- Trails in the Sky 1st Chapter - Charming Backpack Set
addappid(3888710) -- Trails in the Sky 1st Chapter - Archangel Dress-up Set
addappid(3888720) -- Trails in the Sky 1st Chapter - Fallen Angel Dress-up Set
addappid(3888730) -- Trails in the Sky 1st Chapter - Demon King Dress-up Set
addappid(3888740) -- Trails in the Sky 1st Chapter - Exciting Effect set
addappid(3888750) -- Trails in the Sky 1st Chapter - Banner Set A
addappid(3888760) -- Trails in the Sky 1st Chapter - Banner Set B
addappid(3888840) -- Trails in the Sky 1st Chapter - Banner Set C
addappid(3888850) -- Trails in the Sky 1st Chapter - Two-Tone Hair Color Set
addappid(3888860) -- Trails in the Sky 1st Chapter - Unique Hair Color Set
addappid(3888870) -- Trails in the Sky 1st Chapter - Orbment Cover Set
addappid(3888880) -- Trails in the Sky 1st Chapter - Chibi Orbment Cover Set
addappid(3888930) -- Trails in the Sky 1st Chapter - Sepith Set 1
addappid(3888940) -- Trails in the Sky 1st Chapter - Sepith Set 2
addappid(3888950) -- Trails in the Sky 1st Chapter - Sepith Set 3
addappid(3888960) -- Trails in the Sky 1st Chapter - Sepith Set 4
addappid(3888970) -- Trails in the Sky 1st Chapter - Sepith Set 5
addappid(3888990) -- Trails in the Sky 1st Chapter - U-Material Set 1
addappid(3889000) -- Trails in the Sky 1st Chapter - U-Material Set 2
addappid(3889020) -- Trails in the Sky 1st Chapter - U-Material Set 3
addappid(3889030) -- Trails in the Sky 1st Chapter - U-Material Set 4
addappid(3889040) -- Trails in the Sky 1st Chapter - U-Material Set 5
addappid(3889050) -- Trails in the Sky 1st Chapter - Monster Ingredient Set A (1)
addappid(3889060) -- Trails in the Sky 1st Chapter - Monster Ingredient Set A (2)
addappid(3889070) -- Trails in the Sky 1st Chapter - Monster Ingredient Set A (3)
addappid(3889100) -- Trails in the Sky 1st Chapter - Monster Ingredient Set B (1)
addappid(3889110) -- Trails in the Sky 1st Chapter - Monster Ingredient Set B (2)
addappid(3889120) -- Trails in the Sky 1st Chapter - Monster Ingredient Set B (3)
addappid(3889130) -- Trails in the Sky 1st Chapter - Advanced Healing Set 1
addappid(3889140) -- Trails in the Sky 1st Chapter - Advanced Healing Set 2
addappid(3889150) -- Trails in the Sky 1st Chapter - Advanced Healing Set 3
addappid(3889160) -- Trails in the Sky 1st Chapter - Advanced Healing Set 4
addappid(3889170) -- Trails in the Sky 1st Chapter - Advanced Healing Set 5
addappid(3889180) -- Trails in the Sky 1st Chapter - Zeram Powder Set 1
addappid(3889190) -- Trails in the Sky 1st Chapter - Zeram Powder Set 2
addappid(3889200) -- Trails in the Sky 1st Chapter - Zeram Powder Set 3
addappid(3889210) -- Trails in the Sky 1st Chapter - Zeram Capsule Set 1
addappid(3889220) -- Trails in the Sky 1st Chapter - Zeram Capsule Set 2
addappid(3889230) -- Trails in the Sky 1st Chapter - Zeram Capsule Set 3
addappid(3889240) -- Trails in the Sky 1st Chapter - G-Pom Fruit Set 1
addappid(3889250) -- Trails in the Sky 1st Chapter - G-Pom Fruit Set 2
addappid(3889260) -- Trails in the Sky 1st Chapter - G-Pom Fruit Set 3
addappid(3889310) -- Trails in the Sky 1st Chapter - G-Pom Fruit Value Set 1
addappid(3889320) -- Trails in the Sky 1st Chapter - G-Pom Fruit Value Set 2
addappid(3889330) -- Trails in the Sky 1st Chapter - G-Pom Fruit Value Set 3
addappid(3889340) -- Trails in the Sky 1st Chapter - Droplet Set 1
addappid(3889350) -- Trails in the Sky 1st Chapter - Droplet Set 2
addappid(3889360) -- Trails in the Sky 1st Chapter - Droplet Set 3
addappid(3889370) -- Trails in the Sky 1st Chapter - Battle Boost Item Pack Physical
addappid(3889380) -- Trails in the Sky 1st Chapter - Battle Boost Item Pack Magical
addappid(3889390) -- Trails in the Sky 1st Chapter - Free Sample Set Vol.1
addappid(3889400) -- Trails in the Sky 1st Chapter - Free Sample Set Vol.2
addappid(3889410) -- Trails in the Sky 1st Chapter - Free Sample Set Vol.3
addappid(4014990) -- Trails in the Sky 1st Chapter Season Pass