-- 12140's Lua and Manifest Created by Hubcap Manifest
-- Max Payne
-- Created: September 30, 2025 at 00:02:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(12140) -- Max Payne
-- MAIN APP DEPOTS
addappid(12141, 1, "852706f81744732c81de6bb29ee0c7bde48941cbdde1b270c0def608d8414827") -- Max Payne content
setManifestid(12141, "7156053368726620038", 831157520)