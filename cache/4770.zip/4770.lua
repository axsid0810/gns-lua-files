-- 4770's Lua and Manifest Created by Hubcap Manifest
-- Rome: Total War - Alexander
-- Created: September 30, 2025 at 11:09:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4770) -- Rome: Total War - Alexander
-- MAIN APP DEPOTS
addappid(4777, 1, "2b2d209e89275ae0d6c3a1a6ff1383d6a94d8d6f1c1f29e6951bac2770701988") -- Rome Total War Alexander Content2
setManifestid(4777, "3081618763268005219", 1896128192)
addappid(4776, 1, "70a59fe98c29d0c5f4ef8f89965bb497feefafa8a7a064cba96bacffde569cfb") -- Rome Total War Alexander Content1
setManifestid(4776, "4521753898994600882", 640567678)
addappid(4771, 1, "9d878746638b93ef7698b691c660788c5c81f8ecf37b0ee6089240b3000c9c36") -- Rome Total War Alexander Main
setManifestid(4771, "816321877088450201", 484489438)
addappid(4772, 1, "eb25f48957161a082bc95fb862d8dbfb181863a92ac48e0d506654cc99dc7c50") -- Rome: Total War - Alexander French
setManifestid(4772, "6731434196672402628", 126915664)
addappid(4773, 1, "05d29577534e1b602f2ef2a86fc8662e3f4e8d7420ea55b471906419a9b583d8") -- Rome: Total War - Alexander German
setManifestid(4773, "8745608202913813399", 127112676)
addappid(4774, 1, "f563e2dc3652f0eb473834ab7d0f4fcd19baef10c04ed31177a1f788fa3e0291") -- Rome: Total War - Alexander Italian
setManifestid(4774, "2831624220518376374", 5994614)
addappid(4775, 1, "a67bcd40acda049e74a4d2c2e1ca5f39146625b48e2e6cb81eadd2c450381d5d") -- Rome: Total War - Alexander Spanish
setManifestid(4775, "2683209155086849801", 5908886)