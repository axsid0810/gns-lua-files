-- 2244800's Lua and Manifest Created by Hubcap Manifest
-- Force of Nature 2: Prologue
-- Created: September 29, 2025 at 13:03:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2244800) -- Force of Nature 2: Prologue
-- MAIN APP DEPOTS
addappid(2244801, 1, "13f0ea930820b8fd67d96f0991c87b325088a0b894266eaeaaba1ecd2a46d20a") -- Depot 2244801
setManifestid(2244801, "7076951813763569090", 1266258945)