-- 838350's Lua and Manifest Created by Hubcap Manifest
-- The Scroll of Taiwu : Beyond The Dome
-- Created: July 22, 2026 at 13:25:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 13
-- Total DLCs: 10
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(838350, 1, "bf086ed374abbdc30220a8965af14256dd7f48cb48cfe8f47d4f1eaedc79fd2e") -- The Scroll of Taiwu : Beyond The Dome
addtoken(838350, "15146427787086570964")
-- MAIN APP DEPOTS
addappid(838351, 1, "7de3577779d63fd52db715a1898f8353eb0f5f4096ab3391f77b582621e1adb8") -- The Scroll Of Taiwu Alpha
setManifestid(838351, "3974370830506926021", 17380807546)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- Scroll Of Taiwu - OST (AppID: 946970)
addappid(946970)
addtoken(946970, "5933735890991512877")
addappid(946970, 1, "6eb479723fd905892e55add18fe531a67b7e3c42595302faa5685e47fd7603c3") -- Scroll Of Taiwu - OST - Scroll Of Taiwu - OST (946970) 个 Depot
setManifestid(946970, "2089095199798162434", 1208029130)
-- Scroll Of Taiwu -  (AppID: 2172690)
addappid(2172690)
addtoken(2172690, "7035753016401393565")
addappid(2172690, 1, "e456ab9135bdfdaae17d9235af62db550990ed406c0f7e116fe237793c0b3cd0") -- Scroll Of Taiwu -  - Depot 2172690
setManifestid(2172690, "5595148215465884713", 3495999)
-- Scroll Of Taiwu -  (AppID: 2241120)
addappid(2241120)
addtoken(2241120, "1649741745593958494")
addappid(2241120, 1, "306f5087d837883ad86f8b4feb42058723cbb7b7701724c3bb2098df278272d1") -- Scroll Of Taiwu -  - Depot 2241120
setManifestid(2241120, "8929325035393384592", 10448296)
-- Scroll Of Taiwu -  (AppID: 2764950)
addappid(2764950)
addtoken(2764950, "9097792362658511678")
addappid(2764950, 1, "c4c231a528c0f4c95a95fceae57a4530982bd307bd8f07c47070e4a7adebff0b") -- Scroll Of Taiwu -  - Depot 2764950
setManifestid(2764950, "6279348019110604381", 563147039)
-- Scroll Of Taiwu -  (AppID: 2764960)
addappid(2764960)
addtoken(2764960, "10039634942498841467")
addappid(2764960, 1, "00140a77be9fb80581f68904948537eb5ba3ca04ffc9b2c024d128d98cbf9365") -- Scroll Of Taiwu -  - Depot 2764960
setManifestid(2764960, "4096172026402743863", 4572294)
-- Scroll Of Taiwu -  (AppID: 3464590)
addappid(3464590)
addtoken(3464590, "17260488847850872888")
addappid(3464590, 1, "34a15558cad10dbf91bbb3f82e56f56bfdce3e80ca105b90fb69296f4c94d94f") -- Scroll Of Taiwu -  - Depot 3464590
setManifestid(3464590, "2170511017358734763", 36742841)
-- Scroll Of Taiwu -  (AppID: 4395170)
addappid(4395170)
addappid(4395170, 1, "32426e879f3458c36c7827712232c988b375f53b006c967cade6b279b82719f8") -- Scroll Of Taiwu -  - Depot 4395170
setManifestid(4395170, "8007211957462256197", 2761268)
addappid(4395171, 1, "cd96a820b2c9245d21083263f9571fc227fd0fd087dd6abf6f5b740f2ce6ce47") -- Scroll Of Taiwu -  - Depot 4395171
setManifestid(4395171, "1524556137220967800", 5488147)
-- Scroll Of Taiwu -  (AppID: 4528730)
addappid(4528730)
addappid(4528730, 1, "011923e062968acb50f9d2a992c286143858510fc261adedbc079513df981791") -- Scroll Of Taiwu -  - Depot 4528730
setManifestid(4528730, "1577961997428892256", 200511279)
-- Scroll Of Taiwu -  (AppID: 4834440)
addappid(4834440)
addappid(4834440, 1, "f8e3794187a1e35aa42731bcea4507938766a7d8a75db3ca6c73e0a0dfb83ece") -- Scroll Of Taiwu -  - Depot 4834440
setManifestid(4834440, "8000202654872660640", 4623697)
-- Scroll Of Taiwu -  (AppID: 4834450)
addappid(4834450)
addappid(4834450, 1, "8ff4143536007a730a9eb1deb44329ab822ca0b193ce85943b230cf658929096") -- Scroll Of Taiwu -  - Depot 4834450
setManifestid(4834450, "2229522987610810242", 8560522)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2172691) -- Depot 2172691 (empty depot)
-- addappid(4395170) -- Depot 4395170 (empty depot)