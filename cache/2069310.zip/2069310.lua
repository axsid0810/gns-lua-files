-- 2069310's Lua and Manifest Created by Hubcap Manifest
-- RealFlight Evolution
-- Created: July 12, 2026 at 20:58:06 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 81
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2069310, 1, "6cf246ab832fbcc8f4fd473253f2d4d59788b5654467a20db7227c16dfdcfed3") -- RealFlight Evolution
-- MAIN APP DEPOTS
addappid(2069311, 1, "f7c10cf67e59ca711014eb225bff0dd5b23321981134b4a51f54d255632bab00") -- Depot 2069311
setManifestid(2069311, "914531402762009269", 17101940478)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2253010) -- RealFlight Evolution - E-flite Eratix 3D Flat Foamy 860mm
addappid(2253120) -- RealFlight Evolution - E-flite Beechcraft D18 1.5m
addappid(2253121) -- RealFlight Evolution - E-flite UMX P-51D Voodoo
addappid(2253122) -- RealFlight Evolution - E-flite UMX Twin Otter
addappid(2253123) -- RealFlight Evolution - RealFlight 676 NG Airliner
addappid(2253124) -- RealFlight Evolution - E-flite F4U-4 Corsair 1.2m
addappid(2377650) -- RealFlight Evolution - E-flite Slow Ultra Stick 1.2m
addappid(2385000) -- RealFlight Evolution - E-flite P-51D Mustang 1.2m
addappid(2385001) -- RealFlight Evolution - E-flite Carbon-Z T-28 Trojan 2.0m
addappid(2385002) -- RealFlight Evolution - E-flite UMX Turbo Timber Evolution
addappid(2385130) -- RealFlight Evolution - Triple Tree Electric Flightline
addappid(2396270) -- RealFlight Evolution - Hangar 9 Aermacchi MB-339 60-85N Turbine
addappid(2396271) -- RealFlight Evolution - E-flite Twin Timber 1.6m
addappid(2396280) -- RealFlight Evolution - E-flite P-47 Razorback 1.2m
addappid(2396281) -- RealFlight Evolution - E-flite UMX Air Tractor
addappid(2396282) -- RealFlight Evolution - Hangar 9 Pawnee Brave 20cc
addappid(2396283) -- RealFlight Evolution - E-flite Ultimate 3D 950mm
addappid(2396284) -- RealFlight Evolution - Cirrus Vision SF50
addappid(2396285) -- RealFlight Evolution - E-flite EC-1500 Twin 1.5m (updated for 2023)
addappid(2396286) -- RealFlight Evolution - E-flite Carbon-Z Cub SS 2.1m
addappid(2396287) -- RealFlight Evolution - E-flite Ultra Stick SWS (Sport Wood Series) 1.1m
addappid(2396288) -- RealFlight Evolution - Triple Tree 3D Flight Line
addappid(2417210) -- RealFlight Evolution - 2023 Year Content Pass
addappid(2759290) -- RealFlight Evolution - E-flite Air Tractor 1.5m
addappid(2759300) -- RealFlight Evolution - ViperJet
addappid(2759310) -- RealFlight Evolution - E-flite Valiant 1.3m
addappid(2759320) -- RealFlight Evolution - E-flite Commander mPd 1.4m
addappid(2759330) -- RealFlight Evolution - E-flite UMX Waco
addappid(2759340) -- RealFlight Evolution - Tower Hobbies ASW-28
addappid(2759350) -- RealFlight Evolution - E-flite Turbo Timber SWS 2.0m
addappid(2759360) -- RealFlight Evolution - Blade Eclipse 360
addappid(2759370) -- RealFlight Evolution - E-flite Cherokee 1.3m
addappid(2759380) -- RealFlight Evolution - E-flite UMX Conscendo
addappid(2759390) -- RealFlight Evolution - E-flite Super Timber 1.7m
addappid(2759400) -- RealFlight Evolution - Hangar 9 Aermacchi MB-339 60-86N Scale Military Turbine
addappid(2759410) -- RealFlight Evolution - E-flite UMX P-51D Mustang Detroit Miss
addappid(2759420) -- RealFlight Evolution - E-flite UMX F-86 Sabre 30mm EDF
addappid(2759430) -- RealFlight Evolution - E-flite Decathlon RJG 1.2m
addappid(2759440) -- RealFlight Evolution - E-flite Micro DRACO 800mm
addappid(2759450) -- RealFlight Evolution - E-flite Extra 330 SC 1.3m
addappid(2759460) -- RealFlight Evolution - E-flite UMX Me 262 Twin 30mm EDF
addappid(2759470) -- RealFlight Evolution - E-flite Viper 64mm EDF
addappid(2759480) -- RealFlight Evolution - Hangar 9 OV-10 Bronco 20cc
addappid(2759490) -- RealFlight Evolution - Triple Tree Float Flight Line
addappid(2759500) -- RealFlight Evolution - AMA Flying Site 1
addappid(2782000) -- RealFlight Evolution - 2024 Year Content Pass
addappid(3482920) -- RealFlight Evolution  Hangar 9 J-3 Cub 10cc
addappid(3482930) -- RealFlight Evolution  Tower Hobbies Seawind 1.4m
addappid(3482940) -- RealFlight Evolution  E-flite P-51D Mustang 1.0m
addappid(3482950) -- RealFlight Evolution  E-flite S.E.5a 900mm
addappid(3482960) -- RealFlight Evolution  E-flite Sportix 1.1m
addappid(3482970) -- RealFlight Evolution  E-flite UMX Cirrus SR22T
addappid(3482980) -- RealFlight Evolution  E-flite Habu XS 80mm EDF
addappid(3482990) -- RealFlight Evolution  E-flite 4-Site 3D FF Flat Foamy 800mm
addappid(3483000) -- RealFlight Evolution  E-flite ElectroStreak 1.1m
addappid(3483010) -- RealFlight Evolution  Flying Saucer (UFO)
addappid(3483030) -- RealFlight Evolution  William Bennett Airfield
addappid(3483040) -- RealFlight Evolution  E-flite DHC-6 Twin Otter 1.4m
addappid(3483050) -- RealFlight Evolution  Hangar 9 Clipped-Wing Cub 10cc
addappid(3483060) -- RealFlight Evolution  Blade Eclipse 360 Coast Guard
addappid(3483070) -- RealFlight Evolution  E-flite Micro B-2 Spirit of America Twin 30mm EDF 
addappid(3483080) -- RealFlight Evolution  HobbyZone Champ Anniversary Special Edition 515mm
addappid(3483090) -- RealFlight Evolution  Zipper
addappid(3483100) -- RealFlight Evolution - E-flite Eratix 3D SWS 1.6m
addappid(3483110) -- RealFlight Evolution - E-flite Micro Scrappy 800mm
addappid(3483120) -- RealFlight Evolution - E-flite SNJ-5 (AT-6 Texan) 1.5m
addappid(3483130) -- RealFlight Evolution - HardVector
addappid(3483140) -- RealFlight Evolution - Willie McCool Field
addappid(3483210) -- RealFlight Evolution - 2025 Year Content Pass
addappid(4342910) -- RealFlight Evolution - E-flite Beechcraft RC-45J 1.5m
addappid(4342920) -- RealFlight Evolution - E-flite Timber 10-year Anniversary Edition 1.5m
addappid(4342930) -- RealFlight Evolution - E-flite Gee Bee R-2 1.0m
addappid(4342940) -- RealFlight Evolution - E-flite UMX Eratix 3D FF 450mm
addappid(4342950) -- RealFlight Evolution - E-flite UMX Viper 30mm EDF
addappid(4342960) -- RealFlight Evolution - Koi (F3P-A)
addappid(4342980) -- RealFlight Evolution - E-flite Conscendo 2.0m
addappid(4342990) -- RealFlight Evolution - E-flite Super Decathlon 1.2m
addappid(4343000) -- RealFlight Evolution - E-flite UMX Gee Bee R-2 510mm
addappid(4343010) -- RealFlight Evolution - E-flite V1200 1.2m
addappid(4343020) -- RealFlight Evolution - Las Vegas Soaring Club
addappid(4343140) -- RealFlight Evolution - 2026 Year Content Pass