-- 1919590's Lua and Manifest Created by Hubcap Manifest
-- NBA 2K23
-- Created: September 30, 2025 at 03:00:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 5
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1919590) -- NBA 2K23
-- MAIN APP DEPOTS
addappid(1919591, 1, "9a413d95948077bb749d1ac87416be4b6b0da6b5f64ad460fd8afe1dd4897f1e") -- Depot 1919591
setManifestid(1919591, "5390652279031895565", 146110714492)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2074590) -- NBA 2K23 - Championship Edition Content Pack
addappid(2074591) -- NBA 2K23 - Preorder Bonus
addappid(2074592) -- NBA 2K23 - Michael Jordan Edition Content Pack
addappid(2074593) -- NBA 2K23 - Championship Edition Content Pack (Benelux)
addappid(2074594) -- NBA 2K23 - Michael Jordan Edition Content Pack (Benelux)