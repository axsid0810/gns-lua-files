-- 220440's Lua and Manifest Created by Hubcap Manifest
-- DmC Devil May Cry
-- Created: July 21, 2026 at 10:16:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 6

-- MAIN APPLICATION
addappid(220440, 1, "ad3b61b0282021130ef0e0bb285ae81aacee2037f79c872d2c7e43264c577c79") -- DmC Devil May Cry
-- MAIN APP DEPOTS
addappid(220441, 1, "aed2b190f9b8ea15e6f1e22aed2d339f162f17b8673f06124dd11e1ea45b11be") -- DmC Devil May Cry Content
setManifestid(220441, "8660867655925405335", 8992366096)
addappid(220442, 1, "390e4902a68f3b732b8e42fe6fe3ccea44c54c19421e21eaa9860842c26fa973") -- DmC Devil May Cry Content LV
setManifestid(220442, "8284177927415320138", 8988743391)
addappid(229081, 1, "85accb2533445a97fdcf566a1f96bbe3ec7d410be61ff03b62ec2007c6febd47") -- DmC Devil may Cry BloodyPalaceDLC LV
setManifestid(229081, "8118783175340038989", 293227948)
-- DLCS WITH DEDICATED DEPOTS
-- DmC Devil May Cry Costume Pack (AppID: 223790)
addappid(223790)
addappid(223790, 1, "84ed6b57c32b4629f5cc2274674cb95f00d4b65d067170bb9a2f0ba4ffbd76a6") -- DmC Devil May Cry Costume Pack - DmC Devil May Cry DanteOryginalDLC
setManifestid(223790, "7654700979379588386", 77840998)
-- DmC Devil May Cry Weapon Bundle (AppID: 223792)
addappid(223792)
addappid(223792, 1, "8ca028cec8d61d9c12f8ea45f546d2c50f66aa8a2ddbda601a042ab68e909b0a") -- DmC Devil May Cry Weapon Bundle - DmC Devil May Cry WeaponsBundleDLC
setManifestid(223792, "5445163040217040808", 110789004)
-- DmC Devil May Cry Vergils Downfall (AppID: 223793)
addappid(223793)
addappid(223793, 1, "e839ea49e739fb933e04b272dedc90509e470ad48ad698e48433772c64ef86fd") -- DmC Devil May Cry Vergils Downfall - DmC Devil May Cry VergilsDownfallDLC WW
setManifestid(223793, "4639589247481781479", 2146302453)
-- DmC Devil May Cry Vergils Downfall (Japan) (AppID: 223794)
addappid(223794)
addtoken(223794, "4992299147804608241")
addappid(223794, 1, "770976d9313911624d8e4af965dbf09742bbb2388f6838e9071f34468f33c0e9") -- DmC Devil May Cry Vergils Downfall (Japan) - DmC Devil May Cry VergilsDownfallDLC LV
setManifestid(223794, "957085678202193145", 2146219383)
-- DmC Devil May Cry Bloody Palace Mode (AppID: 229080)
addappid(229080)
addappid(229080, 1, "2d5f510f44b55ffd17e3fe6d09bba6d2751544fd151293553fa4466dea0660ef") -- DmC Devil May Cry Bloody Palace Mode - Dmc Devil May Cry BloodyPalaceDLC WW
setManifestid(229080, "1173515098563360562", 293293359)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(223791) -- DmC Devil May Cry Golden Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(223791) -- Depot 223791 (empty depot)