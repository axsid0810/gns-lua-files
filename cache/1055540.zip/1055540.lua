-- 1055540's Lua and Manifest Created by Hubcap Manifest
-- A Short Hike
-- Created: November 26, 2025 at 08:05:38 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1055540) -- A Short Hike
-- MAIN APP DEPOTS
addappid(1055541, 1, "357f3583b508bf2b30b0ef89c3473521718cbc8b93c0c54310a4c47c8d15bdf2") -- A Short Hike Windows
setManifestid(1055541, "8994416012488509370", 331636934)
addappid(1055542, 1, "bf61fb6ad4ff0581ec0c16d2c5682ad3440abd78d64bd9d78f541b8c58049d1e") -- A Short Hike OSX
setManifestid(1055542, "8544185365233604858", 364224026)
addappid(1055543, 1, "f18ee22cbd474dc50d6ca97b6661b3d912dd2d6157eedefa3e8ae2efdb30c65e") -- A Short Hike Linux
setManifestid(1055543, "149383706910377774", 342354393)