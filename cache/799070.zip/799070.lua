-- 799070's Lua and Manifest Created by Hubcap Manifest
-- Zup! 8
-- Created: October 01, 2025 at 09:26:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(799070) -- Zup! 8
-- MAIN APP DEPOTS
addappid(799071, 1, "80277edc6cd9398594f05b5e2a931af10cb032000cf074d71634ee37b10b792f") -- Zup! 8 Content
setManifestid(799071, "6454356020286271836", 21199624)