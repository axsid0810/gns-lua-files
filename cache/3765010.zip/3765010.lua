-- 3765010's Lua and Manifest Created by Hubcap Manifest
-- Forensics: Crime Scene Detective
-- Created: July 23, 2026 at 15:07:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3765010) -- Forensics: Crime Scene Detective
-- MAIN APP DEPOTS
addappid(3765011, 1, "862296624beb296f31c01dfabcf03e1cd32a053be26dfb9d894a0ff8a084435c") -- Depot 3765011
setManifestid(3765011, "6471415682638933441", 12970161402)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)