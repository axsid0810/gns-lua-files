-- 2996040's Lua and Manifest Created by Hubcap Manifest
-- Teenage Mutant Ninja Turtles: Splintered Fate
-- Created: March 26, 2026 at 13:54:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 4
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2996040, 1, "96891d9b2870a84c54bb996262f721b1299c79885486e6feb249653388a2d127") -- Teenage Mutant Ninja Turtles: Splintered Fate
-- MAIN APP DEPOTS
addappid(2996041, 1, "e93c99408425422103d746643c24b3bc8c717cd5110c9f0b876225db50cc6671") -- Depot 2996041
setManifestid(2996041, "6298699032273826769", 2025741707)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- TMNT Splintered Fate - Artbook (AppID: 3255900)
addappid(3255900)
addappid(3255900, 1, "200f77802a15d4f75f7441e2bb4dbbdbd90e6419e42bd8e66715b12bb0452284") -- TMNT Splintered Fate - Artbook - Depot 3255900
setManifestid(3255900, "4587529972681717957", 545320540)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3316670) -- TMNT Splintered Fate - Casey Jones  the Junkyard Jam
addappid(3784190) -- TMNT Splintered Fate - Metalhead
addappid(4152390) -- TMNT Splintered Fate - Alopex