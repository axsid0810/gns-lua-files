-- 2825530's Lua and Manifest Created by Hubcap Manifest
-- Beholder: Conductor
-- Created: December 03, 2025 at 04:21:49 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2825530) -- Beholder: Conductor
-- MAIN APP DEPOTS
addappid(2825531, 1, "9c431873f776d9053638ad83bb819f7f4b0333e29467bca05809f8ca19e1aec9") -- Depot 2825531
setManifestid(2825531, "2040021488576746940", 5745670874)
addappid(2825532, 1, "0e6189a6df541346ac276e66d2f4e0f555a9508be96255cb06fbd42df6d0c06f") -- Depot 2825532
setManifestid(2825532, "1980214402854427152", 5833691730)