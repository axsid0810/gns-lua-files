-- 238320's Lua and Manifest Created by Hubcap Manifest
-- Outlast
-- Created: September 30, 2025 at 05:22:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(238320) -- Outlast
-- MAIN APP DEPOTS
addappid(238321, 1, "4c6dde66a11fc24f39a7e16c0fd5027be8d4227e91867538aef8ee186568ec3a") -- Outlast
setManifestid(238321, "8070241010372854777", 3996301793)
addappid(238322, 1, "d9563699204b1071d794df59950c02ee46497d4f9db36c461fa39114bdf0b859") -- Outlast Linux
setManifestid(238322, "917611862989775609", 3516931680)
addappid(238323, 1, "9c0f4b149e80ddf49aa848fe86a8c58dbbdac73fc55870b945ccc74eafd4b7ec") -- Outlast Mac
setManifestid(238323, "3317545544496803274", 3401037827)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Outlast Whistleblower DLC (AppID: 273300)
addappid(273300)
addappid(273300, 1, "ef20a5f980c8264317c95f217597a95cda9dd8e0de23d66237b0374e1b3b4b19") -- Outlast Whistleblower DLC - Outlast: Whistleblower DLC (273300) Depot
setManifestid(273300, "7518923783983972229", 2304427255)
addappid(238324, 1, "a533af71b69ecc9802e5288c39a3b94942a1e844f2584a8b2d49144fbaa2d3e4") -- Outlast Whistleblower DLC - Outlast: Whistleblower DLC Mac
setManifestid(238324, "44073114614687821", 2400089006)
addappid(238325, 1, "2c90d8d88b5e11e438bf6f0f794fa08da92101921cb4bdc2dfc072cd7348a1c7") -- Outlast Whistleblower DLC - Outlast: Whistleblower DLC Linux
setManifestid(238325, "1733128563364132694", 2402469605)