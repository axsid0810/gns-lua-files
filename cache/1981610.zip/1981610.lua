-- 1981610's Lua and Manifest Created by Hubcap Manifest
-- Wanted: Dead
-- Created: June 06, 2026 at 20:57:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1981610, 1, "fe71803ddc95608c47e32b72369e757b066a82ee94884e5cdeec050c005e9b2a") -- Wanted: Dead
-- MAIN APP DEPOTS
addappid(1981611, 1, "971d000cf3b857bf1088d03afb8fb9722e61691687b5eca11f2444d52f7b0230") -- Depot 1981611
setManifestid(1981611, "3941592613671372508", 35797938749)
addappid(1981612, 1, "26ecb7650c060f90017a65afb157318e37ceb0b10ea70110a3fcf5bacc5e08bd") -- Depot 1981612
setManifestid(1981612, "2309712034724339526", 35797938749)
addappid(1981613, 1, "d017ed7f9e3465bfa8112af21e8e0b906ee849f8159aa39a733524583035fa32") -- Depot 1981613
setManifestid(1981613, "2859973517997269916", 35797938749)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)