-- 469600's Lua and Manifest Created by Hubcap Manifest
-- Legion TD 2
-- Created: July 28, 2026 at 09:41:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 2
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(469600, 1, "553eb0c28cd0bfb84d75a9759a198ff361379a5a6b6955af65fd95372c1aa3b2") -- Legion TD 2
-- MAIN APP DEPOTS
addappid(469606, 1, "8b591e56a834f70ff1bf49b14b99e2c490adca60ee83a708449f01edab91a597") -- Legion TD 2 Alpha Win64
setManifestid(469606, "8092242896146753151", 2452198848)
addappid(469607, 1, "ef467d7153533cc467dc641f921c9274318d344d3e47b1e58160a96a2ce46b6d") -- Legion TD 2 Alpha Win32
setManifestid(469607, "9188699719218773297", 0)
addappid(469608, 1, "392006f5e4e2964f66056341e4f8cc8a45b3d9c85ee44f5ea0629153f2c6768e") -- Legion TD 2 Alpha OSX_Both
setManifestid(469608, "7161654492799964770", 2498525214)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- .NET 3.5 Client Profile Redist (Shared from App 228980)
setManifestid(229001, "4049573910112143457", 267964564)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(562150) -- Legion TD 2 - Floating Isles Campaign
addappid(2162190) -- Legion TD 2 - Desert Ridge Campaign