-- 435150's Lua and Manifest Created by Hubcap Manifest
-- Divinity: Original Sin 2
-- Created: September 29, 2025 at 08:06:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 38
-- Total DLCs: 3
-- Shared Depots: 6

-- MAIN APPLICATION
addappid(435150, 1, "36f9f932ad9495a9e1358408f770dfb10ff6e0c4dd8812c0045a0683bf42b727") -- Divinity: Original Sin 2
-- MAIN APP DEPOTS
addappid(435151, 1, "731b65041709394cb1f07351b745a8582a26c6a48fd7592345ad3d7392a88c66") -- Divinity: Original Sin 2 Content
setManifestid(435151, "5526106730905574720", 63064987639)
addappid(435152, 1, "be7d3052ffc21759a57ada371dafb080ff9c26c4070a5da11d100c607d98191f") -- English
setManifestid(435152, "7844138143823902363", 5909968)
addappid(435153, 1, "b63092b30c4cb490ff898351cfdbcef8ab7b32e1edf5da081ea5e9a327fd5ac8") -- French
setManifestid(435153, "898309843669454558", 6398755)
addappid(435154, 1, "87144192bf22bcf74422adca1f357d4c1102fc638be9b8d2d289c0b4bef54d7f") -- German
setManifestid(435154, "8440673381907628140", 6172389)
addappid(435156, 1, "8c6e57b48a2eba3cfa9170f1d4cc7ce491f86106ca34c992f168c36ba4eef93d") -- Russian
setManifestid(435156, "272792910353549608", 6794792)
addappid(435157, 1, "a73781f92d96ac5df944507301eb62595937f51bf0669209300997f00886ebd4") -- Polish
setManifestid(435157, "8512792953585930507", 6729574)
addappid(435158, 1, "25ffb0c88d875f485d0b69b122810bf6cc4f74f61cbbb78f5ddfa3af21a279e7") -- Spanish
setManifestid(435158, "6679982511610710072", 6348841)
addappid(435159, 1, "7fa1164b8b403927a084a81acf4b73b80ec6708e91749453f582cc8838fa6f1b") -- Chinese
setManifestid(435159, "4582105655470292204", 67634799)
addappid(435155, 1, "5b11c44d59c38cd1dc5f7da417d1fc1e46a1f55b7f8e5f4cae1237bf9c9aa4fe") -- ChineseTrad
setManifestid(435155, "7986547804666186874", 67634810)
addappid(715951, 1, "f9686d54f18a34d655d689716cfa70663657c8a0766cd8d240620391f19d4bcd") -- Divinity: Original Sin 2 OSX Base
setManifestid(715951, "4900955953097048158", 20977923018)
addappid(715952, 1, "d7e9b2867e7552c1506a65de46db0e274ac3c25657084c60d606a6c0bb558265") -- OSX English
setManifestid(715952, "191086137175570855", 558)
addappid(715953, 1, "56c9dda8024a972b1c992a6514fca761618acdd2f733ac04af1e3f779c165710") -- OSX French
setManifestid(715953, "384327680541339692", 572)
addappid(715954, 1, "b443dbb4362b5804df1fba7df780608b2958e3601114d3e4f63736a4c9a8f3c9") -- OSX German
setManifestid(715954, "281910266379371786", 572)
addappid(715955, 1, "3ef66aa31a94675d8fcd7ca0fa62b70e2c7ae227b3c070a02862b0c174ba26d5") -- OSX Russian
setManifestid(715955, "297051897148922143", 573)
addappid(715956, 1, "fe75268ba447d4eb592a59307db8b65b4d2a67289a87f7974a838c80186bdec6") -- OSX Polish
setManifestid(715956, "287289462677585446", 572)
addappid(715957, 1, "7f88d374a9884a2e7d3849c855490c599965463e1dfad6cc28a06fa19705fe82") -- OSX Spanish
setManifestid(715957, "128656930160567689", 573)
addappid(715958, 1, "c2e1a38cecb069e95f582a15b02fff230d5578d304a4a22b20e90a705c87d123") -- OSX Chinese
setManifestid(715958, "514406504296112177", 573)
addappid(715959, 1, "a8fd67532b287524f8453b36459a678b019abb085d7dc67599250eadcd358c35") -- OSX ChineseTrad
setManifestid(715959, "50363199820375883", 584)
addappid(717551, 1, "b95a60c816ca2c2cb995130a95882ecd4553c9d5120230e2d4491fd28d1f1f75") -- Italian
setManifestid(717551, "331726181868903248", 1151)
addappid(717552, 1, "1052ee6d1d2429250e0f5bd0c623833f4a7748f0644e5dd5cb6c84c7af73982e") -- OSX Italian
setManifestid(717552, "6171371540709802965", 573)
addappid(717553, 1, "479cb187236a388eba52dcfe8beecfb3be6370b0d3371fc1a16bcfbdd131c7ba") -- Korean
setManifestid(717553, "256771194908993499", 5909967)
addappid(717554, 1, "6548fa589ca22ce66aaff0d9525031845754131df78c57fe75fe642767b5367c") -- OSX Korean
setManifestid(717554, "8112563861675773573", 572)
addappid(717555, 1, "6be75f4bee9f78f7dc0a997c3f2acbc063bb0ca15964e4ca6089fb9520cb1604") -- Japanese
setManifestid(717555, "552251443734899993", 1152)
addappid(717556, 1, "958316e838b59a8438208d3d6fb11e6c2f23a289648ac2304b77cd0635f31c44") -- OSX Japanese
setManifestid(717556, "1787077817699102212", 574)
addappid(717557, 1, "5199983e4ec87bd03be412bd3ad97ed78cdb2d2a6760ffef87167e4304e45c07") -- Czech
setManifestid(717557, "2412196533632667477", 571)
addappid(717558, 1, "a3f9492e592f2a75bb8078f712ff82a56fa307f57d3d9a743cbacc6d089ccc6c") -- OSX Czech
setManifestid(717558, "146430390947086570", 571)
addappid(717559, 1, "da94d9a1ad1bf1b94ec6df8da0b170c87b45d5935c3af672e84b4c07879b9c98") -- PT-BR
setManifestid(717559, "648053771465102220", 6169661)
addappid(830771, 1, "059370e60a5b90cd8e6500f14919e1c801b8b55639535a1030f78991b13cb445") -- OSX PT-BR
setManifestid(830771, "1106905799378873224", 582)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
addappid(229001, 1, "ec23e1a1e1da6205722291f91bf72d1989cb347245e5a14d8d514c4ad5ba4e97") -- .NET 3.5 Client Profile Redist (Shared from App 228980)
setManifestid(229001, "4049573910112143457", 267964564)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITH DEDICATED DEPOTS
-- Divinity Original Sin 2 - Divine Ascension (AppID: 715950)
addappid(715950)
addappid(715950, 1, "c8dd881a1f53183dac83ea19432373350b1230a455a91ffef0972f549f007be7") -- Divinity Original Sin 2 - Divine Ascension - Divinity: Original Sin 2 - Divine Ascension (715950) Depot
setManifestid(715950, "13092185186497541", 4718214615)
-- Divinity Engine 2 Data (AppID: 717550)
addappid(717550)
addtoken(717550, "8801837011519097498")
addappid(717550, 1, "fafce309dd476bac77451c641f1bfdbee31c189b0066ae65c41619d8f83e987b") -- Divinity Engine 2 Data - Divinity Engine 2 Data (717550) Depot
setManifestid(717550, "1184446583557561731", 7495054592)
-- Divinity Original Sin 2 - Companion Sir Lora the Squirrel (AppID: 880640)
addappid(880640)
addappid(880640, 1, "b104cdc6fff9d11907a3d10b050d1253ca16a2066389ba224bac1e222f21c1a3") -- Divinity Original Sin 2 - Companion Sir Lora the Squirrel - Divinity: Original Sin 2 - Companion: Sir Lora the Squirrel (880640) Depot
setManifestid(880640, "5028798400746426703", 142)
addappid(880641, 1, "5e938fad1154750107d16a5b43ec7680a49c73f0470f925f16950bb9665da120") -- Divinity Original Sin 2 - Companion Sir Lora the Squirrel - Divinity: Original Sin 2 - Companion Sir Lora For Mac
setManifestid(880641, "1700988001881828326", 142)