-- 1250's Lua and Manifest Created by Hubcap Manifest
-- Killing Floor
-- Created: September 29, 2025 at 20:44:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 12
-- Total DLCs: 32

-- MAIN APPLICATION
addappid(1250) -- Killing Floor
-- MAIN APP DEPOTS
addappid(1258, 1, "d18cf52d5a51542928f279c19c1124cf86e9eac11fb756218b3fba1af58ca302") -- KillingFloorMacClient
setManifestid(1258, "96013688694607881", 43760071)
addappid(210935, 1, "233eadb66d2acac096a4bc5fadb2fb4758899a17c6fbf6fe433c5592da284e40") -- KillingFloorLinuxClient
setManifestid(210935, "7563393395723306375", 21559521)
addappid(1252, 1, "63619af1635f84aaf89f4e199b11c118fe6f2cc1b5d9ee32c4e27f34e2165d9b") -- KillingFloorClient
setManifestid(1252, "8847646994748097416", 4210772774)
addappid(1251, 1, "948100db7737b1e42b84518e4ad90b8957d3cb1c4bde1417ae44ffffdbf30a92") -- Killing Floor Shared Content
setManifestid(1251, "9033622738747915238", 2262659300)
addappid(35411, 1, "5e90f263a39ff0aa3e9e0ace96587284b2184c095ac231e603be44cbda000dd5") -- Killing Floor French
setManifestid(35411, "906253386388206029", 83929809)
addappid(35412, 1, "dba800cf4bf02fa884ed0bc39695f0bdf8ca4bd02c1feec9462d6419ee7faa0d") -- Killing Floor Italian
setManifestid(35412, "8468379892522852993", 65006735)
addappid(35413, 1, "ea63939f49f1d556594eb7e1e766123a552c1d79beca2b9cb7489bcfdf1991ae") -- Killing Floor German
setManifestid(35413, "3228135026284527066", 97595828)
addappid(35414, 1, "5df9fa1e7461a27775ed92811a64ab5ae935f8148333b9a9d17c81a4c432084e") -- Killing Floor Spanish
setManifestid(35414, "104832099190976001", 66179304)
addappid(35415, 1, "9438d68a90267aa57aabe35c308be1eb9fce264d10e5f10bc70f110aeaf0c72c") -- Killing Floor Russian
setManifestid(35415, "4068632667278647160", 101204685)
addappid(35416, 1, "a37d5144d606e876bfc32e9488d20bd11b45ba267b21cbec5825426b30c00d4a") -- Killing Floor Polish
setManifestid(35416, "8230602473846459083", 31503969)
addappid(35428, 1, "55245614dca5ba68071421dcea7c967d952a2b9b5e753b6d89d497ffff1d4c5c") -- Killing Floor Hungarian
setManifestid(35428, "2447789526600632028", 935354)
-- DLCS WITH DEDICATED DEPOTS
-- Killing Floor Accessed Content (AppID: 98009)
addappid(98009)
addappid(98009, 1, "1a56b7f2c47e6793771a1e9ad64ae9527cd5c64f18c0392ae6e9cdb51781922e") -- Killing Floor Accessed Content - Killing Floor Accessed Content
setManifestid(98009, "1037980016995672823", 13367259)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1255) -- Killing Floor DLC 1
addappid(1256) -- Killing Floor - Outbreak Character Pack
addappid(1257) -- Killing Floor - Nightfall Character Pack
addappid(35417) -- Killing Floor - PostMortem Character Pack
addappid(35418) -- Killing Floor - The Ball Character
addappid(35419) -- Killing Floor - Londons Finest DLC Character pack
addappid(35425) -- Killing Floor - Steampunk Character Pack
addappid(35426) -- Killing Floor - RO2 Digital Deluxe DLC
addappid(35429) -- Killing Floor - Steampunk Character Pack 2
addappid(210931) -- Killing Floor - KF Gold - Ash Harding
addappid(210932) -- Killing Floor - Urban Nightmare Character Pack
addappid(210933) -- Killing Floor - Harold Lott Character Pack
addappid(210934) -- Killing Floor - Community Weapon Pack 1
addappid(210936) -- Killing Floor - Chickenator DLC
addappid(210937) -- Killing Floor - Robot Premium DLC Character
addappid(210938) -- Killing Floor - Golden AK47 Assault Rifle
addappid(210939) -- Killing Floor - Dwarfs Promotional DLC
addappid(210942) -- Killing Floor - Rising Storm DLC
addappid(210943) -- Killing Floor - Community Weapon Pack 2
addtoken(210943, "16671637310895518466")
addappid(210944) -- Killing Floor - Golden Weapon Pack 2
addappid(210945) -- Killing Floor - Mrs Foster DLC
addappid(258750) -- Killing Floor - Reggie the Rocker Character Pack
addappid(258751) -- Killing Floor - Community Weapons Pack 3 - Us Versus Them Total Conflict Pack
addappid(258752) -- Killing Floor - Camo Weapon Pack
addappid(309990) -- Killing Floor - Neon Character Pack
addappid(309991) -- Killing Floor - Neon Weapon Pack
addappid(1374790) -- KF1 Humble Tier 1 DLC
addappid(1379540) -- KF1 Humble Tier 2 DLC
addappid(1379541) -- KF1 Humble Tier 3 DLC
addappid(1935740) -- KF1 Bundle 2022 Tier 1
addtoken(1935740, "4089888512052313748")
addappid(1935741) -- KF1 Bundle 2022 Tier 2
addtoken(1935741, "13811409566486300977")