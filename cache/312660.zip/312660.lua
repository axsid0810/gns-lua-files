-- 312660's Lua and Manifest Created by Hubcap Manifest
-- Sniper Elite 4
-- Created: January 19, 2026 at 19:40:07 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 42
-- Total DLCs: 13
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(312660, 1, "07c552b1a5f49d1dce4f45eb13fa4eabeb45340a40dea65c0386c557f7885cd2") -- Sniper Elite 4
-- MAIN APP DEPOTS
addappid(312661, 1, "54483c403ad9276b4a4f91dd9b27fff4d3cd7bb4f124064e91bf1f607f26e2b9") -- Sniper Elite 4 Base Files
setManifestid(312661, "4048799331839916338", 487881657)
addappid(312662, 1, "a40781b32678c45183426bdb3941188b92dab9f65edb868dd2700c27be165785") -- Sniper Elite 4 Client Files
setManifestid(312662, "7487199921793331392", 5735099845)
addappid(312663, 1, "318bc91925693301c975235eb3fd4ec5f2ad81dc3b645726250cbaf06aa2fea5") -- Sniper Elite 4 Executables
setManifestid(312663, "2264146200962002967", 123661816)
addappid(312669, 1, "3f0f10f84db96c2a89a4a154cf22487165f09cd121d4bf263eff0de350798c1a") -- Sniper Elite 4 GUI
setManifestid(312669, "5969274732563019921", 32699707)
addappid(474742, 1, "3ecd3a8cd3bce58e39c514c36d1000969438e84782eaaaff907a4d2829129efe") -- Sniper Elite 4 Core Level Textures
setManifestid(474742, "3892601692290998256", 29037027672)
addappid(312666, 1, "9dfef92c2b22ea91fccb9400f216c3caa1e142877ae410af0080f79445e33cfa") -- Sniper Elite 4 Shooting Range
setManifestid(312666, "7711633167199750385", 193598578)
addappid(312667, 1, "edaa360d95b53c2325900e8ab8adcf3f245f3c25794c60d50a928a14300c8f6e") -- Sniper Elite 4 Campaign
setManifestid(312667, "6221223566597367315", 5221196083)
addappid(312664, 1, "a7c78d32b3c5ad3a338922dc3be76d764d8cfcdfefb441d88e7be77c29806b15") -- Sniper Elite 4 SV
setManifestid(312664, "6091003266574404089", 1131819703)
addappid(312665, 1, "9a576851670417fb84943184201513e83142970e837fe59f461a958b4c752209") -- Sniper Elite 4 OW
setManifestid(312665, "400614430372612488", 1002849265)
addappid(474747, 1, "6fccba14988b9fb1e71f4b218681bbe3bf587e9475dcb50cc828cc2ea5b544c3") -- Sniper Elite 4 MP
setManifestid(474747, "9172257210152631323", 3980081655)
addappid(474741, 1, "280105e46d5d80379a5564225a6bc9154e3d474fea39342bee49e21b12665518") -- Sniper Elite 4 Common DLC Data
setManifestid(474741, "367765852226510888", 1739446223)
addappid(474748, 1, "adfd452cd1a4e1f7226d477883801ee09e27c76ded70d4300a00044624b5743a") -- Sniper Elite 4 Chinese (Traditional)
setManifestid(474748, "197688497288452651", 730758263)
addappid(474749, 1, "549ac7c9b973bc5875683674a38d1d3afec50f7a84b6d5deadb9f54477b41f2d") -- Sniper Elite 4 Chinese (Simplified)
setManifestid(474749, "1093999626779585990", 730759437)
addappid(474767, 1, "7c59d1ff02e26e336c43efc304df68be225176a388518ad9210a100d4d3a0360") -- Sniper Elite 4 P03
setManifestid(474767, "474324539935811098", 0)
addappid(312668, 1, "ed3bcb5a328176dda5b8525b8e6dc64a45af0b5d27af74a2c227294c0fd677f1") -- Sniper Elite 4 English
setManifestid(312668, "875427410744468705", 640554629)
addappid(474768, 1, "187e2b192e93712b12cdcceb25d2306451e12b07bde989138faa1fb46bac3b7d") -- Sniper Elite 4 French
setManifestid(474768, "6605632564166394266", 613230307)
addappid(474769, 1, "85855fd20a2bd4de91b357bc931f8d0866a3f117c287bada2c2709c05343a05f") -- Sniper Elite 4 Italian
setManifestid(474769, "3916199146488733183", 614870619)
addappid(513035, 1, "ce61b11afe1dc1524379d50eab08b83d5c22f4469791b27e9c5c2e0377c8a820") -- Sniper Elite 4 German
setManifestid(513035, "655647499445790397", 617894079)
addappid(513036, 1, "399bd75f9f233398f4ff0327495e6dc3837e487472a176ddbd021dca4d12151a") -- Sniper Elite 4 Spanish
setManifestid(513036, "7769475571012969421", 618245713)
addappid(513037, 1, "3a5f654ed4460b17116e8ba6e200eb01638f70ede9c9da79a24705fa8931c387") -- Sniper Elite 4 Portuguese (Brazilian)
setManifestid(513037, "5426484067779589310", 610410573)
addappid(513038, 1, "bc7536236e7f1caa2a26f506a1c1bee3307fc6934d433cd694be7a53549a864e") -- Sniper Elite 4 Russian
setManifestid(513038, "7269827781862112370", 614840583)
addappid(513039, 1, "ed96d0379fbf0efa04b69025221926318d1c7b15d53465647f114adb2e276258") -- Sniper Elite 4 Polish
setManifestid(513039, "2740944131688792039", 640542493)
addappid(474743, 1, "a178deebee6ec47016c09c6917eacf127406deeed8b2ef5b236c3a390f54fffe") -- Sniper Elite 4 Day 30
setManifestid(474743, "711719995978626888", 1993296587)
addappid(474744, 1, "0f397f40729ab83f38aeda3263053ea51a3ae8919dbfde1be6eaab87ae0b5168") -- Sniper Elite 4 Day 60
setManifestid(474744, "8096421991192761435", 2658921683)
addappid(474745, 1, "0ffd6a33f6cc1b5758378b3b1857c55c98c867d3b7d8066de10d84fb3b91194d") -- Sniper Elite 4 Day 90
setManifestid(474745, "1606907339718391772", 2885026691)
addappid(474746, 1, "24ce3ef6313a5435213d70addf19e80e0a9adc5e9ba2acba7054e781e21f53f7") -- Sniper Elite 4 Day 120
setManifestid(474746, "8679890394768222636", 1257529472)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Sniper Elite 4 - Camouflage Rifles Skin Pack (AppID: 474760)
addappid(474760)
addappid(474760, 1, "eafa11bcee8a6ceec359e2c5a9faffafc938d81fd30b6e1625d3872481ed9385") -- Sniper Elite 4 - Camouflage Rifles Skin Pack - DLC 1 - Cassavetes (474760) Depot
setManifestid(474760, "28829398357121428", 300)
-- Sniper Elite 4 - Silent Warfare Weapons Pack (AppID: 474761)
addappid(474761)
addappid(474761, 1, "ec7dbfc5234cc546c5811eadb3889085b02ba977ccb8202971fc1b7a19657028") -- Sniper Elite 4 - Silent Warfare Weapons Pack - DLC 3 - Brown (474761) Depot
setManifestid(474761, "162644798985564415", 156)
-- Sniper Elite 4 - Covert Heroes Character Pack (AppID: 474762)
addappid(474762)
addappid(474762, 1, "73cb91f3281a2b4651096ac9c4736c548262aa77e44d9a6f064b43b3e511453e") -- Sniper Elite 4 - Covert Heroes Character Pack - DLC 5 - Carruthers (474762) Depot
setManifestid(474762, "8440654624900042", 156)
-- Sniper Elite 4 - Target Fhrer (AppID: 474763)
addappid(474763)
addappid(474763, 1, "0644d4e27f926e57fdb7db704e7ea1176ccd37a3fdb411c9ea3f452621217a3a") -- Sniper Elite 4 - Target Fhrer - DLC 2 - Busby (474763) Depot
setManifestid(474763, "3741769615255257528", 3097757686)
-- Sniper Elite 4 - Deathstorm Part 1 Inception (AppID: 474764)
addappid(474764)
addappid(474764, 1, "b82db1fba8e83bc1e8861538369e65385f6cc7187e4bd9d763e74fa55c94c16b") -- Sniper Elite 4 - Deathstorm Part 1 Inception - DLC 6 - Walker (474764) Depot
setManifestid(474764, "5808464973816608405", 3016011898)
-- Sniper Elite 4 - Deathstorm Part 2 Infiltration (AppID: 474765)
addappid(474765)
addappid(474765, 1, "ab393588c9874a49bcd2893ca041c49bf74e91caaaf1b660f9253df354b4ca8e") -- Sniper Elite 4 - Deathstorm Part 2 Infiltration - DLC 8 - Maitland (474765) Depot
setManifestid(474765, "5450898976238845071", 3670931599)
-- Sniper Elite 4 - Deathstorm Part 3 Obliteration (AppID: 474766)
addappid(474766)
addappid(474766, 1, "080d6c4c61ee94a5b064c85e57169a5d11e954f7b710563c7816f5ca1908f6b0") -- Sniper Elite 4 - Deathstorm Part 3 Obliteration - DLC 10 - Mancini (474766) Depot
setManifestid(474766, "1001483521269763185", 4299175553)
-- Sniper Elite 4 - Lock and Load Weapons Pack (AppID: 513030)
addappid(513030)
addappid(513030, 1, "ebf6bc5d47e2969ddb415dbbca2e18018da14f47ffb2b696b3a139420432cf1e") -- Sniper Elite 4 - Lock and Load Weapons Pack - DLC 4 - Sutherland (513030) Depot
setManifestid(513030, "86500979106860738", 156)
-- Sniper Elite 4 - Urban Assault Expansion Pack (AppID: 513031)
addappid(513031)
addappid(513031, 1, "a6df1a5e5b873d44c9e09a1ffa1562e7b433601517cbb1acf70aec947321eace") -- Sniper Elite 4 - Urban Assault Expansion Pack - DLC 7 - Bronson (513031) Depot
setManifestid(513031, "483777213813587289", 516)
-- Sniper Elite 4 - Night Fighter Expansion Pack (AppID: 513032)
addappid(513032)
addappid(513032, 1, "3ee586947e23d7d2d4d822987354c25a0154727145fafe37811239cf9648200b") -- Sniper Elite 4 - Night Fighter Expansion Pack - DLC 9 - Cooper (513032) Depot
setManifestid(513032, "231619628310767692", 516)
-- Sniper Elite 4 - Cold Warfare Winter Expansion Pack (AppID: 513033)
addappid(513033)
addappid(513033, 1, "b2543d4c3e23c3abb7045e2a4929d47f5598e24e303885ecee0f33f52bee21da") -- Sniper Elite 4 - Cold Warfare Winter Expansion Pack - DLC 11 - Lopez (513033) Depot
setManifestid(513033, "3525287541754875858", 516)
-- Sniper Elite 4 - Allied Forces Rifle Pack (AppID: 513034)
addappid(513034)
addappid(513034, 1, "6c77c9b81af2f1fcaac17f0a89d1761400774f1c921e3c57084a31b40b16b593") -- Sniper Elite 4 - Allied Forces Rifle Pack - DLC 12 - Savalas (513034) Depot
setManifestid(513034, "4156768006199445", 156)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(474740) -- Sniper Elite 4 - Season Pass