-- 6010's Lua and Manifest Created by Hubcap Manifest
-- Indiana Jones and the Fate of Atlantis
-- Created: September 29, 2025 at 19:05:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(6010) -- Indiana Jones and the Fate of Atlantis
-- MAIN APP DEPOTS
addappid(6016, 1, "13b2ac833ba17da2d8cc8042d675588e429681e9ba7b555a4cc0f62a711a9d01") -- indiana_jones_fate_of_atlantis_mac_content
setManifestid(6016, "5669880856107212992", 160796805)
addappid(6011, 1, "d3e02b7a8336c3539b3f96c0c750220bb1168cab324590c2c88c074cceeb3aa0") -- Indiana Jones and the Fate of Atlantis_content
setManifestid(6011, "8584153416851488924", 161255109)
addappid(6012, 1, "4c0afa2e651c2412d76dd2963f032ff88c32ca2ebcc2df66dbeeb6860578cd85") -- Indiana Jones and the Fate of Atlantis French
setManifestid(6012, "5902553837266693337", 11242887)
addappid(6013, 1, "b636cff3468adddc39ce62ba63dd6ef2555e67f55fd8773c0db92c9b3b5d6dde") -- Indiana Jones and the Fate of Atlantis German
setManifestid(6013, "7820646257669845939", 11256098)
addappid(6014, 1, "a19a476ed387a979adbeb971ca0af81b690b21875fd279551e4f869cd8877d89") -- Indiana Jones and the Fate of Atlantis Italian
setManifestid(6014, "6828890150884573577", 11048509)
addappid(6015, 1, "b4d830b9893f2dbe7e217b4fd06025ad5b27784b71021d2c95260f375ae2ebe3") -- Indiana Jones and the Fate of Atlantis Spanish
setManifestid(6015, "1198054107095209497", 11215881)