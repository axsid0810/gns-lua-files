-- 2876060's Lua and Manifest Created by Hubcap Manifest
-- A Blocc World
-- Created: October 02, 2025 at 13:35:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2876060) -- A Blocc World
-- MAIN APP DEPOTS
addappid(2876061, 1, "29963ce6949463747933abec765a1287db038f8417f5b5655c272edf543d837f") -- Depot 2876061
setManifestid(2876061, "9095779023594368683", 815516033)