-- 2807960's Lua and Manifest Created by Hubcap Manifest
-- Battlefield™ 6
-- Created: July 21, 2026 at 04:57:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 25
-- Total DLCs: 41 (1 excluded)
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2807960, 1, "4fa6611b3acbfcd70547be82c9b03e17e6c9d995ba169e993d3dc11dc386d72b") -- Battlefield™ 6
-- MAIN APP DEPOTS
addappid(2807961, 1, "73da1db186c20534ecea9f2eaca1c8372f9341dee1f6d8862b4c0787886892b3") -- Depot 2807961
setManifestid(2807961, "6100828598976352368", 44097637525)
addappid(3028321, 1, "6b9fa278cdf39544bd689aea75c0dddaf0820adbfa180df0a558bb69af980f52") -- Depot 3028321
setManifestid(3028321, "7584213329072747015", 4443916429)
addappid(3028322, 1, "470339823530642f5340a16aefd1bbcd2e0a40a9c4f1c9a3d9cecbab616a08e8") -- Depot 3028322
setManifestid(3028322, "5510384879646152219", 2670826557)
addappid(3028323, 1, "69d7cc17544ded90b753e828e6ae31a9ab11e9696a1f1e361275feb9e44271af") -- Depot 3028323
setManifestid(3028323, "6928735846496311996", 3317633789)
addappid(3028324, 1, "0f9cd466928d1f043c07386635bfde394497a92551f3616c16c8e2760e3188b9") -- Depot 3028324
setManifestid(3028324, "8286461628729981725", 3285684461)
addappid(3028325, 1, "ce7bd93afff7f13077b6f2b9b949454e8c7bd92fa2e86b2c72aeca52d4512d9f") -- Depot 3028325
setManifestid(3028325, "5742632257435913774", 2992833829)
addappid(3028326, 1, "c748e00fa373fdcb4eb0bd2520c0ed148786656b14dd0352d738cbc10ca216cd") -- Depot 3028326
setManifestid(3028326, "7954817434834704106", 2797766621)
addappid(3028327, 1, "f9c6e6dbaef16a70af4f8e5d0396c2d704314af6d84f48f75dfab692e1958bfb") -- Depot 3028327
setManifestid(3028327, "6757539409878571296", 2667394469)
addappid(3028328, 1, "0b8d304fd0e68d4a73ec5e8ceb77ea488ddf67a8a3a9e21b41dd4997ee72321d") -- Depot 3028328
setManifestid(3028328, "9177894247786016794", 3234552901)
addappid(3028329, 1, "113bd43d67ea22550370e010e986ce0ea4c103efd15c47d64f575f2b870c9b7e") -- Depot 3028329
setManifestid(3028329, "7118560447170754229", 3199398501)
addappid(3028331, 1, "c2af7bf13379303ce5de8663197d22159f5ebc99343a6cf96df893c53544f3d8") -- Depot 3028331
setManifestid(3028331, "3934862437885068935", 2459660629)
addappid(3028332, 1, "9c37097e30eb1669dc33d87c54cf1d46e20899c0b64f8ca37c36aa2aaf69bd3f") -- Depot 3028332
setManifestid(3028332, "2707252931350600956", 3050096093)
addappid(3028333, 1, "491e106e1cee710bcb145dcf0af6e99e83e42f583f837af6db518f512ff1849e") -- Depot 3028333
setManifestid(3028333, "8747030700950147923", 4446172223)
addappid(3028334, 1, "91235291ebdc928ca5e4093423fab642d9f6a11f49386dbecc24a456691747cb") -- Depot 3028334
setManifestid(3028334, "1504113794263865458", 4446020671)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(3893181, 1, "7f675c2fe8e758d16f3cf8d3b493956afaee78e96d78cdb668a5edb8ac1580f6") -- Depot 3893181 (Shared from App 3893180)
setManifestid(3893181, "5085763297239765731", 290610401)
-- DLCS WITH DEDICATED DEPOTS
-- Battlefield 6 HD Textures (AppID: 3348410)
addappid(3348410)
addtoken(3348410, "13665612973931527059")
addappid(2807966, 1, "549e3538f02c93d5946d444eca7e980fb986bb422180cc7987780613ff568580") -- Battlefield 6 HD Textures - Depot 2807966
setManifestid(2807966, "3287365952011752490", 51573658449)
-- Battlefield REDSEC (AppID: 3348420)
addappid(3348420)
addtoken(3348420, "1467640746561116670")
addappid(2807962, 1, "e2257096f2cb51cc81a8b616c14484e0a550a71a062163856ec28eee545713da") -- Battlefield REDSEC - Depot 2807962
setManifestid(2807962, "5948495243109299045", 10264083374)
-- Battlefield REDSEC HD Textures (AppID: 3348430)
addappid(3348430)
addtoken(3348430, "8961726482197316533")
addappid(2807967, 1, "1c1abe63e9383f9d92d8fe40438233f54998a56b5047dae2a2147c8bc81dfb1c") -- Battlefield REDSEC HD Textures - Depot 2807967
setManifestid(2807967, "9069235240783621030", 1381258113)
-- Battlefield 6 Multiplayer (AppID: 3348440)
addappid(3348440)
addtoken(3348440, "13841136246857316758")
addappid(2807963, 1, "bf51eb02b6d6618e53cfed04159458edf879a832457c7c2333a4eea7a3bcd332") -- Battlefield 6 Multiplayer - Depot 2807963
setManifestid(2807963, "8606971565856896953", 7115759630)
-- Battlefield 6 Multiplayer HD Textures (AppID: 3348450)
addappid(3348450)
addtoken(3348450, "15419143094185166754")
addappid(2807968, 1, "9ecb637d00716f178fbc892341c18fb51d8dcf929b1f3750cf6b70349f5b2c13") -- Battlefield 6 Multiplayer HD Textures - Depot 2807968
setManifestid(2807968, "5835930957532305109", 1527416235)
-- Battlefield 6 Multiplayer  Single Player Shared HD Textures (AppID: 3348460)
addappid(3348460)
addtoken(3348460, "12314544414477136494")
addappid(2807971, 1, "4b5411bff21928a491fb766e1664ea809e79b90b30031ff444bc40aea250af8b") -- Battlefield 6 Multiplayer  Single Player Shared HD Textures - Depot 2807971
setManifestid(2807971, "2538358498757956713", 593650980)
-- Battlefield 6 Multiplayer  Single Player Shared Data (AppID: 3348470)
addappid(3348470)
addtoken(3348470, "3324369909174197558")
addappid(2807965, 1, "2df65824aab0f620dcdda53981db04e30d4ccf52e916d535c00db5933c419f59") -- Battlefield 6 Multiplayer  Single Player Shared Data - Depot 2807965
setManifestid(2807965, "9135984880638528807", 641180959)
-- Battlefield 6 Single Player (AppID: 3348480)
addappid(3348480)
addtoken(3348480, "3352496117720569715")
addappid(2807964, 1, "3db71633bd934e3c3601f253923cde0681423ff9d47a06654df50f7046ee419d") -- Battlefield 6 Single Player - Depot 2807964
setManifestid(2807964, "4303591883502763529", 22285525559)
-- Battlefield 6 - Single Player HD Textures (AppID: 3348490)
addappid(3348490)
addtoken(3348490, "9942472226415604439")
addappid(2807969, 1, "0a35c6f7a451d07c5289c5008b5a5d5707f62a33a19154fbf02c10a52e6bd53d") -- Battlefield 6 - Single Player HD Textures - Depot 2807969
setManifestid(2807969, "1060786723134208168", 8666515349)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3028320) -- Battlefield 6 Marker
addappid(3028330) -- Battlefield REDSEC
addappid(3574340) -- Battlefield 6 - Phantom Content
addappid(3574350) -- Battlefield 6 - Phantom Pack
addappid(3574360) -- Battlefield 6 - Phantom Upgrade
addappid(3574500) -- Battlefield 6 - Tombstone Pack
addappid(3645440) -- BFC for Battlefield 6 and REDSEC
addappid(3880840) -- BF Pro Battlepass (Season 1)
addappid(3933020) -- Rogue Ops Pack - Battlefield 6 and REDSEC
addappid(3933030) -- Season 1 Starter Pack - Battlefield 6 and REDSEC
addappid(3933040) -- Season 1 Advanced Pack - Battlefield 6 and REDSEC
addappid(3933050) -- Lead the Way Pack - XP Boost  Tier Skip
addappid(3933060) -- Lead the Way Pack - Content
addappid(3933070) -- Lead the Way Pack - Battlefield 6 and REDSEC
addappid(4031710) -- Battlefield 6  Standard Edition Marker
addappid(4031720) -- Battlefield 6 Standard Edition Pre-order Marker
addappid(4031730) -- Battlefield 6 Phantom Edition Marker
addappid(4031740) -- Battlefield 6 Phantom Edition Pre-order Marker
addappid(4031750) -- Battlefield Standard Edition Marker
addappid(4149400) -- Season 2 Advanced Pack - Battlefield 6 and REDSEC
addappid(4149410) -- Season 2 Battlefield Pro - Battlefield 6 and REDSEC
addappid(4149420) -- Season 2 Battlefield Pro - XP Boost  Tier Skips - Battlefield 6 and REDSEC
addappid(4149430) -- Season 2 Battlefield Pro Content - Battlefield 6 and REDSEC
addappid(4149440) -- Season 2 Starter Pack - Battlefield 6 and REDSEC
addappid(4149480) -- Toxic Tide Pack - Battlefield 6 and REDSEC
addappid(4373810) -- Season 3 Advanced Pack - Battlefield 6 and REDSEC
addappid(4373820) -- Season 3 Battlefield Pro - Battlefield 6 and REDSEC
addappid(4373830) -- Season 3 Battlefield Pro - Battlefield 6 and REDSEC Pre-Order Bonus
addappid(4373840) -- Search and Destroy Pack - Battlefield 6 and REDSEC
addappid(4373850) -- Season 3 Starter Pack - Battlefield 6 and REDSEC
addappid(4600460) -- Season 4 Advanced Pack - Battlefield 6 and REDSEC
addappid(4600480) -- Season 4 Battlefield Pro - Battlefield 6 and REDSEC Pre-Purchase Bonus
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4600470) -- Season 4 Battlefield Pro - Battlefield™ 6 and REDSEC Pre-Purchase (unreleased)