-- 2525380's Lua and Manifest Created by Hubcap Manifest
-- Tomb Raider IV-VI Remastered
-- Created: October 01, 2025 at 02:13:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2525380) -- Tomb Raider IV-VI Remastered
-- MAIN APP DEPOTS
addappid(2525381, 1, "8349c35cc7c661ae125165df281e9fb6f1eb7b22d82ecb59a948fcef1a70a01c") -- Depot 2525381
setManifestid(2525381, "3177537100764938297", 12600920523)