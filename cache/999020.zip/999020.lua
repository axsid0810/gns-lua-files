-- 999020's Lua and Manifest Created by Hubcap Manifest
-- Mega Man Zero/ZX Legacy Collection
-- Created: September 30, 2025 at 00:14:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(999020, 1, "8364c299262d3ec1a77078110c967b6af0b4c3cf972f0a47cc58366fc1b649a2") -- Mega Man Zero/ZX Legacy Collection
-- MAIN APP DEPOTS
addappid(999021, 1, "974feb98b181de2a334cede506d077ad1374981971c2b55c9902dec581afe55a") -- Mega Man Zero/ZX LC
setManifestid(999021, "117516919102560819", 4223402528)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Mega Man ZeroZX Reploid Remixes      (AppID: 1109480)
addappid(1109480)
addtoken(1109480, "14064416275178176557")
addappid(1109480, 1, "9c67b6dd619329ca1498f6002d0ce7f5cfb04a2560a0f72debd3e1f940692683") -- Mega Man ZeroZX Reploid Remixes      - Mega Man Zero/ZX LC - Music DLC
setManifestid(1109480, "1299431838778270", 31944373)