-- 39140's Lua and Manifest Created by Hubcap Manifest
-- FINAL FANTASY VII
-- Created: September 29, 2025 at 12:14:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(39140) -- FINAL FANTASY VII
-- MAIN APP DEPOTS
addappid(39142, 1, "6c12a4e6828b3bd8eeb3294935f557c79117d257785c190879a535ad7164f7f7") -- FINAL FANTASY VII
setManifestid(39142, "208551466200385657", 1249369018)
addappid(39143, 1, "4b1ecafba0774002e5b0c67cdf69acb6ed7353144d590a621ab2dcfcf0777059") -- FF7 English
setManifestid(39143, "1726957378011170066", 288992100)
addappid(39144, 1, "97cb41a02102e64a1c1b6a9c0e2ae4d1fae52751d0f71dd7d44a16c431474055") -- FF7 French
setManifestid(39144, "6574848179124542893", 290054899)
addappid(39145, 1, "4f2dfd13b0eb9dbb995032ccce71f77fc84e9fd051a39d0cd24ce8271ad57c63") -- FF7 German
setManifestid(39145, "9099229143834763732", 289170972)
addappid(39146, 1, "c6bdbe14b1e561e938fd570d35d1d9825ca2816c43c5f93525c04b1d1c935ab0") -- FF7 Spanish
setManifestid(39146, "7654531756823292283", 289114933)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)