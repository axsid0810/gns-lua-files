-- 2857910's Lua and Manifest Created by Hubcap Manifest
-- Moonripple Lake
-- Created: March 06, 2026 at 00:19:42 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2857910, 1, "7fb8f549ae9d0ea6948fdf91fc1236e7e906004bc4b68bb7414ca00fd9bbd7ca") -- Moonripple Lake
-- MAIN APP DEPOTS
addappid(2857911, 1, "f5450a9e40dba8c6aa6239c657230fd1c387a84e257815fd654a2499756f1792") -- Depot 2857911
setManifestid(2857911, "385175376417299194", 2176322432)