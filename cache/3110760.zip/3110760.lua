-- 3110760's Lua and Manifest Created by Hubcap Manifest
-- Alabaster Dawn
-- Created: May 20, 2026 at 13:55:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3110760, 1, "572e7facf7bdde2eadfdfcc93cda65e715b2639ab8a35b56221c38c779a9bfbf") -- Alabaster Dawn
-- MAIN APP DEPOTS
addappid(3110761, 1, "03f56edb0d3d06afcd1f625b1898343e100f2e00657b86a4bea0bfbac0f341ee") -- Depot 3110761
setManifestid(3110761, "2983318938355564321", 318321833)
addappid(3110762, 1, "f49e304c3273bbf6b8574de212a764f730163a1ff28205c886c4f0d3fa2e35c7") -- Depot 3110762
setManifestid(3110762, "296416421950771157", 373932871)
addappid(3110763, 1, "1c822fb12ffe50c92926da7c8dc7a72bf3705847054f3d65ddeac06d968b0292") -- Depot 3110763
setManifestid(3110763, "3533507189017250171", 339727489)
addappid(3110764, 1, "2b3f6361cb3a51a22ab218523adfa4f286ad1d00d4f1540beecc6f92a0f24b60") -- Depot 3110764
setManifestid(3110764, "7186828213461151622", 490444478)
addappid(3110765, 1, "10693e8d0375e62c533f16c6d8e32d87f68909e0f008b21a1ce63ab91d74f7a3") -- Depot 3110765
setManifestid(3110765, "2713512950690357176", 497702512)