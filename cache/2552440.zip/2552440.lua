-- 2552440's Lua and Manifest Created by Hubcap Manifest
-- KINGDOM HEARTS HD 2.8 Final Chapter Prologue
-- Created: September 29, 2025 at 20:51:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(2552440) -- KINGDOM HEARTS HD 2.8 Final Chapter Prologue
-- MAIN APP DEPOTS
addappid(2552443, 1, "e5176bdda321bbcc30b63de2f1bd4c65627192ac6ab3873322f163f258574cf5") -- Depot 2552443
setManifestid(2552443, "1329845697416523353", 26459701327)
addappid(2552442, 1, "aa2a72186b9d5b0e6051ef85923163544ddfd147950510bae59aaafa9ba00118") -- Depot 2552442
setManifestid(2552442, "2113685480387585597", 24588478798)
addappid(2552445, 1, "cbb8de50bd24129bbb6907a8db75af671ea013054811ccdd1cfa44fd094f2ecf") -- Depot 2552445
setManifestid(2552445, "7118206725190142167", 10477199755)
addappid(2552444, 1, "bfce5797607ede0bf1d4da6979773463c31c6040d20c5f90f563ecd1c2ed6b76") -- Depot 2552444
setManifestid(2552444, "5431506644424694601", 11447054139)
addappid(2552447, 1, "3a3cd77bcccfef0c5c5e8ce6b389516901f10bf009ed1ee31c6cac12b88d16d4") -- Depot 2552447
setManifestid(2552447, "4940755272352547929", 1244735437)
addappid(2552446, 1, "ec25765b66a429dc12261f550d4cdf2a9bb143a632c580a5dc76c5e6b5729696") -- Depot 2552446
setManifestid(2552446, "8087605462041200720", 1291317037)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)