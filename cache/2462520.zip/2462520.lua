-- 2462520's Lua and Manifest Created by Hubcap Manifest
-- I'm on Observation Duty 7
-- Created: October 28, 2025 at 08:24:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2462520) -- I'm on Observation Duty 7
-- MAIN APP DEPOTS
addappid(2462521, 1, "f4b0a0d97098ab3c5ce7a7aa4a7706a3a2068a75ac0797988bf046afb51fa8ac") -- Depot 2462521
setManifestid(2462521, "514048849467059793", 2998665840)
addappid(2462522, 1, "e1c314b4a036bbae337e561fc2aa3fa5fb3ae20522c67bb9dbcf49d10b603b2e") -- Depot 2462522
setManifestid(2462522, "3451340638548324623", 3132592415)
addappid(2462523, 1, "bcc77e77d2a3f8539c2b12090e9cd4941a0aa0f8dc1325afaac2c9e6e7a1b807") -- Depot 2462523
setManifestid(2462523, "4889161673721293068", 3168612337)