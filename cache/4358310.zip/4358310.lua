-- 4358310's Lua and Manifest Created by Hubcap Manifest
-- Coin Tavern
-- Created: July 26, 2026 at 14:49:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4358310) -- Coin Tavern
-- MAIN APP DEPOTS
addappid(4358311, 1, "dbb6cc266f0e12f34c221f010a08419509949d9af6427afdffdb8125d9075f38") -- Depot 4358311
setManifestid(4358311, "367004872267571216", 338395847)