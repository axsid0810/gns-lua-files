-- 379720's Lua and Manifest Created by Hubcap Manifest
-- DOOM
-- Created: September 29, 2025 at 08:19:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 14
-- Total DLCs: 5
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(379720) -- DOOM
-- MAIN APP DEPOTS
addappid(379721, 1, "1c8ecdad203929bb8db1972df40bc73ba97849902d8c04fd8e1a4b3c46e8f64f") -- Windows Executable
setManifestid(379721, "7402417666934369131", 181437520)
addappid(379722, 1, "856cf0143b298696d291b83e9267b90e5fd43f5980d7c93ee37b4aaebbf3b434") -- Configs
setManifestid(379722, "8049776370753024361", 469)
addappid(379723, 1, "7950119200da4b70ea8761adac5a0587f462f545304a853668a1160db081e612") -- Sound
setManifestid(379723, "1406287300602632194", 10932132913)
addappid(379724, 1, "70ef6a2153e541b39054659cb5eac0baff657ff1ed1c403da5dc4f9bb4480bfb") -- Videos
setManifestid(379724, "3656495822077136393", 1645385640)
addappid(379725, 1, "f05990f913804efc05ed64c4ec79d45613ada8dde32fd46293a44fae4eb1f2f7") -- Title Storage/MOTD
setManifestid(379725, "5817063578906359824", 8612462)
addappid(379726, 1, "c608bd51203b54b70ab0fd11e0326c40bfea1a542bcb258f874faf38551f9255") -- SP Resources
setManifestid(379726, "738549394730022244", 9917750412)
addappid(379727, 1, "1b60a70a7dfe50bec64f8c4613567eae67c73bdd4fdb3b0cc50da149517bafe0") -- SP Pages
setManifestid(379727, "8037609299761349397", 9200978000)
addappid(379728, 1, "01d6bfb50f651490153b3c3b482477d721a9fda8e02d56c1f52fcfef20097093") -- MP Resources
setManifestid(379728, "1950426378786289921", 0)
addappid(379729, 1, "8411c77e8e0331a835e7f13059a77dbcd48c0a7dc196df35b419a0ffe264347b") -- MP Pages
setManifestid(379729, "3267062194933049482", 5754565165)
addappid(446371, 1, "018f3aeca9d4835f81fbb48332eca5081c974b9ec4402f8c208057ca7ee7c940") -- Snap Resources
setManifestid(446371, "9171005121425145754", 3207479665)
addappid(446372, 1, "1680d4f2cb8d789d4beecb895d919abdb2d35da78fefc14020fd769a13c3a31d") -- Snap Pages
setManifestid(446372, "7504828670365651918", 6922024725)
addappid(446373, 1, "231d309b1ae8c6fe3f585e4d609ff8b28b31a57d57a6456d9ee3510616e1df6e") -- Vmtrs
setManifestid(446373, "5740097624449687519", 25988685202)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(446370) -- DOOM - Demon Multiplayer DLC Pack
addappid(458020) -- DOOM Season Pass
addappid(499590) -- DOOM - Unto The Evil DLC
addappid(527180) -- DOOM - Hell Followed DLC
addappid(559040) -- DOOM - Bloodfall DLC