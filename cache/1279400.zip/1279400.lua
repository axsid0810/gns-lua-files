-- 1279400's Lua and Manifest Created by Hubcap Manifest
-- STRIKERS 1945 III
-- Created: September 30, 2025 at 20:29:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1279400) -- STRIKERS 1945 III
-- MAIN APP DEPOTS
addappid(1279401, 1, "7cb480d3261e7ab33e344cc6f2b389605c456e39458c87a93c8b2f1d2c78d689") -- STRIKERS1945 III Content
setManifestid(1279401, "1035739070100572372", 94569243)