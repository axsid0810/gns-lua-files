-- 1382070's Lua and Manifest Created by Hubcap Manifest
-- Viewfinder
-- Created: November 29, 2025 at 16:14:50 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1382070) -- Viewfinder
-- MAIN APP DEPOTS
addappid(1382073, 1, "91db9b94243c9fa25520ef73ded5d2c2cc4345c27b38f36f4d110545dcaaa4d5") -- Depot 1382073
setManifestid(1382073, "7275053272387578004", 8393049002)