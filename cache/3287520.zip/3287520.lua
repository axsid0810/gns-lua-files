-- 3287520's Lua and Manifest Created by Hubcap Manifest
-- NINJA GAIDEN 2 Black
-- Created: September 30, 2025 at 03:42:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3287520) -- NINJA GAIDEN 2 Black
-- MAIN APP DEPOTS
addappid(3287521, 1, "d026ecb27a03a6ca26771e7352214eed11c1b9d1553cc0b47aaf6cb6e7f4f371") -- Depot 3287521
setManifestid(3287521, "1162494661906979271", 86966169252)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)