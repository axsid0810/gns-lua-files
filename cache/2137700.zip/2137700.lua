-- 2137700's Lua and Manifest Created by Hubcap Manifest
-- I'm on Observation Duty 6
-- Created: July 04, 2026 at 21:24:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2137700) -- I'm on Observation Duty 6
-- MAIN APP DEPOTS
addappid(2137701, 1, "9b3075859192dff61b3969516dcefdda9a988367fe647fc8d03fb36ff9731554") -- Depot 2137701
setManifestid(2137701, "692631959094116807", 8312638504)
addappid(2137702, 1, "f6f566318ace444903e4060b6cb258b55f410d53a3f4c50560dec1bdb5b62bc2") -- Depot 2137702
setManifestid(2137702, "2089685302877893523", 8335632156)
addappid(2137703, 1, "bb1eea330fc0b72199468c39ad090273fec258e1b9572b36b4559db02a4b23d2") -- Depot 2137703
setManifestid(2137703, "2654886217295953111", 8391040875)