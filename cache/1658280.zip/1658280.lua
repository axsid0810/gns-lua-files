-- 1658280's Lua and Manifest Created by Hubcap Manifest
-- Eiyuden Chronicle: Hundred Heroes
-- Created: September 29, 2025 at 10:02:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 9

-- MAIN APPLICATION
addappid(1658280) -- Eiyuden Chronicle: Hundred Heroes
-- MAIN APP DEPOTS
addappid(1658281, 1, "61d12d4ec2b9e888bfe67fae7c70f6d76bfe64bbef403294b7375cc326523bb4") -- Depot 1658281
setManifestid(1658281, "931861435176872698", 26591529282)
-- DLCS WITH DEDICATED DEPOTS
-- Eiyuden Chronicle Hundred Heroes - Story Expansion The Chapter of Seign (AppID: 2694060)
addappid(2694060)
addappid(2694060, 1, "c0aa52099fb10cf9bb72bb177c12fb2e52918d0bf6d39dc3dfc85eaf07e5d07a") -- Eiyuden Chronicle Hundred Heroes - Story Expansion The Chapter of Seign - Depot 2694060
setManifestid(2694060, "2814350827779174299", 437652860)
-- Eiyuden Chronicle Hundred Heroes - Story Expansion The Chapter of Marisa (AppID: 2694070)
addappid(2694070)
addappid(2694070, 1, "1bf7c8888c8f8eff07d289aaebb430c7ea9bbd4ef1a3f0a1eb1ff1f158f557a6") -- Eiyuden Chronicle Hundred Heroes - Story Expansion The Chapter of Marisa - Depot 2694070
setManifestid(2694070, "5303487694956715357", 60945171)
-- Eiyuden Chronicle Hundred Heroes - Story Expansion The Chapter of Markus (AppID: 2694080)
addappid(2694080)
addappid(2694080, 1, "93f4886b80544255a37428bee906326f84974c434b3439009fdfb1f90d9bb7e4") -- Eiyuden Chronicle Hundred Heroes - Story Expansion The Chapter of Markus - Depot 2694080
setManifestid(2694080, "7839505989973759128", 451586168)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2694030) -- Eiyuden Chronicle Hundred Heroes - Pioneer Pack
addappid(2694050) -- Eiyuden Chronicle Hundred Heroes - Easy Journey Pack
addappid(2694090) -- Eiyuden Chronicle Hundred Heroes - HQ Makeover Pack
addappid(2694110) -- Eiyuden Chronicle Hundred Heroes - Season Pass
addappid(2786940) -- Eiyuden Chronicle Hundred Heroes - Hope of the Alliance - Special HQ Statue
addappid(2786950) -- Eiyuden Chronicle Hundred Heroes - 3x Original Wallpapers by Junko Kawano