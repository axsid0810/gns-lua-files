-- 1114150's Lua and Manifest Created by Hubcap Manifest
-- CarX Street
-- Created: July 28, 2026 at 07:11:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(1114150, 1, "48650f4310aecbd46d7c261b9b6bdef32f593022e12ce27a39b2421526145a83") -- CarX Street
-- MAIN APP DEPOTS
addappid(1114151, 1, "472bd3a70105d0685574189912e9cf277940a72c562a19db7509fc56da74f3de") -- Depot 1114151
setManifestid(1114151, "443689767165194282", 20768125946)
addappid(1114152, 1, "e171e9b88d7b4daa070b5e9fc084af3f6125e81f1147a95de4dc61faa2324dd8") -- Depot 1114152
setManifestid(1114152, "8455777993669761743", 20738852917)
addappid(1114153, 1, "3a239e4cadbfaa98c4e0d89a7e7920daf8625583cb49e453ce2a566581484a5f") -- Depot 1114153
setManifestid(1114153, "3576375820489044154", 20803913242)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3028020) -- CarX Street - Deluxe Cars
addappid(3153040) -- CarX Street - DLC Sunset Speedway
addappid(3285610) -- Carx Street - Drift Cars
addappid(3480680) -- CarX Street - Pure Pulse
addappid(4209640) -- CarX Street - Build Your Car