-- 1007040's Lua and Manifest Created by Hubcap Manifest
-- EARTH DEFENSE FORCE 5
-- Created: September 29, 2025 at 09:51:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 20
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1007040) -- EARTH DEFENSE FORCE 5
-- MAIN APP DEPOTS
addappid(1007041, 1, "9e97f916bd62116e247cbac00bdde6ee17ef433c1f275e1bf91ced2f4bec5106") -- EARTH DEFENSE FORCE 5 Content
setManifestid(1007041, "1745282649550539254", 21534759395)
addappid(1007042, 1, "59820074274e4bba44d87dab26511cbfe7dec04cb3cf08690641dc57ca9f75cf") -- EARTH DEFENSE FORCE 5 Depot Windows 64bit
setManifestid(1007042, "8440089052034728143", 21226560)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1057270) -- EARTH DEFENSE FORCE 5 - Mission Pack 1 Extra Challenge
addappid(1057271) -- EARTH DEFENSE FORCE 5 - Mission Pack 2 Super Challenge
addappid(1057272) -- EARTH DEFENSE FORCE 5 - Ranger Piloted Weapon Omega Freesia
addappid(1057273) -- EARTH DEFENSE FORCE 5 - Ranger Vehicle Light Truck
addappid(1057274) -- EARTH DEFENSE FORCE 5 - Ranger Support Device Detector S-Type
addappid(1057275) -- EARTH DEFENSE FORCE 5 - Ranger Piloted Weapon Blacker Number 4.1
addappid(1057276) -- EARTH DEFENSE FORCE 5 - Wing Diver Support Device Reverse Core S-Type
addappid(1057277) -- EARTH DEFENSE FORCE 5 - Fencer Weapon Grim Reaper Shield
addappid(1057278) -- EARTH DEFENSE FORCE 5 - Fencer Weapon Happy Body Pillow
addappid(1057279) -- EARTH DEFENSE FORCE 5 - Fencer Support Device Wild Skeleton
addappid(1057280) -- EARTH DEFENSE FORCE 5 - Air Raider Weapon FZ-GUN
addappid(1057281) -- EARTH DEFENSE FORCE 5 - Air Raider Piloted Weapon Combat Frame Phantasia Shield Nyx
addappid(1057282) -- EARTH DEFENSE FORCE 5 - Air Raider Piloted Weapon Blacker Number 5
addappid(1057283) -- EARTH DEFENSE FORCE 5 - Air Raider Vehicle Caliban Armored Ambulance Joyful Marking
addappid(1076010) -- EARTH DEFENSE FORCE 5 - Ranger Weapon Decoy Launcher (Pale Wing)
addappid(1076011) -- EARTH DEFENSE FORCE 5 - Air Raider Piloted Weapon Combat Frame Gold Nyx
addappid(1076012) -- EARTH DEFENSE FORCE 5 - Wing Diver Weapon Vulcaneer Cracker
addappid(1076013) -- EARTH DEFENSE FORCE 5 - Wing Diver Weapon Starburst
addappid(1076014) -- EARTH DEFENSE FORCE 5 - Ranger Weapon Singing and Dancing Pure Decoy Launcher Set of 8
addappid(1076015) -- EARTH DEFENSE FORCE 5 - Air Raider Weapon Singing and Dancing Pure Decoy Launcher Set of 8