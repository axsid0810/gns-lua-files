-- 1966900's Lua and Manifest Created by Hubcap Manifest
-- 20 Minutes Till Dawn
-- Created: September 30, 2025 at 17:04:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1966900) -- 20 Minutes Till Dawn
-- MAIN APP DEPOTS
addappid(1966901, 1, "86150b62505519576e84ebd1a2f5deb2dc1464e5c9fbfd04ddc370fedc59fd82") -- Depot 1966901
setManifestid(1966901, "6216844347758689075", 133283416)
addappid(1966902, 1, "8305cb4192af5fea999a2848f6e8d308a2ea46840438d349e65b86514510d0bb") -- Depot 1966902
setManifestid(1966902, "1890137909460856104", 133619279)