-- 3711590's Lua and Manifest Created by Hubcap Manifest
-- Train45
-- Created: July 14, 2026 at 01:02:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3711590, 1, "d0fbcba33e35102ec47709617020d7bc9b402c89fa0f1e92369a5972a8738a3b") -- Train45
-- MAIN APP DEPOTS
addappid(3711591, 1, "66e440ffab28f63a155822137b57433dad7a9ddf50009e8d61ff1d48af37019c") -- Depot 3711591
setManifestid(3711591, "195873931049054039", 1651805064)
-- DLCS WITH DEDICATED DEPOTS
-- Train 45 Artbook (AppID: 4612910)
addappid(4612910)
addappid(4612911, 1, "45f012daa170c726e8d1234119150130a703e293a9513f461608700811726e63") -- Train 45 Artbook - Depot 4612911
setManifestid(4612911, "1415573599890324727", 135282915)