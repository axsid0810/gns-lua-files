-- 2510770's Lua and Manifest Created by Hubcap Manifest
-- Stella of The End
-- Created: September 30, 2025 at 20:02:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2510770) -- Stella of The End
-- MAIN APP DEPOTS
addappid(2510771, 1, "01aab9abea5851d8f368d4b07c30802c4ff53db61479ebcfb6f7a5609bd48a31") -- Depot 2510771
setManifestid(2510771, "929875023832578086", 5545456336)