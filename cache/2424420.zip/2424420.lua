-- 2424420's Lua and Manifest Created by Hubcap Manifest
-- Avatar Legends: The Fighting Game 
-- Created: July 23, 2026 at 11:25:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2424420, 1, "8020155cba97dd0a06f8df328ec539fe855c1fe77a38b1dd0b5dbf5e2ed8ed60") -- Avatar Legends: The Fighting Game 
-- MAIN APP DEPOTS
addappid(2424421, 1, "aecbafdba75c145b913095a622b5665b86c3589fe2a77351c9ddbe48b185c4bd") -- Depot 2424421
setManifestid(2424421, "7266337798456641018", 8573076521)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)