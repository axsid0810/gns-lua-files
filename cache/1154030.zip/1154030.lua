-- 1154030's Lua and Manifest Created by Hubcap Manifest
-- Titan Quest II
-- Created: July 22, 2026 at 12:49:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1154030, 1, "4f807f0c5039d652149b0b3b5e807b3e5df82e52152fc127018534e7b2ff5573") -- Titan Quest II
-- MAIN APP DEPOTS
addappid(1154031, 1, "e4c24aa5ff3a15fba8dcb2762211078a3f284a840b9514a64e6694e2acbb33b3") -- Depot 1154031
setManifestid(1154031, "6282960078166670105", 30102028772)
addappid(1154032, 1, "43500c93da407fa7209d086b870b5e21bf2fe23eb5b4222593992edd340ca26e") -- Depot 1154032
setManifestid(1154032, "8357834312778876792", 584579985)
addappid(1154033, 1, "fd8d7e7db90c144288acda1e77897ffd3ecc1acc26408079c1c8f54c095d3f49") -- Depot 1154033
setManifestid(1154033, "1280571733929986813", 0)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)