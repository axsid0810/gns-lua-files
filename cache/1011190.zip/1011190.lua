-- 1011190's Lua and Manifest Created by Hubcap Manifest
-- SIMULACRA 2
-- Created: September 30, 2025 at 14:17:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1011190) -- SIMULACRA 2
-- MAIN APP DEPOTS
addappid(1011191, 1, "5f46b768617e823a9a3c4ba78c3ab9ba8fd6149c295b2d85026142701112879f") -- Windows Content
setManifestid(1011191, "2330982736764429166", 15201601835)