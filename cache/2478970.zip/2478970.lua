-- 2478970's Lua and Manifest Created by Hubcap Manifest
-- Tomb Raider I-III Remastered Starring Lara Croft
-- Created: April 30, 2026 at 20:43:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2478970, 1, "fa57cf912018d98a6167ea0f1e152501a805a383b3f6cca075db4d7b7453034a") -- Tomb Raider I-III Remastered Starring Lara Croft
-- MAIN APP DEPOTS
addappid(2478971, 1, "d618662f8f002c8bbbe623996f63415e1a4f843bce5608ec23b390a7ea5798ee") -- Depot 2478971
setManifestid(2478971, "758518349756221540", 6573619416)