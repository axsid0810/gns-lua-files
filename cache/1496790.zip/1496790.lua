-- 1496790's Lua and Manifest Created by Hubcap Manifest
-- Gotham Knights
-- Created: February 26, 2026 at 12:22:49 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 11
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1496790, 1, "c0d7e1424d13a91534fc420a5f65a5c43c77063f977664b421db4705ec8eebfe") -- Gotham Knights
-- MAIN APP DEPOTS
addappid(1496791, 1, "40ad1c77c16c71b4c353e1a71b9d7c7a5c2cc1474a2333926db9842c70a45df3") -- Depot 1496791
setManifestid(1496791, "3510075411094225947", 48059404106)
addappid(1496792, 1, "a6bf3c458159607d503b73d7d8868d88b25b0cd748f9641d25a4af3cd9d773e7") -- Depot 1496792
setManifestid(1496792, "6741199118717402024", 141771346)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2074430) -- Gotham Knights 233 Kustom Batcycle Skin
addappid(2074431) -- Gotham Knights Visionary Pack
addappid(2074432) -- Gotham Knights Promethium New Guard Transmogs
addappid(2142690) -- Gotham Knights BOSO22 Batcycle Skin
addappid(2142691) -- Gotham Knights Gilded Age Escrima Sticks
addappid(2142692) -- Gotham Knights Gilded Age Tonfa
addappid(2142693) -- Gotham Knights Gilded Age Pistols
addappid(2142694) -- Gotham Knights Gilded Age Bo Staff
addappid(2142695) -- Gotham Knights Signal Colorway
addappid(2142696) -- Gotham Knights Gilded Age Exclusive Transmog
addappid(2399950) -- Gotham Knights Gilded City Collection