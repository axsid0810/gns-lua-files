-- 953490's Lua and Manifest Created by Hubcap Manifest
-- CARRION
-- Created: February 01, 2026 at 12:00:23 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(953490, 1, "586da51f27a7e3a72e85517adb2c26732c550f72b04a1543bfd64d9847b3549a") -- CARRION
-- MAIN APP DEPOTS
addappid(953491, 1, "ba3221161cac581738cb2433d5658bd0258dea2cedd2bdcbe9dec3d8d5841183") -- Carrion-win64
setManifestid(953491, "2388749483486048975", 188338560)
addappid(953493, 1, "76be4b55c7e4efef7b2bda7cdc00df1ecaf235c2e6badebad025e7e63cc2346a") -- Carrion-linux64
setManifestid(953493, "2518178748484096326", 199866688)
addappid(953494, 1, "06c1cacc01a95017aaf62947d83d93d43db7a11412efea87b5718a307cdb0e16") -- Carrion-osx64
setManifestid(953494, "1359721034225396334", 240041108)
addappid(953492, 1, "09d7515c8233fe027d26fddb81052399bdfcfe5634ca6174a9b06f55d890e2f3") -- Carrion-win32
setManifestid(953492, "5051071834624244651", 218453631)
-- DLCS WITH DEDICATED DEPOTS
-- CARRION Deluxe Edition Content (AppID: 1462530)
addappid(1462530)
addappid(1462530, 1, "8db121a57c8979fececcb3ca4bca2cfd60914c79629d2ca77b4c030b21c04cbe") -- CARRION Deluxe Edition Content - carrion-comicbook-win64
setManifestid(1462530, "4615134159395918773", 727450021)
addappid(1462531, 1, "e2aec49ad9cb9e8dd1ef4ceafde3ca110e7c482e44b225145a4983f8b61dd9b1") -- CARRION Deluxe Edition Content - carrion-comicbook-osx
setManifestid(1462531, "1065692301281315352", 720548859)
addappid(1462532, 1, "098d587fe71772f7050761e21fb69ce6145417439e1366006dfdfc9283a7cb4e") -- CARRION Deluxe Edition Content - carrion-comicbook-linux
setManifestid(1462532, "3012872745704691826", 700479735)