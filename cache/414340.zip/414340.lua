-- 414340's Lua and Manifest Created by Hubcap Manifest
-- Hellblade: Senua's Sacrifice
-- Created: September 29, 2025 at 17:14:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 1
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(414340) -- Hellblade: Senua's Sacrifice
-- MAIN APP DEPOTS
addappid(414341, 1, "b52b49b1aa5b2931a20af4d509e604d4e96a00895d7e75bf04acaffa573ebe09") -- Hellblade Content
setManifestid(414341, "3390494925423867663", 20180032808)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Hellblade Senuas Sacrifice - Digital Comic (AppID: 626750)
addappid(626750)
addtoken(626750, "17242123508152754127")
addappid(626750, 1, "da8b16e5fa6895ec08a5589fd5b68f1adfe6f1f24c7120e06dc2fdcda3219b4a") -- Hellblade Senuas Sacrifice - Digital Comic - Hellblade Senua's Sacrifice - Digital Comic (626750) Depot
setManifestid(626750, "7617494232712978521", 15830326)