-- 909080's Lua and Manifest Created by Hubcap Manifest
-- Cube Escape: Paradox
-- Created: February 01, 2026 at 11:58:47 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(909080) -- Cube Escape: Paradox
-- MAIN APP DEPOTS
addappid(909081, 1, "00224e202fcfed0867c920a785db94c65b076130d63da904985a107d52404546") -- Cube Escape: Paradox Content
setManifestid(909081, "8607521663663987803", 107040653)
addappid(909082, 1, "6a1484847fe1b2026e2c76a1edf2d4e7f51a20f0cc4b004636453176704d953b") -- Cube Escape: Paradox MAC
setManifestid(909082, "5684519743222035837", 116334669)
-- DLCS WITH DEDICATED DEPOTS
-- Cube Escape Paradox - Chapter 2 (AppID: 909150)
addappid(909150)
addappid(909152, 1, "d6e81b812908fd883b9338aba6467bca27b346e912cf19dd962986164dc4a7ee") -- Cube Escape Paradox - Chapter 2 - Cube Escape: Paradox - Chapter 2 WINDOWS
setManifestid(909152, "3086901877671116902", 106728154)
addappid(909151, 1, "1f155b1e6e1af9814a37b3924c434486031de5583aaf01c1ef2e53a1db306184") -- Cube Escape Paradox - Chapter 2 - Cube Escape: Paradox - Chapter 2 MAC
setManifestid(909151, "3451290362467323717", 116334674)