-- 363440's Lua and Manifest Created by Hubcap Manifest
-- Mega Man Legacy Collection
-- Created: November 13, 2025 at 02:04:49 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(363440) -- Mega Man Legacy Collection
-- MAIN APP DEPOTS
addappid(363441, 1, "1674f0c6f57185bb129f249a00553268a4f726c6908bc4ef60598f5abbc72e95") -- Suzy Content
setManifestid(363441, "1471104847962813070", 257047971)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)