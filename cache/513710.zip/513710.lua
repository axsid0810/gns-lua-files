-- 513710's Lua and Manifest Created by Hubcap Manifest
-- SCUM
-- Created: July 22, 2026 at 22:03:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 20
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(513710, 1, "490737566db1c843800690df604ab8b78b767a46299e85da9971068c309e5447") -- SCUM
-- MAIN APP DEPOTS
addappid(513711, 1, "a4217026617fd23bbc1b544c3160c7c7e5157bc3cfcd825b8dbd1c6d0513c3b4") -- SCUM Content
setManifestid(513711, "8829395088831657591", 95058911188)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- SCUM Deluxe (AppID: 919680)
addappid(919680)
addappid(919680, 1, "903d006bb149ccbe1ab4f9dbbad34150079380811c9c78b3cfa5c1505ad889ae") -- SCUM Deluxe - SCUM Deluxe (919680) Depot
setManifestid(919680, "6252294094855435400", 37896840)
-- SCUM Deluxe 2 (AppID: 1643210)
addappid(1643210)
addappid(1643210, 1, "9e747e8f5cf60151ff0c48ce9eb2bb1977b88052fbb610f1a0ae88d28d001194") -- SCUM Deluxe 2 - SCUM Deluxe 2 (1643210) Depot
setManifestid(1643210, "8526987047835682522", 96504739)
-- SCUM Deluxe 3 (AppID: 3596770)
addappid(3596770)
addappid(3596770, 1, "ca8672e87bb66a5095fa0d3bd263d23d78ee88ee808938b6b0df4c0abbbb0cd2") -- SCUM Deluxe 3 - Depot 3596770
setManifestid(3596770, "4482977239842637557", 66059451)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1990860) -- SCUM Danny Trejo
addappid(2321800) -- SCUM Hair Deluxe 1
addappid(2371620) -- SCUM Luis Moncada
addappid(2517160) -- SCUM Charms 1
addappid(2517170) -- SCUM Weapon Skins 1
addappid(2651720) -- SCUM Car Skins 1
addappid(2651740) -- SCUM Man Hair Deluxe 1
addappid(2651750) -- SCUM Dances 1
addappid(2841840) -- SCUM Raymond Cruz
addappid(4062860) -- SCUM Base Building Decor Pack
addappid(4139450) -- SCUM Squad Emblem Pack
addappid(4369750) -- SCUM Eastern Furniture Pack
addappid(4529160) -- SCUM Woodland Hunter Pack
addappid(4635190) -- SCUM Woodland Furniture Pack
addappid(4635200) -- SCUM Apex Predator Pack
addappid(4635240) -- SCUM Specialist Archer Pack
addappid(4635250) -- SCUM Specialist Scout Pack