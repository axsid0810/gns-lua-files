-- 17450's Lua and Manifest Created by Hubcap Manifest
-- Dragon Age: Origins
-- Created: September 29, 2025 at 08:30:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 14
-- Total DLCs: 8

-- MAIN APPLICATION
addappid(17450) -- Dragon Age: Origins
-- MAIN APP DEPOTS
addappid(17451, 1, "cdc62a1813a982618ea32889a2811913ccc8bd862764dc7495cbd218a16734a2") -- dragon age origins content
setManifestid(17451, "5622515225044071038", 14524624975)
addappid(17452, 1, "fb0afe070a44017f507deb285f68addb4c2cdd343869479f385a6ff02cef1bd8") -- Dragon Age: Origins English
setManifestid(17452, "6034339279496214473", 2118715071)
addappid(17453, 1, "c6c618d9a02adc6486178ee3e4110f31bbd2fa63ecf21a9a5055aeacfba69616") -- Dragon Age: Origins French
setManifestid(17453, "3148716036889621834", 3118694798)
addappid(17454, 1, "9148ce7f2d759db4daff7f55a91156f28210cc646e0034daf55c5e673b593aef") -- Dragon Age: Origins German
setManifestid(17454, "5864066546673490958", 3266380073)
addappid(17455, 1, "393890cdf60f7bd6bc67bbf1a8a69b72663a42473a733bda68fe6fe125a2c583") -- Dragon Age: Origins Italian
setManifestid(17455, "5187548981186489524", 2153371159)
addappid(17456, 1, "a6c406e4b6173f57f6240a69375a3b7c211bf82fe308d0273828ffd530506f11") -- Dragon Age: Origins Czech
setManifestid(17456, "5522427151622819249", 2168515793)
addappid(17457, 1, "ac2c145f95e53e31f4177092e3e31df775586fba1617dcaecb8b0722959bfd17") -- Dragon Age: Origins Russian
setManifestid(17457, "6853451709624999993", 2141992303)
addappid(17458, 1, "ac7af165cb99ffd4a751bf7140d638e8ead91bd2f4b6e049ce4e71e99a94a69e") -- Dragon Age: Origins Polish
setManifestid(17458, "835688101717197877", 3610643207)
addappid(17459, 1, "f4b84b6ea944a2e46282b08b77c4462ecaf258c0ae5837fc7f57375529e8996a") -- Dragon Age: Origins Spanish
setManifestid(17459, "8898075025641417741", 2152869828)
-- DLCS WITH DEDICATED DEPOTS
-- Dragon Age Origins Bonus Content (AppID: 24932)
addappid(24932)
addappid(24932, 1, "3b940c2dd56e3cacfb6e35d037fbf81917a87ce31771181b854d293fbad02d39") -- Dragon Age Origins Bonus Content - Dragon Age: Origins Bonus Content
setManifestid(24932, "2501766615208411874", 98032413)
-- Dragon Age Origins Deluxe CD Key (AppID: 24935)
addappid(24935)
addappid(24935, 1, "9a9e10a62eabe94090003658516bcc10835da13845eb79842fad0b0015b8dcca") -- Dragon Age Origins Deluxe CD Key - Dragon Age: Origins Deluxe CD Key
setManifestid(24935, "8264161092105043397", 493)
-- Dragon Age Origins Standard CD Key (AppID: 24936)
addappid(24936)
addappid(24936, 1, "ab93d4a4a3bee3ae48798bc241b3eca5ba61ff6e353c95d910553dd29eb09126") -- Dragon Age Origins Standard CD Key - Dragon Age: Origins Standard CD Key
setManifestid(24936, "1548910472317169263", 493)
-- Dragon Age Origins Deluxe Game CD Key (AppID: 24938)
addappid(24938)
addappid(24938, 1, "624ea608b85b4aa8858039f67505781a0fbb2872f734efee7d8974ad867aa206") -- Dragon Age Origins Deluxe Game CD Key - Dragon Age: Origins Deluxe Game CD Key
setManifestid(24938, "4934397450641569964", 493)
-- Dragon Age Origins Standard Game CD Key (AppID: 24939)
addappid(24939)
addappid(24939, 1, "a223f535ada90b488451d0110836adb7b1261ad974657265b2231d699cae81e6") -- Dragon Age Origins Standard Game CD Key - Dragon Age: Origins Standard Game CD Key
setManifestid(24939, "3461668241962638556", 493)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(24934) -- Dragon Age Origins Deluxe CD Key
addappid(24937) -- Dragon Age Origins Preorder CD Key
addappid(47749) -- Dragon Age Origins - The Awakening DLC (Preorder)