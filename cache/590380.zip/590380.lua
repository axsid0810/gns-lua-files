-- 590380's Lua and Manifest Created by Hubcap Manifest
-- Into the Breach
-- Created: January 22, 2026 at 08:10:05 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(590380, 1, "198dd2b793e4c9ae2b21ed6333ce37d26ce911346d97da8090112020f2d52485") -- Into the Breach
-- MAIN APP DEPOTS
addappid(590381, 1, "0f473a094a1ad7c93b49ad57618ea958e903510c26e39db8fd1bdfb0b29a9061") -- Into the Breach Content
setManifestid(590381, "8335438558621014449", 550774114)
addappid(590382, 1, "d7fbb3e761e4323321c053d368f5c1b99722fcb1f608182fdc9a0a962bccae39") -- Into the Breach Mac
setManifestid(590382, "2336337887533649473", 558921392)
addappid(590383, 1, "d5a2478194548ef6050a0df0ebcdda38e0ec71f36498f865075f50e1694fe011") -- Into the Breach Linux
setManifestid(590383, "8584573075182422035", 556040899)