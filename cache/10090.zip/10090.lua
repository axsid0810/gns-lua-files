-- 10090's Lua and Manifest Created by Hubcap Manifest
-- Call of Duty: World at War
-- Created: July 29, 2026 at 04:44:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 10097: Blacklisted

-- MAIN APPLICATION
addappid(10090, 1, "e783ae9cd92cab6d17482854eefdf91d863044a5d9fc18c3f767c4e8bea4176f") -- Call of Duty: World at War
-- MAIN APP DEPOTS
addappid(10091, 1, "10ec612dbb207b40a95f3d87dfa3ff720d38ae05a9cacedba92b2c584451bf9b") -- Call of Duty: World at War content
setManifestid(10091, "5566849738478017518", 5611397150)
addappid(10092, 1, "73dd3d3391cf0a30abe562035102c9d47b5d8b8ac6f48d8e574b5501926a5bbc") -- Call of Duty: World at War English
setManifestid(10092, "3607600095703252129", 4193416049)
addappid(10093, 1, "2c33b9a6afc043bce38f9c0ba564194895df35c12a885b7bf4cfc6c2e1a18bd2") -- Call of Duty: World at War French
setManifestid(10093, "6144874664931741841", 4151952776)
addappid(10094, 1, "7983e119dfd3586cc64677816aa111a598ba49e1d7e92c6b4db8cc9242ecdb86") -- Call of Duty: World at War German
setManifestid(10094, "8930507410861259500", 4457264550)
addappid(10095, 1, "fe273171200d3e2271a7dddc4064869e3e4966799e710e805be043c2c30ad554") -- Call of Duty: World at War Spanish
setManifestid(10095, "1277981520695176614", 4190800083)
addappid(10096, 1, "e2dbc935ca2ae935ac53479fd77846231acb660baf06b3535d76abc4ccf61c81") -- Call of Duty: World at War Italian
setManifestid(10096, "6181330962488495469", 4173068585)