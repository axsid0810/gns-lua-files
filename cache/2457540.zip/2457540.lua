-- 2457540's Lua and Manifest Created by Hubcap Manifest
-- VGDD2
-- Created: June 01, 2026 at 12:00:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 41
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2457540, 1, "4aed0bdae5b737e1681330876a1666ceb000085b2e6f493d8baa4893ad45695b") -- VGDD2
-- MAIN APP DEPOTS
addappid(2457541, 1, "5195261e7ca5f37ebc06fd9599b9b8cbc1b172ea54cec4096d3e60b8f176643e") -- Depot 2457541
setManifestid(2457541, "7948101894332983848", 35445890294)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3332190) --   DD201
addappid(3332200) --   DD202
addappid(3332210) --   DD2401D-BT
addappid(3332220) --   DD2402D-BT
addappid(3332230) --   DD2403D-BT
addappid(3332240) --   DD2404D-BT
addappid(3332250) --   DD2405D-BT
addappid(3332260) --   DD2406DZ-BT
addappid(3332270) --   DD2407DZ-BT
addappid(3332280) --   DD2408VG-BT
addappid(3332310) --   DD2
addappid(3332330) --   DD2vol.1DZ-BT04
addappid(3332340) --   DD2vol.3DZ-SS02Stride Deckset Harri(  )	
addappid(3332350) --   DD2vol.4DZ-SS03Stride Deckset Nightrose(  )
addappid(3332360) -- vol.2DZ-BT05
addappid(3493490) --   DD201
addappid(3493500) --   DD202
addappid(3493510) --   DD203
addappid(3493520) --   DD204
addappid(3493530) --   DD2410DZ-BT04
addappid(3619670) --   DD2vol.1
addappid(3619680) --   DD2411DZ-BT05
addappid(3619690) --   DD2412vol.1
addappid(3619700) --   DD205
addappid(3619710) --   DD206
addappid(3619720) --   DD207
addappid(3785990) --   DD2vol.2
addappid(3786000) --   DD2413vol.2
addappid(3902290) --   DD2vol.5DZ-BT06
addappid(3902300) --   DD2414DZ-BT06
addappid(3987600) -- 2
addappid(3996280) -- vol.6DZ-BT07
addappid(3996300) --   DD2415DZ-BT07
addappid(3996310) --   DD208
addappid(3996320) --   DD209
addappid(4133570) --   DD2vol.7DZ-BT08
addappid(4133580) --   DD2416DZ-BT08
addappid(4133590) --   DD2vol.7.5DZ-SS0708
addappid(4133600) --   DD210
addappid(4306500) --   DD2vol.8DZ-SS112025
addappid(4306510) --   DD2417DZ-SS11