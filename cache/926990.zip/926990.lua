-- 926990's Lua and Manifest Created by Hubcap Manifest
-- WolfQuest: Anniversary Edition
-- Created: July 11, 2026 at 15:08:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 5

-- MAIN APPLICATION
addappid(926990, 1, "a5dd3c389135ba85be0dd79d749b272ea5308061e75b02d0b1765d3cd917eeb0") -- WolfQuest: Anniversary Edition
-- MAIN APP DEPOTS
addappid(926992, 1, "b6898f382435b9c540dae42e9a2b5fdf283a5c4f340c3294e032e782a89ff950") -- WolfQuest: Anniversary Edition (Mac)
setManifestid(926992, "8780973511526831938", 15741324909)
addappid(926991, 1, "28d993a32040d80b634e5f3338c3f228c75b765f38f99568a398e53b75670e8f") -- WolfQuest: Anniversary Edition (Windows)
setManifestid(926991, "6111914322843964296", 15583584291)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1529920) -- WolfQuest Anniversary - Yellowstone Wolf Coat Pack
addappid(1529930) -- WolfQuest Anniversary - Lost River
addappid(1970630) -- WolfQuest Anniversary - Building Character Pack
addappid(2874030) -- WolfQuest Anniversary - Hellroaring Mountain
addappid(4241680) -- WolfQuest Anniversary - Tower Fall
-- EMPTY DEPOTS (no content on any branch)
-- addappid(926993) -- Depot 926993 (empty depot)
-- addappid(926994) -- Depot 926994 (empty depot)