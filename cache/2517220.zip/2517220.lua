-- 2517220's Lua and Manifest Created by Hubcap Manifest
-- Entity: The Black Day
-- Created: February 19, 2026 at 14:57:30 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2517220, 1, "9a5f389509214a4e03900b61ba4fdc0315e65b6604826babb018355d20996ec9") -- Entity: The Black Day
-- MAIN APP DEPOTS
addappid(2517221, 1, "172154d86126f1a6c064d6901fd4f1a346dc8a781f9e3e35eb98973b29574d93") -- Depot 2517221
setManifestid(2517221, "1588215694435031112", 22137815093)
addappid(2517222, 1, "a3dd758b8fbc982d31076474680fd8b805f1a9b5efc08d56ede165d188fcb3dd") -- Depot 2517222
setManifestid(2517222, "791017410246693638", 16047830001)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)