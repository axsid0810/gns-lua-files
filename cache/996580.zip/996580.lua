-- 996580's Lua and Manifest Created by Hubcap Manifest
-- Spyro™ Reignited Trilogy
-- Created: September 30, 2025 at 19:15:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(996580) -- Spyro™ Reignited Trilogy
-- MAIN APP DEPOTS
addappid(996581, 1, "43f678f5e86f5f0e6f236ba830580719be039e1185121a7650e3a5733e593865") -- Spyro Reignited Trilogy - Binaries
setManifestid(996581, "8223464263088965733", 58739180)
addappid(996582, 1, "6cab8b3208e30fc352684bb5ca8390e5e7e22926b56cf58545f72b528e87a923") -- Spyro Reignited Trilogy - Content
setManifestid(996582, "6673579705803232637", 41603544053)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)