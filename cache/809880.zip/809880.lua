-- 809880's Lua and Manifest Created by Hubcap Manifest
-- Degrees of Separation
-- Created: September 29, 2025 at 07:14:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(809880) -- Degrees of Separation
-- MAIN APP DEPOTS
addappid(809883, 1, "edde71c9c9a27898179fa7b14291875c2c60edddcb78ea28b4b05e8416eba646") -- Degrees of Separation Depot Windows
setManifestid(809883, "6417322076303818863", 412547038)
addappid(809884, 1, "4d099715486bd0b00c687d05bf141a0a852b120437fd6755f6ebd81fb732fd26") -- Degrees of Separation Depot Windows 32
setManifestid(809884, "6021602633546206692", 405181113)