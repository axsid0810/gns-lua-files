-- 2366980's Lua and Manifest Created by Hubcap Manifest
-- Thank Goodness You're Here!
-- Created: September 30, 2025 at 22:29:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2366980) -- Thank Goodness You're Here!
-- MAIN APP DEPOTS
addappid(2366981, 1, "436c3a988f36c4fc3f8bebe8661ad1a4ce467bfad673d0a76c1cc174a44792f0") -- Depot 2366981
setManifestid(2366981, "4960030984262173479", 842750425)
addappid(2366982, 1, "c3653cc3f2c3580882e504a12cad17115a9b5574f3a569a6625eddc03a1a7a02") -- Depot 2366982
setManifestid(2366982, "4467394041721781619", 1000921539)