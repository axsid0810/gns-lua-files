-- 1681430's Lua and Manifest Created by Hubcap Manifest
-- RoboCop: Rogue City
-- Created: June 25, 2026 at 17:00:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 3
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1681430, 1, "c394a0477819dc886a962bdda6dcaca5220a3b97602947fb4caa685174d75a3f") -- RoboCop: Rogue City
-- MAIN APP DEPOTS
addappid(1681431, 1, "9df4746c06e6c3240fdbbb7fafdc7ee3d4461387c34371ffcf2a5db0ac571b27") -- Depot 1681431
setManifestid(1681431, "583119793512475952", 40600272392)
addappid(1681432, 1, "232386dc8910dc12e16112ae451c13c73855f4615ffc6c2736e1da5d40bb8fb3") -- Depot 1681432
setManifestid(1681432, "1601850106946005766", 40720090303)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- RoboCop Rogue City - Digital Artbook (AppID: 2436842)
addappid(2436842)
addappid(2436842, 1, "7429f5a3d4c7fa42b6d594040def2e00bd50c410843d7ac9e33b7f5c70081f6b") -- RoboCop Rogue City - Digital Artbook - Depot 2436842
setManifestid(2436842, "2913461760137024199", 21782897)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2436840) -- RoboCop Rogue City - Vanguard Pack
addappid(2436841) -- RoboCop Rogue City - Alex Murphy Pack