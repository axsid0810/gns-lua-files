-- 3670140's Lua and Manifest Created by Hubcap Manifest
-- Godzilla x Kong: Titan Chasers
-- Created: July 27, 2026 at 06:55:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3670140) -- Godzilla x Kong: Titan Chasers
-- MAIN APP DEPOTS
addappid(3670141, 1, "6651a8bd4250372e1268197dfed3830205f145ffa03fa38458d6f3a0c6d6a501") -- Depot 3670141
setManifestid(3670141, "2762378918952527144", 352957814)
addappid(3670142, 1, "3475386ba884a433aac50777161acbe788b2f8032a3ec97663505f8c0ba38919") -- Depot 3670142
setManifestid(3670142, "2528742844632580566", 627431277)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4046390) -- Godzilla x Kong Titan Chasers - Primal Starter Pack