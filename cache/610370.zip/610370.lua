-- 610370's Lua and Manifest Created by Hubcap Manifest
-- Desperados III
-- Created: September 29, 2025 at 07:28:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(610370) -- Desperados III
-- MAIN APP DEPOTS
addappid(610371, 1, "07ee906f4ffc80a33d0c85b228a548d123a15087f533124e99cdb2d4bf592244") -- Desperados III Content
setManifestid(610371, "1026796419896246112", 23456104368)
addappid(610372, 1, "707d1e1d896ccb3f7825e35f073c6f342b2ae65ca0dd30b54c91a9278df1e8f7") -- Desperados III OSX
setManifestid(610372, "6454656903798300902", 23648146598)
addappid(610373, 1, "cbc2eebaa57ba2cd878b76226b674b97fb81791e87488065194dbfd71e7cf8a4") -- Desperados III Linux
setManifestid(610373, "1716129747829083633", 24356522876)
addappid(610374, 1, "de941b1d1cd2c1e306d599027d54ad78d2c122d7373960b4fb88cb8ff956b6fe") -- Desperados III Docs
setManifestid(610374, "6435867264939876538", 602631)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
-- DLCS WITH DEDICATED DEPOTS
-- Desperados III Season Pass (AppID: 1308850)
addappid(1308850)
addappid(1308850, 1, "6374288be9cd9c83ac406578ce4643c62bf3ef25904a6589d0aa3f2fa1b747fa") -- Desperados III Season Pass - Desperados III Season Pass (1308850) Depot
setManifestid(1308850, "7278237865980967493", 128281086)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1287600) -- Desperados III Money for the Vultures - Part 1 Late to the Party
addappid(1287601) -- Desperados III Money for the Vultures - Part 2 Five Steps Ahead
addappid(1287602) -- Desperados III Money for the Vultures - Part 3 Once More With Feeling