-- 320140's Lua and Manifest Created by Hubcap Manifest
-- Absolute Drift
-- Created: September 28, 2025 at 21:23:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(320140) -- Absolute Drift
-- MAIN APP DEPOTS
addappid(320141, 1, "cdf0086eeb3d80beb86bd45680d48cb53f555103c2511d7985d903da2f2b0975") -- Absolute Drift Depot - Windows
setManifestid(320141, "5389423999088490459", 355860084)
addappid(320142, 1, "8977c37b2473d5ef3beb304d652fb9424ef0ba3aa5515b817558016ec173f1de") -- Absolute Drift Depot - Mac
setManifestid(320142, "2688677701709527850", 376303844)
addappid(320143, 1, "4ea8e2b5cd4868b3de6ecbd36d376981aa9512a01c70c80fdc88a773dac2b2f9") -- Absolute Drift Depot - Linux
setManifestid(320143, "4421506249304054846", 355483518)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)