-- 823130's Lua and Manifest Created by Hubcap Manifest
-- Totally Accurate Battlegrounds
-- Created: October 28, 2025 at 00:41:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(823130) -- Totally Accurate Battlegrounds
-- MAIN APP DEPOTS
addappid(823131, 1, "7e190008c73c1ad83bd9b89becea2318a43d57e0a849b355377323220e91e791") -- TABG Windows Content
setManifestid(823131, "4440301980517303032", 4221273062)