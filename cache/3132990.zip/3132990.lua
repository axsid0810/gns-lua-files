-- 3132990's Lua and Manifest Created by Hubcap Manifest
-- Black Myth: Wukong Benchmark Tool
-- Created: October 02, 2025 at 17:39:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(3132990) -- Black Myth: Wukong Benchmark Tool
-- MAIN APP DEPOTS
addappid(3132991, 1, "a76096f781e0c6b4496779df4773cfcf92053906873fcaa9003f0e9f95b2ea98") -- Depot 3132991
setManifestid(3132991, "2001970149514029866", 8365222843)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)