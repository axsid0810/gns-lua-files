-- 3061570's Lua and Manifest Created by Hubcap Manifest
-- Persona5: The Phantom X
-- Created: May 01, 2026 at 14:52:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3061570, 1, "8f227cc26032b926449ae8071f369e5c9c574c8e32a11927c7595fd2552a447c") -- Persona5: The Phantom X
-- MAIN APP DEPOTS
addappid(3061571, 1, "08c9bf8c96295b965da7d11e5262f6d143a4ec15b8697d994997f14df4bf7f38") -- Depot 3061571
setManifestid(3061571, "5149433803342269842", 355672516)
addappid(3061572, 1, "c9af8bc6dcbbbec05d5f14bd8925fdfbad45a319fb067f32493d00266cf6d49a") -- Depot 3061572
setManifestid(3061572, "4069392135709538347", 350481477)