-- 782660's Lua and Manifest Created by Hubcap Manifest
-- Modern Tanks
-- Created: July 25, 2026 at 10:51:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(782660, 1, "409c8a6eb56e1ad1ada9540b48b121080806f417ace2b121d5279e156a0d09b1") -- Modern Tanks
-- MAIN APP DEPOTS
addappid(782661, 1, "3645c420a6fa94dfcf347c93d047c0a830a55f930e961e0afd1672334d68e9a5") -- Armada: Modern Tanks Windows
setManifestid(782661, "6429579230887155238", 1481342292)
addappid(782662, 1, "808e9267b50636b9ac5397cf077731f1b6983e77ab368ab4bc55030eb6785046") -- Armada: Modern Tanks Linux
setManifestid(782662, "3177707817028684161", 1608962113)
addappid(782663, 1, "6114dc99b12024f10d827f8398adc06cf15a5958a3310c7ef02651f7d33a2100") -- Armada: Modern Tanks macOS
setManifestid(782663, "6250536014382598494", 2070554159)