-- 1238860's Lua and Manifest Created by Hubcap Manifest
-- Battlefield 4™ 
-- Created: July 03, 2026 at 11:15:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 120
-- Total DLCs: 26
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1238860, 1, "58ddf0a37c6062a924e46290df04dd9e6bfb5ffa55bd639c07a460f0aa4463c7") -- Battlefield 4™ 
-- MAIN APP DEPOTS
addappid(1238861, 1, "a70aeb51423fa65eff9fb75092a3bafbedf41c2f0cc4f66caee89c3d31be99d2") -- Battlefield 4 - Content
setManifestid(1238861, "5790550315647961519", 33848868288)
addappid(1238862, 1, "4c0d025b655f6d76c0118b94dfdb05170f5e030dcd87687c1415976908f2b07d") -- Battlefield 4 - en_US
setManifestid(1238862, "4134516474567351318", 951769289)
addappid(1238863, 1, "9abb028584fd39382a972e489d5b0e437664b94458b65aa9cdba5d163f2821f4") -- Battlefield 4 - fr_FR
setManifestid(1238863, "1179971805763842997", 1428184534)
addappid(1238864, 1, "434c27900b081b42c0dbdee98ee7d2096307f6f0c1c3f4d29b0c290506e60f05") -- Battlefield 4 - it_IT
setManifestid(1238864, "1884370580307172439", 1444723314)
addappid(1238865, 1, "82b5da1d97ace868a8b27c25927ec77928a9ef159c7cb4975995be22a7ab0826") -- Battlefield 4 - de_DE
setManifestid(1238865, "3561209213128132980", 1477662826)
addappid(1238866, 1, "fd77ebbbd8bc560070ffc11a6f94e1d18de714341cb4e0dad41201d09863d3c3") -- Battlefield 4 - es_ES
setManifestid(1238866, "5082204154841506598", 1477291249)
addappid(1238867, 1, "2e09ae88bf21599995be746fcf13f5918f4c7d65c17ca8d2edbc00c31bc58ec4") -- Battlefield 4 - pl_PL
setManifestid(1238867, "3874316708377682985", 813510463)
addappid(1238868, 1, "2e231f6c99fac90432559ae3b51ad05a34c1903704e16c9240e288e03854b6ba") -- Battlefield 4 - ru_RU
setManifestid(1238868, "8042912031614746500", 883377557)
addappid(1238869, 1, "c68272de8a3e563d022b970329af67fa3c2f0f35313276f085ebad2f3a4684c5") -- Battlefield 4 - pt_BR
setManifestid(1238869, "8139537678996583048", 1462907848)
addappid(1238872, 1, "9743c66c09d3c6e0e52fdb5cfed0341e621e36f25575576de5d9c211cfa58b6c") -- Battlefield 4 - ja_JP
setManifestid(1238872, "7645850408715557464", 1444458355)
addappid(1238873, 1, "776f34401a8172781ef5cc608f59dd20718fb644071a1daed61aa86bfee80813") -- Battlefield 4 - cs_CZ
setManifestid(1238873, "7370055068262480597", 952083382)
addappid(1238874, 1, "4663f85a8f01aa04196e1e39cddf285a44d5f46520dc2c9db18d7c957bafb443") -- Battlefield 4 - ko_KR
setManifestid(1238874, "3410540413806087694", 952237426)
addappid(1238875, 1, "38f003a48cd1e5bc78b2bac043fa502b896d52c99e66199978cb29b2689f21ff") -- Battlefield 4 - zh_TW
setManifestid(1238875, "6644320650706456549", 951995150)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
setManifestid(3340991, "2155225770093841476", 239536599)
-- DLCS WITH DEDICATED DEPOTS
-- Battlefield 4 China Rising (AppID: 1272641)
addappid(1272641)
addtoken(1272641, "6480156903692853383")
addappid(1272641, 1, "4b7c6e263f412fb775d5e07caf36e78a3a33220b089bcdb013af22e3da1c4f16") -- Battlefield 4 China Rising - Depot 1272641
setManifestid(1272641, "2870391146105912331", 4765055194)
addappid(1276900, 1, "acb9bd7c4fbcc1a00ee1b2ce0dfbb18d158cbb0e97cb2d79605706ef229ec7f9") -- Battlefield 4 China Rising - Depot 1276900
setManifestid(1276900, "4181986429116835240", 203)
addappid(1276901, 1, "4a745f9df1655538495e53dbb7489f1bf2896dc2ff24ad2c115b68c685ee30a1") -- Battlefield 4 China Rising - Depot 1276901
setManifestid(1276901, "5855347449393767816", 203)
addappid(1276902, 1, "db4e624fa1471e5b32ae8491ce03842fe7d03264d32d98b3b927427d761a7aaa") -- Battlefield 4 China Rising - Depot 1276902
setManifestid(1276902, "4678972542143157307", 203)
addappid(1276903, 1, "d31e4ae8f13946b6156d75ef28d367f64a322563f83a8ba20a6c2d1b644ff221") -- Battlefield 4 China Rising - Depot 1276903
setManifestid(1276903, "8317377548782098384", 203)
addappid(1276904, 1, "6033c7669ad9602b6d044b6687521e5262433e5b98f7b09cb6eebe9e02c83a05") -- Battlefield 4 China Rising - Depot 1276904
setManifestid(1276904, "3862666479438746925", 203)
addappid(1276905, 1, "c79fd9d6f61b7fbf91ec3b4c9cc2bead2743fad6a20bd8378e21304f552243a5") -- Battlefield 4 China Rising - Depot 1276905
setManifestid(1276905, "3926429291228864986", 203)
addappid(1276906, 1, "3a202d1a47d9048650f978ae4e57f214ba9ed2869a307f41c8b1a523c11f35da") -- Battlefield 4 China Rising - Depot 1276906
setManifestid(1276906, "6510313343463014476", 203)
addappid(1276907, 1, "30af3c7ce4c0adfca36b7e077c38e88ef8afba86f0773669c40cdaf5526c7c6d") -- Battlefield 4 China Rising - Depot 1276907
setManifestid(1276907, "2142544489333167210", 203)
addappid(1276908, 1, "eeb93a052049eaa0c93dde4d0770aa7d97ee02ef6109bcb16244aa0cebc93608") -- Battlefield 4 China Rising - Depot 1276908
setManifestid(1276908, "5654197825691402474", 203)
addappid(1276909, 1, "be48a25531a6d288835f0ebe6b71ef0410a4d7ab01e84084dbbd886146b99e76") -- Battlefield 4 China Rising - Depot 1276909
setManifestid(1276909, "5987606866657841046", 203)
addappid(1276910, 1, "c69b3f85e4d79e03835bcf6e048953c526ae44b3425112ea8516f6fd5a0479b8") -- Battlefield 4 China Rising - Depot 1276910
setManifestid(1276910, "7647728759790374952", 203)
addappid(1276911, 1, "9f32d8e288381016da45539c476dd0ed23ed94c1642468a03fa52674665d760a") -- Battlefield 4 China Rising - Depot 1276911
setManifestid(1276911, "8520383169458193453", 203)
-- Battlefield 4 Second Assault (AppID: 1272642)
addappid(1272642)
addtoken(1272642, "8880021263436484369")
addappid(1272642, 1, "e8bff1661a34550e276551b56b813fa53f6ed08295cfbf0af1aed53bd6eaea5c") -- Battlefield 4 Second Assault - Depot 1272642
setManifestid(1272642, "4799997946610759113", 5729606895)
addappid(1276920, 1, "adf8e20dc4ae323ef439608de4d24a8689c67e953f43b3254f597376c4c657b7") -- Battlefield 4 Second Assault - Depot 1276920
setManifestid(1276920, "2181763122694354087", 207)
addappid(1276921, 1, "b5e048a7cda6a59f4de7951813795dc00fe95e8a2b861d5e91c66fbacf66e1a1") -- Battlefield 4 Second Assault - Depot 1276921
setManifestid(1276921, "4442054289872731429", 207)
addappid(1276922, 1, "e19ea69c5a3b99bf06019e42159684e8c850f31a0cd07bb2173285c131e9ea69") -- Battlefield 4 Second Assault - Depot 1276922
setManifestid(1276922, "1657497480384982347", 207)
addappid(1276923, 1, "0f471b518936519f0b765b4209f1eab3b43b6a6bf1fc452c786792322c4049b0") -- Battlefield 4 Second Assault - Depot 1276923
setManifestid(1276923, "317235164081304864", 207)
addappid(1276924, 1, "36ca348fc81c8136d8ac73465eed734e33452665a9cbf5349e43548c9956dbfb") -- Battlefield 4 Second Assault - Depot 1276924
setManifestid(1276924, "8021567397349223468", 207)
addappid(1276925, 1, "5d6a80438338f77958be087b33471765f0d3bd52825fdec9382ae14f5b0f529a") -- Battlefield 4 Second Assault - Depot 1276925
setManifestid(1276925, "6371346241255933069", 207)
addappid(1276926, 1, "95733b1efe7f91fd741e601c34ca0f5dab2d7436e89dae2cfa50207bbc8507c3") -- Battlefield 4 Second Assault - Depot 1276926
setManifestid(1276926, "4178735096089053258", 207)
addappid(1276927, 1, "8fdd5b202c5c1b4fd902a8093ab18bce1b0ffd4cf7d1ec7dc44b9bcc91378bad") -- Battlefield 4 Second Assault - Depot 1276927
setManifestid(1276927, "4428613579205707953", 207)
addappid(1276928, 1, "6b3c2e5d35e1eff5e2e174c6e7b7a0e560c064cc7cd48289c78876d5d88a99ed") -- Battlefield 4 Second Assault - Depot 1276928
setManifestid(1276928, "5747277430313950526", 207)
addappid(1276929, 1, "d8524f8b1209aaca9f3f516e5160921b5e35f5694c957dfa2190dd6b142dfc8a") -- Battlefield 4 Second Assault - Depot 1276929
setManifestid(1276929, "4547855417639820659", 207)
addappid(1276930, 1, "9bd29a4ea38325ed99090c8d023190b26b36d41175927f06e4a6998bb8d70616") -- Battlefield 4 Second Assault - Depot 1276930
setManifestid(1276930, "1873996807203079370", 207)
addappid(1276931, 1, "d7957ad08d79ab71ce948074c53396fa513d5398634ce6e8dc72dcd8366699a6") -- Battlefield 4 Second Assault - Depot 1276931
setManifestid(1276931, "5331907516347077913", 207)
-- Battlefield 4 Final Stand (AppID: 1272643)
addappid(1272643)
addtoken(1272643, "1744884208708993561")
addappid(1272643, 1, "a8745a79e0e701e42944ae8f346eb502964c661a1a33521385294b5cd88ad142") -- Battlefield 4 Final Stand - Depot 1272643
setManifestid(1272643, "2007847468385633827", 7625197127)
addappid(1276940, 1, "4a12749fbed4b1e04f19fc2321e342b0b2a3334fc8854e670ecb761cce53fca8") -- Battlefield 4 Final Stand - Depot 1276940
setManifestid(1276940, "3293581160905808199", 207)
addappid(1276941, 1, "5e27ae7646041403c5e084f7d95b643b8e739f1e49795521994e070aa9402de2") -- Battlefield 4 Final Stand - Depot 1276941
setManifestid(1276941, "8778909672927447548", 207)
addappid(1276942, 1, "2a0a2b9aa2ad3f499dc36471af4023ba58183d890aec70377821a1d532d3c645") -- Battlefield 4 Final Stand - Depot 1276942
setManifestid(1276942, "8599224911747635311", 207)
addappid(1276943, 1, "7b93ef286f27cc5d6460b738b02a13454e42abb9c01f9c8c70acc5c77a8dc567") -- Battlefield 4 Final Stand - Depot 1276943
setManifestid(1276943, "9141152475954728482", 207)
addappid(1276944, 1, "89459bba1a2617a61c6530de92009524b8591f4189c8d7c28c0236aa71fca2db") -- Battlefield 4 Final Stand - Depot 1276944
setManifestid(1276944, "8676710764222584005", 207)
addappid(1276945, 1, "989e97713fa9f662176de1c559c9dcff05abb08b8dc522ca1138c0a99115cbca") -- Battlefield 4 Final Stand - Depot 1276945
setManifestid(1276945, "1962403466025819538", 207)
addappid(1276946, 1, "c42225bee9650de3c8eef2b6cd1bdf351e3662c12306b2f95942bb5490f9264d") -- Battlefield 4 Final Stand - Depot 1276946
setManifestid(1276946, "7404839377196390427", 207)
addappid(1276947, 1, "1d5472123f800329d30c23db740e7bd7e28bc14fd12d8ff31dfcb0cedd6d7390") -- Battlefield 4 Final Stand - Depot 1276947
setManifestid(1276947, "4988107019324951480", 207)
addappid(1276948, 1, "e30c03d57c0f4e48de7a43e48c605d6c6ade223c6e5f52b2f8057fc590e4256e") -- Battlefield 4 Final Stand - Depot 1276948
setManifestid(1276948, "740601182547857990", 207)
addappid(1276949, 1, "7067c6f85cf21aa7c8935e1ce110e22c2509d3ab13d3c168cdb64a56635a67f1") -- Battlefield 4 Final Stand - Depot 1276949
setManifestid(1276949, "5910526862675349379", 207)
addappid(1276950, 1, "f88946fad6d5b55229b0420f5b85d186c7ee3b7bd65d7937a497e76852596b43") -- Battlefield 4 Final Stand - Depot 1276950
setManifestid(1276950, "58485920832411525", 207)
addappid(1276951, 1, "a2b462498da3676ac2cb964e88f52759680ee92426f7bfd0b67883cff0f51789") -- Battlefield 4 Final Stand - Depot 1276951
setManifestid(1276951, "4007557153699093107", 207)
-- Battlefield 4 Naval Strike (AppID: 1272644)
addappid(1272644)
addtoken(1272644, "16314643703021354892")
addappid(1272644, 1, "c9f79a91da01a26b55cada38e571969a2e638070484074d104fdc7bfabb00845") -- Battlefield 4 Naval Strike - Depot 1272644
setManifestid(1272644, "8322727022651352092", 5330658503)
addappid(1276960, 1, "cf4520a038cfdc9510de8c5d8cc80e2a896c6c09f088d20a813dd10f1a920e2a") -- Battlefield 4 Naval Strike - Depot 1276960
setManifestid(1276960, "3373225400227618699", 205)
addappid(1276961, 1, "224aac6c93ed0985d44abfc94cb0930a672a3b9cc554eddbac016b081ebb9291") -- Battlefield 4 Naval Strike - Depot 1276961
setManifestid(1276961, "904463543900474550", 205)
addappid(1276962, 1, "20e65a84ac31fde6717c25d6ae571ba247a96b40fcb28535461acd1cff4a728f") -- Battlefield 4 Naval Strike - Depot 1276962
setManifestid(1276962, "171740206058059156", 205)
addappid(1276963, 1, "3f7f107a6a4f929a90f953a376611927fed4d7d03ecb3db2b6e1e3b76ba51ceb") -- Battlefield 4 Naval Strike - Depot 1276963
setManifestid(1276963, "7880371010077244552", 205)
addappid(1276964, 1, "e55ab3e52be9fd67d8327ca6c2a8c2bc3a07c3d24383b980334b8ff51b9eb15c") -- Battlefield 4 Naval Strike - Depot 1276964
setManifestid(1276964, "8405245584576418551", 205)
addappid(1276965, 1, "bcbb6ffbf4f7da745778e4b694ff2a496b8f26c0e209c2e757c573bc9056c6a4") -- Battlefield 4 Naval Strike - Depot 1276965
setManifestid(1276965, "3141434712726604786", 205)
addappid(1276966, 1, "8ade27f9f85e6094738a8d1819242225c4232a02c15e08178b4d3f9991562fee") -- Battlefield 4 Naval Strike - Depot 1276966
setManifestid(1276966, "288806837185686119", 205)
addappid(1276967, 1, "cee35624ee05a9906fa507ae808fb57a1d708fb2d39fb1883039c993473afe33") -- Battlefield 4 Naval Strike - Depot 1276967
setManifestid(1276967, "4931504251023592997", 205)
addappid(1276968, 1, "20fb8810c7ff39b444c9b25c1457f223f8cf6dec1d9598a2105033d8fbeec289") -- Battlefield 4 Naval Strike - Depot 1276968
setManifestid(1276968, "2218652606665818602", 205)
addappid(1276969, 1, "8b5817de50ad13cde527737a28f42f92d6b7d19ad101c65b00f413a422c0ce85") -- Battlefield 4 Naval Strike - Depot 1276969
setManifestid(1276969, "711706575276955594", 205)
addappid(1276970, 1, "b4141126fe33ea6480dd9e96f3c0a1817ba0ba656ef280d14fa42aaa9852c8c1") -- Battlefield 4 Naval Strike - Depot 1276970
setManifestid(1276970, "5800741897138928140", 205)
addappid(1276971, 1, "fc5068aa8f2938f779e0b88db57d3e042628500317a913496cb52442ad1934e3") -- Battlefield 4 Naval Strike - Depot 1276971
setManifestid(1276971, "7910731398344451971", 205)
-- Battlefield 4 Dragons Teeth (AppID: 1272645)
addappid(1272645)
addtoken(1272645, "14007976601830084197")
addappid(1272645, 1, "04b5db856fa893e2bc3d7fb417d2a3905f6ac73f08f549c238ff9efaf377dd1b") -- Battlefield 4 Dragons Teeth - Depot 1272645
setManifestid(1272645, "1887065100443037285", 7759523749)
addappid(1276980, 1, "5a8eb4cce56d61f3c06dc92adf231f71c114e8b18c37fb3165be2aa3d925f894") -- Battlefield 4 Dragons Teeth - Depot 1276980
setManifestid(1276980, "5157794876455757335", 207)
addappid(1276981, 1, "52b6964afd5d7e371f1caf76fba41e4d4a4a768bf8bb903a1d16f68b545bebed") -- Battlefield 4 Dragons Teeth - Depot 1276981
setManifestid(1276981, "7038559158090672381", 207)
addappid(1276982, 1, "7a4980be2d23b0bb907aef6091d137ecbde0ca0734ec8f9e8b8c131cbd1a36aa") -- Battlefield 4 Dragons Teeth - Depot 1276982
setManifestid(1276982, "5467904705221065467", 207)
addappid(1276983, 1, "a0e70faf040460725d21401a5c40e974a85886299d509045b1104aaf9418c9c9") -- Battlefield 4 Dragons Teeth - Depot 1276983
setManifestid(1276983, "2915395497129894446", 207)
addappid(1276984, 1, "3082237eb81ad8e29066b4c4ec74a49275ae9d8b9ecd3ca7122e1aeebba218b3") -- Battlefield 4 Dragons Teeth - Depot 1276984
setManifestid(1276984, "7314486080655998380", 207)
addappid(1276985, 1, "f8f0c8c2099e706515e6e564ede2eb18e06425d1ebe670a92e2988c87f8e6992") -- Battlefield 4 Dragons Teeth - Depot 1276985
setManifestid(1276985, "5574997351517055396", 207)
addappid(1276986, 1, "07777e6765c998ebb9fe7d0d7ceb9416ef9a40ee2b0b65a0fd77ff04a4e495de") -- Battlefield 4 Dragons Teeth - Depot 1276986
setManifestid(1276986, "9184553502356435840", 207)
addappid(1276987, 1, "f78c31fafd0a90137b99b7d926156800703e49133e493333dc780663f576df7b") -- Battlefield 4 Dragons Teeth - Depot 1276987
setManifestid(1276987, "5689368205292952984", 207)
addappid(1276988, 1, "ef84e58ce42cbe68ac29bf77f4a321b000aecd03a0a52b66f53ad155db200b25") -- Battlefield 4 Dragons Teeth - Depot 1276988
setManifestid(1276988, "6880244344126767606", 207)
addappid(1276989, 1, "f8ef11ef1ddc4ba07f95cef1485116ed395f7c172de0e11fc49b0bb62fd4c732") -- Battlefield 4 Dragons Teeth - Depot 1276989
setManifestid(1276989, "5683997674220526566", 207)
addappid(1276990, 1, "e6cbe7b7b67a486d08a097318eb08175111644ea158c54bda457cbf3ab3d4b1f") -- Battlefield 4 Dragons Teeth - Depot 1276990
setManifestid(1276990, "4840522730242727817", 207)
addappid(1276991, 1, "4bd69eb14fa0d7f4693b662f60cd8bdb21558f3aa3bc38e705eacbfbc7753de6") -- Battlefield 4 Dragons Teeth - Depot 1276991
setManifestid(1276991, "5583330323908170752", 207)
-- Battlefield 4 Community Operations (AppID: 1272650)
addappid(1272650)
addappid(1272650, 1, "5c7d38f8e9899a9ed1e2ae951070aa3fbf284b6ce70bd7f3ec60451406e717b3") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - Content
setManifestid(1272650, "8189153946608321125", 3052085878)
addappid(1272658, 1, "bad245d97f801f424c404d867afc245a42283dae04dbe9bbdcbc45e422f34c05") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - en_US
setManifestid(1272658, "1434996877352769812", 207)
addappid(1272659, 1, "8284bca717638233091b3ccb6b7aaee70b6d811b69ae68ba7a3298b1095e5d18") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - fr_FR
setManifestid(1272659, "2324364489166023688", 207)
addappid(1277000, 1, "84b01bf6fa77de1fe055656320e1601d12b025b84049c7bc2ac0028f3a7c55cd") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - it_IT
setManifestid(1277000, "9008508770248271278", 207)
addappid(1277001, 1, "59f06e98bb1d9ba7b6bc7f66cce897ea68577816e489b17edab97f4496657a9e") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - de_DE
setManifestid(1277001, "5627938216587220944", 207)
addappid(1277002, 1, "a0cf66721ce66acd390a72f4071436393bc7852ca7b69590f7915b683c226957") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - es_ES
setManifestid(1277002, "2845838032828787436", 207)
addappid(1277003, 1, "7dd848dcdb35d33c664617206211fae04819027f8862d5e12eca6a6005b95fc7") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - pl_PL
setManifestid(1277003, "7485616906029489831", 207)
addappid(1277004, 1, "491421c524af7a28432f8cb0a92fc39a0e6aca287eb7c2b5104ec7b84300e39d") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - ru_RU
setManifestid(1277004, "6438894928042359864", 207)
addappid(1277005, 1, "ea3b36ab61cb39a7b1bba9f7e2f58cf441aa3eb0dea22d74141b36201616184c") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - pt_BR
setManifestid(1277005, "5643239877949005998", 207)
addappid(1277006, 1, "1c86872bf31b3b46ad0a733be8a70c0b108219da9837a9e6566cd144ea822a46") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - ja_JP
setManifestid(1277006, "5821429518505440230", 207)
addappid(1277007, 1, "ebb6a7bfa044e6f17726228add11d83210067c172de2b0687ae3dc9db9a25bbd") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - cs_CZ
setManifestid(1277007, "3464933931786430342", 207)
addappid(1277008, 1, "01451622f3b2caac69231c834e0e61309a32d285ae4787573fb2140968eab52a") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - ko_KR
setManifestid(1277008, "7323057193122362050", 207)
addappid(1277009, 1, "306ea8cf96104676b2415bb4681509380a72e3e1f4d728208c5b98e17260c395") -- Battlefield 4 Community Operations - Battlefield 4 Community Operations - zh_TW
setManifestid(1277009, "2981626549977600983", 207)
-- Battlefield 4 Night Operations (AppID: 1272654)
addappid(1272654)
addappid(1272654, 1, "27a19a5f4615a2baf3ffdbdf90599572a51c47a0992616e675efac8c33a103c8") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - Content
setManifestid(1272654, "1045052835655380351", 1015660175)
addappid(1277020, 1, "39f9dba08679f98da2e386caffe5436b5be81f6f3a87065f62c6cd91a7b92270") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - en_US
setManifestid(1277020, "673014866185137298", 207)
addappid(1277021, 1, "9eb05c400091204e951dcf02f96055ba451689ca53a2a53510315997d58d99d2") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - fr_FR
setManifestid(1277021, "8874310982080589143", 207)
addappid(1277022, 1, "524b24df75c696b37aed7c97a4ee4644858a2ac25481f881ca91962254ea0694") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - it_IT
setManifestid(1277022, "8292679587716402855", 207)
addappid(1277023, 1, "1855b9b4f4de3c69586c4e3802e4080b0bdd33340af947e4fdc2490865b8e9b0") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - de_DE
setManifestid(1277023, "4546639915991340860", 207)
addappid(1277024, 1, "60c2c34d28e5fd7671bb5f69cab6f4e789061aef1a4fd0613e6b390972a10b0d") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - es_ES
setManifestid(1277024, "6523170316932347708", 207)
addappid(1277025, 1, "77106d8cee6f13834191b2757ac656464e228f4a9248336f8598b28a8384ee61") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - pl_PL
setManifestid(1277025, "9193391038746787754", 207)
addappid(1277026, 1, "37b0be4c91d012e1da27b5d1efc11e5280a9d18496da5609d969f428f7eb19a4") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - ru_RU
setManifestid(1277026, "8412430344268926156", 207)
addappid(1277027, 1, "85b97e14f41d8e06b6226f6546b6a4699658273264fb12d64fde7150991a005e") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - pt_BR
setManifestid(1277027, "738803481736316564", 207)
addappid(1277028, 1, "d3c2b9167531f5fac9db07ba59174137d2d5cf8148ba4780fc01f0faa231a49c") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - ja_JP
setManifestid(1277028, "5469913080843878539", 207)
addappid(1277029, 1, "053515ee9bd88846aa4e0eb6dc006bc0b18470c24570173a3dde3b1d40520c20") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - cs_CZ
setManifestid(1277029, "4757173540653704648", 207)
addappid(1277030, 1, "89623331537c42ea1b73ec6a9be935e5685027437c04d10cc5c6e5e58b49803c") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - ko_KR
setManifestid(1277030, "8092221007795059891", 207)
addappid(1277031, 1, "858aedda6f785500f8dbe6ec50fc986d7b5603dcba0db1432f014964873b79e8") -- Battlefield 4 Night Operations - Battlefield 4 Night Operations - zh_TW
setManifestid(1277031, "2100212834282816064", 207)
-- Battlefield 4 Legacy Operations (AppID: 1272657)
addappid(1272657)
addappid(1272657, 1, "ce870122f2802b867a41de7d8b3ce9aa0de5af61a264ce3de9d09576a10e8176") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - Content
setManifestid(1272657, "2560882888371150786", 3115292055)
addappid(1277040, 1, "b8023e0d30afdd3b12bf791d9752a8293558f164f032eb60835dcb5a0079e704") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - en_US
setManifestid(1277040, "5925974092013194913", 207)
addappid(1277041, 1, "483a7a0a347cb69cda006ac4ab78031ba5b12ecc5fef397fe6681245d1fcc9c4") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - fr_FR
setManifestid(1277041, "3080481614081291389", 207)
addappid(1277042, 1, "e30e30d87dcc5c84943071f273d5903b0963cbb79a577d96d6cd9cc5845a63f3") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - it_IT
setManifestid(1277042, "2352534588065124529", 207)
addappid(1277043, 1, "3dacfe0f1752fdee16efe85877a22729ab1ed05c75073b3483965bca8bfe1e55") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - de_DE
setManifestid(1277043, "1024195867706260014", 207)
addappid(1277044, 1, "8f8e5a3967c86866923f93b03440af59f31672228b8084b1739b68b8edefc9b0") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - es_ES
setManifestid(1277044, "551413099187343965", 207)
addappid(1277045, 1, "5c2d068f117af2e78408d58406f034b19e0d3e4aba51165b4ca7abbcf91ce561") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - pl_PL
setManifestid(1277045, "1156373570140536123", 207)
addappid(1277046, 1, "1eaabb6698f1f72f119a3695884152959417f78e7488279d4716ec961ccb0f49") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - ru_RU
setManifestid(1277046, "6135512750757700865", 207)
addappid(1277047, 1, "f10120e161e62053d171dcd2b580d03cbede06795b53e47f781aa234d52728a4") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - pt_BR
setManifestid(1277047, "8016969571309461966", 207)
addappid(1277048, 1, "30a013ff004d379d21ec133ec78327f01c4962f17dbbe05cc80712ff558d8ae8") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - ja_JP
setManifestid(1277048, "365876245565934165", 207)
addappid(1277049, 1, "c16b5ffa1c2c7aa0a74f6cad6f6237ea22bfcfdda0636669c5abe7e381869ea8") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - cs_CZ
setManifestid(1277049, "5284941833546291750", 207)
addappid(1277050, 1, "6d6a22c18b7f0a51a3c5789714c83720bd57e4f320ece312ae75ef99307728a2") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - ko_KR
setManifestid(1277050, "7006746036466336266", 207)
addappid(1277051, 1, "cf331d04e115aa00bf7ddf3a2ef716b2e75d9515fa9648b44dc0649cadb8f257") -- Battlefield 4 Legacy Operations - Battlefield 4 Legacy Operations - zh_TW
setManifestid(1277051, "1154277164389555118", 207)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1238870) -- Battlefield 4 Premium Membership
addtoken(1238870, "394572474292069447")
addappid(1238871) -- Battlefield 4 Ultimate Shortcut Bundle
addappid(1272640) -- Battlefield 4 Premium Edition - Key
addtoken(1272640, "11249254201869736922")
addappid(1276020) -- Battlefield 4 Standard Edition - Key
addappid(1315430) -- Battlefield 4 DMR Shortcut Kit
addappid(1315431) -- Battlefield 4 Handgun Shortcut Kit
addappid(1315432) -- Battlefield 4 Shotgun Shortcut Kit
addappid(1315433) -- Battlefield 4 Grenade Shortcut Kit
addappid(1315434) -- Battlefield 4 Carbine Shortcut Kit
addappid(1315435) -- Battlefield 4 Engineer Shortcut Kit
addappid(1315440) -- Battlefield 4 Ground  Sea Vehicle Shortcut Kit
addappid(1315441) -- Battlefield 4 Air Vehicle Shortcut Kit
addappid(1315442) -- Battlefield 4 Weapon Shortcut Bundle
addtoken(1315442, "17653099291739995246")
addappid(1315443) -- Battlefield 4 Vehicle Shortcut Bundle
addtoken(1315443, "5881263046246690550")
addappid(1315470) -- Battlefield 4 Assault Shortcut Kit
addappid(1315471) -- Battlefield 4 Recon Shortcut Kit
addappid(1315472) -- Battlefield 4 Support Shortcut Kit
addappid(1315480) -- Battlefield 4 Soldier Shortcut Bundle
addtoken(1315480, "1001675746326222669")