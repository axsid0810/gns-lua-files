-- 2507980's Lua and Manifest Created by Hubcap Manifest
-- Meta Ghost: Breaking Show
-- Created: July 19, 2026 at 01:05:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2507980, 1, "ef9bd33516affb9ce5b9635c9df0ed9557802c15bf19f2cc7e0853ac0d07bc49") -- Meta Ghost: Breaking Show
addtoken(2507980, "7549346252839575706")
-- MAIN APP DEPOTS
addappid(2507981, 1, "8520d99b3096cc762d3ad718e0b7a9247890d54f1630eb6f1ea63336e22ca59a") -- Depot 2507981
setManifestid(2507981, "8268834818902323952", 7919571601)
addappid(2507982, 1, "bd939bb60e2e65cb09775e8253d7f99b007027502baf8dedf57614f644c1dbba") -- Depot 2507982
setManifestid(2507982, "3713218367745909684", 7919571606)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4818150) -- Meta Ghost Breaking Show  Eisa Downloadable Content
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2507983) -- Depot 2507983 (empty depot)