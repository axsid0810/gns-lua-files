-- 4000's Lua and Manifest Created by Hubcap Manifest
-- Garry's Mod
-- Created: May 16, 2026 at 21:58:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4000, 1, "85c35e0e023c1e99185ca5645fe083568247de0cd3f786655a10845805935393") -- Garry's Mod
-- MAIN APP DEPOTS
addappid(4001, 1, "70b50aa1b52c66816a5f3ee61235edc988520ba54e96913f0bf7ff73c37794de") -- GMOD
setManifestid(4001, "220404784471597770", 6800537492)
addappid(4002, 1, "a3e3a34828218993dbc70c168dd602ee73fe43b8fef8cd6458be59de953da3d9") -- GMOD Windows
setManifestid(4002, "8989514576105529138", 312799722)
addappid(4003, 1, "f12729464515b02d079469c178a93188480f07765f21fe5191f3cc35c18378aa") -- GMOD Linux
setManifestid(4003, "1075478557630448531", 277257490)
addappid(4004, 1, "bda3d73d97ece9ee942f1275a70d9af5d37dcd48e2e47565feb3b00fc6b66dbd") -- GMOD OSX
setManifestid(4004, "2562883153234512593", 160085114)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)