-- 1497440's Lua and Manifest Created by Hubcap Manifest
-- COCOON
-- Created: October 20, 2025 at 06:04:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1497440) -- COCOON
-- MAIN APP DEPOTS
addappid(1497441, 1, "3cef947e85b4c01e51727a736bb830ae92bd9e014c9a3d60b0b5d78ac45f3697") -- Depot 1497441
setManifestid(1497441, "3800392628809777641", 1657904318)