-- 32450's Lua and Manifest Created by Hubcap Manifest
-- LEGO® Indiana Jones™ 2: The Adventure Continues
-- Created: September 29, 2025 at 21:51:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(32450) -- LEGO® Indiana Jones™ 2: The Adventure Continues
-- MAIN APP DEPOTS
addappid(32451, 1, "7667a7f344fae16bd27047db8178e686f87e4a6250e76148c69b56b417e8eca6") -- lego_indy_2_content
setManifestid(32451, "2039629895929226819", 4675796450)