-- 1173820's Lua and Manifest Created by Hubcap Manifest
-- FINAL FANTASY VI
-- Created: October 13, 2025 at 14:11:29 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1173820) -- FINAL FANTASY VI
-- MAIN APP DEPOTS
addappid(1173821, 1, "f14232f6b12f98270c9af46260c0e9ed60c5c3b2e7ea5aa7d7a4a3aad47b27b6") -- Depot 1173821
setManifestid(1173821, "7246209900814962606", 1167864617)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)
-- DLCS WITH DEDICATED DEPOTS
-- FINAL FANTASY VI OST  Wallpaper (AppID: 1638420)
addappid(1638420)
addappid(1638420, 1, "044ac29b160a56f2451fe51f246515764b172431ebf2871f35f8afad63db50fa") -- FINAL FANTASY VI OST  Wallpaper - Depot 1638420
setManifestid(1638420, "4312747159132628671", 109922615)