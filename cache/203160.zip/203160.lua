-- 203160's Lua and Manifest Created by Hubcap Manifest
-- Tomb Raider
-- Created: July 04, 2026 at 07:14:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 65
-- Total DLCs: 28

-- MAIN APPLICATION
addappid(203160, 1, "8761f25506d656a2def8ed120f4dd7a8232fe0022f208c6e9b84d85d3e81c0fd") -- Tomb Raider
-- MAIN APP DEPOTS
addappid(203161, 1, "61e24eab63c4bab53d1bb8a95f77ee8243fb5fcdf4860c6fbf1408316cdfbf90") -- Main Content
setManifestid(203161, "6868169268668587009", 9666955757)
addappid(203162, 1, "ce442b8d1224660972c96a55e1d87cec7ce819ca4e9537cedb0a2aa22d4fdfa4") -- Executable
setManifestid(203162, "7173325336906608099", 19198000)
addappid(203163, 1, "a2a0cd3c8b65e27fefe2de84bbddcf331df98dc680e163177f50ec8f713de9c3") -- English
setManifestid(203163, "6372322314347314780", 1386342132)
addappid(203164, 1, "c3a901690af3fbfe7a70701120f4c4a6978facd16adcee72fb39db3724b29bd1") -- French
setManifestid(203164, "2221628542884248728", 1376271172)
addappid(203165, 1, "16b5e87c15d6b9a517fc58d810412d5ff6dd639cd0766472b77543a540592a48") -- Italian
setManifestid(203165, "8032797791648544821", 1372082372)
addappid(203166, 1, "2bcb99cbe9a392168d737888a7e4abbb29a372cd5b9ce10c7f975c8f9c8b9c88") -- German
setManifestid(203166, "6175707587917180945", 1388530548)
addappid(203167, 1, "2b0a98c8c2561ac9adb8135100d2032d135ce48b7616e051d797f2d0f0267d47") -- Spanish
setManifestid(203167, "3029664700874485048", 1381630836)
addappid(203168, 1, "c52a9d42193ea243ce8a917d1048626acc0162667f15fc4529472781fbd3f32d") -- Russian
setManifestid(203168, "1651304722641604491", 1393190388)
addappid(203169, 1, "a1e968e7fb8ab624fe2ea724e5661cb04b386bc9270b5ceab2209ca6220e3ebf") -- Polish
setManifestid(203169, "4159211050702832863", 1387197044)
addappid(203170, 1, "8d22d061e8be4014c0c0fedb37a89b7b800457b0cd5d92c160dd7c9299b9c6d7") -- Arabic
setManifestid(203170, "7500082729520061352", 1395028196)
addappid(203171, 1, "e6d3cc52e870009b676358d6cade6ecd78a596e2549ace8639df5323a14f549c") -- Czech
setManifestid(203171, "308773064163359714", 169833)
addappid(203172, 1, "3a16bfb7d748266f2e780c303330e3961a5bd7529c48d7c490f130b709dbc1cb") -- Dutch
setManifestid(203172, "417401587203691460", 174725)
addappid(203173, 1, "c3793f66fc422c1f12fa01c86c14fbf4982fb43aeb39c377cd9ee89b93abbe68") -- Portuguese
setManifestid(203173, "126943139984375656", 175829)
addappid(203174, 1, "d56c11d30362515834313a671db394a9a372b454d3929e3b7b8cc84205727f52") -- Chinese
setManifestid(203174, "1498933388783282340", 156033)
addappid(203175, 1, "e5b474d973fd5771c61512a6401d301503256b4dfd07a9f3ba0f9daa7be946e1") -- Korean
setManifestid(203175, "15894646782811881", 188146)
addappid(203177, 1, "c9f606cbed8879048fe6729db59b533e4177b87c576db69c6066ce6ff68201f5") -- Debug files
setManifestid(203177, "6998570952704227523", 519308076)
addappid(203179, 1, "7a18ab94096c1a1a2feed8156b8d8f10b696bf7b60b136043ae9edb311efe33e") -- Redists
setManifestid(203179, "6983198772927377089", 0)
addappid(208819, 1, "6a903994b94482b0030ad66e359db442e3104a576f58764045922c15c65cfa40") -- Mac_Main_Data
setManifestid(208819, "4250963835913782316", 11074219181)
addappid(208820, 1, "2e3ff779c13331b3b285b9bf2f58dd290254aab8e7dbf5f97bea3868790d4e51") -- Mac_Main_App
setManifestid(208820, "4761804522679938323", 91379207)
addappid(208821, 1, "6b4a16f6fcba71023893e7e36c24613ed4f97474113dafa9a469687b0f4768e5") -- Mac_English
setManifestid(208821, "156998305983886859", 2)
addappid(208822, 1, "2f688e8dbf49dbe3d470bff2e77fcba0693e339ffb1e8e64bdbfc7bf0555ed59") -- Mac_French
setManifestid(208822, "364503334385755210", 1376271174)
addappid(208823, 1, "d61f132460921b85eb652621940771b8d475bca479d4d198ef1a9cc34587b903") -- Mac_German
setManifestid(208823, "6478998103927324083", 1388530550)
addappid(208824, 1, "75a061356ac31cb3f16371e9e8cf3a090488bc7f302e5aef1d6750a173ca1dbd") -- Mac_Italian
setManifestid(208824, "8975875999616940784", 1372082374)
addappid(208825, 1, "6f1c26b862fba59a1c5a02517073f9fae74e496167992eae468d59d5e4fab7b2") -- Mac_Spanish
setManifestid(208825, "3390880869564412", 1381630838)
addappid(208826, 1, "4855c6e3c3d35f4f10c412aabcbf445367420d2e2125cbaeffebf0bc1809348b") -- Mac_Russian
setManifestid(208826, "40304662574714752", 1393190390)
addappid(208827, 1, "ecba04933d21a8c0b34a6f4bffd7a51ce0ab7101f82043264e46a61b3084f0e3") -- Mac_Polish
setManifestid(208827, "160232140839323009", 1387197046)
addappid(208828, 1, "741d0e9abbf8621e7619caf4562c62ce09845cc082a919f5a480b939f3fb249f") -- Mac_Arabic
setManifestid(208828, "129976517472939654", 1395028198)
addappid(208829, 1, "8fb1b21e479c2b7076f3a366d4a5c03bd7452211e639502db538f8325b9322f9") -- Mac_Czech
setManifestid(208829, "3726386665239070", 169835)
addappid(237451, 1, "36c7c0593c3bb0a21e1055bcf1bcff36113d6e040180435638d24e72537c586e") -- Mac_Dutch
setManifestid(237451, "153548021890381304", 174727)
addappid(237452, 1, "70094aaac1f8fd02f99f3cdaf10c4b07e5c45a661ba22446748644d55ba633e5") -- Mac_Portuguese
setManifestid(237452, "114014132200688411", 175834)
addappid(237453, 1, "865777cc2940161ffef13df392fa2609e888d053375b6131e913b3d81c964ad0") -- Mac_Chinese
setManifestid(237453, "452271965386658834", 156038)
addappid(237454, 1, "37f321e447aff127c3599c2dd8ca9dd7631c6bd69b0ca1d37bcb21e4b2b479d2") -- Mac_Korean
setManifestid(237454, "306367810370998586", 188148)
addappid(440590, 1, "579fe46e49191847bdb359a297e87b9aee0e9e63387127567e0ba8b64c3f80a4") -- Linux_Main_Data
setManifestid(440590, "986069843286313347", 10994427250)
addappid(440591, 1, "37165f1cf6b7f62b255e41d636a0d0bcfa98ae51730cf58f85c1877c1b923fe5") -- Linux_Main_App
setManifestid(440591, "5842367704209189430", 259044450)
addappid(440592, 1, "184e6efe5968e59109cc244e9b7343842415eea6c4da90218d0305a0690bbc2f") -- Linux_English
setManifestid(440592, "687047217854720503", 2)
addappid(440593, 1, "950477178761563ba92ccd3aa8980a9853ac88b6f599d0a1a7f1d0b2559743fc") -- Linux_French
setManifestid(440593, "42266299039414392", 1376271174)
addappid(440594, 1, "b47b94ec78e23f3af352cdd07c3c7edcba43793adfefd6006e15fba30218a6e9") -- Linux_German
setManifestid(440594, "127074928721898036", 1388530550)
addappid(440595, 1, "94db1da5ff0f2029d7f0199815ba68d824ffbb29d254686fad57d65ab33a1ff5") -- Linux_Italian
setManifestid(440595, "523582744900039895", 1372082374)
addappid(440596, 1, "c1e9a4ae88b9f3f6ad372542c5180655589d669f1a8dd6a104418b536fe01208") -- Linux_Spanish
setManifestid(440596, "311989343064462570", 1381630838)
addappid(440597, 1, "d65d20b83bebf65a4e24cb7b81fe939c295f7e58d3969f0b482303ab84005e8e") -- Linux_Russian
setManifestid(440597, "89755833937208614", 1393190390)
addappid(440598, 1, "963d8a58e262056ad9d4cfe7069a5fed85beb74a8d155bd12417aa13d84f3eac") -- Linux_Polish
setManifestid(440598, "294956608902313012", 1387197046)
addappid(440599, 1, "9d5961c505889f2c6e7dd230284247426615e1400c0060b9c2bbf5fffc43c8b0") -- Linux_Arabic
setManifestid(440599, "21527117070026924", 1395028198)
addappid(440600, 1, "b220c02ea904ca52cef8057642e5de9c1af4e559f8d4d375db3a23a2bea6757f") -- Linux_Czech
setManifestid(440600, "327041864207408675", 169835)
addappid(440601, 1, "a27b89abd71d95c2f4a2ed29b8cbadaf809f08f10b7850b1ceaee363700dcc48") -- Linux_Dutch
setManifestid(440601, "85444624794647936", 174727)
addappid(440602, 1, "d441309a37ba9c2385111f88914235548c94b7976d087d6d2e98fe182aa6897f") -- Linux_Portuguese
setManifestid(440602, "541594753172684", 175834)
addappid(440603, 1, "16f090e9848cccae1f5d17ab5e19ca4b88b64fbf78e12f7076156e362df1649c") -- Linux_Chinese
setManifestid(440603, "354943449932580860", 156038)
addappid(440604, 1, "df62c5b80439a363592a1ee983069e38754fbe26d2a9d9b04b7a513dee844a6e") -- Linux_Korean
setManifestid(440604, "357474473073951759", 188148)
addappid(237464, 1, "4d21234bfbdd6669fc3a25767ea2604651821fff500e08d182154e149e90b9ec") -- Linux_Launch_Overrides
setManifestid(237464, "18517573592165402", 2094987)
-- DLCS WITH DEDICATED DEPOTS
-- Tomb Raider MP Map - Shanty Town (AppID: 208810)
addappid(208810)
addappid(208810, 1, "3cfa43884715f368d8b2dad9bfa28fc087ddd410df13da33b8f294f3b55dac67") -- Tomb Raider MP Map - Shanty Town - DLC: MP Map - Shanty Town
setManifestid(208810, "3849166016491976395", 69550800)
addappid(237457, 1, "a249501c98fbf6545731af9f8ab85af2b5d7256de6a6d92abe34b26dca89eac4") -- Tomb Raider MP Map - Shanty Town - Mac DLC: MP Map - Shanty Town
setManifestid(237457, "258205796996777006", 69550800)
addappid(440606, 1, "38521192fd13905227c7dbb59d3fcfbb3b30de61fdf05cfbea95b9902fc515ae") -- Tomb Raider MP Map - Shanty Town - Linux DLC: MP Map - Shanty Town
setManifestid(440606, "100941034871829048", 69550800)
-- Tomb Raider Caves and Cliffs Multiplayer Map Pack (AppID: 208811)
addappid(208811)
addappid(208811, 1, "1d442f8e0515ec2863511a06103ef5b433825abac89acc5aeec29ebf0180bf2d") -- Tomb Raider Caves and Cliffs Multiplayer Map Pack - DLC: Caves and Cliffs Multiplayer Map Pack
setManifestid(208811, "4516305040932421733", 295199840)
addappid(237458, 1, "2a77cf47e00e579378c9dcaf7a225394191008805c12d66ce925a8d0ce0cf9bd") -- Tomb Raider Caves and Cliffs Multiplayer Map Pack - Mac DLC: Caves and Cliffs Multiplayer Map Pack
setManifestid(237458, "213429337703824649", 295199840)
addappid(440607, 1, "d0b1c061556fb963b76deadb1c1885157bb73b6ec30f640ee8888f3b3ca513f7") -- Tomb Raider Caves and Cliffs Multiplayer Map Pack - Linux DLC: Caves and Cliffs Multiplayer Map Pack
setManifestid(440607, "91893288272464053", 295199840)
-- Tomb Raider Tomb of the Lost Adventurer (AppID: 208812)
addappid(208812)
addappid(208812, 1, "36b097c22c87912ceb3065529cf17734e858329344cdd0146dcc193acd8b7e8d") -- Tomb Raider Tomb of the Lost Adventurer - DLC: Tomb of the Lost Adventurer
setManifestid(208812, "2242108116796868778", 38919328)
addappid(237459, 1, "aeef7ba03236fa05e24d64bb0d185794b1bce9b8df9ffb67303f181c3b4c8d9b") -- Tomb Raider Tomb of the Lost Adventurer - Mac DLC: Tomb of the Lost Adventurer
setManifestid(237459, "30328455661219517", 38919328)
addappid(440608, 1, "31484bd8a45d93f55a03d301daa3e0ba8132660f30ffb254e34f48a91f2d5aa0") -- Tomb Raider Tomb of the Lost Adventurer - Linux DLC: Tomb of the Lost Adventurer
setManifestid(440608, "169708167060440312", 38919328)
-- Tomb Raider Shipwrecked Multiplayer Map Pack (AppID: 208813)
addappid(208813)
addappid(208813, 1, "16dc24c6ef722950c5df43d929c2d89256f4b7123b42dbadf4c4888faf1bbfc4") -- Tomb Raider Shipwrecked Multiplayer Map Pack - DLC: Shipwrecked Multiplayer Map Pack
setManifestid(208813, "9089747663761388950", 189376400)
addappid(237460, 1, "ab0b7115a2c210a037846d36d95ab39c4e34f2fa6b77da8dac28b1df4d227d28") -- Tomb Raider Shipwrecked Multiplayer Map Pack - Mac DLC: Shipwrecked Multiplayer Map Pack
setManifestid(237460, "68243511687155423", 189376400)
addappid(440609, 1, "d393b24757bf76803e08c469daf0986c89f2b4938ce2c5d1ad20a0b709241b40") -- Tomb Raider Shipwrecked Multiplayer Map Pack - Linux DLC: Shipwrecked Multiplayer Map Pack
setManifestid(440609, "98653675563851327", 189376400)
-- Tomb Raider 1939 Multiplayer Map Pack (AppID: 208814)
addappid(208814)
addappid(208814, 1, "91aeef621ab95387902eeabaf5b70788934234d242ece22a6982093358264c4f") -- Tomb Raider 1939 Multiplayer Map Pack - DLC: 1939 Multiplayer Map Pack
setManifestid(208814, "3065129487810682314", 94397024)
addappid(237461, 1, "772e1391a58143897265094469df430c11778fdf159f5000f23a0aa4cfec599f") -- Tomb Raider 1939 Multiplayer Map Pack - Mac DLC: 1939 Multiplayer Map Pack
setManifestid(237461, "16604663053197898", 94397024)
addappid(237455, 1, "74e49ea35c1168af45bb67994811af9e09f311ecd6a05f8ecdaae81b6455a2d8") -- Tomb Raider 1939 Multiplayer Map Pack - Linux DLC: 1939 Multiplayer Map Pack
setManifestid(237455, "119770789988999687", 94397024)
-- Survival Edition Bonus Content (AppID: 208816)
addappid(208816)
addappid(208816, 1, "7b1433cb7e4f09d837e4ded167d1aaa1b0c298f377b9f53cdb59aa7e140dea83") -- Survival Edition Bonus Content - Survival Editon Bonus Content
setManifestid(208816, "56818866596074144", 1752272341)
-- Tomb Raider Japanese Language Pack (AppID: 237450)
addappid(237450)
addappid(203176, 1, "71ad0423b3d812e84dfe9b1d190bd80c0ff78584a1681ab754c33b408544e94b") -- Tomb Raider Japanese Language Pack - Japanese
setManifestid(203176, "7927540942304709888", 2887985378)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(208790) -- Tomb Raider Scavenger Scout
addappid(208791) -- Tomb Raider Scavenger Executioner
addappid(208792) -- Tomb Raider Scavenger Bandit
addappid(208793) -- Tomb Raider Fisherman
addappid(208795) -- Tomb Raider Hitman Gun - Silverballer
addappid(208796) -- Tomb Raider Hitman Gun - Agency SPS 12
addappid(208797) -- Tomb Raider Hitman Gun - HX AP-15
addappid(208798) -- Tomb Raider Hitman Gun - JAGD P22G
addappid(208799) -- Tomb Raider Hitman Gun - M590 12ga
addappid(208800) -- Tomb Raider Hitman Gun - STG 58 Elite
addappid(208801) -- Tomb Raider Animal Instinct
addappid(208802) -- Tomb Raider Agility
addappid(208803) -- Tomb Raider Headshot Reticle
addappid(208804) -- Tomb Raider Pistol Burst
addappid(208805) -- Tomb Raider Pistol Silencer
addappid(208806) -- Tomb Raider Hunter Skin
addappid(208807) -- Tomb Raider Aviatrix Skin
addappid(208808) -- Tomb Raider Guerilla Skin
addappid(208809) -- Tomb Raider Mountaineer Skin
addappid(208817) -- Tomb Raider Demolition
addappid(208818) -- Tomb Raider Sure-Shot
-- EMPTY DEPOTS (no content on any branch)
-- addappid(237456) -- Depot 237456 (empty depot)
-- addappid(237462) -- Depot 237462 (empty depot)
-- addappid(237463) -- Depot 237463 (empty depot)
-- addappid(440605) -- Depot 440605 (empty depot)