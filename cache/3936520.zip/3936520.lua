-- 3936520's Lua and Manifest Created by Hubcap Manifest
-- Tour de France 2026
-- Created: July 02, 2026 at 10:55:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(3936520) -- Tour de France 2026
-- MAIN APP DEPOTS
addappid(3936521, 1, "54a7be6f753caa5473c9f098b40a9c1519ca57f4d0985f84d940de9812450675") -- Depot 3936521
setManifestid(3936521, "2999476546498220553", 33836056368)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4502380) -- Tour de France 2026 - Spanish Grand Dpart Pack
addappid(4502390) -- Tour de France 2026 - Upgrade to Deluxe