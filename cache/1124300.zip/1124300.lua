-- 1124300's Lua and Manifest Created by Hubcap Manifest
-- HUMANKIND™
-- Created: May 13, 2026 at 10:46:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 9
-- Shared Depots: 6

-- MAIN APPLICATION
addappid(1124300, 1, "4d092aea0cdc3bc272cb80eb0511617bc474b5cdafcebae2408b700eadf9ce84") -- HUMANKIND™
-- MAIN APP DEPOTS
addappid(1124301, 1, "31824a528b21cc0a39767df59e54f348eea747f224c7df02c059dceeb02d744a") -- HUMANKIND™ Windows
setManifestid(1124301, "1069006138388157750", 37295796465)
addappid(1124302, 1, "a69d865390db19a0c3c7a5a141b33fbbb1b732aff23e1b9cc0f5b7bc706aa623") -- HUMANKIND™ macOS
setManifestid(1124302, "7581361316124851545", 37342725351)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
-- DLCS WITH DEDICATED DEPOTS
-- HUMANKIND - Digital Deluxe Upgrade (AppID: 1633650)
addappid(1633650)
addappid(1124303, 1, "5193634fe68221a87011d503d6041e6f94ecd34252547c4e9a7bd2dfd3d9cdc7") -- HUMANKIND - Digital Deluxe Upgrade - HUMANKIND™ OST and Posters
setManifestid(1124303, "4307787678226630570", 249854910)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1633651) -- HUMANKIND Pre-Purchase
addappid(1704220) -- HUMANKIND - Default Content 1
addappid(1819400) -- HUMANKIND - Cultures of Africa Pack
addappid(1819410) -- HUMANKIND - Cultures of Latin America Pack
addappid(1833990) -- HUMANKIND - Together We Rule Expansion Pack
addappid(1838710) -- HUMANKIND - Great Zimbabwe Wonder
addtoken(1838710, "1027677571221873596")
addappid(2320210) -- HUMANKIND - Para Bellum Wonders Pack
addappid(2320211) -- HUMANKIND - Cultures of Oceania Pack