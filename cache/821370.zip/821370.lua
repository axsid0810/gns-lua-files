-- 821370's Lua and Manifest Created by Hubcap Manifest
-- MLB Home Run Derby VR
-- Created: July 26, 2026 at 05:34:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(821370, 1, "f48b2beec198b25fd2971aa6ab31091e2699ed93610c32b23af46ae570603b7b") -- MLB Home Run Derby VR
-- MAIN APP DEPOTS
addappid(821371, 1, "b49030f55487302c943f52cc99c4501379286c9d608bcd83fbc7fce1bb19b272") -- MLB Home Run Derby VR Content
setManifestid(821371, "8571462775244809206", 18268282145)