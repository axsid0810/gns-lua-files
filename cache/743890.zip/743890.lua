-- 743890's Lua and Manifest Created by Hubcap Manifest
-- Mega Man X Legacy Collection
-- Created: March 18, 2026 at 03:54:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(743890, 1, "bf4f6d1f1d06c739dc8a50b3eed2ed8975627ad6ee705a047420b775b18c1b4c") -- Mega Man X Legacy Collection
-- MAIN APP DEPOTS
addappid(743891, 1, "aa7be958260862cf85f39eddd672463ecb9c606ec8bd342b786363ecd049651f") -- kinoko Content
setManifestid(743891, "1036283505936301385", 2141822440)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- MMXLC Wallpaper (AppID: 861800)
addappid(861800)
addappid(861801, 1, "88ba52fae3de69e7a39adb93fe05ace294dcdd49b3dcaa59f0f4ab42f15aa5ad") -- MMXLC Wallpaper - MMXLC Wallpaper デポ
setManifestid(861801, "2415755387975123019", 78124008)