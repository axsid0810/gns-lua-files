-- 1265920's Lua and Manifest Created by Hubcap Manifest
-- Life is Strange Remastered
-- Created: September 29, 2025 at 22:05:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1265920) -- Life is Strange Remastered
-- MAIN APP DEPOTS
addappid(1265921, 1, "1d3906ef8fa5305f9430e0cdb7db5a577fe38da35a49dba3ec73ad9468f65807") -- Life is Strange Remastered Content
setManifestid(1265921, "9135202032808388294", 34898212673)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)