-- 2069250's Lua and Manifest Created by Hubcap Manifest
-- High On Life 2
-- Created: June 01, 2026 at 22:26:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2069250, 1, "574ed53530569d05713036fa5ad12551743a5f57bc10b303d7d56a107c1806e2") -- High On Life 2
-- MAIN APP DEPOTS
addappid(2069251, 1, "35becf1e6b195ea0a6a5e58c1b0821e9c32c46f0bec9c201161448ef5b5d578f") -- Depot 2069251
setManifestid(2069251, "8288753715680421026", 93263261057)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4137500) -- High On Life 2 Pre-Order