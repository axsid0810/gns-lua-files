-- 302510's Lua and Manifest Created by Hubcap Manifest
-- Ryse: Son of Rome
-- Created: September 30, 2025 at 11:52:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(302510) -- Ryse: Son of Rome
-- MAIN APP DEPOTS
addappid(302511, 1, "077ac69c92a280ff9f72fa74a851954290a19850014909f6b279a4212f58f2be") -- Code
setManifestid(302511, "8667567128975034676", 231699655)
addappid(302512, 1, "dd7454ff229c81fc90bceb393ec2890da81e9861d81451f753c83d08ead4f9e0") -- Game
setManifestid(302512, "357659076918886484", 7357018001)
addappid(302513, 1, "a9e59645be4be6ba2d78709770f02cabc2281ea94b745cb1c228d1674b1da0a8") -- Localization
setManifestid(302513, "2571127227622219141", 2270305945)
addappid(302514, 1, "fed6e6f944a7b2b20766b2d8a006d61bac6a3c64f7c93eecef61e51d6215e574") -- Videos
setManifestid(302514, "6208579577591692956", 8091617196)
addappid(302515, 1, "24b30498739fec2fd5f4686a16d7981a2d0f649f23a0ed34c474268a31eee466") -- Objects
setManifestid(302515, "1334171669266498056", 9704980117)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Ryse Son of Rome Soundtrack (AppID: 321440)
addappid(321440)
addappid(321440, 1, "d87d4b8597c7efae35d59386eb9e2e3139cd6b8b8c6b1b6f6868caba8843ca79") -- Ryse Son of Rome Soundtrack - Soundtrack
setManifestid(321440, "6850152720501266738", 1785294847)