-- 1046480's Lua and Manifest Created by Hubcap Manifest
-- THE IDOLM@STER STARLIT SEASON 
-- Created: September 30, 2025 at 23:44:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 64
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1046480) -- THE IDOLM@STER STARLIT SEASON 
-- MAIN APP DEPOTS
addappid(1046481, 1, "2ee5bf09b9d7baa1b266f7633c7d79e96e9f626ea852f7d0e5014b0cad3209d4") -- Messiah Content
setManifestid(1046481, "6143086522038126720", 16030525560)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- THE IDOLMSTER STARLIT SEASON - Colorful Session Wallpaper (AppID: 1537360)
addappid(1537360)
addappid(1537360, 1, "f0a34e17c3f510d50a0f3525083b457abb24076662931697d9c6036c53458c66") -- THE IDOLMSTER STARLIT SEASON - Colorful Session Wallpaper - IMAS-EarlyPurchaseBonus (1537360) デポ
setManifestid(1537360, "7526776945750321298", 36654825)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1539820) -- THE IDOLMSTER STARLIT SEASON - Secret Message Arc
addappid(1539821) -- THE IDOLMSTER STARLIT SEASON - MSTERPIECE
addappid(1539822) -- THE IDOLMSTER STARLIT SEASON - Star Piece Memories
addappid(1539823) -- THE IDOLMSTER STARLIT SEASON - Pure White Bathing Suit
addappid(1732550) -- THE IDOLMSTER STARLIT SEASON - Harukas E-mail
addappid(1732551) -- THE IDOLMSTER STARLIT SEASON - Chihayas E-mail
addappid(1732552) -- THE IDOLMSTER STARLIT SEASON - Mikis E-mail
addappid(1732553) -- THE IDOLMSTER STARLIT SEASON - Yukihos E-mail
addappid(1732554) -- THE IDOLMSTER STARLIT SEASON - Yayois E-mail
addappid(1732555) -- THE IDOLMSTER STARLIT SEASON - Ritsukos E-mail
addappid(1732556) -- THE IDOLMSTER STARLIT SEASON - Azusas E-mail
addappid(1732557) -- THE IDOLMSTER STARLIT SEASON - Ioris E-mail
addappid(1732558) -- THE IDOLMSTER STARLIT SEASON - Makotos E-mail
addappid(1732559) -- THE IDOLMSTER STARLIT SEASON - Amis E-mail
addappid(1732630) -- THE IDOLMSTER STARLIT SEASON - Mamis E-mail
addappid(1732631) -- THE IDOLMSTER STARLIT SEASON - Takanes E-mail
addappid(1732632) -- THE IDOLMSTER STARLIT SEASON - Hibikis E-mail
addappid(1732633) -- THE IDOLMSTER STARLIT SEASON - Nanas E-mail
addappid(1732634) -- THE IDOLMSTER STARLIT SEASON - Rankos E-mail
addappid(1732635) -- THE IDOLMSTER STARLIT SEASON - Mikas E-mail
addappid(1732636) -- THE IDOLMSTER STARLIT SEASON - Anzus E-mail
addappid(1732637) -- THE IDOLMSTER STARLIT SEASON - Kiraris E-mail
addappid(1732638) -- THE IDOLMSTER STARLIT SEASON - Mirais E-mail
addappid(1732639) -- THE IDOLMSTER STARLIT SEASON - Shizukas E-mail
addappid(1732670) -- THE IDOLMSTER STARLIT SEASON - Tsubasas E-mail
addappid(1732671) -- THE IDOLMSTER STARLIT SEASON - Tsumugis E-mail
addappid(1732672) -- THE IDOLMSTER STARLIT SEASON -Kaoris E-mail
addappid(1732673) -- THE IDOLMSTER STARLIT SEASON - Sakuyas E-mail
addappid(1732674) -- THE IDOLMSTER STARLIT SEASON - Rinzes E-mail
addappid(1732675) -- THE IDOLMSTER STARLIT SEASON - Kahos E-mail
addappid(1732676) -- THE IDOLMSTER STARLIT SEASON - Amanas E-mail
addappid(1732677) -- THE IDOLMSTER STARLIT SEASON - Tenkas E-mail
addappid(1732678) -- THE IDOLMSTER STARLIT SEASON - Kohakus E-mail
addappid(1732700) -- THE IDOLMSTER STARLIT SEASON - Shiny Colors E-mail Bundle
addappid(1732701) -- THE IDOLMSTER STARLIT SEASON - Million Live E-mail Bundle
addappid(1732702) -- THE IDOLMSTER STARLIT SEASON - Cinderella Girls E-mail Bundle
addappid(1732703) -- THE IDOLMSTER STARLIT SEASON - THE IDOLMSTER E-mail Bundle
addappid(1732704) -- THE IDOLMSTER STARLIT SEASON - E-mail Bundle From Everyone
addappid(1732770) -- THE IDOLMSTER STARLIT SEASON - Harukas Stage Production Set
addappid(1732771) -- THE IDOLMSTER STARLIT SEASON - Chihayas Stage Production Set
addappid(1732772) -- THE IDOLMSTER STARLIT SEASON - Mikis Stage Production Set
addappid(1732773) -- THE IDOLMSTER STARLIT SEASON - Yukihos Stage Production Set
addappid(1732774) -- THE IDOLMSTER STARLIT SEASON - Yayois Stage Production Set
addappid(1732775) -- THE IDOLMSTER STARLIT SEASON - Ritsukos Stage Production Set
addappid(1732776) -- THE IDOLMSTER STARLIT SEASON - Azusas Stage Production Set
addappid(1732777) -- THE IDOLMSTER STARLIT SEASON - Ioris Stage Production Set
addappid(1732778) -- THE IDOLMSTER STARLIT SEASON - Makotos Stage Production Set
addappid(1732779) -- THE IDOLMSTER STARLIT SEASON - Amis Stage Production Set
addappid(1732780) -- THE IDOLMSTER STARLIT SEASON - Mamis Stage Production Set
addappid(1732781) -- THE IDOLMSTER STARLIT SEASON - Takanes Stage Production Set
addappid(1732782) -- THE IDOLMSTER STARLIT SEASON - Hibikis Stage Production Set
addappid(1732783) -- THE IDOLMSTER STARLIT SEASON - Nanas Stage Production Set
addappid(1732784) -- THE IDOLMSTER STARLIT SEASON - Rankos Stage Production Set
addappid(1732785) -- THE IDOLMSTER STARLIT SEASON - Mikas Stage Production Set
addappid(1732786) -- THE IDOLMSTER STARLIT SEASON - Anzus Stage Production Set
addappid(1732787) -- THE IDOLMSTER STARLIT SEASON - Kiraris Stage Production Set
addappid(1732788) -- THE IDOLMSTER STARLIT SEASON - Mirais Stage Production Set
addappid(1732789) -- THE IDOLMSTER STARLIT SEASON - Shizukas Stage Production Set
addappid(1732790) -- THE IDOLMSTER STARLIT SEASON - Tsubasas Stage Production Set
addappid(1732791) -- THE IDOLMSTER STARLIT SEASON - Tsumugis Stage Production Set
addappid(1732792) -- THE IDOLMSTER STARLIT SEASON - Kaoris Stage Production Set
addappid(1732793) -- THE IDOLMSTER STARLIT SEASON - Sakuyas Stage Production Set
addappid(1732794) -- THE IDOLMSTER STARLIT SEASON - Kahos Stage Production Set