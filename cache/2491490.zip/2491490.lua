-- 2491490's Lua and Manifest Created by Hubcap Manifest
-- Pit Panic
-- Created: July 21, 2026 at 14:54:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2491490, 1, "29001e07b8a7e29074270de181c36e3112142eb94fda4442541e091f8ed80d7b") -- Pit Panic
-- MAIN APP DEPOTS
addappid(2491491, 1, "39b0887ef1e54b5139ffc6a67307759e33f69b32d608c71b379ef2fd973dcc80") -- Depot 2491491
setManifestid(2491491, "5627013486174888370", 2414498633)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)