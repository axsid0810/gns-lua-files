-- 3813350's Lua and Manifest Created by Hubcap Manifest
-- Azure Striker Gunvolt Trilogy Enhanced
-- Created: February 07, 2026 at 01:23:08 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3813350) -- Azure Striker Gunvolt Trilogy Enhanced
-- MAIN APP DEPOTS
addappid(3813351, 1, "d9578d4abcef6451a3c30d6bd9e792a6175c87c15e9da8d2a386b5161d1a3ffd") -- Depot 3813351
setManifestid(3813351, "2175493435303999939", 8479527650)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)