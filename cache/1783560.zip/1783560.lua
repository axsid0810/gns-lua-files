-- 1783560's Lua and Manifest Created by Hubcap Manifest
-- The Last Caretaker
-- Created: June 29, 2026 at 07:49:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1783560, 1, "1c151b194b41372e8e74c46f236d71755cf5c3eb7777e330759d69eb37887c9a") -- The Last Caretaker
-- MAIN APP DEPOTS
addappid(1783561, 1, "41cafd1c9367ffc962fab9d00cf8e6f16d2111b649a8161810a924b1cbf91fc2") -- Depot 1783561
setManifestid(1783561, "5149575974239303756", 16977453147)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)