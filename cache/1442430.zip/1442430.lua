-- 1442430's Lua and Manifest Created by Hubcap Manifest
-- Storage Hunter
-- Created: March 07, 2026 at 02:35:30 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 0
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(1442430, 1, "097d21ca4f6944a8a618d03762988833616f06fee274d2f55c96170f74973dd2") -- Storage Hunter
-- MAIN APP DEPOTS
addappid(1442431, 1, "2143ac048a0302d64fe1279b0b62672b0ffcb1f10350c672b96c89f5be2d01f1") -- Depot 1442431
setManifestid(1442431, "8343976460326114012", 13655879395)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)