-- 3756010's Lua and Manifest Created by Hubcap Manifest
-- SUPER BOMBERMAN COLLECTION
-- Created: February 27, 2026 at 02:05:01 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3756010) -- SUPER BOMBERMAN COLLECTION
-- MAIN APP DEPOTS
addappid(3756011, 1, "1d444f9339cc4e776127c190e7f8f474736a99e2e72768f78fccc1aeb8f8004e") -- Depot 3756011
setManifestid(3756011, "2957850262402184880", 2101440095)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)