-- 2640's Lua and Manifest Created by Hubcap Manifest
-- Call of Duty: United Offensive
-- Created: January 15, 2026 at 09:51:57 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2640, 1, "eb8629b36678a93c10d71128deb2346788b36d05ca5dc8d8355aaf3625de5003") -- Call of Duty: United Offensive
-- MAIN APP DEPOTS
addappid(2641, 1, "36f1541ab1d713a20a676d2a797a0827e02e423ab89565e65791608bc2222da4") -- Call of Duty United Offensive Content
setManifestid(2641, "3417320556416905624", 810408355)
addappid(2687, 1, "f29fa16ccf350b23a8857bca1441ad303c852d4ccafeea2d175093de44fa5b7b") -- call of duty united offensive mac content
setManifestid(2687, "8489547966516424766", 985423197)
addappid(2642, 1, "04bf9fd8c34331f7f1e3270ce1f5e39aeae22532f11b1d606d316d8380f26472") -- Call of Duty: United Offensive English
setManifestid(2642, "5930555561332439777", 126987117)
addappid(2643, 1, "b09d9e478376212e6d088091efeb0247b6333bec6ffa2704639607c1444773f4") -- Call of Duty: United Offensive Italian
setManifestid(2643, "251240555274784949", 137930612)
addappid(2644, 1, "61f34a50c83de39dba6b02810d0d3a8a562758d56c45fdee47e50db543dfbb3c") -- Call of Duty: United Offensive French
setManifestid(2644, "2093258244524288041", 134141283)
addappid(42621, 1, "f080b273800dda8b1cdb94cfabed02993c8c0c9fe5d05990cdd4517349da77c8") -- Call of Duty: United Offensive English Mac
setManifestid(42621, "443939036136994768", 126987117)
-- SHARED DEPOTS (from other apps)
addappid(2621, 1, "5491a58960839f2a84d89ab4f60ba804a9223e294e009e546b5a583326628691") -- Call of Duty Content (Shared from App 2620)
setManifestid(2621, "235916370645017959", 954204780)