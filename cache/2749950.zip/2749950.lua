-- 2749950's Lua and Manifest Created by Hubcap Manifest
-- Esports Manager 2026
-- Created: July 22, 2026 at 20:13:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2749950) -- Esports Manager 2026
-- MAIN APP DEPOTS
addappid(2749951, 1, "bbca891b03feb6b30b61373f1fdb51376656cf5ab5fee47855c742e6878b0598") -- Depot 2749951
setManifestid(2749951, "7116033794303425019", 7351873776)