-- 2395210's Lua and Manifest Created by Hubcap Manifest
-- Tony Hawk's™ Pro Skater™ 1 + 2
-- Created: October 01, 2025 at 02:21:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2395210) -- Tony Hawk's™ Pro Skater™ 1 + 2
-- MAIN APP DEPOTS
addappid(2395211, 1, "ec38e51d7550cee26aa882d00fd667e7151be357001e9705d7cad29c5d74f9cc") -- Depot 2395211
setManifestid(2395211, "7405974297257598601", 66312563)
addappid(2395212, 1, "075552dcaa4900b55ed24f823d7b1056af53aa2d62af4a453fef7f14dc6e44a8") -- Depot 2395212
setManifestid(2395212, "5122926186042011441", 24543337847)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2586220) -- Tony Hawks Pro Skater 1  2 - Digital Deluxe Edition