-- 1913120's Lua and Manifest Created by Hubcap Manifest
-- Tears of Metal
-- Created: July 22, 2026 at 18:16:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1913120, 1, "c789b529828e652dbd3f3e408af75a733fef864e5728655a076aac0d14145f6e") -- Tears of Metal
-- MAIN APP DEPOTS
addappid(1913121, 1, "ef09faa539a0032c86e138039553cfb95ed24ac0a3af18e948854bf7d108cbea") -- Depot 1913121
setManifestid(1913121, "2285823510591115866", 4628675181)