-- 2543370's Lua and Manifest Created by Hubcap Manifest
-- HoneyCome come come party
-- Created: October 16, 2025 at 22:49:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2543370) -- HoneyCome come come party
-- MAIN APP DEPOTS
addappid(2543371, 1, "9d0c70ba9f59cdeabcdcf85ce0bdf753641d5bf4ba8facb1c7dd157526595349") -- Depot 2543371
setManifestid(2543371, "4455032410207202941", 13768055404)
-- DLCS WITH DEDICATED DEPOTS
-- HoneyCome come come party dolce (AppID: 2689900)
addappid(2689900)
addappid(2689900, 1, "948557928de271f79f590e699b62d5aa27c7f5692b95e369b0442f13cdc06fe3") -- HoneyCome come come party dolce - Depot 2689900
setManifestid(2689900, "1423201853278905073", 19508368914)