-- 2474770's Lua and Manifest Created by Hubcap Manifest
-- Momento
-- Created: July 15, 2026 at 08:26:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2474770, 1, "f2d19950a5b07f49978e15e8c0c89196b0e109b173c91422c369d0432e50ed16") -- Momento
-- MAIN APP DEPOTS
addappid(2474771, 1, "0f02ca4247920ae8e6363c52e61053785ed520abf7e8e0c122df32b0eeb6a1f2") -- Depot 2474771
setManifestid(2474771, "2910611112358204849", 1795340869)
addappid(2474772, 1, "8adedace1b1018c1a9fca660a3fc1cdd76b224d1ac7bcfcb1f1af8b77752503e") -- Depot 2474772
setManifestid(2474772, "1657194866567707640", 1472776691)