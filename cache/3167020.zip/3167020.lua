-- 3167020's Lua and Manifest Created by Hubcap Manifest
-- Escape from Duckov
-- Created: July 02, 2026 at 03:43:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3167020, 1, "868bad77591803956d03d9863f4775a7d402330362cbd41c1c764c994dfae9fa") -- Escape from Duckov
-- MAIN APP DEPOTS
addappid(3167021, 1, "6a1377569bff7441f985074b6ed8692c0c8f6681b80a75e020dd1a10419b5dea") -- Depot 3167021
setManifestid(3167021, "177545053407069080", 3091569706)
addappid(3167022, 1, "862fd0e5628b2423c67e71daa4e95147265f746e4f4adf57350eb171f822c616") -- Depot 3167022
setManifestid(3167022, "2670200030787709548", 3125630786)