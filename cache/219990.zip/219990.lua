-- 219990's Lua and Manifest Created by Hubcap Manifest
-- Grim Dawn
-- Created: July 23, 2026 at 12:44:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 14
-- Total DLCs: 7
-- Shared Depots: 6

-- MAIN APPLICATION
addappid(219990, 1, "f526be8add966b86be32ef5a4b61c78a5cd1f1621dfcd168368922397abc39cb") -- Grim Dawn
-- MAIN APP DEPOTS
addappid(219991, 1, "24ba5f38bc31d02b7075c9464e178e08c9552de08a183056fbf1aa79b405e4c6") -- Grim Dawn Content
setManifestid(219991, "8006922163969537169", 4920555221)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)
-- DLCS WITH DEDICATED DEPOTS
-- Grim Dawn - Crucible Mode DLC (AppID: 483840)
addappid(483840)
addappid(483840, 1, "25fb87a62fad42ff98bde06d9be0995cc02349c65bc47637fc8e713ed6d9d3e1") -- Grim Dawn - Crucible Mode DLC - Grim Dawn - Crucible Mode DLC (483840) Depot
setManifestid(483840, "4219096235914851781", 177078562)
-- Grim Dawn - Ashes of Malmouth Expansion (AppID: 642280)
addappid(642280)
addappid(642280, 1, "af5387c55c30f622c2cb2aafa8bb289785c75d67ee675b5a2db9a1dc40b0e55d") -- Grim Dawn - Ashes of Malmouth Expansion - Grim Dawn - Ashes of Malmouth Expansion (642280) Depot
setManifestid(642280, "2275863479823292335", 2534565682)
addappid(642281, 1, "40263ca158fa164ef993b52a491845a7508f4b9a784e0a4b1f6a78fb1109e9f9") -- Grim Dawn - Ashes of Malmouth Expansion - Grim Dawn - Ashes of Malmouth Crucible
setManifestid(642281, "1006721765621603920", 19623909)
-- Grim Dawn - Forgotten Gods Expansion (AppID: 897670)
addappid(897670)
addappid(897670, 1, "9e9fdd83057e0d41385fd8bb3461125aecaed7e3ff3cc7890834639322e00e30") -- Grim Dawn - Forgotten Gods Expansion - Grim Dawn - Forgotten Gods Expansion (897670) Depot
setManifestid(897670, "4804720554373426689", 3281698980)
addappid(897671, 1, "deefcab56ed487ca3ff25be38f578ead6650ae4e1b1fbe39450cdd9ccd737333") -- Grim Dawn - Forgotten Gods Expansion - Grim Dawn - Forgotten Gods Crucible
setManifestid(897671, "2984427886892515994", 5462687)
-- Grim Dawn - Fangs of Asterkarn (AppID: 2699230)
addappid(2699230)
addappid(2699230, 1, "4843e2630d30639c182670a20fcd1a15b455f6917c345f7824fc2062fdc46a11") -- Grim Dawn - Fangs of Asterkarn - Depot 2699230
setManifestid(2699230, "1575323658468418166", 5764886847)
addappid(2699231, 1, "336117c2e4cd9ad52a8bdd10e432814d6ac7e4ffb6ac21fc8ba7872a9e825a7d") -- Grim Dawn - Fangs of Asterkarn - Depot 2699231
setManifestid(2699231, "2924790412415164930", 22046047)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(565610) -- Grim Dawn - Steam Loyalist Upgrade
addappid(1088290) -- Grim Dawn - Steam Loyalist 2 DLC
addappid(2701090) -- Grim Dawn - Steam Loyalist 3 DLC