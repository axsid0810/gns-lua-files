-- 508440's Lua and Manifest Created by Hubcap Manifest
-- Totally Accurate Battle Simulator
-- Created: January 19, 2026 at 20:43:59 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(508440, 1, "5b7e684bff1e4800cd621ab1dcbddefe6befe0c557601fa6a7dc3170234f6037") -- Totally Accurate Battle Simulator
-- MAIN APP DEPOTS
addappid(508442, 1, "1ce344084592b51c732ae49f9ace3a58f5ab718c6e95e3721fbd20a3a0ecf026") -- Totally Accurate Battle Simulator Pre Release
setManifestid(508442, "8242906715970617352", 2790484484)
addappid(508443, 1, "6de3434d18886e0ff07614c02781c1f625e189a4a9833e36f4287f77443ce44c") -- Totally Accurate Battle Simulator Windows
setManifestid(508443, "7032160763023751725", 4823550893)
addappid(508444, 1, "c831d684196d21677fc279e01f064dd989c00c2f5c4975b0c58793fd71c1f3f9") -- Totally Accurate Battle Simulator OSX
setManifestid(508444, "1380846934100563863", 4794610800)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1270340) -- Totally Accurate Battle Simulator - BUG DLC