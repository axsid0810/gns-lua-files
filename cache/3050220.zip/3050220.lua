-- 3050220's Lua and Manifest Created by Hubcap Manifest
-- THE KING OF FIGHTERS XIII GLOBAL MATCH
-- Created: September 30, 2025 at 23:52:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3050220) -- THE KING OF FIGHTERS XIII GLOBAL MATCH
-- MAIN APP DEPOTS
addappid(3050221, 1, "ce82976ac100fcb11681d16de899309652c7d66f55a1be142470d3c3a44a22f2") -- Depot 3050221
setManifestid(3050221, "5942384979721414069", 2444752738)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)