-- 4229410's Lua and Manifest Created by Hubcap Manifest
-- Wayblazer Dämmerung Sound Collection
-- Created: February 19, 2026 at 08:48:50 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4229410) -- Wayblazer Dämmerung Sound Collection
-- MAIN APP DEPOTS
addappid(4229411, 1, "3d6fd34f55631ba3983461927937bf68073f9a1639ac21005016b7595ef56670") -- Depot 4229411
setManifestid(4229411, "7293192453672581017", 184613766)