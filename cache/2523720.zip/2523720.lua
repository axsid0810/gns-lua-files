-- 2523720's Lua and Manifest Created by Hubcap Manifest
-- Gears of War: Reloaded
-- Created: October 02, 2025 at 10:42:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2523720) -- Gears of War: Reloaded
-- MAIN APP DEPOTS
addappid(2523721, 1, "3e44ca039e0a56e928a0f15185ec4dd1a6122548cafccbeeb625c4af6b7fdaaa") -- Depot 2523721
setManifestid(2523721, "2156965768602915417", 76345902085)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2986070) -- Civilian Anya Character Skin
addappid(3144570) -- Adam Fenix Character Skin