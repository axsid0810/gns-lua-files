-- 1099410's Lua and Manifest Created by Hubcap Manifest
-- A Total War Saga: TROY
-- Created: July 25, 2026 at 21:51:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 43
-- Total DLCs: 5
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(1099410, 1, "1cfefae8f8515f03055474450a313484006ecfd15d4a610ea46aa022056aeec5") -- A Total War Saga: TROY
-- MAIN APP DEPOTS
addappid(1099411, 1, "6844b3e1c2860bbe081e48f62f7ce6839c4f87553a811e3ddd9b2ac1249c2417") -- exe_win
setManifestid(1099411, "5861799683138164142", 650105437)
addappid(1099412, 1, "ef851c6ddf7e18ac56eb829702b0a8cf03402d6f3bd0518e4ad7349cdd488cdf") -- data
setManifestid(1099412, "1268024772830079096", 36625051291)
addappid(1099413, 1, "4eedb338be0081b1e881a396283ad4960b2098f03a20c0b439653b49b8230ebc") -- english
setManifestid(1099413, "1866366734277315680", 8413)
addappid(1099414, 1, "c9e66757f4f6f858baf8c0df5645254364a1964d29027f9d9837742a259f5255") -- brazilian
setManifestid(1099414, "3494693337311580466", 9256)
addappid(1099415, 1, "7a13f3dfe17259d4bd281a273f9df7b66c50f12a2bf12777bc9db73f94122dfd") -- czech
setManifestid(1099415, "5967994353594053417", 9366)
addappid(1099416, 1, "dc2602e4b61b6adb63db3362082b7abed1842ec02a374df3a8d9b7e30bcd2369") -- german
setManifestid(1099416, "7606752633669346207", 9484)
addappid(1099417, 1, "fda0ebddb8243e8bd42f1ebb7e3fdc1773e9a3d04e15de1f5b6b457a0971084c") -- spanish
setManifestid(1099417, "5603042473283940476", 9597)
addappid(1099418, 1, "ce0ec5d661b395112baf42618510f5c6e461eb080e3d75fcf97efd2fe8f914eb") -- french
setManifestid(1099418, "8392066300727705413", 9569)
addappid(1099419, 1, "4ae6579382019f5475571e911e3548941df77ed78bd029ca0344adf95169ff2d") -- italian
setManifestid(1099419, "8197740202134659878", 9517)
addappid(1099670, 1, "23d0d8c35de344a0ef48df20317c8b4788c6dd45cf85ed8133b434fb85fcdfb6") -- korean
setManifestid(1099670, "2237835351077399485", 9382)
addappid(1099671, 1, "2e76e592cea0d0fddfc3c720f654023af5bf8031e1ad6ade1479ea5e817bd34a") -- polish
setManifestid(1099671, "4194709582149587609", 9509)
addappid(1099672, 1, "a1c3428863434e05c98bb7d6ba9e3e89cbbb2c47e1dae76e3fed8950ddc8e2b8") -- russian
setManifestid(1099672, "1722828010076033466", 9424)
addappid(1099673, 1, "1a61b181b2164d6afa30cb8eeabf689c60c6fb4348cf108c112e993c42a09ea9") -- turkish
setManifestid(1099673, "3005804968898167321", 9466)
addappid(1099674, 1, "c9631d00de831c7ea077275c23d3fc3c10dbab348641de8286cc0c36e3297c14") -- simplified chinese
setManifestid(1099674, "8634548783143969267", 9277)
addappid(1099675, 1, "0ffb98baa2f0e1c1e7ab86bc8874c67c2d3a3e496cfc120a8bdfc9611d2ab9d1") -- traditional chinese
setManifestid(1099675, "1603047319221160328", 9508)
addappid(1099676, 1, "ca20ee2b06e11794b0542379a28f5dfa9ec981ca4455004fbd7d31ecacedf679") -- Mac Executable (1099411)
setManifestid(1099676, "8146612564955765091", 249249342)
addappid(1099677, 1, "32d5ed8033dbd5906b39da9cad5362b38423ca6070dbd0dd54aeb5401f396d19") -- Mac Data (1099412)
setManifestid(1099677, "6102419642077735257", 36642525775)
addappid(1099678, 1, "ae860b533bae0fc9a1b056fe8d3cdd74d8c780460d66d1bb70b4b85241cf01ee") -- Mac English (1099413)
setManifestid(1099678, "108511696208146868", 8413)
addappid(1099679, 1, "9c8b89708a9838fb60f747b3be02fafec31052df3b4c9ec1f405226d8d741dad") -- Mac Brazilian (1099414)
setManifestid(1099679, "7528706751729061989", 9256)
addappid(1099680, 1, "bd8149cef8b5ea7cc2ec0815016c39102b8589ff9264985bef6ec4ae9a9ea708") -- Mac Czech (1099415)
setManifestid(1099680, "6871225037534252603", 9366)
addappid(1099681, 1, "8df8d86e46418091700a7bd95f9884f2242042d16103cb662fd6de8af4f31b80") -- Mac German (1099416)
setManifestid(1099681, "6298639561153387137", 9484)
addappid(1099682, 1, "857ea8b6c90d180eb1bdc28df23faf4aef74ed55ed33151a25de3abdf63473d2") -- Mac Spanish (1099417)
setManifestid(1099682, "5171449420077171133", 9597)
addappid(1099683, 1, "fb8dccd21f6425e700ae212af2a6bfe46677dd1f74fe7fd16bee532c5ef75068") -- Mac French (1099418)
setManifestid(1099683, "4892878438083010425", 9569)
addappid(1099684, 1, "a2c9939f1799e2e6f22bd15b4ac34b27ec95752aef76578b3ff8317b1f2058e3") -- Mac Italian (1099419)
setManifestid(1099684, "1948669064876435623", 9517)
addappid(1099685, 1, "d6cb5103b235c644c77bb0a2f98f1f1bb90f3add7ef151816acdd70df6b8a964") -- Mac Korean (1099670)
setManifestid(1099685, "6052793660573777808", 9382)
addappid(1099686, 1, "13991831ab4e8562da4f3e6f2d0eddaa6d99503dbdab46afd99b14e4ca27e407") -- Mac Polish (1099671)
setManifestid(1099686, "8366826138520473997", 9509)
addappid(1099687, 1, "fe575209c75e8b513b9748928c4215a073fa2a2070770beddf7889ae6a69ad6e") -- Mac Russian (1099672)
setManifestid(1099687, "1546333954808153835", 9424)
addappid(1099688, 1, "0ebc8b82eb09388eef1490446e5f1ebf22c7c4a9625e29945269daa9cd129f3f") -- Mac Turkish (1099673)
setManifestid(1099688, "4600624791685556618", 9466)
addappid(1099689, 1, "d5b1bc99f3a2f0798a924f6882c2a8f8716e10962880bbf85d85b5a8c530e6f5") -- Mac Simplified Chinese (1099674)
setManifestid(1099689, "2888499434010520786", 9277)
addappid(1099690, 1, "a2bab96987cb4ac34bfa55fc63931bf62881d991e0b4d3bd9b450078d78223f8") -- Mac Traditional Chinese (1099674)
setManifestid(1099690, "405028133510124339", 9508)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- A Total War Saga TROY - Amazons (AppID: 1188790)
addappid(1188790)
addappid(1188790, 1, "55c61a851aa048db8f99c1c12567102ea4d5cc70a4b309f4066393096e2f1182") -- A Total War Saga TROY - Amazons - bronx (1188790)
setManifestid(1188790, "351106891191495683", 66)
addappid(1099707, 1, "8eadee83a26ba6b6839ffede661cfa76cd09c56e3e47e5829f25cf7fba420d25") -- A Total War Saga TROY - Amazons - Mac - bronx amazon (1188790)
setManifestid(1099707, "503373528595424738", 66)
-- A Total War Saga TROY - Blood  Glory (AppID: 1353190)
addappid(1353190)
addappid(1353190, 1, "42ccda9b9e27a48e3d9d8f7335bc391736973f9d2721c122c22eadb2bd3f06b9") -- A Total War Saga TROY - Blood  Glory - queens (1353190)
setManifestid(1353190, "2483791420967936907", 115828516)
addappid(1099706, 1, "e05df790f53c155c4f7addf70dc99e231870a340c9167528e7bee276f8a0b68f") -- A Total War Saga TROY - Blood  Glory - Mac - queens blood (1353190)
setManifestid(1099706, "233105651323918445", 115828516)
-- A Total War Saga TROY - Ajax  Diomedes (AppID: 1486710)
addappid(1486710)
addappid(1486710, 1, "d3ea86061628d078e635a38689faeccd2b85dbeca1a6af4fefb011e5dc5a6cf0") -- A Total War Saga TROY - Ajax  Diomedes - harlem (1486710)
setManifestid(1486710, "7812930979527723877", 66)
addappid(1099708, 1, "5aa4beb7471112d372343300864c34973f7ebd1f208313795916703d1d9177f5") -- A Total War Saga TROY - Ajax  Diomedes - Mac - harlem ajax (1486710)
setManifestid(1099708, "1669660990349990117", 66)
-- A Total War Saga TROY - Rhesus  Memnon (AppID: 1553060)
addappid(1553060)
addappid(1553060, 1, "590908429db625543cbaf6fe976abe85994ea411978036c34ed07932412fd742") -- A Total War Saga TROY - Rhesus  Memnon - soho (1553060) Depot
setManifestid(1553060, "3881970437725751344", 66)
-- A Total War Saga TROY - MYTHOS (AppID: 1553061)
addappid(1553061)
addappid(1553061, 1, "bfe6618a7a1e5d220de0de9ccd4056f05ed753b97e431690b48a15fcbe2bdc1e") -- A Total War Saga TROY - MYTHOS - astoria (1553061)
setManifestid(1553061, "3862503120536545923", 66)
addappid(1099709, 1, "85652a644129bb9b766d661d95b067e47320031e57fc744faf02c2bb8deac073") -- A Total War Saga TROY - MYTHOS - Mac - astoria mythos (1553061)
setManifestid(1099709, "3670117697319492789", 66)