-- 3447940's Lua and Manifest Created by Hubcap Manifest
-- Metal Slugger Ops
-- Created: March 17, 2026 at 15:46:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3447940) -- Metal Slugger Ops
-- MAIN APP DEPOTS
addappid(3447941, 1, "4d12c8310a8389bb5fbb5eb671edd2b8967e242820173cca7a053270b3970362") -- Depot 3447941
setManifestid(3447941, "84516779920537399", 331057451)