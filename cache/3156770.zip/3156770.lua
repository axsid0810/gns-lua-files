-- 3156770's Lua and Manifest Created by Hubcap Manifest
-- Witchfire
-- Created: July 15, 2026 at 21:58:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3156770, 1, "a3d625ea35ccb9f6b7f85adb4bc578f136e51437a97ea3277887ca9ed995e2e8") -- Witchfire
-- MAIN APP DEPOTS
addappid(3156771, 1, "e09d98ec7fb6604ed8c2f44292e3f8cb278dd0add46641f0434375eeb9255e87") -- Depot 3156771
setManifestid(3156771, "2208463186393063821", 52652044723)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)