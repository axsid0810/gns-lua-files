-- 1289310's Lua and Manifest Created by Hubcap Manifest
-- Helltaker
-- Created: July 03, 2026 at 13:40:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1289310, 1, "61b522f50b7263640eec49fdf744ab50f1794d1391b19dc6435782ba4a15a4a0") -- Helltaker
-- MAIN APP DEPOTS
addappid(1289311, 1, "8a76446486a985b6fb8019f9ff9cb51717155afebaf093f777936ca31df07bd8") -- Helltaker Content
setManifestid(1289311, "9164867365911753620", 348099925)
addappid(1289312, 1, "0aef62a3de894c4ef02336c5798e38c21a2a4564caa327e5412fe7d240811288") -- Helltaker Content Mac
setManifestid(1289312, "5439647822064687051", 349158366)
addappid(1289313, 1, "36a1150a257c814238b63986e8bd03f1179691714589bff626e2bf0b7d6794a2") -- Helltaker Content 32bit
setManifestid(1289313, "6051994899057452556", 341250557)
addappid(1289314, 1, "0ae3f8de8828c5aa3bafe13d91bb5c66830de99cae356751025b076dfbff3cb1") -- Helltaker Content Linux
setManifestid(1289314, "8723838119065609357", 349387016)
addappid(1289315, 1, "77e4cd127cd6a189e8409ad5b3bed50b03b00b130c9e35a17f02b8d1daefa9fd") -- Helltaker Local
setManifestid(1289315, "6394422377711576735", 50692)
-- DLCS WITH DEDICATED DEPOTS
-- Helltaker Artbook  Pancake Recipe (AppID: 1298590)
addappid(1298590)
addappid(1298590, 1, "839e47fd3b43d3eba1d5cff9162c1b94ee0ac5053f347e46cf3dbd1d8de44acd") -- Helltaker Artbook  Pancake Recipe - Helltaker: Artbook + Pancake Recipe (1298590) Depot
setManifestid(1298590, "5335439833889055261", 169293695)