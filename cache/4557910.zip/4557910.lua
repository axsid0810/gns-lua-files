-- 4557910's Lua and Manifest Created by Hubcap Manifest
-- Breach Protocol
-- Created: July 27, 2026 at 23:26:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4557910) -- Breach Protocol
-- MAIN APP DEPOTS
addappid(4557911, 1, "840509027b3eb9bee05c430c6d000ef032539f55a5abe51dbb13d9eedc29f390") -- Depot 4557911
setManifestid(4557911, "2409449821345442379", 6535317300)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)