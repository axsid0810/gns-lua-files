-- 579180's Lua and Manifest Created by Hubcap Manifest
-- Ys VIII: Lacrimosa of Dana
-- Created: October 01, 2025 at 08:53:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 28
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(579180) -- Ys VIII: Lacrimosa of Dana
-- MAIN APP DEPOTS
addappid(579181, 1, "31d9c6b793e7119501f27acde3eb75748facee4c7708c44b9f432c8f1daebab3") -- Ys VIII: Lacrimosa of Dana Content
setManifestid(579181, "854622410832629482", 22593990017)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Ys VIII Lacrimosa of DANA - Digital Mini Art Book (AppID: 677691)
addappid(677691)
addappid(677691, 1, "31efb3e1909213ce670db3feb5d8625367fc924fc834640c6cede41b93fce04b") -- Ys VIII Lacrimosa of DANA - Digital Mini Art Book - Ys VIII: Lacrimosa of DANA - Digital Mini Art Book (677691) 個のデポ
setManifestid(677691, "152208443005290560", 126708845)
-- Ys VIII Lacrimosa of DANA - Digital Soundtrack Sampler (AppID: 677692)
addappid(677692)
addappid(677692, 1, "a7cfdede3d687513e47c4b03a3824adb2f4c4f25280e46f5f813b3810d6c9a46") -- Ys VIII Lacrimosa of DANA - Digital Soundtrack Sampler - Ys VIII: Lacrimosa of DANA - Digital Soundtrack Sampler (677692) 個のデポ
setManifestid(677692, "1885907665976373275", 19380892)
-- Ys VIII Lacrimosa of DANA - HQ Texture Pack (AppID: 707189)
addappid(707189)
addappid(579182, 1, "b0a69215e48ef5ba197b4363532701e3b86e561c0dbaedd5a6b9ddf8a27a184c") -- Ys VIII Lacrimosa of DANA - HQ Texture Pack - Ys VIII Extra Data
setManifestid(579182, "5946258577333185190", 7279996276)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(677690) -- Ys VIII Lacrimosa of DANA - Adols Adventure Essentials DLC
addappid(707170) -- Ys VIII Lacrimosa of DANA - Free Set 1
addappid(707172) -- Ys VIII Lacrimosa of DANA - Advanced Accessory Set
addappid(707173) -- Ys VIII Lacrimosa of DANA - Bottled Potion Set
addappid(707174) -- Ys VIII Lacrimosa of DANA - Castaway Start Dash Set
addappid(707175) -- Ys VIII Lacrimosa of DANA - Economy Ingredient Set
addappid(707176) -- Ys VIII Lacrimosa of DANA - Elixir Set 1
addappid(707177) -- Ys VIII Lacrimosa of DANA - Elixir Set 2
addappid(707178) -- Ys VIII Lacrimosa of DANA - Elixir Set 3
addappid(707179) -- Ys VIII Lacrimosa of DANA - Elixir Set 4
addappid(707180) -- Ys VIII Lacrimosa of DANA - Elixir Set 5
addappid(707181) -- Ys VIII Lacrimosa of DANA - Fish Bait Set 1
addappid(707182) -- Ys VIII Lacrimosa of DANA - Fish Bait Set 2
addappid(707183) -- Ys VIII Lacrimosa of DANA - Fish Bait Set 3
addappid(707184) -- Ys VIII Lacrimosa of DANA - Free Set 2
addappid(707185) -- Ys VIII Lacrimosa of DANA - Laxias Eternian Scholar Costume
addappid(707186) -- Ys VIII Lacrimosa of DANA - Premium Material Set
addappid(707187) -- Ys VIII Lacrimosa of DANA - Ripe Fruit Set
addappid(707188) -- Ys VIII Lacrimosa of DANA - Status Recovery Set
addappid(707190) -- Ys VIII Lacrimosa of DANA - Tempest Set 1
addappid(707191) -- Ys VIII Lacrimosa of DANA - Tempest Set 2
addappid(707192) -- Ys VIII Lacrimosa of DANA - Tempest Set 3
addappid(707193) -- Ys VIII Lacrimosa of DANA - Tempest Set 4
addappid(707194) -- Ys VIII Lacrimosa of DANA - Tempest Set 5
addappid(707195) -- Ys VIII Lacrimosa of DANA - Useful Accessory Set