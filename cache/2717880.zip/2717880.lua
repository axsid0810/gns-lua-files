-- 2717880's Lua and Manifest Created by Hubcap Manifest
-- The Rogue Prince of Persia
-- Created: March 02, 2026 at 22:15:16 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2717880) -- The Rogue Prince of Persia
-- MAIN APP DEPOTS
addappid(2717881, 1, "4f68e98dcd0e02d77029d74ec41d2bb82ac62a486db69b9a034683ae1bddbf41") -- Depot 2717881
setManifestid(2717881, "5807315004995814392", 1080166107)
addappid(2717882, 1, "9cf88420d3b56db810785d1f9254e8368b15540c6441246024469862221f7edd") -- Depot 2717882
setManifestid(2717882, "1985153297907939899", 1109179063)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3956130) -- The Rogue Prince of Persia Ubisoft Activation