-- 2187220's Lua and Manifest Created by Hubcap Manifest
-- Apollo Justice: Ace Attorney Trilogy
-- Created: September 28, 2025 at 22:47:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2187220) -- Apollo Justice: Ace Attorney Trilogy
-- MAIN APP DEPOTS
addappid(2187221, 1, "d9865c4fe54425b3fd8b8bb95b5f3b1d87e4c6c02a3ff6777ae43f9c480ac365") -- Depot 2187221
setManifestid(2187221, "2858207920791406536", 20267318833)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)