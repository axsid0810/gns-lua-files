-- 495140's Lua and Manifest Created by Hubcap Manifest
-- NARUTO: Ultimate Ninja STORM
-- Created: September 30, 2025 at 02:52:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(495140) -- NARUTO: Ultimate Ninja STORM
-- MAIN APP DEPOTS
addappid(495141, 1, "78542431af43146b9f53910d3bf2450a1cebf5ce5166f7d05cf474135be186ea") -- QWANT Content
setManifestid(495141, "8686507798773437685", 8087875030)