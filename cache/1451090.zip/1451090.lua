-- 1451090's Lua and Manifest Created by Hubcap Manifest
-- Tactics Ogre: Reborn
-- Created: September 30, 2025 at 21:42:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 3
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1451090) -- Tactics Ogre: Reborn
-- MAIN APP DEPOTS
addappid(1451091, 1, "05d42e1703b05e7a865e15447318d8cb35bc0b30f9221f1150ee53f7cb434096") -- Depot 1451091
setManifestid(1451091, "4303847580532694722", 12207344370)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- Tactics Ogre Reborn Digital Mini Soundtrack (AppID: 2087040)
addappid(2087040)
addappid(2087040, 1, "639da6f29f8b18e4459d9dbc175a3528f2c3bcd8aae3fa19c1eee2e155a4d490") -- Tactics Ogre Reborn Digital Mini Soundtrack - Depot 2087040
setManifestid(2087040, "6709308679858427498", 38967672)
-- Tactics Ogre Reborn Original Soundtrack (AppID: 2087050)
addappid(2087050)
addappid(2087050, 1, "d93fafda8d97e7e1ac209676dbfdf0f1eca7f4ff5615d70e0a39edfcba518c08") -- Tactics Ogre Reborn Original Soundtrack - Depot 2087050
setManifestid(2087050, "3612992678427616094", 580880311)
-- Tactics Ogre(1995) Digital Mini Soundtrack (AppID: 2087060)
addappid(2087060)
addappid(2087060, 1, "5ca95a891b2b5664523233d3293f1b94ae7e5cb10c2736082877144ecdecbc8e") -- Tactics Ogre(1995) Digital Mini Soundtrack - Depot 2087060
setManifestid(2087060, "3570739091751671204", 46271984)