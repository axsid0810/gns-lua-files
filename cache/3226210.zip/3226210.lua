-- 3226210's Lua and Manifest Created by Hubcap Manifest
-- Skeleseller
-- Created: July 07, 2026 at 07:17:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3226210, 1, "8674687eba44fa21fd546837454b1ff586eae6117403adb53357e83b695a163e") -- Skeleseller
-- MAIN APP DEPOTS
addappid(3226211, 1, "57db0352b1aaaf3821a119708028d6f1a160ad5fea71cb86dccd2117cf8b3881") -- Depot 3226211
setManifestid(3226211, "8073889601499137049", 324422364)
addappid(3226212, 1, "2abbbb91da0ef2da8706855a6f9fc39214e1513992abe28d2793dc36ec3a86f9") -- Depot 3226212
setManifestid(3226212, "7120827650763803218", 513034994)
addappid(3226213, 1, "6ad72f0806e8b4925c0a7d5476f44cf5f8ebdc364124a40a96ca206c2b671f8b") -- Depot 3226213
setManifestid(3226213, "6175946536093216379", 291728723)