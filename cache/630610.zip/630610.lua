-- 630610's Lua and Manifest Created by Hubcap Manifest
-- Disneyland Adventures
-- Created: September 29, 2025 at 07:59:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(630610) -- Disneyland Adventures
-- MAIN APP DEPOTS
addappid(630611, 1, "1ee9d227ae66c196b42a041d34a596cb7e75d5014e8a8a845f39bd7c7eae368d") -- Disneyland Adventures Content
setManifestid(630611, "9164595599853455996", 25299996279)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)