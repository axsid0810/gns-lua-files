-- 3050010's Lua and Manifest Created by Hubcap Manifest
-- Platform Control
-- Created: October 02, 2025 at 13:55:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3050010) -- Platform Control
-- MAIN APP DEPOTS
addappid(3050011, 1, "23d3332002ae8f268549bd54d36696d2f9f14b1bf7ebf5900ee774a5402f5be1") -- Depot 3050011
setManifestid(3050011, "439646129286698444", 83324816)