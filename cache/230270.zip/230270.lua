-- 230270's Lua and Manifest Created by Hubcap Manifest
-- N++
-- Created: July 18, 2026 at 21:30:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(230270, 1, "ecda3542a2fb84d33f6bec922903c2059856cc2b06844732fd73cafcf0fb1bc8") -- N++
-- MAIN APP DEPOTS
addappid(230271, 1, "012ae7bf93394d9c13a6fe0b6a19bb864b9c9a12987f502e3701037af032e5d9") -- Windows Base
setManifestid(230271, "7567238814520421478", 1455844051)
addappid(230272, 1, "e85c3de7820321443622a22835dcc9979d4f773dfa8dd2e1e8a6fbdb330e5534") -- OSX Base
setManifestid(230272, "5385924979330004871", 761159195)
addappid(230273, 1, "b77ff2a02f39145844f959ef3717452a87054211288ed96dcdf0575749b20d37") -- Linux Base
setManifestid(230273, "8506372043750881751", 1490915719)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)