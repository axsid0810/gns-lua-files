-- 237930's Lua and Manifest Created by Hubcap Manifest
-- Transistor
-- Created: October 01, 2025 at 03:32:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 0
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(237930) -- Transistor
-- MAIN APP DEPOTS
addappid(237931, 1, "64d71a7396179714511a13c17f8608210be0b1e6454ed22bbcf1ca39974773a9") -- Content
setManifestid(237931, "2847119190678602113", 3250871333)
addappid(237932, 1, "feea2c931de8b99499f33a16b4008b739231d19ef4b3bb9010545dd808e6cdd6") -- Win Debug
setManifestid(237932, "7503667268009216447", 57636468)
addappid(237933, 1, "4da16e2d3b3b3b5d640f12ce049cb54e2a7e650a02e3fef9d96d9f392a75b218") -- Win Release
setManifestid(237933, "2807022345768240460", 56735824)
addappid(237934, 1, "ca69c0b218742d719af7cc241ab5c6bae6bbe737c541936cf1ca7533f9c6b221") -- OSX
setManifestid(237934, "647649016693665867", 3288333589)
addappid(237935, 1, "442c4ba3dddca111764d9ed8d36c3c76b5a3966980261046021102fe2553d5a0") -- Linux
setManifestid(237935, "497367110190727741", 3309847688)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)