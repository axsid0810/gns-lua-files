-- 1149460's Lua and Manifest Created by Hubcap Manifest
-- Icarus
-- Created: July 17, 2026 at 02:31:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 20
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1149460, 1, "fecfa8dae0f009276447d67ac2d4aad77ce51ed669d1cad33af05676f6d99699") -- Icarus
-- MAIN APP DEPOTS
addappid(1149461, 1, "c71fc47ef9e1e718df06677c0d6cf06fc0f01145d8481e0db444a26eed261296") -- Icarus Content
setManifestid(1149461, "2834334880147612958", 53269773393)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1648532) -- Icarus New Frontiers Expansion
addappid(1648533) -- Icarus Dangerous Horizons Expansion
addappid(1648540) -- Icarus Holdfast Outpost
addappid(1648541) -- Icarus Iceholm Outpost
addappid(1995690) -- Icarus Styx Expansion
addappid(2445280) -- Icarus Interior Decorations Pack
addappid(2536360) -- Icarus Tecton Outpost
addappid(2536370) -- Icarus Everbark Outpost
addappid(2536380) -- Icarus Cactus Outpost
addappid(2536390) -- Icarus Arcticus Outpost
addappid(2679990) -- Icarus Industrial Furniture Pack
addappid(2686540) -- Icarus Art Deco Furniture Pack
addappid(2790990) -- Icarus Creature Comforts Pack
addappid(2791000) -- Icarus Homestead Content Pack
addappid(2923820) -- Icarus Pet Companions Pack
addappid(2923830) -- Icarus Zebra Rescue Mission
addappid(3052290) -- Icarus Matariki Holiday Mission
addappid(3315290) -- Icarus Great Hunts Campaigns
addappid(3364360) -- Icarus Frostfall Outpost
addappid(3984230) -- Icarus Aquatica Isle Outpost