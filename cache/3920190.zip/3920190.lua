-- 3920190's Lua and Manifest Created by Hubcap Manifest
-- SEX Guild Simulator ⚔️🔞
-- Created: July 25, 2026 at 16:12:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3920190) -- SEX Guild Simulator ⚔️🔞
-- MAIN APP DEPOTS
addappid(3920191, 1, "1b7685d48061cd813bc8305fc3cd6a9179a1ce3a963716631fe14af4bee42e6a") -- Depot 3920191
setManifestid(3920191, "1890732921137296753", 1478354012)
addappid(3920192, 1, "9bfb59102c7c27ffc97a79060bc04b4d360abf444ac210bf9dc26ad375abb86d") -- Depot 3920192
setManifestid(3920192, "7568662368871602419", 1494936369)
addappid(3920193, 1, "05a8a3c18f15a705d65722203df3559c966e0f0209c8b77dff09101fa952e0f1") -- Depot 3920193
setManifestid(3920193, "1469472131597081592", 1474594724)
-- DLCS WITH DEDICATED DEPOTS
-- SEX Guild Simulator  - Wallpapers Pack (AppID: 4450510)
addappid(4450510)
addappid(4450510, 1, "376df249ee3f184dc5940905716d2511c9176070f41ea9ffa953dd400db02268") -- SEX Guild Simulator  - Wallpapers Pack - Depot 4450510
setManifestid(4450510, "3857043841253101337", 477826391)