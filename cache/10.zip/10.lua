-- 10's Lua and Manifest Created by Hubcap Manifest
-- Counter-Strike
-- Created: February 09, 2026 at 12:30:01 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 24
-- Total DLCs: 0
-- Shared Depots: 15

-- MAIN APPLICATION
addappid(10, 1, "7b83732c00d6cb6178cdd01d4e6b9d858e5c62dc03d15be859d4851486812ebb") -- Counter-Strike
-- MAIN APP DEPOTS
addappid(11, 1, "dacfb281a0abbecc078e884aef2a69caf7723f4066ce3f493ea02248abc8de71") -- Counter-Strike Base Content
setManifestid(11, "3018093494972814332", 292340389)
addappid(95, 1, "7ab15ade88539a6bee8195ae0b1a2a44ad68813632ac2dc230169a64893556e2") -- Condition Zero Models
setManifestid(95, "7685864384078520360", 26459518)
addappid(12, 1, "4989c0128f7c8f0194425db0e36c2800e0f0c0e31373bff7661e8a806f79c82c") -- Counter-Strike French
setManifestid(12, "7476629819067189879", 2573248)
addappid(13, 1, "2f7229ad38de3e01bbf7816c22aa22a239bebbd9eb1347b5b8d48681e53117f3") -- Counter-Strike Italian
setManifestid(13, "1596103708518313909", 6335639)
addappid(14, 1, "447273cfeac2d08447c113fd1065235f5abe5a17e6f6487c50393fed0014e131") -- Counter-Strike German
setManifestid(14, "4163740413628378088", 2137436)
addappid(15, 1, "7b217d6cc4650b0657392c11b8f0a689be2ac7037a17d3a82f8c1a09d3cd386b") -- Counter-Strike Spanish
setManifestid(15, "2951655054604220030", 2087297)
addappid(17, 1, "67bff47a4f20a2dbfc1e156d84fc6f1508dce43212347723f3bb916619224506") -- Counter-Strike sChinese
setManifestid(17, "8232848132911478974", 10864020)
addappid(18, 1, "8d2761f52afa196eda68faa7a613e64965fa0ce7ebca0780ba2cbe94c1d6a409") -- Counter-Strike Koreana
setManifestid(18, "9210252686867714338", 2954322)
addappid(19, 1, "42ed27e3851524839873cc01d0408d2d76ae6d879404f16d48681329efffadad") -- Counter-Strike tChinese
setManifestid(19, "5149037574830114753", 2651129)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(1, 1, "b465d45ab2a7c396f7d1c08a6644e68529ec86b14da77e18588abbbcd2412060") -- Base Goldsrc Shared Content (Shared from App 70)
setManifestid(1, "2667117727132184734", 513399519)
addappid(3, 1, "d249f7d93387a793ed021f0e2314ad0cea0d6aef0b0881c3b725a33deec37d59") -- Base Goldsrc Shared Platform (Shared from App 70)
setManifestid(3, "6081070194444336449", 893958)
addappid(8, 1, "20af1043db56d6408ddd965580e1269005b6e04f81c3676d155174f73099da95") -- Base Goldsrc Linux (Shared from App 70)
setManifestid(8, "1360709870205537514", 127612567)
addappid(2, 1, "fd681c065529f5ee95e920321a780a9290f8f31ef51c232ccb3e98d27e132ebc") -- Base Goldsrc Shared Binaries (Shared from App 70)
setManifestid(2, "724247850320422500", 49814373)
addappid(9, 1, "68c92cf2532cdc6e0b7a9d2783b473b6d16bac72218badf68d7be9b033076096") -- Base Goldsrc OSX (Shared from App 70)
setManifestid(9, "1083345737969856561", 55480049)
addappid(6, 1, "cd3d8b6f23fb863aea4d6789a53dd58dcf284141860e893e8e580d1988d93d3c") -- Base Goldsrc LV (Shared from App 70)
setManifestid(6, "8518478957342391261", 52196711)
addappid(72, 1, "bbc1a14b0c63025aece7d9c3b5a98089205580f321bb5edf6b5f00d368c6face") -- Half-Life French (Shared from App 70)
setManifestid(72, "491735997354925434", 39331832)
addappid(73, 1, "9604a5ba9ad4b580269d5362e201d217cdd9d268bf1098e2c6beb0c5ade020d3") -- Half-Life Italian (Shared from App 70)
setManifestid(73, "3587203030189636184", 54692939)
addappid(74, 1, "49d573f303205df2316749a6ede6725b74651fae3e845494b88ac3d0022a2857") -- Half-Life German (Shared from App 70)
setManifestid(74, "6929797608257779911", 52412233)
addappid(75, 1, "1339202607b6485322859fc1f045c6790bbc470a2d3bb8158aa94b06da31f9bb") -- Half-Life Spanish (Shared from App 70)
setManifestid(75, "6599379689843151742", 48016168)
addappid(77, 1, "793780217977cc3a005dc4410e963c980137e4faca4442f92dc41ab56af96983") -- Half-Life sChinese (Shared from App 70)
setManifestid(77, "8307934900153578333", 45708546)
addappid(78, 1, "39f04a0cc8cffae8023eff1e3e933680681997409823942a5f0f2899d2d2c4b2") -- Half-Life Koreana (Shared from App 70)
setManifestid(78, "2582370374354695075", 45515236)
addappid(79, 1, "019e1cb0950e060fb992001657a444fe03cbc4984081e0d1d9a6505259a7a7e7") -- Half-Life tChinese (Shared from App 70)
setManifestid(79, "6488358189498321283", 45707416)
addappid(141, 1, "0d85b74e163cceabf3651fdd6084585587461f6f7735c37eef875634fc6886cb") -- Half-Life Russian (Shared from App 70)
setManifestid(141, "3921686991280371259", 45052)