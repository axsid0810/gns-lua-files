-- 2396980's Lua and Manifest Created by Hubcap Manifest
-- Fate/stay night REMASTERED
-- Created: January 31, 2026 at 01:19:26 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2396980, 1, "4a0d15735aaeada2cd3039b72b6c9768a9bb6b0fad2c5a7fd63c78d2f8aa1aa4") -- Fate/stay night REMASTERED
-- MAIN APP DEPOTS
addappid(2396981, 1, "62bc96ae2b5b2f680456b0ec8a425ab43d8a57725810e3c3efe590cf7e31f6fc") -- Depot 2396981
setManifestid(2396981, "773222667354721773", 8751368143)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)