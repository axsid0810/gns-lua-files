-- 6860's Lua and Manifest Created by Hubcap Manifest
-- Hitman: Blood Money
-- Created: September 29, 2025 at 17:54:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(6860) -- Hitman: Blood Money
-- MAIN APP DEPOTS
addappid(6863, 1, "d09b82c93b3200d9d8676b007c91ce09aa115ed53a9e3ecc74901facac90a2c2") -- Hitman Blood Money Str
setManifestid(6863, "850320853657837713", 1877041133)
addappid(6862, 1, "fd3be40379ef630b8c1d2330b32dde338221c64caadfc4f4589b25c4373c2f8d") -- Hitman Blood Money Movies
setManifestid(6862, "5059790140597408715", 1375693072)
addappid(6861, 1, "c3cdb6bf3ebc7489b0730732691a77bbc0102317d229d5d095a5bc4a3f6c4b98") -- Hitman Blood Money Binaries
setManifestid(6861, "8073500917896053054", 1213394254)