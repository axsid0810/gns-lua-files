-- 951770's Lua and Manifest Created by Hubcap Manifest
-- Forsaken Realms: Vahrin's Call
-- Created: July 27, 2026 at 11:34:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(951770, 1, "825397bdd12b6c11f58dc54be212d076cefb49d85202ab55ff889a9a6be5e619") -- Forsaken Realms: Vahrin's Call
-- MAIN APP DEPOTS
addappid(951772, 1, "31a7a95bb604c282b64c35095e3d144a66852a23a046c491fb0454361e3d4a65") -- Depot 951772
setManifestid(951772, "4849872360892719060", 20445261856)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)