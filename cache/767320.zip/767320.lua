-- 767320's Lua and Manifest Created by Hubcap Manifest
-- Granblue Fantasy
-- Created: June 03, 2026 at 15:37:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(767320, 1, "4c77f7f8220514554c0fc1aafaedc2e4b989dd0e4faf594cdbefd8b7b12f43f3") -- Granblue Fantasy
-- MAIN APP DEPOTS
addappid(767321, 1, "a59b2e271b7dccebb86cf97a8be93f199add7213306a933dd8bc4baf2fcd4550") -- Depot 767321
setManifestid(767321, "1135010537738626834", 392550492)