-- 2413570's Lua and Manifest Created by Hubcap Manifest
-- Solo Breeding
-- Created: October 01, 2025 at 00:24:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2413570) -- Solo Breeding
-- MAIN APP DEPOTS
addappid(2413571, 1, "5578cd674d089e9ac2b53f9bc03e1a193ad3dc8c9564d45741984f44c7ba0e17") -- Depot 2413571
setManifestid(2413571, "423555956172604485", 1957250202)