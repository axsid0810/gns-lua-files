-- 574720's Lua and Manifest Created by Hubcap Manifest
-- Little Big Workshop
-- Created: December 18, 2025 at 16:24:15 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(574720) -- Little Big Workshop
-- MAIN APP DEPOTS
addappid(574721, 1, "3639fec2e6886f768df5a18f61f57086cb4ac9eb28f086648d0db45ef6c81d56") -- Little Big Workshop - Windows
setManifestid(574721, "7815680612611859828", 3871659946)
addappid(574722, 1, "7b383b5204c7a2aaaaf20f553b86a2b63981886349b250a12774f50d8c7579f3") -- Little Big Workshop - Mac
setManifestid(574722, "5222809907896261218", 3908277431)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1426880) -- Little Big Workshop - The Evil DLC