-- 391540's Lua and Manifest Created by Hubcap Manifest
-- Undertale
-- Created: October 01, 2025 at 04:43:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(391540) -- Undertale
-- MAIN APP DEPOTS
addappid(391541, 1, "b416ce2b64256c530f83775eef790b171047ce48c3795077ebcfd83f9c627cab") -- Undertale [WINDOWS]
setManifestid(391541, "3413030246586915448", 163095879)
addappid(391542, 1, "6b3c4e270f515da237a568230e441e3a28a5984fa2a9224c31b6c3c825ca44fd") -- Undertale [Mac OSX]
setManifestid(391542, "1593483711954100372", 178123538)
addappid(391544, 1, "ba1155a879c71e2f624fe2fe74a0ac1baf68e199cc84e32e507c4c737299d92b") -- Undertale [LINUX]
setManifestid(391544, "5730345506996883260", 162330011)