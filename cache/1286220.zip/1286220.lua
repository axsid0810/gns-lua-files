-- 1286220's Lua and Manifest Created by Hubcap Manifest
-- Sea Power
-- Created: July 21, 2026 at 01:43:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1286220, 1, "dbdef3444402c235c449614d6b97c9d4723f3cd0f1e0a7fbea407eb56b4a07c8") -- Sea Power
-- MAIN APP DEPOTS
addappid(1286221, 1, "984343174565db9374b496a4535fbef08482bad32064195c9afa10617cb1346f") -- Depot 1286221
setManifestid(1286221, "8377380382042969911", 18740212594)