-- 743900's Lua and Manifest Created by Hubcap Manifest
-- Mega Man X Legacy Collection 2
-- Created: March 18, 2026 at 03:54:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(743900, 1, "0e763baeb9f47061ff8c81110f15201772b55deb196ce2b07e2048ad8c5c8a21") -- Mega Man X Legacy Collection 2
-- MAIN APP DEPOTS
addappid(743901, 1, "c74902c0f8ad2d93265e04fff41f127b40f1936c12544237ee9dd600392c7276") -- takenoko Content
setManifestid(743901, "1685310364114588712", 3744438653)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)