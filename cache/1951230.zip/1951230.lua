-- 1951230's Lua and Manifest Created by Hubcap Manifest
-- Pizza Possum
-- Created: September 30, 2025 at 07:05:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1951230) -- Pizza Possum
-- MAIN APP DEPOTS
addappid(1951231, 1, "025460d66afb6412c986c25877a6bd5a7782c206a2775bc9a0b044adceb489b4") -- Depot 1951231
setManifestid(1951231, "1626597803542491560", 915502963)
addappid(1951232, 1, "2a99c0068de13930bf27756368087af851c41d3cf32781092ece7ae693919ccc") -- Depot 1951232
setManifestid(1951232, "4834008335498410312", 759962338)