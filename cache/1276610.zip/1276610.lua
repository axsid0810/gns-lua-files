-- 1276610's Lua and Manifest Created by Hubcap Manifest
-- My Cute Roommate
-- Created: September 30, 2025 at 02:25:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1276610) -- My Cute Roommate
-- MAIN APP DEPOTS
addappid(1276611, 1, "e5e51bc88000aa99ba94977175e0bf4415e4738ffff76bf9fd14a632b79f7301") -- My Cute Roommate Content
setManifestid(1276611, "4455853253124457167", 1937563078)
addappid(1276612, 1, "361354d81ce852b89720998eaaf38e9c7d2b4dfd0d3ba0eff28925b68485b5e9") -- My Cute Roommate for Mac
setManifestid(1276612, "6905572369619240815", 1938834771)