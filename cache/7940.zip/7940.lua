-- 7940's Lua and Manifest Created by Hubcap Manifest
-- Call of Duty 4: Modern Warfare (2007)
-- Created: July 25, 2026 at 10:34:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 27
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 7953, 7954, 7964: Blacklisted

-- MAIN APPLICATION
addappid(7940, 1, "8689a6f56193acf90f9799cc1672c9cd915ea0ed9d12b52efe7c64ca5411d548") -- Call of Duty 4: Modern Warfare (2007)
-- MAIN APP DEPOTS
addappid(7967, 1, "1037dcb2ead997bbaa7194fc900892bb8eaba94a64a93645c1f56809b078f659") -- cod 4 dat
setManifestid(7967, "6005281766938853887", 1)
addappid(7942, 1, "f95bed44156017b1ebe0d4a88ae4c9ebbd817dc92aff0ef6f4bf768778df52d7") -- call of duty 4 modern warfare content 2
setManifestid(7942, "645298708590566320", 1670062543)
addappid(7941, 1, "06494a0cd8015991122e714350b0f240b7006148ffcad8180afd2bdcef0f30bc") -- call of duty 4 modern warfare content
setManifestid(7941, "485990305878906444", 863860530)
addappid(7944, 1, "1358469d87ccd698a96d9dcd313cceb9c40f745609095ed09f32c92ccd410284") -- call of duty 4: modern warfare english 2
setManifestid(7944, "1270795756404865641", 1552879264)
addappid(7945, 1, "7c7f2556883d38a535b0908a1ca4a30b32aaaaec90d7c45a428a988f0b10dcaa") -- call of duty 4: modern warfare english 3
setManifestid(7945, "7416619848934544008", 1679642703)
addappid(7946, 1, "a44e558f453c043d8009fa29ae4b966a6b4c4285cc7954fd7a617ea10dffa22f") -- call of duty 4: modern warfare english 4
setManifestid(7946, "2123215338511832483", 1694616880)
addappid(7948, 1, "95a4759e3b8570861933f046d1b89bdbc9febc7a7ed860bd9f4e702eb7d15bb8") -- call of duty 4: modern warfare french 2
setManifestid(7948, "4648158139028953905", 1654572321)
addappid(7949, 1, "95f8fae5c2360b9a967006b24615fc350aaf584ac2ca51486e9c203f3d72e7e4") -- call of duty 4: modern warfare french 3
setManifestid(7949, "2973235683415973773", 1543388578)
addappid(7951, 1, "70bec55ac568c59edf9dded0a2c69f70b8e50a528e861260c63ff58331d1efd3") -- call of duty 4: modern warfare french 4
setManifestid(7951, "1569883009213664900", 1694508488)
addappid(7956, 1, "5273af14e7ee03bd2ca2078ad76d195886a04b22b4f1396e347978db19a430b4") -- call of duty 4: modern warfare italian 2
setManifestid(7956, "2316711176254772873", 1700611940)
addappid(7957, 1, "bcda7eff54d650906df2ccf608427866a158c966f71606ab00d146d48f9cd0e5") -- call of duty 4: modern warfare italian 3
setManifestid(7957, "5879833614856912925", 1369676830)
addappid(7959, 1, "b6d796583882c418ce5803c3fa5a0a77498943bc2453c67ef52758d7828c16b0") -- call of duty 4: modern warfare spanish 2
setManifestid(7959, "9148603186836614189", 4660024528)
addappid(7961, 1, "ed4449def14fa326fae15039eb55e9bc6b6e46daba06d1e8bd14c947269e2b04") -- call of duty 4: modern warfare spanish 3
setManifestid(7961, "3224169185101846447", 1295935506)
addappid(7962, 1, "8a97acdc5da02a24e3390392bde55e4a81a6cef205261be83f23aa923db017f5") -- call of duty 4: modern warfare english public
setManifestid(7962, "9202751254486490586", 1514063408)
addappid(7963, 1, "4d9a0b5e86a1cd42a3605de5684eae3a8d339fd174eccdef0d14296590e4bddf") -- call of duty 4: modern warfare french public
setManifestid(7963, "3336453290445255785", 1720247286)
addappid(7965, 1, "dc47ed947eacce96178a65617034ad3b440e8cec65d05dfa1648020d40968f71") -- call of duty 4: modern warfare italian public
setManifestid(7965, "2620362561217950731", 1554865461)
addappid(7966, 1, "8f7d2858332c7c6f6c1edbf07210a7da4de966d5035eac1da818be7aab7d20ba") -- call of duty 4: modern warfare spanish public
setManifestid(7966, "7049870480103654382", 1556027691)
addappid(7968, 1, "b1d5d746e222e081fd1da9ae006e1e80b2fcffdd1ada0a77a5496f921ac42413") -- call of duty 4: modern warfare german real
setManifestid(7968, "830685572847006058", 1543533163)
addappid(7969, 1, "03e68b6e096900a3a3c4f0fb28a33f18735012dcf64cf1e9d1aeca6c57b4b90f") -- call of duty 4: modern warfare german real 2
setManifestid(7969, "1594764497270660680", 1650687885)
addappid(10071, 1, "332f3354ac2d6c87f62050906743ca400bea99a97f62cae9e976bbabfb841cc3") -- call of duty 4: modern warfare german real 3
setManifestid(10071, "8716669227858905656", 1295949806)
addappid(231951, 1, "323e9542ca2063fef5923e132afff8a14451b7fe9fbc52e5c46cbabd9a9807f5") -- Call of Duty 4 OS X Exe
setManifestid(231951, "4624141764057936712", 14739554)
addappid(231952, 1, "3199ecf5b63c55c5f1c73028c53d876a6430c392bc3af80302a1ff8d74073083") -- Call of Duty 4 OS X Content
setManifestid(231952, "4381207422635173045", 3928094720)
addappid(231953, 1, "a038d98150719845bf31ad8d9033c71c19731a81dcf6495376517c8a65a53d8c") -- Call of Duty 4 OS X English
setManifestid(231953, "2135792621304785486", 3569906336)
addappid(231954, 1, "d2d0e1a8684c63761b46f3a15629c951a39640b83458d38812acacbe9347b972") -- Call of Duty 4 OS X French
setManifestid(231954, "237231261166079678", 3584679625)
addappid(231955, 1, "ddbd2ae289176f6ca96b09e9b4463800939995d6af304e91be9944898ed1e11f") -- Call of Duty 4 OS X Italian
setManifestid(231955, "6399189440013381748", 3743273620)
addappid(231956, 1, "ad6fce0392ca3262ffbdd3815c69e91c7f7345dd210a31d74fe4e958d02ba35e") -- Call of Duty 4 OS X Spanish
setManifestid(231956, "914777274218043390", 3720445338)
addappid(231957, 1, "68635ea2a00ce626cb349768e9a8c47845a0a0b3e8eac6367069a28aff623622") -- Call of Duty 4 OS X German
setManifestid(231957, "885730226063538474", 3619909537)