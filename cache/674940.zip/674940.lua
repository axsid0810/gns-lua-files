-- 674940's Lua and Manifest Created by Hubcap Manifest
-- Stick Fight: The Game
-- Created: January 20, 2026 at 11:31:31 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(674940, 1, "1a031daa727c81e12f3d00c23a4c634f8c79bf1e428c7b3e3879da2138eb1be6") -- Stick Fight: The Game
-- MAIN APP DEPOTS
addappid(674941, 1, "b6184320732c4df9365dc179616f688a3da2bb9334c80267f54d47e49ab84969") -- Stick man game Content
setManifestid(674941, "6963720474772919938", 392892776)
addappid(726050, 1, "3866668b1a85adef60c3470be739a60c4764d0fcbd9fd7f7813b703233f9548e") -- Stick Fight: The Game OST (726050) depå
setManifestid(726050, "987934740586805841", 265181044)
addappid(674942, 1, "0d4f44eb9a21c3d76b3ae3ad2cf2d1445c3132c443d4a63957f6ccf89b6a9cd8") -- Stick man game Content MAC
setManifestid(674942, "6708735043648025786", 405580676)
addappid(674944, 1, "4f8739acea8e537672897925fdae67d2e6519846299b9289c0e12c90416c845a") -- Stick man game Content MAC 64Bit
setManifestid(674944, "5454866201526278118", 408967389)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(674945) -- Depot 674945 (empty depot)