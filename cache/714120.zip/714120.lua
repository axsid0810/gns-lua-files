-- 714120's Lua and Manifest Created by Hubcap Manifest
-- Little Misfortune
-- Created: September 29, 2025 at 22:20:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(714120) -- Little Misfortune
-- MAIN APP DEPOTS
addappid(714121, 1, "9c8332d28ea3cc30897635a7e15fb74637c0ba49bde89c1a8d697ef70c77bcad") -- Little Misfortune Content
setManifestid(714121, "7662918906800596140", 6510214930)
addappid(714122, 1, "e386b71b624c76abab0ebfd0b2ffc234ae03731e4e15517ecc34c083ca208507") -- Little Misfortune Linux
setManifestid(714122, "4027211924498502787", 6480493163)
addappid(714123, 1, "a06bfa34f7f5afebbc5cc77e1bf2c5ac5a4cea980938025e54490f9429b5166d") -- Little Misfortune Mac
setManifestid(714123, "5294680053252111094", 6552611563)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Little Misfortune - Official Artbook (AppID: 1146790)
addappid(1146790)
addappid(1146790, 1, "a5ee4a47b15583927994977ed495dc321cbccf682d8936de73535cd1919a04bd") -- Little Misfortune - Official Artbook - Little Misfortune - Official Artbook (1146790) Depot
setManifestid(1146790, "8533749430160234548", 118604727)