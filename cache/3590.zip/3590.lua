-- 3590's Lua and Manifest Created by Hubcap Manifest
-- Plants vs. Zombies: Game of the Year
-- Created: September 30, 2025 at 07:11:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3590) -- Plants vs. Zombies: Game of the Year
-- MAIN APP DEPOTS
addappid(3593, 1, "2fec966bebbf74b5fad937c61ad06d393d521b64f27d97992ae7ef3775c50c10") -- plants vz zombies mac content
setManifestid(3593, "2896720143485326882", 46337545)
addappid(3591, 1, "1625fdac425750d0736c420f3877d3b4b4119d1d361629c2d12b360eb3689839") -- plants vs zombies content
setManifestid(3591, "7598841597413163537", 51584086)