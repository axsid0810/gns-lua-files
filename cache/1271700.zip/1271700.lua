-- 1271700's Lua and Manifest Created by Hubcap Manifest
-- HOT WHEELS UNLEASHED™
-- Created: September 29, 2025 at 18:18:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 67
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1271700) -- HOT WHEELS UNLEASHED™
-- MAIN APP DEPOTS
addappid(1271701, 1, "ff5665727b233ab8a0dca5d6d9eb0fb3be4a737fa3a73656f1290d9a132d6e6a") -- HW Game Project Content
setManifestid(1271701, "4557623839855560102", 28857792745)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1633670) -- HOT WHEELS - Pass Vol. 1
addappid(1633680) -- HOT WHEELS - Pass Vol. 2
addappid(1633690) -- HOT WHEELS - Pass Vol. 3
addappid(1633700) -- HOT WHEELS - Sportscars Pack
addtoken(1633700, "5139054706492759865")
addappid(1633710) -- HOT WHEELS - Beefed Up Pack
addtoken(1633710, "5936819933601309048")
addappid(1633720) -- HOT WHEELS - Street Beasts Pack
addtoken(1633720, "6163121150202563403")
addappid(1633730) -- HOT WHEELS - Bone Shaker Unleashed Edition
addappid(1663460) -- HOT WHEELS - Street Fighter M. Bison
addappid(1663470) -- HOT WHEELS - Superman
addappid(1663480) -- HOT WHEELS - Aston Martin DB5 1963
addappid(1663490) -- HOT WHEELS - Bye Focal II
addappid(1663510) -- HOT WHEELS - Street Fighter Blanka
addappid(1663520) -- HOT WHEELS - Wonder Woman
addappid(1663530) -- HOT WHEELS - AcceleRacers Deora II
addappid(1663540) -- HOT WHEELS - TMNT Leonardo
addappid(1663550) -- HOT WHEELS - Thanksgiving Pack
addappid(1663570) -- HOT WHEELS - Batman Expansion
addappid(1663590) -- HOT WHEELS - AcceleRacers Bassline
addappid(1663600) -- HOT WHEELS - Christmas Pack
addappid(1663610) -- HOT WHEELS - 2-Tuff
addappid(1663630) -- HOT WHEELS - Barbie Dream Camper
addappid(1668220) -- HOT WHEELS - Tropical Wave Customization Pack
addappid(1668230) -- HOT WHEELS - Rolling Boulders Module
addappid(1668240) -- HOT WHEELS - Pink Fashion Customization Pack
addappid(1668250) -- HOT WHEELS - Dinopult Module
addappid(1671790) -- HOT WHEELS - TMNT Michelangelo
addappid(1671820) -- HOT WHEELS - AcceleRacers Power Rage
addappid(1671830) -- HOT WHEELS - Street Fighter Chun-Li
addappid(1671840) -- HOT WHEELS - Mattel Dream Mobile
addappid(1671850) -- HOT WHEELS - Street Fighter Vega
addappid(1671860) -- HOT WHEELS - Corvette Stingray Convertible 2014
addappid(1671870) -- HOT WHEELS - McLaren Senna
addappid(1671880) -- HOT WHEELS - Night Burner
addappid(1671900) -- HOT WHEELS - Monster Trucks Expansion
addappid(1671910) -- HOT WHEELS - Street Fighter Ryu
addappid(1671920) -- HOT WHEELS - TMNT Raphael
addappid(1671930) -- HOT WHEELS - AcceleRacers Hollowback
addappid(1671940) -- HOT WHEELS - Chevy 1956
addappid(1671950) -- HOT WHEELS - Mad Manga
addappid(1671960) -- HOT WHEELS - TMNT Donatello
addappid(1671970) -- HOT WHEELS - He-Man
addappid(1671980) -- HOT WHEELS - The Mystery Machine
addappid(1671990) -- HOT WHEELS - Hotweiler
addappid(1672000) -- HOT WHEELS - Looney Tunes Expansion
addappid(1672010) -- HOT WHEELS - TMNT Shredder
addappid(1672020) -- HOT WHEELS - Skeletor
addappid(1672030) -- HOT WHEELS - Swamp Thing
addappid(1672040) -- HOT WHEELS - Aston Martin DBS 2010
addappid(1672050) -- HOT WHEELS - The Jetsons
addappid(1672060) -- HOT WHEELS - Classic Packard
addappid(1672070) -- HOT WHEELS - McLaren 720S
addappid(1672080) -- HOT WHEELS - Fun Pack
addappid(1698090) -- HOT WHEELS - Holiday Season Customization Pack
addappid(1698100) -- HOT WHEELS - Spinning Tire Module
addappid(1723980) -- HOT WHEELS - Outer Space Customization Pack
addappid(1723990) -- HOT WHEELS - Skaters Customization Pack
addappid(1790950) -- HOT WHEELS - Booster Slam Module
addappid(1790970) -- HOT WHEELS - Gorilla Garage Module
addappid(1797470) -- HOT WHEELS - Haunted Customization Pack
addappid(1839650) -- HOT WHEELS - Shark Jaws Module
addappid(1852420) -- HOT WHEELS - Cyberpunk Customization Pack
addappid(1852430) -- HOT WHEELS - Retro Game Customization Pack
addappid(1852440) -- HOT WHEELS - Jumping Towers Module
addappid(1852450) -- HOT WHEELS - Hot Rod Customization Pack
addappid(1881890) -- HOT WHEELS - Zero Gravity Checkpoint Module
addappid(1881900) -- HOT WHEELS - Super Dealership Module
addappid(2051380) -- HOT WHEELS - GOTY Upgrade Pack