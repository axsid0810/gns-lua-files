-- 2157830's Lua and Manifest Created by Hubcap Manifest
-- John Carpenter's Toxic Commando
-- Created: July 02, 2026 at 09:44:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 4
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2157830, 1, "323fee23e77e9fc177fae952a0ebf63f1764b48b94e8a45270e21e47bb00f01f") -- John Carpenter's Toxic Commando
-- MAIN APP DEPOTS
addappid(2157831, 1, "3198b1f3831fde3e4f41577b2f01b20595ff7961ac9a679f856809d3219d0ef3") -- Depot 2157831
setManifestid(2157831, "6123300899332003446", 63907034443)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3933860) -- John Carpenters Toxic Commando - Leons Secret Stash
addappid(3933870) -- John Carpenters Toxic Commando - Cosmetic Pack Bloody Pass  
addappid(3933880) -- John Carpenters Toxic Commando - Bloody Pass 
addappid(4148650) -- John Carpenters Toxic Commando - Cosmetic Pack 1