-- 1212740's Lua and Manifest Created by Hubcap Manifest
-- CHAMELEON | くるくるカメレオン
-- Created: December 28, 2025 at 10:29:10 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1212740) -- CHAMELEON | くるくるカメレオン
-- MAIN APP DEPOTS
addappid(1212741, 1, "c88bf5ec525228ef3e21845b59c0ee9164120a037fc0e2fb6d22251a4c339909") -- 64bit CHAMELEON | くるくるカメレオン Content
setManifestid(1212741, "7524943174708647041", 406768402)