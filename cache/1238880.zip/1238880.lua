-- 1238880's Lua and Manifest Created by Hubcap Manifest
-- Battlefield™ Hardline
-- Created: July 03, 2026 at 08:48:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 68
-- Total DLCs: 16
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1238880, 1, "fe296d1d52db3d01d5bc7003ca4c205474fed0b8d6b3e179f70ceb5638e08546") -- Battlefield™ Hardline
-- MAIN APP DEPOTS
addappid(1238881, 1, "ca3213c27f45fd919fb3bbcc717d1fc836d56c9cadf6d7c5484aef22a2e9d886") -- Battlefield Hardline - Content
setManifestid(1238881, "6826322720323828727", 51747567379)
addappid(1238882, 1, "2ebe691fe34ea5ca9107fd88b53a6f821a6aa045026efc3b7ef232c72ece882a") -- Battlefield Hardline - en_US
setManifestid(1238882, "5814594304937679643", 1670464229)
addappid(1238883, 1, "e1198986c9ffaab4271866ef20e776ba574e9b8b8040ecadbb3b76b1e424b205") -- Battlefield Hardline - cs_CZ
setManifestid(1238883, "4310926822665069738", 2201534)
addappid(1238884, 1, "2d306ab061b8201a93d108fbd2f291f24efd36512d565ba88464ec6c4b121dae") -- Battlefield Hardline - de_DE
setManifestid(1238884, "4534105736785367841", 1461253461)
addappid(1238885, 1, "c5340ac0a0ed7f342cd4f828385b2cb49efb905acec556d75567da2df9e0e3c6") -- Battlefield Hardline - es_ES
setManifestid(1238885, "1245164389321818488", 1480193405)
addappid(1238886, 1, "950e5af714c7dbb4e5bfe0d4ff452d1f928d21837693850f9309ab786768a295") -- Battlefield Hardline - fr_FR
setManifestid(1238886, "2017350244556318474", 1423177351)
addappid(1238887, 1, "30a987c78b276c7f506a4ee56651e3a334bde3ff35f7d79d5761c0d5d857b065") -- Battlefield Hardline - it_IT
setManifestid(1238887, "403053245919075471", 1467738959)
addappid(1238888, 1, "2268764d6bc1f2f32a7458b3571487ede7466bca0fdc990f9afc8a3a96394ddc") -- Battlefield Hardline - ja_JP
setManifestid(1238888, "5841245290236083918", 1455550166)
addappid(1238889, 1, "2346893aec717451d709a962d67a2e32f10fc08642c7596c358fe9fb9b994773") -- Battlefield Hardline - ko_KR
setManifestid(1238889, "3822655056749081611", 2621230)
addappid(1238892, 1, "82eb2ed4c66d175c26dd9fb2aab0dfae52ad55d50ebfd4c997983be50a4b1867") -- Battlefield Hardline - pl_PL
setManifestid(1238892, "6285831484115087703", 1448109268)
addappid(1238893, 1, "7bc37388f1986e9db3f5edf96121383cfc438df8d9f39875786f4ef7392e7494") -- Battlefield Hardline - pt_BR
setManifestid(1238893, "1268099092303341209", 1481943478)
addappid(1238894, 1, "382618919bb7d5b0a5b3f73014eccdff8ae21c7cb89f626b5215e7a74af6d103") -- Battlefield Hardline - ru_RU
setManifestid(1238894, "6956063495166561242", 1499616963)
addappid(1238895, 1, "888d9571a3d76aaa8c83b15934a902da713d19a9ca98c4f5127304d432b979f6") -- Battlefield Hardline - zh_TW
setManifestid(1238895, "6789680548342885196", 2181607)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
setManifestid(3340991, "2155225770093841476", 239536599)
-- DLCS WITH DEDICATED DEPOTS
-- Battlefield Hardline Criminal Activity (AppID: 1279010)
addappid(1279010)
addtoken(1279010, "48877489347043244")
addappid(1279010, 1, "9f545aec964a9ed79f02aa905661e8b60d9779809df2ad83f5c9ed7b6d5f6505") -- Battlefield Hardline Criminal Activity - Depot 1279010
setManifestid(1279010, "3864776569937690931", 2824609089)
addappid(1279014, 1, "6dee9ef05d6fb92dcdf886202337589fb9eca3b6114fa32f0eb622571f107d09") -- Battlefield Hardline Criminal Activity - Depot 1279014
setManifestid(1279014, "314312405178047499", 187)
addappid(1279015, 1, "53c4b53228f961a5a1af1a949d35a49404de04f69146a6341e7b55fc9f52b412") -- Battlefield Hardline Criminal Activity - Depot 1279015
setManifestid(1279015, "6047018941342444665", 187)
addappid(1279016, 1, "00fd4893c253e2b4a7eec1b7c8edd6a68aa965de7e4dee9b463238e2eccb0057") -- Battlefield Hardline Criminal Activity - Depot 1279016
setManifestid(1279016, "3252023435084255387", 187)
addappid(1279017, 1, "ffdf8b1fb6b6e4190858d7a3bc6abea62271144af4448d01a8c8f5db3232b36a") -- Battlefield Hardline Criminal Activity - Depot 1279017
setManifestid(1279017, "8734083244295894001", 187)
addappid(1279018, 1, "f062c6a4ded82038f9b05dea65ab19482613cdb81a36ab358b176000b8dd8bab") -- Battlefield Hardline Criminal Activity - Depot 1279018
setManifestid(1279018, "2087064565008118259", 187)
addappid(1279019, 1, "ed298b5b77020b52452e29d3f8fabcbcc3652186208e2340137899592b31dadc") -- Battlefield Hardline Criminal Activity - Depot 1279019
setManifestid(1279019, "8288042534711483866", 187)
addappid(1279190, 1, "9494cbb525df7178d7271aec47029897f84a78bf6e218d7b177a2ab22cd3d1c1") -- Battlefield Hardline Criminal Activity - Depot 1279190
setManifestid(1279190, "6859001272676331247", 187)
addappid(1279191, 1, "0185dd11e21391416a390a8bb0e7c8eee62cfb4b970d95576b3ceeb3c2b24341") -- Battlefield Hardline Criminal Activity - Depot 1279191
setManifestid(1279191, "265429889911667354", 187)
addappid(1279192, 1, "1cfdec0e03fd3a0ab5a9c3d6b978d5eb5fde557833be6059ea2a77673e253c57") -- Battlefield Hardline Criminal Activity - Depot 1279192
setManifestid(1279192, "361617578874147096", 187)
addappid(1279193, 1, "438b5061835877f3c6b4d7b7d041b8de493545294939176ae9dc2fb027152abd") -- Battlefield Hardline Criminal Activity - Depot 1279193
setManifestid(1279193, "4012450220004360887", 187)
addappid(1279194, 1, "3f7edd02dca70799957be64a5b2b23d33d275c734a52cb30f9e35a636f614fee") -- Battlefield Hardline Criminal Activity - Depot 1279194
setManifestid(1279194, "8417066641940676614", 187)
addappid(1279195, 1, "05770ca4f8d9b8c131c9c7fd650f9d6210ae8c23eeae8c574e45b6807f812dc9") -- Battlefield Hardline Criminal Activity - Depot 1279195
setManifestid(1279195, "4783833899212770353", 187)
-- Battlefield Hardline Betrayal (AppID: 1279011)
addappid(1279011)
addtoken(1279011, "17297542848205981231")
addappid(1279011, 1, "8046b013db12e08839203c6ad72f5d63fae84e30e7cb197671a4b544b03d37da") -- Battlefield Hardline Betrayal - Depot 1279011
setManifestid(1279011, "3238296660468642244", 6037136973)
addappid(1279170, 1, "59f46eb8a62f6e0e2a23a759d88d760e75612660ab0ac8a420c4e46b1fe7c410") -- Battlefield Hardline Betrayal - Depot 1279170
setManifestid(1279170, "281757841541435736", 187)
addappid(1279171, 1, "7f029db84eb4dfb3d0ee752d8d8070877085ada1e7be5c199ee4edb169c87fa1") -- Battlefield Hardline Betrayal - Depot 1279171
setManifestid(1279171, "6578774102658349551", 187)
addappid(1279172, 1, "b24d342a33d83debf3c2ecd46f519cb3488cc984ea52af4797b77d6c35bedfe3") -- Battlefield Hardline Betrayal - Depot 1279172
setManifestid(1279172, "8932185199151008757", 187)
addappid(1279173, 1, "168d33e9849641063ae2df30efbea2d21226c9f970d0c75e07eada757b2b9677") -- Battlefield Hardline Betrayal - Depot 1279173
setManifestid(1279173, "4139751739208206631", 187)
addappid(1279174, 1, "3baed4640bdd294d3ecbbb2f921d29e96b37391e87ff692960a82126adf5b662") -- Battlefield Hardline Betrayal - Depot 1279174
setManifestid(1279174, "592305820586905847", 187)
addappid(1279175, 1, "dccbd486e10b94f0c28cf87c38324ca12075cdf7801666d9a41bdca7ab040e0b") -- Battlefield Hardline Betrayal - Depot 1279175
setManifestid(1279175, "2904558924802715701", 187)
addappid(1279176, 1, "0eecbca4dd04d5d3aef039703ac1b097b39508b419e706574043dccff5637f7f") -- Battlefield Hardline Betrayal - Depot 1279176
setManifestid(1279176, "1516222060316041562", 187)
addappid(1279177, 1, "9ffe969cedbcf7161ddfb606bf6c60b68b9ea68f92ae395fed7be5dcd5936869") -- Battlefield Hardline Betrayal - Depot 1279177
setManifestid(1279177, "3223997961141354688", 187)
addappid(1279178, 1, "db5189810c4c7d515f8750bf3d8fb42d1c612ea0e61e20616e66cd6305a75fb7") -- Battlefield Hardline Betrayal - Depot 1279178
setManifestid(1279178, "1532647957089213078", 187)
addappid(1279179, 1, "bf2507ee9e62c05ecde90b6e608dcd416fceef51efb181f127787eb5de01833e") -- Battlefield Hardline Betrayal - Depot 1279179
setManifestid(1279179, "7063042333689095237", 187)
addappid(1279180, 1, "db3f7bbb9be8d2e3f8a84aeef37b73fca7e9abb0cd3de945062ef116d881a0a8") -- Battlefield Hardline Betrayal - Depot 1279180
setManifestid(1279180, "1852800710402006699", 187)
addappid(1279181, 1, "e9f32ba96373a6843d71007d3a544b26b2d52ac533aa4c2e1ce52bb0a592c81b") -- Battlefield Hardline Betrayal - Depot 1279181
setManifestid(1279181, "7936284322912938220", 187)
-- Battlefield Hardline Robbery (AppID: 1279012)
addappid(1279012)
addtoken(1279012, "2997523365052677686")
addappid(1279012, 1, "0891832b3961e9961523351db5568d2e69e9512b05c42ff62f17be49f5b5d9f9") -- Battlefield Hardline Robbery - Depot 1279012
setManifestid(1279012, "5990545865470234136", 4236994483)
addappid(1279150, 1, "820e518ec941330b004f60a5fd2cd704062621fab6cd8bda71d97c879cb83ea1") -- Battlefield Hardline Robbery - Depot 1279150
setManifestid(1279150, "8907987562461328938", 187)
addappid(1279151, 1, "75d76716de522070c9b4866dd0fee0644a6fcce2a7269dc3bb30e794bfde2c70") -- Battlefield Hardline Robbery - Depot 1279151
setManifestid(1279151, "1277083325787430287", 187)
addappid(1279152, 1, "2ec412da17d5cf8eb73d4df9e3c58ad3e96fe763b2c4db7516a56360dfb9d73f") -- Battlefield Hardline Robbery - Depot 1279152
setManifestid(1279152, "870680507737206105", 187)
addappid(1279153, 1, "07701f89962d228e3efb095e664b2ec943c8a3c50b57072e33fb252f9126bad3") -- Battlefield Hardline Robbery - Depot 1279153
setManifestid(1279153, "3467940028908567689", 187)
addappid(1279154, 1, "4c3bf14aa119888b8d99f5b53cda51844eb5c1f1bf44af2349cbf732bffa070c") -- Battlefield Hardline Robbery - Depot 1279154
setManifestid(1279154, "4981932354758328739", 187)
addappid(1279155, 1, "09bd64a9ec57fcc224294d88840df7999a3a54435af548a0ce93e30832b006c3") -- Battlefield Hardline Robbery - Depot 1279155
setManifestid(1279155, "1638221721764416985", 187)
addappid(1279156, 1, "f22627c5ed129117d607350d45420af70a80c08e2005ccccf136433f0aebe5a0") -- Battlefield Hardline Robbery - Depot 1279156
setManifestid(1279156, "5991248474187900272", 187)
addappid(1279157, 1, "b66a7a9017f945caecb8bd9911cba1251e6444a578b05c7fc0c5107f4f536a3d") -- Battlefield Hardline Robbery - Depot 1279157
setManifestid(1279157, "3825740860610680641", 187)
addappid(1279158, 1, "a2f12238dbba941e4ab849d32804ee960415d86f82578090aa1147211d49133e") -- Battlefield Hardline Robbery - Depot 1279158
setManifestid(1279158, "772393523382491624", 187)
addappid(1279159, 1, "c1de98dfd2d07634e5986c51a5a8445c7496c8372acbcb1f97870a483e4c9152") -- Battlefield Hardline Robbery - Depot 1279159
setManifestid(1279159, "5064997243424094711", 187)
addappid(1279160, 1, "d9905de8817cada4ae299bb1650f1cf84265e8f986b3f2676221b1f6a063b609") -- Battlefield Hardline Robbery - Depot 1279160
setManifestid(1279160, "2216754269136049304", 187)
addappid(1279161, 1, "e03b59bff953b8ccb0590e0ffed938a2fabaa3c7df505dbb59018e6d41f67401") -- Battlefield Hardline Robbery - Depot 1279161
setManifestid(1279161, "2745596611407327321", 187)
-- Battlefield Hardline Getaway (AppID: 1279013)
addappid(1279013)
addtoken(1279013, "3369056561361956016")
addappid(1279013, 1, "55a0bdf74159109ccafb4bfc27182e63926264cdbde00ca5edd3fc2fb3d21d31") -- Battlefield Hardline Getaway - Depot 1279013
setManifestid(1279013, "5315311685472691521", 4718249277)
addappid(1279130, 1, "6eeaa92993c5d7bbe981babf8957ad4fdc4b866f567ef4e6158acd38c0ea482c") -- Battlefield Hardline Getaway - Depot 1279130
setManifestid(1279130, "5021546189257229127", 187)
addappid(1279131, 1, "d4734b2d0d43d148ce06c61e5a3fe18944823c477bcd44ab4791edab1331fb5e") -- Battlefield Hardline Getaway - Depot 1279131
setManifestid(1279131, "497023596259925788", 187)
addappid(1279132, 1, "9f1e22afa44448e57a1a8f09f3f423ad2d41f5de0b66345306944305454070f0") -- Battlefield Hardline Getaway - Depot 1279132
setManifestid(1279132, "567628806756532363", 187)
addappid(1279133, 1, "5f02e928ab3d6c5ed19a8d932092fee4f033a51c04d468e67ec8f4bc95b072d1") -- Battlefield Hardline Getaway - Depot 1279133
setManifestid(1279133, "5021739258436603137", 187)
addappid(1279134, 1, "243b010b30b8169e6bc2e4282d9f001c51805701e014df18e8bbce0bcba8c00c") -- Battlefield Hardline Getaway - Depot 1279134
setManifestid(1279134, "7486337491646951645", 187)
addappid(1279135, 1, "eeb5f4eacf71095d4809e33b87830e65727bcc42bf451016b0430c1200867a10") -- Battlefield Hardline Getaway - Depot 1279135
setManifestid(1279135, "954237752482349562", 187)
addappid(1279136, 1, "c951e6bbea113e26b3639a19622f923ac4cb3c5fab4be34e1daa36e488858fac") -- Battlefield Hardline Getaway - Depot 1279136
setManifestid(1279136, "8457638184692627675", 187)
addappid(1279137, 1, "42bfac8d6db1363e557631b330d26722bb3c1e33f8f8a3ce744c70f9dce7955c") -- Battlefield Hardline Getaway - Depot 1279137
setManifestid(1279137, "7559102498003660145", 187)
addappid(1279138, 1, "32e8e18aac03c2b4d38cd6d3e5ac0995437800f318b1f52f0a21aa8605ce68ec") -- Battlefield Hardline Getaway - Depot 1279138
setManifestid(1279138, "1630987826810986245", 187)
addappid(1279139, 1, "2016f53b18b4538557be4174fc8d18f617db11f77f9309fe51506061ce7c701e") -- Battlefield Hardline Getaway - Depot 1279139
setManifestid(1279139, "6450596958636873381", 187)
addappid(1279140, 1, "2a8467fa034cff60b648b3e5ef1e5852cdde2a391e23ba344b4277ba027f7651") -- Battlefield Hardline Getaway - Depot 1279140
setManifestid(1279140, "1972158717429155247", 187)
addappid(1279141, 1, "b553d845b9837443ce0f0b669dba1aa356b972c655a62ce98af9dd27e1d00c20") -- Battlefield Hardline Getaway - Depot 1279141
setManifestid(1279141, "7968840306095797985", 187)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1238890) -- Battlefield Hardline Premium
addtoken(1238890, "15157183607126784100")
addappid(1238891) -- Battlefield Hardline Ultimate Shortcut Unlock
addappid(1279340) -- Battlefield Hardline Standard Edition - Key
addappid(1279341) -- Battlefield Hardline Ultimate Edition - Key
addtoken(1279341, "4507831183104054246")
addappid(1279350) -- Battlefield Hardline 10 x Gold Battlepack
addappid(1279351) -- Battlefield Versatility Battlepack
addappid(1279352) -- Battlefield Precision Battlepack
addappid(1279353) -- Battlefield Suppression Battlepack
addappid(1279354) -- Battlefield Hardline 5 X Gold Battlepacks
addappid(1279355) -- Battlefield Hardline Bronze Battlepack
addappid(1279356) -- Battlefield Hardline Gold Battlepack
addappid(1279357) -- Battlefield Hardline Silver Battlepack