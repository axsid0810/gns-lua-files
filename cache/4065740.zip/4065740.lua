-- 4065740's Lua and Manifest Created by Hubcap Manifest
-- Express Rider Simulator
-- Created: July 29, 2026 at 12:53:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4065740) -- Express Rider Simulator
-- MAIN APP DEPOTS
addappid(4065741, 1, "d500850aa6b4aebade5aff5385760a0388ea82630752f077c9d03586e01ee9d7") -- Depot 4065741
setManifestid(4065741, "3240820812880366211", 4073134723)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)