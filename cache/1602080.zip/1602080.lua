-- 1602080's Lua and Manifest Created by Hubcap Manifest
-- Soulstice
-- Created: September 30, 2025 at 18:31:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1602080) -- Soulstice
-- MAIN APP DEPOTS
addappid(1602081, 1, "0ef50763f874a2a88253fb66ba50b92cdb0b0a78871ec332d3ee2ad98943e6e0") -- Depot 1602081
setManifestid(1602081, "8830670894140579743", 25447213575)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Soulstice Artbook (AppID: 2101860)
addappid(2101860)
addappid(2101860, 1, "04be9c575d301dc1606fe8e7a1c44cf98e43711c8b7e326ef00271e48e55cc44") -- Soulstice Artbook - Depot 2101860
setManifestid(2101860, "3425044909442637175", 429817077)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2110210) -- Soulstice Ashen Blade Item Pack