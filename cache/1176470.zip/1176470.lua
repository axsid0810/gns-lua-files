-- 1176470's Lua and Manifest Created by Hubcap Manifest
-- Terra Invicta
-- Created: July 28, 2026 at 04:24:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1176470, 1, "d438aed372c166200b60c1a0dc505f3d60fa189ef49543898f4097062692fa39") -- Terra Invicta
-- MAIN APP DEPOTS
addappid(1176471, 1, "32afe0ca44ac3ee8659bb2d081a83e48b296b6a04937ad62f469dff1a46068e3") -- Depot 1176471
setManifestid(1176471, "3113903098434653548", 23150717416)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- Terra Invicta - Supporter Pack (AppID: 2939040)
addappid(2939040)
addappid(2939040, 1, "6831aefd5e338fcfde0969b2d8866d1aee18976ac5de489825abc606302a78a9") -- Terra Invicta - Supporter Pack - Depot 2939040
setManifestid(2939040, "2471507827232603259", 2280670951)
-- Terra Invicta - Dark Skies (AppID: 4713340)
addappid(4713340)
addappid(4713340, 1, "cf6ce897ca4986cfb94ca258707375e5021ecfe47bbcf109d44656b8251f9184") -- Terra Invicta - Dark Skies - Depot 4713340
setManifestid(4713340, "8256177759247408017", 5747849883)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1176472) -- Depot 1176472 (empty depot)