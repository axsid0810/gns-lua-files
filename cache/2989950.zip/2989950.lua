-- 2989950's Lua and Manifest Created by Hubcap Manifest
-- The Bathhouse | 地獄銭湯 Restored Ver.
-- Created: September 30, 2025 at 22:41:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2989950) -- The Bathhouse | 地獄銭湯 Restored Ver.
-- MAIN APP DEPOTS
addappid(2989951, 1, "46ba9c35893709885a253dc16ae624a59f7ba30e7d5673c8d70bab12dd2dfa75") -- Depot 2989951
setManifestid(2989951, "8502982591506204150", 27072868337)