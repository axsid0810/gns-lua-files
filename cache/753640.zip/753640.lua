-- 753640's Lua and Manifest Created by Hubcap Manifest
-- Outer Wilds
-- Created: October 07, 2025 at 21:02:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(753640) -- Outer Wilds
-- MAIN APP DEPOTS
addappid(753641, 1, "57452658900ae11ac7c0e91c17d64353fa62936759ca202f4ecbbc9f29cf4b60") -- Outer Wilds Content
setManifestid(753641, "2759471679100125861", 11652599956)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1622100) -- Outer Wilds - Echoes of the Eye