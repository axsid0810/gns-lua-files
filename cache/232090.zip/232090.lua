-- 232090's Lua and Manifest Created by Hubcap Manifest
-- Killing Floor 2
-- Created: September 29, 2025 at 20:44:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 11
-- Total DLCs: 16
-- Shared Depots: 7

-- MAIN APPLICATION
addappid(232090, 1, "d50a5c27ad4f493a022571ee34c65609d373b8344825dbe065bff22e893e06e8") -- Killing Floor 2
-- MAIN APP DEPOTS
addappid(232091, 1, "f46359be90614cd82464602ee51bc2122dc359d6a493844be3a2edfd2a733be7") -- Harmonica Content
setManifestid(232091, "3780140359303487885", 101783993695)
addappid(232094, 1, "ff56a2e376c3a8baddd72e9f22d3c896728aa0846076d76806d96e56e7ff3bec") -- Killing Floor 2 Beta Wallpaper
setManifestid(232094, "1845006560688334540", 2717371)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229000, 1, "3aae9271fb93da5395ffbfe338d3647de5dcfab3fc6fb901ca2ec28849b3d6bf") -- .NET 3.5 Redist (Shared from App 228980)
setManifestid(229000, "4622705914179893434", 242743889)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3") -- PhysX System Software 9.14.0702 (Shared from App 228980)
setManifestid(229033, "2059065101492814639", 60039803)
-- DLCS WITH DEDICATED DEPOTS
-- KF2 - Soundtrack (AppID: 360930)
addappid(360930)
addappid(232092, 1, "4e45d5cae89bca85c7df390c27343ee8c743dd49404f6bb848c900a1a1ef7dcc") -- KF2 - Soundtrack - Killing Floor 2 Soundtrack
setManifestid(232092, "5954956292867565444", 875965681)
-- KF2 - Artbook (AppID: 360931)
addappid(360931)
addappid(232093, 1, "15e06cd0dba1b90a3daedffd14e329e4134ec76f3ba808f6f44dc11b32835c0a") -- KF2 - Artbook - Killing Floor 2 Artbook
setManifestid(232093, "2216080875481941448", 54160245)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(294850) -- KF2 - Mr Foster Dosh Jacket
addappid(354020) -- KF2 - Digital Deluxe Edition DLC
addappid(361240) -- KF2 - Full Game
addappid(408560) -- KF2 - Alienware DLC
addappid(1368501) -- KF Franchise Humble Bundle Tier 2
addappid(1368502) -- KF Franchise Humble Bundle Tier 3
addappid(1368503) -- KF Franchise Humble Bundle Mid Promo
addappid(1524820) -- KF2 - Season Pass 2021
addappid(1914490) -- KF2 - Season Pass 2022
addappid(1914560) -- KF2 - Ultimate Edition Upgrade DLC
addappid(1937240) -- KF2 Bundle 2022 Tier 3
addtoken(1937240, "15231710637902033995")
addappid(1937241) -- KF2 Bundle 2022 Tier 4
addappid(1993760) -- KF2 - Ultimate Edition Upgrade Bundle DLC
addappid(2363410) -- Killing Floor 2 - Cosmetics Season Pass