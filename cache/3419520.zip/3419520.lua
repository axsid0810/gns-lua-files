-- 3419520's Lua and Manifest Created by Hubcap Manifest
-- Quarantine Zone: The Last Check
-- Created: July 23, 2026 at 14:10:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 6
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3419520, 1, "9e084611ffbd6bd1c569aa8dcabdc825ca4c326880e19064b50ed1c6a244db7b") -- Quarantine Zone: The Last Check
-- MAIN APP DEPOTS
addappid(3419521, 1, "7763e89ed36372394d459530e45e7dab3aca85588166e1c59d3bd1f7993bfac6") -- Depot 3419521
setManifestid(3419521, "5606625684550222443", 13415592999)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3960620) -- Quarantine Zone Twitch Drop - Rat Skin - Raccoon
addappid(3960630) -- Quarantine Zone Twitch Drop - Military Skin
addappid(3960640) -- Quarantine Zone Twitch Drop - Scanner Skin
addappid(3960650) -- Quarantine Zone Twitch Drop - Hammer Skin
addappid(3960660) -- Quarantine Zone Twitch Drop - Thermopulse
addappid(4312380) -- Quarantine Zone The Last Check Supporter Pack