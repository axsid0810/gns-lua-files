-- 1118520's Lua and Manifest Created by Hubcap Manifest
-- Paralives
-- Created: July 17, 2026 at 14:58:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1118520, 1, "e52365d9e88efee525a3978c4991cad62a7f1bf6a53054dc6b38df387bc8dece") -- Paralives
-- MAIN APP DEPOTS
addappid(1118521, 1, "20543823281f3ef968fcd728fafb6786a33991bb918fbce88cd0a5c7fa49eb5a") -- Depot 1118521
setManifestid(1118521, "5797116023292045383", 8355345107)
addappid(1118522, 1, "e4e1d8088155be0d69686a0d236bb8693beede9db841019973b75aa8c8677ecd") -- Depot 1118522
setManifestid(1118522, "5966907182055833863", 8378580428)