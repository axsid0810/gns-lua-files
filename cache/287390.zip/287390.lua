-- 287390's Lua and Manifest Created by Hubcap Manifest
-- Metro: Last Light Redux
-- Created: September 30, 2025 at 00:34:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(287390) -- Metro: Last Light Redux
-- MAIN APP DEPOTS
addappid(287391, 1, "b83248490dbb4df7788d5976584e6829597922e10fb4a9ab537e4da04c52b61b") -- Project Redux Two Content
setManifestid(287391, "5751786806703515364", 9855985703)
addappid(287392, 1, "b31b8b47d359f387ffb0f435de1b127ab2a3dfcfd16304b1d18efff394f3c7f5") -- Project Redux Two Binaries
setManifestid(287392, "2801661353323416159", 57370606)
addappid(287393, 1, "fa5c1730f37f191734c73125f261a1f4d6055af0c97b73aad96a19d5f6d33beb") -- Metro: Last Light Redux Linux
setManifestid(287393, "5149438900906501530", 9904073554)
addappid(287394, 1, "1c30d69b4f3d6c0c219d09fd9c9cdce42c3802d44cd76490d2be50dab0e45c9c") -- Metro: Last Light Redux Mac
setManifestid(287394, "5510399873816608986", 9903116699)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229032, 1, "15b3308d4e95d1156182211bab1c823b6df0a06fd74a5c0833abed89bc307cfb") -- PhysX System Software 9.13.1220 (Shared from App 228980)
setManifestid(229032, "3616495131483866412", 41178235)