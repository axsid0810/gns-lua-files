-- 2229850's Lua and Manifest Created by Hubcap Manifest
-- Command & Conquer: Red Alert™ 2 and Yuri’s Revenge™
-- Created: September 29, 2025 at 04:52:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2229850, 1, "c77d357feaf80aeffec05b1e927bb30c6fd94bf15a98088112db8416e70d13ee") -- Command & Conquer: Red Alert™ 2 and Yuri’s Revenge™
-- MAIN APP DEPOTS
addappid(2229851, 1, "2cb1c174f12c44bec71bc796c767aef1b47a5a476b79292a7bb41af3b03cd511") -- Depot 2229851
setManifestid(2229851, "4928885831751969588", 1961731509)
addappid(2229852, 1, "ba66f3a0933b3cfd878d8340e59dbaec8359a68b0a525207879f5fe6161a5340") -- Depot 2229852
setManifestid(2229852, "2191822715159570153", 1197118950)
addappid(2229853, 1, "2b1ab0ac6f851ca3821881bcf715dd376c8625dc5514c6f0f7b1abd3cd3a7eef") -- Depot 2229853
setManifestid(2229853, "651095031539856178", 1212260812)
addappid(2229854, 1, "961ba56200f2d06dc6abaf473928366f54ed4aaf2ed7abf48d93c19a2857d6af") -- Depot 2229854
setManifestid(2229854, "2407982433826224240", 1230326497)
addappid(2229855, 1, "96abb4a7dc16cf7f80ab5df7f89cfa8f5e3fab2255b77e6f54b55236fde7e125") -- Depot 2229855
setManifestid(2229855, "126987739780522527", 1196864436)
addappid(2229856, 1, "e9d8e9953162e17f2a7f6e780c6cfaa05f80099046b39782568763dac32543c1") -- Depot 2229856
setManifestid(2229856, "6637089396038252853", 1212619172)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)