-- 33910's Lua and Manifest Created by Hubcap Manifest
-- Arma 2
-- Created: September 28, 2025 at 23:02:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(33910) -- Arma 2
-- MAIN APP DEPOTS
addappid(33911, 1, "b4bae85e5006274c8aeb976c8613caa3a06e304eef6e945533b1f266aee8b0dd") -- arma 2 row exe
setManifestid(33911, "665065183021719977", 11566584)
addappid(33912, 1, "070c4b56d793fb31c18730b3f3c226a1de3870bdb2306b7c8af21df0ca0dbd43") -- Arma 2 Beta Depot
setManifestid(33912, "4865777636804643330", 8923874699)
-- SHARED DEPOTS (from other apps)
addappid(33901, 1, "c07cec672c1aa48a1493532ec6a9e04a5f351ce1d1445f8eb98ba8c93ff5fa27") -- arma 2 content (Shared from App 33900)
setManifestid(33901, "357000457446013132", 8939751577)