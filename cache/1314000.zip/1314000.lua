-- 1314000's Lua and Manifest Created by Hubcap Manifest
-- Achilles: Legends Untold
-- Created: July 11, 2026 at 00:38:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 2
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1314000, 1, "f1c6e9ebc92f72638f9c6d696257788fd41830cfbb9d8495f62ff2c940ad961c") -- Achilles: Legends Untold
-- MAIN APP DEPOTS
addappid(1314001, 1, "f8ea6ebbef185079adc617c41c6c867f04dcd43446d42aed3ca43a18a39ef4f8") -- Depot 1314001
setManifestid(1314001, "5211930544520819651", 19456987948)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITH DEDICATED DEPOTS
-- Achilles Legends Untold - 3D Print Achilles Model (AppID: 2445710)
addappid(2445710)
addappid(2445710, 1, "db02dd0af8eaee425e4a0e14ef9e5c37fb529fd028cfbbfaaab96401e50020c0") -- Achilles Legends Untold - 3D Print Achilles Model - Depot 2445710
setManifestid(2445710, "1222008679826958043", 1934632479)
-- Achilles Legends Untold - Mythic Hero 3D Figurine 2.0 Achilles Edition (AppID: 2705610)
addappid(2705610)
addappid(2705610, 1, "8e4168ed36e387b02f0eebb736f984892f7613b9283f77eb15efd68055049456") -- Achilles Legends Untold - Mythic Hero 3D Figurine 2.0 Achilles Edition - Depot 2705610
setManifestid(2705610, "3732485595865581976", 1187916795)