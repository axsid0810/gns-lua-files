-- 3935020's Lua and Manifest Created by Hubcap Manifest
-- Backyard Baseball
-- Created: July 24, 2026 at 13:03:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3935020) -- Backyard Baseball
-- MAIN APP DEPOTS
addappid(3935021, 1, "0408029333b8fb91116eedd0fcdfc3aaca556fd8695ded07acfd5d99c2dace89") -- Depot 3935021
setManifestid(3935021, "1836929868571341993", 12587333142)
addappid(3935022, 1, "e2d083324d8b66c7ee9b4bed9bcd9d546c24f0fcf0c5be75e1e11af6328e9524") -- Depot 3935022
setManifestid(3935022, "859729787483975314", 12680850136)