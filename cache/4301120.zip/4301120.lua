-- 4301120's Lua and Manifest Created by Hubcap Manifest
-- Camp Hollow
-- Created: July 21, 2026 at 04:49:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(4301120) -- Camp Hollow
-- MAIN APP DEPOTS
addappid(4301121, 1, "ab9a964aa42a54cfd17764b6c83c3641b56e1440c5c54a0fe2f551b9633ff5d6") -- Depot 4301121
setManifestid(4301121, "2196901153981201551", 1946533924)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)