-- 4112070's Lua and Manifest Created by Hubcap Manifest
-- An Eggstremely Hard Game
-- Created: July 25, 2026 at 15:03:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4112070) -- An Eggstremely Hard Game
-- MAIN APP DEPOTS
addappid(4112071, 1, "7c49838e7979b3923471af9ab2dd836f6d564e0afa86af388dfabdb2d411db5d") -- Depot 4112071
setManifestid(4112071, "932100824409871492", 631288829)