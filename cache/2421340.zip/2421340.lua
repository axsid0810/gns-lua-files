-- 2421340's Lua and Manifest Created by Hubcap Manifest
-- 不倫婚姻審判官
-- Created: July 21, 2026 at 13:38:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2421340) -- 不倫婚姻審判官
-- MAIN APP DEPOTS
addappid(2421341, 1, "e5ec407b5b6857bfdaedc00107fa636c88ae84f3d4745e7f39dc34ba1e943a00") -- Depot 2421341
setManifestid(2421341, "173502785099525060", 2391254903)
addappid(2421342, 1, "ada118a5745579078e08c953b9c3b9ad670b34eb9115a0040160a040b074c73c") -- Depot 2421342
setManifestid(2421342, "5824513969601833216", 1030824365)