-- 1105510's Lua and Manifest Created by Hubcap Manifest
-- Yakuza 5 Remastered
-- Created: October 01, 2025 at 08:40:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1105510) -- Yakuza 5 Remastered
-- MAIN APP DEPOTS
addappid(1105511, 1, "0c335e9d30387b322b2822752aa8827d47a59d2bad54a144ce93dbc1e3377ae9") -- RINO 5 Content
setManifestid(1105511, "5169313411801023997", 33631404241)
addappid(1105512, 1, "dfb8b0ac80dab6c0375b39f503efa542922000358f6ffd84978656d0859cfeae") -- RINO 5 Binary
setManifestid(1105512, "6566473845791138832", 32626992)