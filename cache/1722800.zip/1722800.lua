-- 1722800's Lua and Manifest Created by Hubcap Manifest
-- Colossus - Eternal Blight
-- Created: July 29, 2026 at 11:57:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1722800) -- Colossus - Eternal Blight
-- MAIN APP DEPOTS
addappid(1722802, 1, "78ef76ad29bc9ce9839dbbe0e4ea8218829503b1dd07379f39aa189843f2f2cf") -- Depot 1722802
setManifestid(1722802, "5953974014761817482", 755818939)