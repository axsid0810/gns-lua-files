-- 2157680's Lua and Manifest Created by Hubcap Manifest
-- Lunar Mirror:The Pavilion of Desire
-- Created: September 29, 2025 at 23:03:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2157680) -- Lunar Mirror:The Pavilion of Desire
-- MAIN APP DEPOTS
addappid(2157681, 1, "73dcd3d4b21d5b46b3ccc85cd339659397f865b345c64717424a2ee33856c0d7") -- Depot 2157681
setManifestid(2157681, "6058912897030029653", 1341555751)
-- DLCS WITH DEDICATED DEPOTS
-- Lunar MirrorThe Pavilion of Desire-Patch (AppID: 2192630)
addappid(2192630)
addappid(2192630, 1, "1614b072f33a76e43a3c57f8a625c7062d98de4734856ac98c10ac64e03f932f") -- Lunar MirrorThe Pavilion of Desire-Patch - Depot 2192630
setManifestid(2192630, "371457083531553023", 624804772)