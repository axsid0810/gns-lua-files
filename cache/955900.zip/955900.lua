-- 955900's Lua and Manifest Created by Hubcap Manifest
-- Amazing Cultivation Simulator
-- Created: September 28, 2025 at 22:13:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(955900, 1, "5424a9ed4a4e466dae7151acf58d8bf0b60a8aa54a3289af037b1e56d36be716") -- Amazing Cultivation Simulator
-- MAIN APP DEPOTS
addappid(955901, 1, "7a3f5a92b6422af44c29c94bc4d54cb778ee157e58873e3e7b4e3fd4f25d3956") -- 了不起的修仙模拟器 Content
setManifestid(955901, "1652931289589496880", 2144960727)
addappid(955902, 1, "41dddf3f2fdc9cf3c5f99e7b96ca775a8ecb996de611c526fb3e6223a9aa6944") -- 了不起的修仙模拟器 个 Depot
setManifestid(955902, "7378292070912114805", 2129834351)
-- DLCS WITH DEDICATED DEPOTS
-- Amazing Cultivation Simulator - Deep in the bamboo Forest (AppID: 1446730)
addappid(1446730)
addappid(1446730, 1, "df4bff2f0d54a794ba24b7faa60d334cc2abaf20d7ea625138d15a1bc6ac439d") -- Amazing Cultivation Simulator - Deep in the bamboo Forest - 了不起的修仙模拟器 - 竹林深处 (1446730) 个 Depot
setManifestid(1446730, "8455975255050325821", 378297)
-- Amazing Cultivation Simulator - Immortal Tales of Wudang (AppID: 1701600)
addappid(1701600)
addappid(1701600, 1, "d358bbd50b412fd6ccd9a211041aaf9f0b8927f65d503c2026576162a2140dcc") -- Amazing Cultivation Simulator - Immortal Tales of Wudang - Amazing Cultivation Simulator - Immortal Tales of WuDang (1701600) 个 Depot
setManifestid(1701600, "6746209964332676910", 278595)