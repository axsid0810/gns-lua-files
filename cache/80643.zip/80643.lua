-- 80643's Lua and Manifest Created by Hubcap Manifest
-- Assassins Creed Brotherhood - Story
-- Created: February 19, 2026 at 16:39:11 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(80643) -- Assassins Creed Brotherhood - Story
-- MAIN APP DEPOTS
addappid(910, 1, "168405455442eaf4e8e75a13b5914f35d7be54b0cdc4220ea1dc464f79711248") -- Media Player
setManifestid(910, "1332084816209327708", 266240)