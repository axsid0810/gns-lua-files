-- 9710's Lua and Manifest Created by Hubcap Manifest
-- Desperados 2: Cooper’s Revenge
-- Created: September 29, 2025 at 07:28:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(9710) -- Desperados 2: Cooper’s Revenge
-- MAIN APP DEPOTS
addappid(9713, 1, "e03d25ed1e63897160d3079c4abd11a67cacee7453cd3de04d10aa7d02ca68eb") -- Desperados 2 content 3
setManifestid(9713, "2234746951781510724", 1509405012)
addappid(9712, 1, "e02870049664114b7fec6ba200d0f3126b34a4d0396be7165cd486992e976844") -- Desperados 2 content 2
setManifestid(9712, "2155014127795534570", 451049929)
addappid(9711, 1, "cf33296d20f606f292ceac718aa7e5a61b9bcc0b3075eae16270339f96c9b6fd") -- Desperados 2 content
setManifestid(9711, "3412477053663209491", 1651341196)