-- 519490's Lua and Manifest Created by Hubcap Manifest
-- NBA 2KVR Experience
-- Created: September 30, 2025 at 03:01:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(519490) -- NBA 2KVR Experience
-- MAIN APP DEPOTS
addappid(519491, 1, "f7380b705efbea4ce72d201aa905cb3153d3cd9ae4ada92109b45d02dc8bd780") -- NBA AppID Content
setManifestid(519491, "2144235094911888737", 2014486213)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)