-- 3767850's Lua and Manifest Created by Hubcap Manifest
-- SpiritVale
-- Created: July 20, 2026 at 20:29:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3767850) -- SpiritVale
-- MAIN APP DEPOTS
addappid(3767852, 1, "d459074fd9a4f3a208f174e2e96927ae137a2d145da02f3a4502c09b484829c1") -- Depot 3767852
setManifestid(3767852, "8558363878793951866", 7527729389)