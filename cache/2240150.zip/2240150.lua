-- 2240150's Lua and Manifest Created by Hubcap Manifest
-- Summer's Gone - Season 1
-- Created: September 30, 2025 at 20:47:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(2240150) -- Summer's Gone - Season 1
-- MAIN APP DEPOTS
addappid(2240156, 1, "38f3f5def72b7c4fb2d2576d0fc5defe68bb7a42b24709762df57f7dc1eca08c") -- Depot 2240156
setManifestid(2240156, "2755634768372092709", 9933481115)
-- DLCS WITH DEDICATED DEPOTS
-- Summers Gone - Season 1 TreatsWallpapers (AppID: 2961150)
addappid(2961150)
addappid(2961150, 1, "a3fb2af3228a08142e19202d5f1a170e379d80f949f93d2028cfffcf0b795dbd") -- Summers Gone - Season 1 TreatsWallpapers - Depot 2961150
setManifestid(2961150, "6995672705435133638", 393273259)
-- Summers Gone - The Book Club - Wallpapers (AppID: 2975570)
addappid(2975570)
addappid(2975570, 1, "f153dcc1363143ca690b24d1c6b0e9518ad56f5e33a6b49fabc93a99108f4c4b") -- Summers Gone - The Book Club - Wallpapers - Depot 2975570
setManifestid(2975570, "5209111543196110760", 262148809)