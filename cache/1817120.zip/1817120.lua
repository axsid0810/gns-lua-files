-- 1817120's Lua and Manifest Created by Hubcap Manifest
-- Combat Troops VR
-- Created: October 02, 2025 at 00:28:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1817120) -- Combat Troops VR
-- MAIN APP DEPOTS
addappid(1817121, 1, "14175d23fb5038c691e05ced71725059587243125c2acf353728a9f0a2ac8463") -- Depot 1817121
setManifestid(1817121, "677775316170685327", 37224274405)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)