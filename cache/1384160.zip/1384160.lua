-- 1384160's Lua and Manifest Created by Hubcap Manifest
-- GUILTY GEAR -STRIVE-
-- Created: July 02, 2026 at 05:54:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 42
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1384160, 1, "4021c3f3cfb8f9988d57a209da688cab4371c55ff00d68981a69363aec1f8afc") -- GUILTY GEAR -STRIVE-
-- MAIN APP DEPOTS
addappid(1384161, 1, "6a00a68034e78cffd8a0e7bb055e336446bf6b732c3605b5c96b73cffa5b3ecd") -- GGST Content
setManifestid(1384161, "1280605393815460385", 31961421092)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Guilty Gear -Strive- Ultimate Edition Content Kit DLC (AppID: 1652891)
addappid(1652891)
addappid(1652891, 1, "927ff307380ff6d4ccf5e19cb9434dae2ce3aaa43296e650580564a68245684d") -- Guilty Gear -Strive- Ultimate Edition Content Kit DLC - Depot 1652891
setManifestid(1652891, "7995703727095321935", 2413782153)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1544400) -- GGST Early Purchase Bonus (Up to Jun 25th 2021 only)
addtoken(1544400, "2043393504352978338")
addappid(1544401) -- GGST Additional Character 1 - Goldlewis Dickinson
addappid(1544402) -- GGST Additional Character 2 - Jack-O
addappid(1544403) -- GGST Additional Character 3 - Happy Chaos
addappid(1544404) -- GGST Additional Character 4 - Baiken
addappid(1544405) -- GGST Additional Character 5 - Testament
addappid(1544406) -- Guilty Gear -Strive- Additional Colors 1 DLC
addappid(1544407) -- GGST Additional Battle Stage 1 - Lap of the Kami
addappid(1544408) -- GGST Additional Battle Stage 2 - White House Reborn
addappid(1649880) -- Guilty Gear -Strive- Season Pass 1
addappid(1652890) -- Guilty Gear -Strive- Season Pass 2
addappid(1652892) -- Guilty Gear -Strive- Season Pass 3
addappid(2081050) -- GGST Additional Character 6 - Bridget
addappid(2081051) -- GGST Additional Character 7 - Sin Kiske
addappid(2081052) -- GGST Additional Character 8 - Bedman
addappid(2081053) -- GGST Additional Character 9 - Asuka
addappid(2081054) -- Guilty Gear -Strive- Additional Colors 2 DLC
addappid(2081055) -- GGST Additional Battle Stage 3 - Fairys Forest Factory
addappid(2081056) -- GGST Additional Battle Stage 4 - Tr na ng
addappid(2410760) -- GGST Guilty Gear 25th Anniversary Appreciation Color
addappid(2410761) -- GGST Guilty Gear 25th Anniversary Colors
addappid(2524030) -- GGST Additional Character 10 - Johnny
addappid(2524040) -- GGST Additional Character 11 - Elphelt Valentine
addappid(2524050) -- GGST Additional Character 12 - A.B.A
addappid(2524060) -- GGST Additional Character 13 - Slayer
addappid(2524070) -- GGST Additional Character 14 - Queen Dizzy
addappid(2524080) -- GGST Additional Character 15 - Venom
addappid(2524090) -- GGST Additional Battle Stage 5 - Fallen Prayer, Engulfed Lives
addappid(2524100) -- GGST Additional Battle Stage 6 - Amber Fest with Kind Neighbors
addappid(2524110) -- GGST Season 3 Characters Additional Colors
addappid(2524120) -- GGST Season 4 Characters Additional Colors
addappid(3001230) -- GGST Additional Character 16 - Unika
addappid(3001240) -- GGST Additional Character 17 - Lucy
addappid(3001250) -- GGST Additional Character 18 - Jam Kuradoberi
addappid(3001260) -- GGST Additional Battle Stage 7 - In the Name of Peace
addappid(3001270) -- GGST Additional Battle Stage 8 - New Dawn, A Future Unfolding
addappid(3060720) -- Guilty Gear -Strive- Season Pass 4
addappid(4413140) -- GGST Additional Character 19 - Robo-Ky
addappid(4413190) -- Guilty Gear -Strive- Season Pass 5
addappid(4580410) -- GGST Blazing Pass Plus Duel 1 Reignite
addappid(4758340) -- GGST Blazing Pass Plus - Duel 2 Ennui Protocol