-- 1874880's Lua and Manifest Created by Hubcap Manifest
-- Arma Reforger
-- Created: June 24, 2026 at 12:06:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 1 (1 excluded)
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1874880, 1, "b52c7bfff7cf6936c36fdd97b188bc70fe248c77f487c595951876b49d5f33d0") -- Arma Reforger
-- MAIN APP DEPOTS
addappid(1874881, 1, "f1bc308d3a58a8d144a76dc02d552819b433bda49c325060fcab53e8100cead3") -- Depot 1874881
setManifestid(1874881, "8544567844636812494", 27395095449)
addappid(1874882, 1, "c964efe3e6ee7295beeb474f46e6c78d1f2f62097dc3c793b1474cfab9f2f055") -- Depot 1874882
setManifestid(1874882, "1650233779375073015", 233489401)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Refrogger Supporter Pack (AppID: 3923950)
addappid(3923950)
addappid(3923952, 1, "a958403d909fa984ff77e097be93096f01942ed66f2dcd3793e85c7d15ef6fcb") -- Refrogger Supporter Pack - Depot 3923952
setManifestid(3923952, "77953387113932170", 4186273290)
addappid(3923951, 1, "6093cb5032a8d98863652c35177f7653c823c16613b35ac3d61f6814d00e5e89") -- Refrogger Supporter Pack - Depot 3923951
setManifestid(3923951, "690578477946807091", 83667822)
addappid(3923953, 1, "5a8fc21ce8d7116717039f57ee9e017f244fb52890ee401b55a8110a535452ab") -- Refrogger Supporter Pack - Depot 3923953
setManifestid(3923953, "3992893852227475416", 107869973)
addappid(3923954, 1, "7143a76a793670739b7ce21d832695bd14a5b48f4c98a888de32bf6328643bb5") -- Refrogger Supporter Pack - Depot 3923954
setManifestid(3923954, "7616342300144661544", 60283617)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Modder Supporter Pack (AppID: 4631450) - missing depot keys
-- addappid(4631450)