-- 1815780's Lua and Manifest Created by Hubcap Manifest
-- Asphalt Legends 
-- Created: July 21, 2026 at 10:00:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 3
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1815780, 1, "f1c3e8bb4e041dac475812b84aed835b9f7bdb135f8522a1dc947db417ebd74f") -- Asphalt Legends 
-- MAIN APP DEPOTS
addappid(1815781, 1, "5bcde2a5b270cc5f3a1a571b16fba5c90347280e05940c8ac301a5a38df2a451") -- Depot 1815781
setManifestid(1815781, "3173063175721151574", 10307158376)
addappid(1815783, 1, "6dfefc3ab40f2cd060163b974417bee18cbee8cb1ad5c7cb9e8a10e4a4a71878") -- Depot 1815783
setManifestid(1815783, "1218362812621837947", 9190623849)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3673190) -- ALU_DLC_01
addappid(3831570) -- ALU_DLC_02
addappid(4241640) -- Asphalt Legends - Single-Player Boost Pack
-- FORCE-ADDED DLCS (BYPASSES ALL VALIDATION)
addappid(4241640) -- Asphalt Legends - Single-Player Boost Pack
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1815782) -- Depot 1815782 (empty depot)
-- addappid(3673190) -- Depot 3673190 (empty depot)
-- addappid(3831570) -- Depot 3831570 (empty depot)
-- addappid(4241640) -- Depot 4241640 (empty depot)