-- 332310's Lua and Manifest Created by Hubcap Manifest
-- LEGO® Worlds
-- Created: September 29, 2025 at 21:53:53 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 6
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(332310) -- LEGO® Worlds
-- MAIN APP DEPOTS
addappid(332311, 1, "2a2e9283226d9f8629506901f7bc620ff108770740f463eb9a5c16c44dab0ed6") -- LEGO® Worlds
setManifestid(332311, "8591390432503644646", 3617758723)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- LEGO Worlds - Soundtrack (AppID: 551850)
addappid(551850)
addappid(551850, 1, "7c4c225d2602c9a2718f39c0dd3c8d0486c59092d822ecf6a5ad8be55c8052f8") -- LEGO Worlds - Soundtrack - LEGO® Worlds - Soundtrack (551850) Depot
setManifestid(551850, "7026537084708848281", 194038438)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(590410) -- LEGO Worlds - Early Access Reward
addappid(641000) -- LEGO Worlds Classic Space Pack
addappid(720960) -- LEGO Worlds Monster Pack
addappid(816880) -- LEGO Worlds Showcase Collection Pack One
addappid(1046500) -- LEGO Worlds Showcase Collection Pack 2