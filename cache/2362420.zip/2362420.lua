-- 2362420's Lua and Manifest Created by Hubcap Manifest
-- Mass Effect 2 (2010) Edition
-- Created: July 24, 2026 at 06:24:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 13
-- Total DLCs: 26
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(2362420, 1, "8d87b7ccb1c84e6a04fa8ea1d181f7eb5cf1e22ad690b039620ab4f2fdcfcd60") -- Mass Effect 2 (2010) Edition
-- MAIN APP DEPOTS
addappid(2362421, 1, "6acb38025a65260ecc29ee65d57edc160788f39ba85ae9dcd38f849f090a851d") -- Depot 2362421
setManifestid(2362421, "4560419044933123957", 19567491945)
addappid(2362422, 1, "e559e7888896f1efd0d3d8443b6849826aa6ed15d55a269862df486de5de08b3") -- Depot 2362422
setManifestid(2362422, "3136357254128328956", 1776250)
addappid(2362423, 1, "bd9452d538ffd929f88f960d56b5ad445a87304b7cd76b5832367e7f69419972") -- Depot 2362423
setManifestid(2362423, "3527259002518869105", 2523850377)
addappid(2362424, 1, "400372fb079f178b4993fc26789a961bed053c82b2e9394b68f0e47ad04d6d5f") -- Depot 2362424
setManifestid(2362424, "1370062332830505835", 2443697693)
addappid(2362425, 1, "6df7a14d7d9d1b081d96b417c3a2ae272f8ca04d2d0e6ebbd5c84890fead0bb1") -- Depot 2362425
setManifestid(2362425, "7218643441554702545", 2536807800)
addappid(2362426, 1, "1725a6bcd345e6fc6e7086704fc619beb50401c18756f02588389610acebfc3d") -- Depot 2362426
setManifestid(2362426, "7519270999258911593", 33699097)
addappid(2362427, 1, "8fe28013b5ce1ccd3d7b4035e879216ee3766c9c589766dc1fb0823e6eb6d8a9") -- Depot 2362427
setManifestid(2362427, "8722167186703874235", 34078008)
addappid(2362428, 1, "9d106f063bd34fd7e97894a49eb3bca0e6a73cfd3c61e772a4f2d91f0703538e") -- Depot 2362428
setManifestid(2362428, "2698552165227600163", 2495886163)
addappid(2362429, 1, "72ff8581bb870af9130c09cc240b7d7f03ac8686f64d949990ad1b699a7713c5") -- Depot 2362429
setManifestid(2362429, "6925610625506859871", 18057846)
addappid(2362431, 1, "edcdc8f1d132cac005c581e298c97edb1a2d9e52e4231d50dfdd6447ea284075") -- Depot 2362431
setManifestid(2362431, "1421994893589409185", 18056903)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
setManifestid(3340991, "6717304605949129056", 240979991)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2362430) -- Mass Effect 2 - (2010) Edition Key
addappid(2368020) -- Mass Effect 2 DLC Bundle
addappid(2368021) -- Mass Effect 2 DLC - Zaeed The Price of Revenge
addappid(2368022) -- Mass Effect 2 DLC - Arc Projector
addappid(2368023) -- Mass Effect 2 DLC - Blood Dragon Armor
addappid(2368024) -- Mass Effect 2 DLC - Firewalker Pack
addappid(2368025) -- Mass Effect 2 DLC - Alternate Appearance Pack 1
addappid(2368026) -- Mass Effect 2 DLC - Alternate Appearance Pack 2
addappid(2368027) -- Mass Effect 2 DLC - Inferno Armor
addappid(2368028) -- Mass Effect 2 DLC - Recon Hood
addappid(2368029) -- Mass Effect 2 DLC - Firepower Pack
addappid(2368040) -- Mass Effect 2 DLC - Equalizer Pack
addappid(2368041) -- Mass Effect 2 DLC - Genesis Interactive Comic
addappid(2368042) -- Mass Effect 2 DLC - Normandy Crash Site
addappid(2368043) -- Mass Effect 2 DLC - M-29 Incisor
addappid(2368044) -- Mass Effect 2 DLC - Cerberus Weapon and Armor
addappid(2368045) -- Mass Effect 2 DLC - Sentry Interface
addappid(2368046) -- Mass Effect 2 DLC - Terminus Weapon and Armor
addappid(2368047) -- Mass Effect 2 DLC - Cerberus Network
addappid(2368048) -- Mass Effect 2 DLC - Collectors Weapon and Armor
addappid(2368049) -- Mass Effect 2 DLC - Aegis Pack
addappid(2368050) -- Mass Effect 2 DLC - Arrival
addappid(2368051) -- Mass Effect 2 DLC - Lair of the Shadow Broker
addappid(2368052) -- Mass Effect 2 DLC - Umbra Visor
addappid(2368053) -- Mass Effect 2 DLC - Overlord
addappid(2368054) -- Mass Effect 2 DLC - Kasumi Stolen Memory