-- 2138610's Lua and Manifest Created by Hubcap Manifest
-- The Legend of Heroes: Trails through Daybreak
-- Created: October 19, 2025 at 08:40:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 11
-- Total DLCs: 9
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2138610) -- The Legend of Heroes: Trails through Daybreak
-- MAIN APP DEPOTS
addappid(2138611, 1, "e8a0e3b7330b50a57cc4173f91e1df4c6b8f2ad4c082b2f42c4370d7b5abf995") -- Depot 2138611
setManifestid(2138611, "240241087203124025", 16967722686)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- The Legend of Heroes Trails through Daybreak - Bonus Set (AppID: 2259910)
addappid(2259910)
addappid(2259910, 1, "fcb461254530e820c5d5babd7a9a6635c1a1a12f19e075c417062a73904c5878") -- The Legend of Heroes Trails through Daybreak - Bonus Set - Depot 2259910
setManifestid(2259910, "4610249162430550201", 52)
-- The Legend of Heroes Trails through Daybreak - Costume Set (AppID: 2259911)
addappid(2259911)
addappid(2259911, 1, "ab31d8785a0caee367ed34a49eb91c85d8803fd68f20722a050e9b75de6ee8bd") -- The Legend of Heroes Trails through Daybreak - Costume Set - Depot 2259911
setManifestid(2259911, "8344392307170184939", 36)
-- The Legend of Heroes Trails through Daybreak - Accessories Set (AppID: 2259912)
addappid(2259912)
addappid(2259912, 1, "57600ca5921fc66a24a7d091ac2a93b2b287559073768d09ca8862bc3d669f56") -- The Legend of Heroes Trails through Daybreak - Accessories Set - Depot 2259912
setManifestid(2259912, "2331933228898816086", 52)
-- The Legend of Heroes Trails through Daybreak - Voice Set (AppID: 2259913)
addappid(2259913)
addappid(2259913, 1, "1bddeafb42268c351cde1557f03476c70ea6337801be50f5a5995b4e62b8c2f3") -- The Legend of Heroes Trails through Daybreak - Voice Set - Depot 2259913
setManifestid(2259913, "2202590727995782603", 12)
-- The Legend of Heroes Trails through Daybreak - Starter Consumable Set (AppID: 2259914)
addappid(2259914)
addappid(2259914, 1, "1b4d96d7e782c3ac06fbd9571f12547a8da6132004eab3c2f251e591de96edd6") -- The Legend of Heroes Trails through Daybreak - Starter Consumable Set - Depot 2259914
setManifestid(2259914, "7835925582341421216", 40)
-- The Legend of Heroes Trails through Daybreak - Advanced Consumable Set (AppID: 2259915)
addappid(2259915)
addappid(2259915, 1, "6a7fae92b324d27011a874fbaeab22f0c049ca62ac1e093b04b0fc1cabd95fb2") -- The Legend of Heroes Trails through Daybreak - Advanced Consumable Set - Depot 2259915
setManifestid(2259915, "4347739267177522555", 104)
-- The Legend of Heroes Trails through Daybreak - Free Sample Set (AppID: 2259916)
addappid(2259916)
addappid(2259916, 1, "5e5c494537ac675c63958fa270e7b73423be6526e28f2b858e63d5d782617ea2") -- The Legend of Heroes Trails through Daybreak - Free Sample Set - Depot 2259916
setManifestid(2259916, "3998681734054012237", 12)
-- The Legend of Heroes Trails through Daybreak - Mini Art Book (AppID: 2949130)
addappid(2949130)
addappid(2949130, 1, "423ad5ace3e36a11013c089917a9d11686d9292873c0aeb82b95d63054bec661") -- The Legend of Heroes Trails through Daybreak - Mini Art Book - Depot 2949130
setManifestid(2949130, "8932441816386113046", 49545102)
-- The Legend of Heroes Trails through Daybreak - Art Book (AppID: 2949150)
addappid(2949150)
addappid(2949150, 1, "6c94dcbf4a507763b16d513d210dc654216eed6c469dbd3e9e3c9010e1b801f4") -- The Legend of Heroes Trails through Daybreak - Art Book - Depot 2949150
setManifestid(2949150, "7738527897783233617", 393666388)