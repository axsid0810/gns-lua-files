-- 1785650's Lua and Manifest Created by Hubcap Manifest
-- TopSpin 2K25
-- Created: October 01, 2025 at 02:24:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 12
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1785650) -- TopSpin 2K25
-- MAIN APP DEPOTS
addappid(1785651, 1, "378291ca5d9f448851858d96883fd163188369d47a68b51012798acd9dc5e5b1") -- Depot 1785651
setManifestid(1785651, "8602937547752847301", 31415035221)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2820460) -- TopSpin 2K25 Under the Lights Pack
addappid(2820470) -- TopSpin 2K25 - New Wave Pack
addappid(2820480) -- TopSpin 2K25 Grand Slam Champion Pack
addappid(2820490) -- TopSpin 2K25 Premium Centre Court Pass Season 1
addappid(2820500) -- TopSpin 2K25 Premium Centre Court Pass Season 2
addappid(2820510) -- TopSpin 2K25 Premium Centre Court Pass Season 3
addappid(2820520) -- TopSpin 2K25 Premium Centre Court Pass Season 4
addappid(2820530) -- TopSpin 2K25 Premium Centre Court Pass Season 5
addappid(2820540) -- TopSpin 2K25 Premium Centre Court Pass Season 6
addappid(2820550) -- TopSpin 2K25 All Access Cosmetic Pack
addappid(2820560) -- TopSpin 2K25 Ultimate Upgrade Pack
addappid(2820570) -- TopSpin 2K25 - All Access Pass