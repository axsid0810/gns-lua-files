-- 1339000's Lua and Manifest Created by Hubcap Manifest
-- Aquarium Designer
-- Created: September 28, 2025 at 22:49:58 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 2 (1 excluded)

-- MAIN APPLICATION
addappid(1339000) -- Aquarium Designer
-- MAIN APP DEPOTS
addappid(1339001, 1, "79f2b8b5fa266ea2f429988c0f994a678f215cf066802189f9db0809d341b285") -- Aquascaping Content
setManifestid(1339001, "7655070563839540333", 28118616668)
-- DLCS WITH DEDICATED DEPOTS
-- Aquarium Designer  Sea Life (AppID: 1939750)
addappid(1939750)
addappid(1939751, 1, "0ba8c5a592eb9ca6ad837915f34a6184268be788e3b52a4584afbcc65b7583d7") -- Aquarium Designer  Sea Life - Depot 1939751
setManifestid(1939751, "184710328273269296", 5131746130)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2433780) -- Aquarium Designer - Amazon River
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Aquarium Designer - Japan (AppID: 2295420) - missing depot keys
-- addappid(2295420)