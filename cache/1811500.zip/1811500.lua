-- 1811500's Lua and Manifest Created by Hubcap Manifest
-- LOOPERS
-- Created: September 29, 2025 at 22:34:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1811500) -- LOOPERS
-- MAIN APP DEPOTS
addappid(1811501, 1, "0d09ba15e0345b7f8c05ca7f8f82e9960ac0cfc62cd74e3206b266a998d38291") -- Depot 1811501
setManifestid(1811501, "2210634857629591315", 2738598212)