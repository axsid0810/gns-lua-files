-- 1466060's Lua and Manifest Created by Hubcap Manifest
-- Tainted Grail: The Fall of Avalon
-- Created: July 20, 2026 at 13:41:50 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 8 (1 excluded)

-- MAIN APPLICATION
addappid(1466060, 1, "f53acb7f143a62f46c302975a2d5cdb7d58fb41a5a7d9a0a03f722a39493e160") -- Tainted Grail: The Fall of Avalon
-- MAIN APP DEPOTS
addappid(1466062, 1, "b164844c9d1dcef4202a397a747eff0fc24b75b5553e21bebbd7e86042d94bca") -- Depot 1466062
setManifestid(1466062, "7923749585628793804", 42260507263)
-- DLCS WITH DEDICATED DEPOTS
-- Tainted Grail The Fall of Avalon - Supporters Pack (AppID: 3687050)
addappid(3687050)
addappid(3687050, 1, "8a5843ffcee408b2a16680531955ed57dd20d577be56ebb42d7c99dd653a3b2e") -- Tainted Grail The Fall of Avalon - Supporters Pack - Depot 3687050
setManifestid(3687050, "3877787421677591921", 818012192)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4132150) -- Tainted Grail The Fall of Avalon - Sanctuary of Sarras DLC
addappid(4183140) -- Tainted Grail The Fall of Avalon - Bonus Content 1
addappid(4492250) -- Tainted Grail The Fall of Avalon - Bonus Content 2
addappid(4514980) -- Tainted Grail The Fall of Avalon - Merlins Tomb DLC
addappid(4639800) -- Tainted Grail The Fall of Avalon - Challenge Mode DLC
addappid(4704460) -- Tainted Grail The Fall of Avalon - Bonus Content 3 Anniversary
addappid(4831420) -- Tainted Grail The Fall of Avalon - Bonus Content 4
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3681950) -- Tainted Grail: The Fall of Avalon - Horse Armor DLC (unreleased)