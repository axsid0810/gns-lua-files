-- 4339880's Lua and Manifest Created by Hubcap Manifest
-- Game Compressor
-- Created: July 10, 2026 at 13:55:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4339880) -- Game Compressor
-- MAIN APP DEPOTS
addappid(4339881, 1, "068f5329555cc9874fce0e22d2d0fc71ce32dcef1c4e45e83241a4856348e9bb") -- Depot 4339881
setManifestid(4339881, "6639089360093276134", 185287445)