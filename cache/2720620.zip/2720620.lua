-- 2720620's Lua and Manifest Created by Hubcap Manifest
-- One More Night
-- Created: July 23, 2026 at 20:46:23 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(2720620) -- One More Night
-- MAIN APP DEPOTS
addappid(2720621, 1, "3cdb35e089661a1ff0a427ca4f6e72b88a8461de151ccc96ce8079b5adaf4c3b") -- Depot 2720621
setManifestid(2720621, "3984770166677514895", 4887139509)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4528750) -- One More Night Into the Abyss