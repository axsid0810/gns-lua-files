-- 2183650's Lua and Manifest Created by Hubcap Manifest
-- MEGA MAN X DiVE Offline
-- Created: October 26, 2025 at 11:01:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2183650) -- MEGA MAN X DiVE Offline
-- MAIN APP DEPOTS
addappid(2183651, 1, "b65ef186c0a946139f12cda82197079ecef408e6b7eecf14b5ebf6f33faf0c81") -- Depot 2183651
setManifestid(2183651, "5712932775268181695", 2069507244)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)