-- 6020's Lua and Manifest Created by Hubcap Manifest
-- STAR WARS™ Jedi Knight: Jedi Academy™
-- Created: September 30, 2025 at 19:34:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(6020) -- STAR WARS™ Jedi Knight: Jedi Academy™
-- MAIN APP DEPOTS
addappid(6021, 1, "f745c993a0ccded106e85f47a80a9dcb6fc588690e20dae76393f0057283bfaf") -- Jedi_Academy_content
setManifestid(6021, "6927902281353816404", 1332353423)
addappid(6022, 1, "e0dc495e2d14fa6fa01a58714aba151ce54c4582778595803a77ea12e6ebf17b") -- Star Wars Jedi Knight: Jedi Academy Spanish
setManifestid(6022, "2790077089176024383", 14030)
addappid(6023, 1, "d1647205dc8aa9a6774166d73614227dd4f66f121a06411b9717bb4d9986f388") -- Star Wars Jedi Knight: Jedi Academy German
setManifestid(6023, "7901891665523225948", 14028)
addappid(6024, 1, "99bd3178dd1429b7d93f4ce31d5a8e6bd5c51eaea8f056782ecda437b9a5f246") -- Star Wars Jedi Knight: Jedi Academy French
setManifestid(6024, "5094143811248357121", 14030)
addappid(6025, 1, "443ca25b7f604ad880e44bf1f8fec552bdfefdddd4f0ce7f39a428445cda9a36") -- JKJA OS X
setManifestid(6025, "5454027630159677174", 1246131289)