-- 803330's Lua and Manifest Created by Hubcap Manifest
-- Destroy All Humans!
-- Created: September 29, 2025 at 07:30:48 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(803330) -- Destroy All Humans!
-- MAIN APP DEPOTS
addappid(803331, 1, "8548ae2dc9ed3193e4ebb386ea566523714b8ca47ab85919c5b0d58b8aa94c02") -- Destroy All Humans! Depot - Shared Content
setManifestid(803331, "162929606556726402", 8682087477)
addappid(803332, 1, "69762cce364c47101a23c7cc4fe695d0f3e73acf90abb0a8d4891a52bfa596e0") -- Destroy All Humans! Depot - Full Game
setManifestid(803332, "4386657334275739391", 8133399286)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1254570) -- Destroy All Humans Skin Pack