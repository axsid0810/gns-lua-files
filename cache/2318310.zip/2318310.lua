-- 2318310's Lua and Manifest Created by Hubcap Manifest
-- Class of '09: The Re-Up
-- Created: June 13, 2026 at 13:31:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2318310, 1, "14b2c2b39b329ff910a3db6f115f4c23fe8a5346c2def48f9d4baacb7c60dd31") -- Class of '09: The Re-Up
-- MAIN APP DEPOTS
addappid(2318311, 1, "e66e5394c607068e30ae879f37749246d2f8c1c56ef69abe96347284dbcdb519") -- Depot 2318311
setManifestid(2318311, "8926651450589153057", 1347496455)
addappid(2318312, 1, "f0ea25a3cd262ad8273182d8b100cf30ab9cd9e1ea779e85dc4871b6cd81181e") -- Depot 2318312
setManifestid(2318312, "6946662988823711150", 1345806513)