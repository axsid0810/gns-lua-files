-- 1443200's Lua and Manifest Created by Hubcap Manifest
-- Class of '09
-- Created: September 29, 2025 at 04:27:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1443200) -- Class of '09
-- MAIN APP DEPOTS
addappid(1443201, 1, "f2b5b84d38ada5c10ba273744eb6bca3639fcaf0aaabd7650015e65c46019029") -- Class of '09 Content
setManifestid(1443201, "1819005242797135757", 927106649)