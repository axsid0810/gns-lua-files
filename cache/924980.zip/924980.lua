-- 924980's Lua and Manifest Created by Hubcap Manifest
-- Trials of Mana
-- Created: October 01, 2025 at 03:42:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 2
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(924980) -- Trials of Mana
-- MAIN APP DEPOTS
addappid(924981, 1, "244e36cc32635256e4eda55f4850ee8ac6dece4b04825dbbe4586e418f798cda") -- Base Contents
setManifestid(924981, "5848832891921004539", 16311327007)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
-- DLCS WITH DEDICATED DEPOTS
-- Trials of Mana - Rabite Adornment (AppID: 1144960)
addappid(1144960)
addtoken(1144960, "13346872008802388898")
addappid(1144960, 1, "6e104e07086cad2fa00b0088d9da6a5fdfb49ca1b8a0bf47660c190adaad0dae") -- Trials of Mana - Rabite Adornment - Trials of Mana - DLC01 (1144960) デポ
setManifestid(1144960, "180951989313432265", 5295646)
-- Trials of Mana - Wallpapers (AppID: 1190470)
addappid(1190470)
addtoken(1190470, "237369522274306146")
addappid(1190470, 1, "4197f91760ac16404b9fcef6851a187b50398e15d6f00b1bc222c9d273b34791") -- Trials of Mana - Wallpapers - Trials of Mana - Wallpapers (1190470) Depot
setManifestid(1190470, "1062287549024850255", 60038554)