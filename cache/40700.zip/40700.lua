-- 40700's Lua and Manifest Created by Hubcap Manifest
-- Machinarium
-- Created: July 20, 2026 at 03:37:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(40700, 1, "0ee66ed9704750e4cea115ab752f688847d4004d46ba9e0bb7fe35a76e7e81f0") -- Machinarium
-- MAIN APP DEPOTS
addappid(40702, 1, "d1a795482b2ed2bc97591ba8a6020c1a1392da9794f3f0648611113f22f323ec") -- machinarium_mac_content
setManifestid(40702, "8328639856908019060", 315720807)
addappid(40701, 1, "37b5c7293653b02c677be46f10d154102e715fda6a2e0ccbbf7f8a11c5e7c91e") -- machinarium_content
setManifestid(40701, "2396199780517335850", 310605728)