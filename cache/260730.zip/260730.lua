-- 260730's Lua and Manifest Created by Hubcap Manifest
-- Desperados - Wanted Dead or Alive
-- Created: September 29, 2025 at 07:28:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(260730) -- Desperados - Wanted Dead or Alive
-- MAIN APP DEPOTS
addappid(260731, 1, "6e863d81e4d5b29893100c994036a85a336ab55dc4bac7ade46cd04bc760a881") -- Desperados Content
setManifestid(260731, "8883348394163131400", 1982044634)
addappid(260738, 1, "7e6c8a43688173444d17e5fc2b767f1761710865b4506bf9db6f8cb60c87fc4a") -- Desperados - Wanted Dead or Alive MAC
setManifestid(260738, "8956399286214579350", 1993457075)
addappid(260739, 1, "49afbafbdedaa17bde2e3430323960006320044fe869a41cbb396234d44dd0d5") -- Desperados - Wanted Dead or Alive LINUX
setManifestid(260739, "4628167066855842232", 1983662690)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)