-- 1046820's Lua and Manifest Created by Hubcap Manifest
-- I'm on Observation Duty
-- Created: November 26, 2025 at 10:53:13 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1046820) -- I'm on Observation Duty
-- MAIN APP DEPOTS
addappid(1046821, 1, "6bb56e4bf27dc7489280e84f72104014a04fe77d0cfe74f682d5479eedc13813") -- I'm on Observation Duty Windows content
setManifestid(1046821, "6735845432083755299", 1161307157)
addappid(1046822, 1, "b9942d5978857a9a96b647a3644c38ad0688b617e54b2824262462aac88cbc44") -- I'm on Observation Duty linux
setManifestid(1046822, "4057039379542568235", 1221467897)
addappid(1046823, 1, "f9e8259e7fd7e1817fe579805797766e9a13f7c7dbf21dddd1b68a60e66ab8ad") -- I'm on Observation Duty mac
setManifestid(1046823, "6614964141506584050", 1189327935)