-- 3484260's Lua and Manifest Created by Hubcap Manifest
-- DeadCore Redux
-- Created: February 24, 2026 at 19:28:59 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3484260) -- DeadCore Redux
-- MAIN APP DEPOTS
addappid(3484261, 1, "db4c462bc3c7f178e117a1c2449b8fa2c7cd9fd182f6e15985548e624cb59f8a") -- Depot 3484261
setManifestid(3484261, "5198085574438131887", 9066008794)