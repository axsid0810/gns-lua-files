-- 4674310's Lua and Manifest Created by Hubcap Manifest
-- Airport Mania: First Flight
-- Created: June 05, 2026 at 18:59:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4674310) -- Airport Mania: First Flight
-- MAIN APP DEPOTS
addappid(4674311, 1, "f1e639afa3e3babf7a071e250a20f7d4fd190f6b573758a72f3350712fa93513") -- Depot 4674311
setManifestid(4674311, "9051274258702896912", 53910945)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)