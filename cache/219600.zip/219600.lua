-- 219600's Lua and Manifest Created by Hubcap Manifest
-- NBA 2K13
-- Created: September 30, 2025 at 03:00:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(219600) -- NBA 2K13
-- MAIN APP DEPOTS
addappid(219601, 1, "23b7d1205a37743c80fdab6b511280c2339332f2c908ea82b4ca4ac97cebb9ad") -- NBA2K13 Content
setManifestid(219601, "6765084184662499668", 7667318326)