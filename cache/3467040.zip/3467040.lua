-- 3467040's Lua and Manifest Created by Hubcap Manifest
-- Bookshop Simulator
-- Created: July 21, 2026 at 14:59:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3467040, 1, "76c37eaeddab1223319be57cf6fdc0fda1a4a3f4f9c66ab79933f17add81cfbd") -- Bookshop Simulator
-- MAIN APP DEPOTS
addappid(3467041, 1, "7416c54d61cf32054ec624e2d1c4e3a825c272e5e79cd38461665165df5e7e61") -- Depot 3467041
setManifestid(3467041, "8015904963297033362", 6598911737)