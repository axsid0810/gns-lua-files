-- 1126320's Lua and Manifest Created by Hubcap Manifest
-- Being a DIK
-- Created: September 29, 2025 at 00:57:07 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 3 (2 excluded)
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1126320) -- Being a DIK
-- MAIN APP DEPOTS
addappid(1126321, 1, "b487bb317f141b1ea8c7f43473ae7192dc9c3ddabf47e75c0b8ea091ea83f5dd") -- Being a DIK - Season 1
setManifestid(1126321, "4158248342270159261", 6664543787)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- Being a DIK - Season 2 (AppID: 1215820)
addappid(1215820)
addappid(1215820, 1, "0890c98fa0aa823afe57e4bfdbdbfa87a06f0532f447baa16117044c87eee172") -- Being a DIK - Season 2 - Being a DIK - Season 2 (1215820)
setManifestid(1215820, "1689708494354971282", 13535561566)
-- Being a DIK  Season 1 - The complete official guide (AppID: 1223490)
addappid(1223490)
addappid(1223490, 1, "1d2d2ea68cb27690634e2ff82a64426f397f85aaf001bbf2c14cff8b4bd551a9") -- Being a DIK  Season 1 - The complete official guide - Being a DIK:  Season 1 - The complete official guide (1223490)
setManifestid(1223490, "5978801628945559663", 55794854)
-- Being a DIK Season 2 - The complete official guide (AppID: 1631620)
addappid(1631620)
addappid(1631620, 1, "11aa46b31524868c0f6390fba205305425c13bae710c8a44f309281fe43a88b7") -- Being a DIK Season 2 - The complete official guide - Being a DIK: Season 2 - The complete official guide (1631620)
setManifestid(1631620, "5931159407815891390", 80636556)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(1807120) -- Being a DIK - Season 3 (unreleased)
-- addappid(2220920) -- Being a DIK: Season 3 - The complete official guide (unreleased)