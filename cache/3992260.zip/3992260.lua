-- 3992260's Lua and Manifest Created by Hubcap Manifest
-- Ascend From Nine Mountains
-- Created: July 22, 2026 at 01:47:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3992260, 1, "66cfaac4d331e04e7bde64b4f14cf71d47137e92411d7f54b6247ffcbefa8587") -- Ascend From Nine Mountains
-- MAIN APP DEPOTS
addappid(3992261, 1, "61d31c274436ab72a4d0da81b8df7dbd67bb85a3b4fa4ad6b22786a9218c9ab7") -- Depot 3992261
setManifestid(3992261, "7811657940445758465", 1567541281)
addappid(3992262, 1, "4744cca75d09ae16c33491a520a216d9ef25c64f5eb558536c7e6ab37e612f1b") -- Depot 3992262
setManifestid(3992262, "8659304563017645346", 1521879713)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)