-- 1515950's Lua and Manifest Created by Hubcap Manifest
-- Capcom Arcade Stadium
-- Created: September 29, 2025 at 03:13:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 36
-- Total DLCs: 38
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1515950) -- Capcom Arcade Stadium
-- MAIN APP DEPOTS
addappid(1515951, 1, "b17c1e836dd605dbae3d6c5ce107337a1e41201081f2c539e0d5fe0d18365855") -- Content
setManifestid(1515951, "8730299595221726936", 1624856182)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Capcom Arcade StadiumGhosts n Goblins (AppID: 1556690)
addappid(1556690)
addappid(1556690, 1, "ae9bf5222456733f81de31dd28422136799abc974480462ebd42b492e55cfa3c") -- Capcom Arcade StadiumGhosts n Goblins - Content0
setManifestid(1556690, "720985918200840956", 325620)
-- Capcom Arcade StadiumVULGUS (AppID: 1556700)
addappid(1556700)
addappid(1556700, 1, "e90c414030ace0221c08e16aab14b4ba21b20397265d68371b5778274fac8e1e") -- Capcom Arcade StadiumVULGUS - Content1
setManifestid(1556700, "5256365349174359542", 141556)
-- Capcom Arcade StadiumPIRATE SHIP HIGEMARU (AppID: 1556701)
addappid(1556701)
addappid(1556701, 1, "08f7b0950d22a8b726ca4de48792646b15887fe7736b9349a663ce0bc6b6d075") -- Capcom Arcade StadiumPIRATE SHIP HIGEMARU - Content2
setManifestid(1556701, "2839819348004594506", 32210)
-- Capcom Arcade Stadium1942 (AppID: 1556702)
addappid(1556702)
addappid(1556702, 1, "0a1acc6ebc2c301ecdb7ca99627ea9b748701ea37a248d7381e179515c3b89d0") -- Capcom Arcade Stadium1942 - Content3
setManifestid(1556702, "930775891296948257", 107480)
-- Capcom Arcade StadiumCOMMANDO (AppID: 1556703)
addappid(1556703)
addappid(1556703, 1, "557fcdd64e397a9c566e8796636a4960e8c4100c83d59423b7bd6b63e6ef0b98") -- Capcom Arcade StadiumCOMMANDO - Content4
setManifestid(1556703, "3068512296888649504", 274966)
-- Capcom Arcade StadiumSECTION Z (AppID: 1556704)
addappid(1556704)
addappid(1556704, 1, "0eb18001376a70f82835a977e719ae1487101a7ec0fc8a79e6f7f347b3e3e15b") -- Capcom Arcade StadiumSECTION Z - Content5
setManifestid(1556704, "4115256064438261885", 203369)
-- Capcom Arcade StadiumTatakai no Banka (AppID: 1556705)
addappid(1556705)
addappid(1556705, 1, "283f2d18224ac5b5ad7cffc1cf79d4b9be2b46ec85c0d9a413c4e97c0fd59d5e") -- Capcom Arcade StadiumTatakai no Banka - Content6
setManifestid(1556705, "2012252709011603898", 335136)
-- Capcom Arcade StadiumLEGENDARY WINGS (AppID: 1556706)
addappid(1556706)
addappid(1556706, 1, "d3e69e5d63519b5c24708e99f059c5038114e4bdcf20d8bbfa087a7f4743ce2f") -- Capcom Arcade StadiumLEGENDARY WINGS - Content7
setManifestid(1556706, "1060722444987922461", 465196)
-- Capcom Arcade StadiumBIONIC COMMANDO (AppID: 1556707)
addappid(1556707)
addappid(1556707, 1, "6f6af01ce8b8beff1483241523422c9e76f4ce74ed53b87815fa21441b2c9ab1") -- Capcom Arcade StadiumBIONIC COMMANDO - Content8
setManifestid(1556707, "3311060249623978404", 349150)
-- Capcom Arcade StadiumFORGOTTEN WORLDS (AppID: 1556708)
addappid(1556708)
addappid(1556708, 1, "0eb370b28178f597817a1120bb8d820c451fbd18f425bd8f5be11ab263a1874b") -- Capcom Arcade StadiumFORGOTTEN WORLDS - Content9
setManifestid(1556708, "1338479023925864521", 3936206)
-- Capcom Arcade StadiumGhouls n Ghosts (AppID: 1556709)
addappid(1556709)
addappid(1556709, 1, "5f0bb814d4b803b857136f0d4e0ee14b4b5ad7f19e15dc4704bb280bb3610255") -- Capcom Arcade StadiumGhouls n Ghosts - Content10
setManifestid(1556709, "4791960461403205195", 3327867)
-- Capcom Arcade StadiumSTRIDER (AppID: 1556710)
addappid(1556710)
addappid(1556710, 1, "5cfea9206d52817b90e89c41fd462a9e4bc48be8c64dadd38c51bcdbf5c887bf") -- Capcom Arcade StadiumSTRIDER - Content11
setManifestid(1556710, "8852060672413987001", 4294405)
-- Capcom Arcade StadiumDYNASTY WARS (AppID: 1556711)
addappid(1556711)
addappid(1556711, 1, "6a349882f10a164f671636764d1440ac6287c1dd486d5e7cfc5715d87bc1a629") -- Capcom Arcade StadiumDYNASTY WARS - Content12
setManifestid(1556711, "4583266592555943480", 4612365)
-- Capcom Arcade StadiumFINAL FIGHT (AppID: 1556712)
addappid(1556712)
addappid(1556712, 1, "0a109fef09d9648a303396945c8c5524baa94d94e455fabdf2293562014076b7") -- Capcom Arcade StadiumFINAL FIGHT - Content13
setManifestid(1556712, "6599462489458630755", 2943369)
-- Capcom Arcade Stadium1941 - Counter Attack - (AppID: 1556713)
addappid(1556713)
addappid(1556713, 1, "2e27d6636250c3b6fa780a15fb780ea2d1f808e4657f9aaf1218c3d9ef54aeb0") -- Capcom Arcade Stadium1941 - Counter Attack - - Content14
setManifestid(1556713, "3043018487682955546", 2923651)
-- Capcom Arcade StadiumSenjo no Okami (AppID: 1556714)
addappid(1556714)
addappid(1556714, 1, "4b5ccbbf446a42e2cb467c0c68d5c21b6c96890b6cb4bf1d645b357e88839950") -- Capcom Arcade StadiumSenjo no Okami - Content15
setManifestid(1556714, "8684632688241706607", 1811805)
-- Capcom Arcade StadiumMEGA TWINS (AppID: 1556715)
addappid(1556715)
addappid(1556715, 1, "4c89395cb2fff69c2d657f9347f0eb88779caf88c545394f6c044b4f62ac4ade") -- Capcom Arcade StadiumMEGA TWINS - Content16
setManifestid(1556715, "2594671030254058043", 2964498)
-- Capcom Arcade StadiumCARRIER AIR WING (AppID: 1556716)
addappid(1556716)
addappid(1556716, 1, "bf9cd9b4ce5b1ad4cc09cb96baa575aa23e05f2fec59973da10ca8b945f35449") -- Capcom Arcade StadiumCARRIER AIR WING - Content17
setManifestid(1556716, "3262338654785901818", 3044343)
-- Capcom Arcade StadiumSTREET FIGHTER II - The World Warrior - (AppID: 1556717)
addappid(1556717)
addappid(1556717, 1, "f67d1a2faf78f8cb97e1ffa6a68761bbd157e01253db553a4d14d7d56e89a3d1") -- Capcom Arcade StadiumSTREET FIGHTER II - The World Warrior - - Content18
setManifestid(1556717, "6565168997152152747", 7215466)
-- Capcom Arcade StadiumCAPTAIN COMMANDO (AppID: 1556718)
addappid(1556718)
addappid(1556718, 1, "f40ac31ec7c2a4a256abba8e818aafc4b58fdb826a577b96528d79e1b829c359") -- Capcom Arcade StadiumCAPTAIN COMMANDO - Content19
setManifestid(1556718, "3828378947312518235", 5206223)
-- Capcom Arcade StadiumVARTH - Operation Thunderstorm - (AppID: 1556719)
addappid(1556719)
addappid(1556719, 1, "e052885256fd042e71d34eea1c020065f860f53f39f2c13e625d477552c7cd50") -- Capcom Arcade StadiumVARTH - Operation Thunderstorm - - Content20
setManifestid(1556719, "7633392002448169369", 3187619)
-- Capcom Arcade StadiumWARRIORS OF FATE (AppID: 1556720)
addappid(1556720)
addappid(1556720, 1, "b3b699b2ff23ef66fe1914b6d42a7849054547127a6d2825e372ddf5fa2a976e") -- Capcom Arcade StadiumWARRIORS OF FATE - Content21
setManifestid(1556720, "939928116172609116", 8020766)
-- Capcom Arcade StadiumSTREET FIGHTER II - Hyper Fighting - (AppID: 1556721)
addappid(1556721)
addappid(1556721, 1, "0efdb75351e98de8936741b7153c9b3dc9bf05764da779bc1b942cfe98f51003") -- Capcom Arcade StadiumSTREET FIGHTER II - Hyper Fighting - - Content22
setManifestid(1556721, "8853416909907985637", 7452685)
-- Capcom Arcade StadiumSuper Street Fighter II Turbo (AppID: 1556722)
addappid(1556722)
addappid(1556722, 1, "bb8c62d11f7d934bc4bd77be9dc6de4ff6c73856569104cd17680493ad58ab8b") -- Capcom Arcade StadiumSuper Street Fighter II Turbo - Content23
setManifestid(1556722, "8868733674607803535", 30445303)
-- Capcom Arcade StadiumPowered Gear - Strategic Variant Armor Equipment - (AppID: 1556723)
addappid(1556723)
addappid(1556723, 1, "11971cebeefb10a36e522ade9dbe948bc263eae24da7ebf99540bfdb719db9cd") -- Capcom Arcade StadiumPowered Gear - Strategic Variant Armor Equipment - - Content24
setManifestid(1556723, "3507050944236305691", 15826430)
-- Capcom Arcade StadiumCYBERBOTS - FULLMETAL MADNESS - (AppID: 1556724)
addappid(1556724)
addappid(1556724, 1, "cfd106b6ad24104efc0257d447bb49649e142e7faef8f2e46a7c48c5e1119252") -- Capcom Arcade StadiumCYBERBOTS - FULLMETAL MADNESS - - Content25
setManifestid(1556724, "2973553248234592332", 40680961)
-- Capcom Arcade Stadium19XX - The War Against Destiny - (AppID: 1556725)
addappid(1556725)
addappid(1556725, 1, "3ad1297113c4ac3b940877c96a73e61a92544775574c4b9de72e56237badbf85") -- Capcom Arcade Stadium19XX - The War Against Destiny - - Content26
setManifestid(1556725, "9114491010637683972", 18160351)
-- Capcom Arcade StadiumBattle Circuit (AppID: 1556726)
addappid(1556726)
addappid(1556726, 1, "edd9a34b2d862a3f9d4addec430f6884be3dc17cbd8c013685faefe751d1084c") -- Capcom Arcade StadiumBattle Circuit - Content27
setManifestid(1556726, "7256561282705776837", 25129918)
-- Capcom Arcade StadiumGiga Wing (AppID: 1556727)
addappid(1556727)
addappid(1556727, 1, "1bb6a466823e379630060f9b0351902890081232b158440f485104a6babafd65") -- Capcom Arcade StadiumGiga Wing - Content28
setManifestid(1556727, "88396441350106139", 25229338)
-- Capcom Arcade Stadium1944 - The Loop Master - (AppID: 1556728)
addappid(1556728)
addappid(1556728, 1, "42e5b1fd6a5d61ddef35d0aaa9fcba40af563865b819642f91b364bbda0dffa0") -- Capcom Arcade Stadium1944 - The Loop Master - - Content29
setManifestid(1556728, "8656237320360188678", 30449360)
-- Capcom Arcade StadiumProgear (AppID: 1556729)
addappid(1556729)
addappid(1556729, 1, "3563df941599cb7c85cafaaf51f001607cf85e594ee8cff6fa393e72572193c3") -- Capcom Arcade StadiumProgear - Content30
setManifestid(1556729, "9110940077951262143", 33009179)
-- Capcom Arcade Stadium Display Frames Set 1 (AppID: 1556730)
addappid(1556730)
addappid(1556730, 1, "e1cc101bc96d48f1122ecb09d846300c7f09f5e4c0351879b466f6c6a897735c") -- Capcom Arcade Stadium Display Frames Set 1 - Content31
setManifestid(1556730, "1469740142157942751", 25207763)
-- Capcom Arcade Stadium Invincibility (AppID: 1560440)
addappid(1560440)
addappid(1560440, 1, "c9c0122a3adf38b7e67c99e8dc8047be96593e52e041c1b5230743eeb6be7527") -- Capcom Arcade Stadium Invincibility - Content32
setManifestid(1560440, "8399030712089674735", 408053)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1674610) -- Capcom Arcade Stadium Pack 1 Dawn of the Arcade (84  88)
addappid(1674611) -- Capcom Arcade Stadium Pack 2 Arcade Revolution (89  92)
addappid(1674612) -- Capcom Arcade Stadium Pack 3 Arcade Evolution (92  01)
addappid(1674613) -- Capcom Arcade Stadium Packs 1, 2, and 3
addappid(1674614) -- Capcom Arcade Stadium Packs 1, 2, and 3  Mini-Album Bundle