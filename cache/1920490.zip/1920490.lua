-- 1920490's Lua and Manifest Created by Hubcap Manifest
-- The Outer Worlds: Spacer's Choice Edition
-- Created: June 24, 2026 at 14:18:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1920490, 1, "7c8a0ce5d7190df1f4a119e69ee86ec4242bf12d581b82a93d7d3d242f81ddd8") -- The Outer Worlds: Spacer's Choice Edition
-- MAIN APP DEPOTS
addappid(1920491, 1, "27a2f143dfdef7f57d92c95cd6fc0682e767921c962694a6c4efa9fc5054fab4") -- Depot 1920491
setManifestid(1920491, "1831635440497948513", 57172814472)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)