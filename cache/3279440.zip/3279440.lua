-- 3279440's Lua and Manifest Created by Hubcap Manifest
-- Drone Sector
-- Created: July 21, 2026 at 16:27:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3279440) -- Drone Sector
-- MAIN APP DEPOTS
addappid(3279441, 1, "66f000122b2ceffdc4bdaef8fcf24f22fbad160ed86e5830c480d7a3f0d54920") -- Depot 3279441
setManifestid(3279441, "1077441612471567189", 4511786147)