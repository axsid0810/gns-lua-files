-- 3314340's Lua and Manifest Created by Hubcap Manifest
-- Burgie's cozy kitchen
-- Created: July 26, 2026 at 02:38:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1 (1 excluded)

-- MAIN APPLICATION
addappid(3314340) -- Burgie's cozy kitchen
-- MAIN APP DEPOTS
addappid(3314342, 1, "4a553b925ea338f09b056513e1f0feeb7aea85a2ae975aa82cbc38b5019bf985") -- Depot 3314342
setManifestid(3314342, "7732277880694895688", 569288833)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4127290) -- Burgies cozy kitchen - Halloween
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4969500) -- Burgie's cozy kitchen - Dungeon (unreleased)