-- 1222680's Lua and Manifest Created by Hubcap Manifest
-- Need for Speed™ Heat 
-- Created: July 23, 2026 at 18:10:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 18
-- Total DLCs: 6
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(1222680, 1, "fedb1548e1dac6e72f46c85a36820a3dfda019c1c9cfdfafe97e12ad356ea3e0") -- Need for Speed™ Heat 
-- MAIN APP DEPOTS
addappid(1222681, 1, "e249f05202889ee5fb53d5acc1e08682922c11271482791e5da05e6734701886") -- Telstar - NFSH Content
setManifestid(1222681, "4929521867669947405", 36748822704)
addappid(1222682, 1, "9c5ac539f5ac43b3d6bd0f35f0e0029428e6f0a43ecf3b8f46fe38bcd18f9dba") -- NFS Heat - en_US
setManifestid(1222682, "4677077573126563900", 201791)
addappid(1222683, 1, "af537c758c633a19ce3813a24f5e500ead5702bf4f19099fbfe9565e07d2037b") -- NFS Heat - ar_SA
setManifestid(1222683, "4366693261551491466", 274205)
addappid(1222684, 1, "614d9dc54641056b7ad618c7eec7d529936b12d09a5b509817087da737f08310") -- NFS Heat - de_DE
setManifestid(1222684, "3264608771884247608", 170707)
addappid(1222685, 1, "bd111b0f1c8ca081e1a42fa6396ede6db5457f89459fab4f2e3541e40e04a8b1") -- NFS Heat - es_ES
setManifestid(1222685, "137827128056067669", 186359)
addappid(1222686, 1, "5558fee1456efe525639e332612f4c570c01f78794b8568eee269b5bc1ceb085") -- NFS Heat - fr_FR
setManifestid(1222686, "4139935978556642585", 178532)
addappid(1222687, 1, "6ae364964d073aaed1a0fb11d41fa0e96bb739a1bc9ea73211a1b8edef09ee17") -- NFS Heat - it_IT
setManifestid(1222687, "7498522625082584980", 174250)
addappid(1222688, 1, "d66941c60b7acd8a783877e3978512ff0de840da0f7f89008c4ff75bd2f873d7") -- NFS Heat - ja_JP
setManifestid(1222688, "1279642730456692929", 257000)
addappid(1222689, 1, "2978b8056d052c21c497b86291884868f369fb899d01925e5117af252926760a") -- NFS Heat - ko_KR
setManifestid(1222689, "5547551303099253415", 392069)
addappid(1239381, 1, "29d5d384c7b7d2fbe8859976b5ded0a92b7e0a9f7e85dab36ed0925fe3e6574d") -- NFS Heat - pl_PL
setManifestid(1239381, "2014000203717803678", 177582)
addappid(1239382, 1, "653083c0dc812529f876ee63a304de920c3d9563a658d95c0e5e4f5d15d28158") -- NFS Heat - pt_BR
setManifestid(1239382, "3142845027285203463", 113884)
addappid(1239383, 1, "01137b8d3ec1007333c574a8f890efbe6aada461151e2784ddcdd2fd450ea3c2") -- NFS Heat - ru_RU
setManifestid(1239383, "4525595491971643433", 243031)
addappid(1239384, 1, "152c66145c46cb792b8b3a0e7b18f8336892ccd1e72bb0726039bdd843d40163") -- NFS Heat - zh_CN
setManifestid(1239384, "1259673667407970256", 178325)
addappid(1239385, 1, "3a475f80eb2bc6cdede83e8eb1b69fb44d34e3cfdaa9756e688d4d25d540fbfb") -- NFS Heat - zh_TW
setManifestid(1239385, "5278051178232028739", 167226)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
setManifestid(3340991, "6717304605949129056", 240979991)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1251050) -- Need for Speed Heat Deluxe Edition Upgrade
addappid(1281880) -- Need for Speed Heat - McLaren F1 Black Market Delivery
addappid(1281881) -- Need for Speed Heat - Keys to the Map
addappid(1290400) -- Need for Speed Heat Deluxe Edition - Key
addappid(1290401) -- Need for Speed Heat Deluxe Edition Upgrade Content
addappid(1290402) -- Need for Speed Heat K.S Edition Mitsubishi Lancer Evolution X