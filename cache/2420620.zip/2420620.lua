-- 2420620's Lua and Manifest Created by Hubcap Manifest
-- Demon Slayer Shion
-- Created: May 25, 2026 at 07:12:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2420620, 1, "6de7d2280934f0ac7c72658baf94cb27d9c1c1826f9bfcd3a0e6696b0fe0de1e") -- Demon Slayer Shion
-- MAIN APP DEPOTS
addappid(2420621, 1, "b3ff0f74222b07268172c442345ad1f7cab2c9e4496a6fa236f9857490ae76e9") -- Depot 2420621
setManifestid(2420621, "4729547431402115077", 555107951)
addappid(2420622, 1, "84812569a20de81dd4a9b4e6862ccf367b6c85fe1973048f06b32faabdce8c9f") -- Depot 2420622
setManifestid(2420622, "3083171688947046369", 465396577)
addappid(2420623, 1, "f5d30954feb6392b1985821417a8d49ce9da5a1d056ffc6ad0762233402e5b8b") -- Depot 2420623
setManifestid(2420623, "8783752942954494512", 456029516)