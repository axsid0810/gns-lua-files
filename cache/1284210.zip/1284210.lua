-- 1284210's Lua and Manifest Created by Hubcap Manifest
-- Guild Wars 2®
-- Created: June 05, 2026 at 17:46:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 10

-- MAIN APPLICATION
addappid(1284210, 1, "eb756d0fb369aba7d86fd962fb0eb2eec10a759903418823d50af7af7f188c75") -- Guild Wars 2®
-- MAIN APP DEPOTS
addappid(1284211, 1, "15957cae60ac6d6ef2c8d2972c2a77160c6620b01c02dff14ae85510c0b2c5b6") -- Depot 1284211
setManifestid(1284211, "8867225726661558093", 53266801)
addappid(1284212, 1, "3621a9dd9b026862d51a738bbf79f6e3d7e8ac07521d78934c20d8588e00bbbc") -- Depot 1284212
setManifestid(1284212, "7142984589613885574", 92020824328)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1996840) -- Guild Wars 2 Heart of Thorns and Path of Fire Expansions
addappid(2008610) -- Guild Wars 2 End of Dragons Expansion
addappid(2013750) -- Guild Wars 2 Living World
addappid(2450010) -- Guild Wars 2 Secrets of the Obscure Expansion
addappid(2486290) -- Guild Wars 2 Secrets of the Obscure Prepurchase Rewards
addappid(2982320) -- Guild Wars 2 Janthir Wilds Expansion
addappid(2982330) -- Guild Wars 2 Janthir Wilds Prepurchase Rewards
addappid(3845860) -- Guild Wars 2 Visions of Eternity Prepurchase Rewards
addappid(3845870) -- Guild Wars 2 Visions of Eternity Expansion
addappid(4158070) -- Guild Wars 2 Starter Pack