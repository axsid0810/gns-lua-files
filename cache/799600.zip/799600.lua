-- 799600's Lua and Manifest Created by Hubcap Manifest
-- Cosmoteer: Starship Architect & Commander
-- Created: May 09, 2026 at 17:21:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(799600, 1, "3c95902da48b975afeb0b51b08f0b885271b45f59738a49af7108d2f146e3ac2") -- Cosmoteer: Starship Architect & Commander
-- MAIN APP DEPOTS
addappid(799601, 1, "c7c1275eba141988dcc75746510071b5a1b826a01cf6c0f974b03f07d89652d4") -- Depot 799601
setManifestid(799601, "405732339647904822", 1713137011)
addappid(799602, 1, "e15c9b74effae3f79409f360b71bf5b110cc1561e23ce2515459dee9e4569cf4") -- Depot 799602
setManifestid(799602, "8345483787108677701", 199484758)
addappid(799603, 1, "957e695d970db86795eea257e7b86217684794eaeabba1ac8ba96167dc412bfe") -- Depot 799603
setManifestid(799603, "1928854620339794221", 210896140)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)