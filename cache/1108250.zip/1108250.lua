-- 1108250's Lua and Manifest Created by Hubcap Manifest
-- All Systems Operational
-- Created: January 19, 2026 at 16:57:22 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1108250) -- All Systems Operational
-- MAIN APP DEPOTS
addappid(1108251, 1, "5283d43da9d7addd0f34e822c27832c3f8b380fd003ba2f8753959449af74d05") -- All Systems Operational Content Depot Win
setManifestid(1108251, "5937958504350528077", 923702514)
addappid(1108252, 1, "5679d60fec784ce49344094eef6e898c93a375078dee4daa42cb53562b16ecc4") -- All Systems Operational Content Depot Mac
setManifestid(1108252, "1432662107671578107", 951115056)