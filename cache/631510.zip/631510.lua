-- 631510's Lua and Manifest Created by Hubcap Manifest
-- Devil May Cry HD Collection
-- Created: September 29, 2025 at 07:36:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(631510) -- Devil May Cry HD Collection
-- MAIN APP DEPOTS
addappid(631511, 1, "79183f987f646ce0abe58d2a413285f83e8bc0d045c01864d28e30bb6ee37ae2") -- hifumi Content
setManifestid(631511, "7018858071300627307", 12126176825)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
-- DLCS WITH DEDICATED DEPOTS
-- DMCHDC Wallpaper (AppID: 811840)
addappid(811840)
addappid(811840, 1, "16b5d8916c93e2e48652438e21a29ca27db96cdf30f095c95d0ee9eec24cf34b") -- DMCHDC Wallpaper - DMCHDC Wallpaper (811840) Depot
setManifestid(811840, "1956669955052522073", 4993049)