-- 1687670's Lua and Manifest Created by Hubcap Manifest
-- LAST CLOUDIA
-- Created: July 30, 2026 at 01:14:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1687670) -- LAST CLOUDIA
-- MAIN APP DEPOTS
addappid(1687671, 1, "d8dd4776e4529e69105a81b2b732fbb4f8e49e5a4edec00929f6600c4ee679ce") -- LAST CLOUDIA depo
setManifestid(1687671, "4770413872945400622", 459181104)