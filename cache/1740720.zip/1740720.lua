-- 1740720's Lua and Manifest Created by Hubcap Manifest
-- Have a Nice Death
-- Created: October 15, 2025 at 14:30:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1740720) -- Have a Nice Death
-- MAIN APP DEPOTS
addappid(1740721, 1, "3d157af207a2219654574f372c41161daf4b1ca850b8a6967669c14a31dc302a") -- Depot 1740721
setManifestid(1740721, "7416424018944525784", 1986469420)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)
-- DLCS WITH DEDICATED DEPOTS
-- Have a Nice Death - Digital Artbook (AppID: 2368520)
addappid(2368520)
addappid(2368520, 1, "84710e64a350b57f4d613117406856f8c14bcd42724b5c693e7833b0ea838631") -- Have a Nice Death - Digital Artbook - Depot 2368520
setManifestid(2368520, "6635975447246389432", 26907904)