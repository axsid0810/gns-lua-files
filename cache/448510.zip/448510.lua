-- 448510's Lua and Manifest Created by Hubcap Manifest
-- Overcooked
-- Created: September 30, 2025 at 05:26:13 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(448510) -- Overcooked
-- MAIN APP DEPOTS
addappid(448511, 1, "d54ea6782642b416a2c5587f03ed3c9b7cbf6098565dca9cd91325ac1c79e750") -- Overcooked Content
setManifestid(448511, "9147951660691927483", 714493456)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Overcooked - The Lost Morsel (AppID: 530060)
addappid(530060)
addappid(530060, 1, "ddca5a86b69fd74aec04867274a9171d22a319ca1efe116d60ad195e840710c2") -- Overcooked - The Lost Morsel - Overcooked - The Lost Morsel (530060) Depot
setManifestid(530060, "5412867458573439150", 83648345)