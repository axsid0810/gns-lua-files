-- 207140's Lua and Manifest Created by Hubcap Manifest
-- SpeedRunners
-- Created: June 06, 2026 at 12:44:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 3
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(207140, 1, "103f304a9e7ffda2f7a393b47f68409a81c235de32521f3a9c571dd376dcf2af") -- SpeedRunners
-- MAIN APP DEPOTS
addappid(207141, 1, "2a380068679014b0f5249bc4968d341a6467fc4f4eac292e259ad5a5e660f34f") -- SpeedRunners All Windows Files
setManifestid(207141, "4258464523898132195", 715167342)
addappid(207142, 1, "071e1a3caf8dadaaf299c91b768079a0eff26aad6f7fd40334302de0d13e0a83") -- SpeedRunners All Linux Files
setManifestid(207142, "6394228400517799954", 769646513)
addappid(207143, 1, "43694c31e2449eb1b43e9d1d1cc8d4e94053ff8f03451ea4e7ac28f684770b63") -- SpeedRunners All Mac OS X Files
setManifestid(207143, "2694071498128780329", 760934606)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(317480) -- SpeedRunners - Youtuber Pack 1
addappid(317490) -- SpeedRunners - Youtuber Pack 2
addappid(895440) -- SpeedRunners - Civil Dispute
-- EMPTY DEPOTS (no content on any branch)
-- addappid(317480) -- Depot 317480 (empty depot)
-- addappid(317490) -- Depot 317490 (empty depot)
-- addappid(895440) -- Depot 895440 (empty depot)