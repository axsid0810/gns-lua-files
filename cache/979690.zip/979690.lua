-- 979690's Lua and Manifest Created by Hubcap Manifest
-- The Ascent
-- Created: September 30, 2025 at 22:36:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 9
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(979690) -- The Ascent
-- MAIN APP DEPOTS
addappid(979691, 1, "8f6782f423cd2844f6369c96e17e6778495eb7c864d0e32f401fae10868fe04b") -- The Ascent Content
setManifestid(979691, "1974478407244271281", 21284821220)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- The Ascent - Artbook  Weapon Pack (AppID: 3896950)
addappid(3896950)
addappid(979692, 1, "2ba23f9748f7b6c1f04f4fbf6fc25d44d62e8cc4a27232c0bd32045133fc4a8a") -- The Ascent - Artbook  Weapon Pack - Extra content
setManifestid(979692, "3529311369023439933", 63782557)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1690300) -- The Ascent - The Persuader
addappid(1698300) -- The Ascent - Bitsplit
addtoken(1698300, "3626827782281571448")
addappid(1792190) -- The Ascent - Halloween Pack
addappid(1802450) -- The Ascent - CyberSec Pack
addappid(1802451) -- The Ascent - Cyber Warrior Pack
addappid(1802452) -- The Ascent - Chongqing Pack
addappid(1802470) -- The Ascent - Cyber Heist
addappid(1826620) -- The Ascent - Winter Pack