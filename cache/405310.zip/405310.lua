-- 405310's Lua and Manifest Created by Hubcap Manifest
-- LEGO® MARVEL's Avengers
-- Created: September 29, 2025 at 21:52:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 28
-- Total DLCs: 12
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(405310) -- LEGO® MARVEL's Avengers
-- MAIN APP DEPOTS
addappid(405311, 1, "4300f321ec68abdfdd31b4598fa933395cfb899aaaeb6de4d81526d02f79740c") -- LEGO Marvel's Avengers Content
setManifestid(405311, "6063411457562023067", 6493373903)
addappid(405317, 1, "1d756808f649dcf8fe4dc18ad95aa527a09df57996407c78ad809cf1cda0ae70") -- LEGO Marvel's Avengers Content over one DVD
setManifestid(405317, "2067011827255010025", 7948152919)
addappid(405312, 1, "347e45a2260eaf17914b06730c812e1b9b1b0fded9e6d1347f91c755c071cf3d") -- Mac Application
setManifestid(405312, "317053838533756556", 114551600)
addappid(405313, 1, "a8db60f269b17c9eedee437a5707b5bbdcc6580e1cbacd5c8b31ecf8c284043e") -- Mac Data
setManifestid(405313, "3897895021595406798", 14926568840)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- LEGO MARVELs Avengers DLC - The Avengers Explorer Character Pack (AppID: 418220)
addappid(418220)
addtoken(418220, "13096880992263282786")
addappid(418220, 1, "cb33ef43a48e490ca918eece7577106727e39ac7945df7387b5cece24d5d7e15") -- LEGO MARVELs Avengers DLC - The Avengers Explorer Character Pack - LEGO MARVEL's Avengers DLC - The Avengers Explorer Character Pack (418220) Depot
setManifestid(418220, "1996835240450749014", 5277426)
addappid(405315, 1, "63bb542919a79c132c2dca0b434d779e50f5a6dceef503e966651f7af6d3331b") -- LEGO MARVELs Avengers DLC - The Avengers Explorer Character Pack - Mac DLC1 - Explorer Character Pack
setManifestid(405315, "2104650834576028263", 4715007)
-- LEGO MARVELs Avengers DLC - The Avengers Adventurer Character Pack (AppID: 418221)
addappid(418221)
addtoken(418221, "15277992778505707324")
addappid(418221, 1, "025bc4e7910dc6857680543838d7f1aee3834ccc052bc4756d29f4716837da30") -- LEGO MARVELs Avengers DLC - The Avengers Adventurer Character Pack - LEGO MARVEL's Avengers DLC - The Avengers Adventurer Character Pack (418221) Depot
setManifestid(418221, "1349214868882099721", 2253258)
addappid(405314, 1, "69a09d6dbb6ef3810b481b623994cb4e7b0e7b7e2f6433b03217067efd0f289e") -- LEGO MARVELs Avengers DLC - The Avengers Adventurer Character Pack - Mac DLC2 - Adventurer Character Pack
setManifestid(405314, "3198709766254151679", 1899627)
-- LEGO MARVELs Avengers DLC - The Thunderbolts Character Pack (AppID: 422480)
addappid(422480)
addtoken(422480, "14624279480146860960")
addappid(422480, 1, "9be6d06f2a3edda3b2a2c197684a8ede96ac115e8a959ff8dda014729abaac7a") -- LEGO MARVELs Avengers DLC - The Thunderbolts Character Pack - LEGO MARVEL's Avengers - The Thunderbolts Character Pack (422480) Depot
setManifestid(422480, "4569800913507110423", 5544994)
addappid(405316, 1, "0822190248b32ee413b50c58f6c04e4f7bc3693ae4cca9a6bcaa8e5d62072c90") -- LEGO MARVELs Avengers DLC - The Thunderbolts Character Pack - Mac DLC3 - Thunderbolt Character Pack
setManifestid(405316, "3140932226056991437", 5076894)
-- LEGO MARVELs Avengers DLC - The Masters of Evil Pack (AppID: 439500)
addappid(439500)
addappid(439500, 1, "264ef45336017125f0560485e545137ff3f3376182da941f0f7f30386ff154c7") -- LEGO MARVELs Avengers DLC - The Masters of Evil Pack - LEGO® MARVEL's Avengers DLC - The Masters of Evil level pack (439500) Depot
setManifestid(439500, "584947749258280763", 154098586)
addappid(405318, 1, "bf1879728e3a9738c4dd4715ee8705c62c83b25c38b59cd2e2ec8175284c8da6") -- LEGO MARVELs Avengers DLC - The Masters of Evil Pack - Mac DLC5 - The Masters of Evil level pack (439500) Depot
setManifestid(405318, "4737591070779478040", 144715594)
-- LEGO MARVELs Avengers DLC - Classic Captain Marvel Pack (AppID: 439501)
addappid(439501)
addappid(439501, 1, "d3b8bb8194f4a50003e2184d1298142dedc821b439a51c1f46f511a380e58331") -- LEGO MARVELs Avengers DLC - Classic Captain Marvel Pack - LEGO® MARVEL's Avengers DLC - The Captain Marvel level pack (439501) Depot
setManifestid(439501, "389838282352392872", 490618308)
addappid(405319, 1, "91e4b8b4df5ed50f7655ef5f8323b08795276a20292cff67bf52387c106d435e") -- LEGO MARVELs Avengers DLC - Classic Captain Marvel Pack - Mac DLC6 - The Captain Marvel level pack (439501) Depot
setManifestid(405319, "417231177927221512", 477418050)
-- LEGO MARVELs Avengers DLC - Marvels Captain America Civil War Character Pack (AppID: 446520)
addappid(446520)
addappid(446520, 1, "a9c42b9ffd7875acb1c4952f3dc529fcde1a0b75ced6d85dc31e483bc0e50541") -- LEGO MARVELs Avengers DLC - Marvels Captain America Civil War Character Pack - LEGO® MARVEL's Avengers DLC - The Captain America Civil War Character Pack (446520) Depot
setManifestid(446520, "6279650362125631875", 7859880)
addappid(418225, 1, "ab2c83095332fdd0d6582d0b20245bb01a7d21a1cc9279976de034acbaa2737c") -- LEGO MARVELs Avengers DLC - Marvels Captain America Civil War Character Pack - Mac DLC4 - The Captain America Civil War Character Pack (446520) Depot
setManifestid(418225, "3250358225833735785", 7079647)
-- LEGO MARVELs Avengers DLC - Classic Black Panther Pack (AppID: 449390)
addappid(449390)
addappid(449390, 1, "64c7aa78dfcec700c7f05792ef3757b7dcf8fff4702e52d86034136a919f761c") -- LEGO MARVELs Avengers DLC - Classic Black Panther Pack - LEGO® MARVEL's Avengers DLC - The Black Panther Level Pack (449390) Depot
setManifestid(449390, "204657960520205911", 298562684)
addappid(418226, 1, "a33b2f8dc1cbdd5953c17ea24d88b2b7db20ba56815c3e758cd7d4c19422b56c") -- LEGO MARVELs Avengers DLC - Classic Black Panther Pack - Mac DLC7 - The Black Panther Level Pack (449390) Depot
setManifestid(418226, "437327118168289729", 287694357)
-- LEGO MARVELs Avengers DLC - All-New, All-Different Doctor Strange Pack (AppID: 449391)
addappid(449391)
addappid(449391, 1, "2b092e8186b4d21f896476de2ef0c462ee5647652d38bb1a46ca3a2ed8a7bd92") -- LEGO MARVELs Avengers DLC - All-New, All-Different Doctor Strange Pack - LEGO® MARVEL's Avengers DLC - The Doctor Strange Level Pack (449391) Depot
setManifestid(449391, "8592237886548709683", 273580820)
addappid(418222, 1, "f5b6bf9088461148bd1e76d8ecd56d184fa8d74d5bb4072fbb9dd1588bbf3c9e") -- LEGO MARVELs Avengers DLC - All-New, All-Different Doctor Strange Pack - Mac DLC8 - The Doctor Strange Level Pack (449391) Depot
setManifestid(418222, "3540383300546800706", 264522790)
-- LEGO MARVELs Avengers DLC - Marvels Agents of S.H.I.E.L.D. Pack (AppID: 449392)
addappid(449392)
addappid(449392, 1, "adef08361852ccea7d99efbb7e3f0eb66f6b7c7779d02f9bd848b6730582e796") -- LEGO MARVELs Avengers DLC - Marvels Agents of S.H.I.E.L.D. Pack - LEGO® MARVEL's Avengers DLC - Marvel’s Agents of S.H.I.E.L.D. Level Pack (449392) Depot
setManifestid(449392, "241071011227377207", 340137726)
addappid(418223, 1, "ae2f45fa81cb37c8d05a54297dc45df1157ca08e0c67903673692c5efb274a7a") -- LEGO MARVELs Avengers DLC - Marvels Agents of S.H.I.E.L.D. Pack - Mac DLC9 - Marvel’s Agents of S.H.I.E.L.D. Level Pack (449392) Depot
setManifestid(418223, "553121742249896751", 327765248)
-- LEGO MARVELs Avengers DLC - Marvels Ant-Man Pack  (AppID: 449393)
addappid(449393)
addappid(449393, 1, "bbb1b5ac0de7ed0e65d1d11b5e1dec9adc3472fca79eec9e57f6bee35da4a706") -- LEGO MARVELs Avengers DLC - Marvels Ant-Man Pack  - LEGO® MARVEL's Avengers DLC - Marvel’s Ant-Man Pack (449393) Depot
setManifestid(449393, "8567525142084066310", 171141048)
addappid(418224, 1, "8be8696de167c12c028d50eae47a25648a06adb693f1b61efec1a8c4ca9ce247") -- LEGO MARVELs Avengers DLC - Marvels Ant-Man Pack  - Mac DLC10 - Marvel’s Ant-Man Pack (449393)
setManifestid(418224, "1479039934450168328", 161012619)
-- LEGO MARVELs Avengers DLC - Spider-Man Character Pack (AppID: 449394)
addappid(449394)
addappid(449394, 1, "117a008fc6d35f4deda7055e369155a37d2b11c1aea99938ce52a1617ebc04a1") -- LEGO MARVELs Avengers DLC - Spider-Man Character Pack - LEGO® MARVEL's Avengers DLC - Character Pack (449394) Depot
setManifestid(449394, "8457008892073555877", 9917094)
addappid(418227, 1, "66d1abf611b0c704e1f272243546988f06089a26a628a7fd06ef160e755ed9b5") -- LEGO MARVELs Avengers DLC - Spider-Man Character Pack - Mac DLC12 - Character Pack (449394)
setManifestid(418227, "3159750649875786772", 9453407)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(426860) -- LEGO MARVELs Avengers Season Pass