-- 1090630's Lua and Manifest Created by Hubcap Manifest
-- Granblue Fantasy: Versus
-- Created: September 29, 2025 at 15:17:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 53
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1090630) -- Granblue Fantasy: Versus
-- MAIN APP DEPOTS
addappid(1090631, 1, "b5f78f47f569c27ce004a9fbfdded96e4aa71e27aaa6004283b2fcc5ecdaa615") -- GBVS Content
setManifestid(1090631, "3851353714291425015", 10663410991)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1213940) -- Granblue Fantasy Versus - Additional Character Set (Narmaya)
addappid(1213950) -- Granblue Fantasy Versus - Additional Character Set (Beelzebub)
addappid(1254920) -- Granblue Fantasy Versus - Additional Character Set (Soriz)
addappid(1254921) -- Granblue Fantasy Versus - Additional Character Set (Djeeta)
addappid(1254922) -- Granblue Fantasy Versus - Additional Character Set (Zooey)
addappid(1254923) -- Granblue Fantasy Versus - Character Pass 1
addappid(1255070) -- Granblue Fantasy Versus - Color Pack Set 1
addappid(1255071) -- Granblue Fantasy Versus - Color Pack Set 2
addappid(1255072) -- Granblue Fantasy Versus - Color Pack Set 3
addappid(1255073) -- Granblue Fantasy Versus - Color Pack Set 4
addappid(1255074) -- Granblue Fantasy Versus - Color Pack Set 5
addappid(1255075) -- Granblue Fantasy Versus - Color Pack Set 6
addappid(1255080) -- Granblue Fantasy Versus - Additional Stage (Lumacie)
addappid(1255081) -- Granblue Fantasy Versus - Additional Stage (Jewel Resort)
addappid(1400300) -- Granblue Fantasy Versus - Character Pass 2
addappid(1400301) -- Granblue Fantasy Versus - Additional Character Set (Belial)
addappid(1400302) -- Granblue Fantasy Versus - Additional Character Set (Cagliostro)
addappid(1400303) -- Granblue Fantasy Versus - Additional Character Set (Yuel)
addappid(1400304) -- Granblue Fantasy Versus - Additional Character Set (Anre)
addappid(1400305) -- Granblue Fantasy Versus - Additional Character Set (Eustace)
addappid(1400306) -- Granblue Fantasy Versus - Additional Character Set (Seox)
addappid(1400307) -- Granblue Fantasy Versus - Color Pack Set 7
addappid(1400308) -- Granblue Fantasy Versus - Color Pack Set 8
addappid(1400309) -- Granblue Fantasy Versus - Color Pack Set 9
addappid(1400310) -- Granblue Fantasy Versus - Additional Stage (Dydroit Belt)
addappid(1808430) -- Granblue Fantasy Versus - Lobby Avatar (Gold Ship)
addappid(1808431) -- Granblue Fantasy Versus - Additional Character Set (Vira  Avatar Belial)
addappid(1867860) -- Granblue Fantasy Versus - Weapon Skin Set (Gran)
addappid(1867861) -- Granblue Fantasy Versus - Weapon Skin Set (Katalina)
addappid(1867862) -- Granblue Fantasy Versus - Weapon Skin Set (Charlotta)
addappid(1867863) -- Granblue Fantasy Versus - Weapon Skin Set (Lancelot)
addappid(1867864) -- Granblue Fantasy Versus - Weapon Skin Set (Percival)
addappid(1867865) -- Granblue Fantasy Versus - Weapon Skin Set (Ladiva)
addappid(1867866) -- Granblue Fantasy Versus - Weapon Skin Set (Metera)
addappid(1867867) -- Granblue Fantasy Versus - Weapon Skin Set (Lowain)
addappid(1867868) -- Granblue Fantasy Versus - Weapon Skin Set (Ferry)
addappid(1867869) -- Granblue Fantasy Versus - Weapon Skin Set (Zeta)
addappid(1867870) -- Granblue Fantasy Versus - Weapon Skin Set (Vaseraga)
addappid(1867871) -- Granblue Fantasy Versus - Weapon Skin Set (Beelzebub)
addappid(1867872) -- Granblue Fantasy Versus - Weapon Skin Set (Narmaya)
addappid(1867873) -- Granblue Fantasy Versus - Weapon Skin Set (Soriz)
addappid(1867874) -- Granblue Fantasy Versus - Weapon Skin Set (Djeeta)
addappid(1867875) -- Granblue Fantasy Versus - Weapon Skin Set (Zooey)
addappid(1867876) -- Granblue Fantasy Versus - Weapon Skin Set (Belial)
addappid(1867877) -- Granblue Fantasy Versus - Weapon Skin Set (Cagliostro)
addappid(1867878) -- Granblue Fantasy Versus - Weapon Skin Set (Yuel)
addappid(1867879) -- Granblue Fantasy Versus - Weapon Skin Set (Anre)
addappid(1867880) -- Granblue Fantasy Versus - Weapon Skin Set (Eustace)
addappid(1867881) -- Granblue Fantasy Versus - Weapon Skin Set (Seox)
addappid(1867882) -- Granblue Fantasy Versus - Weapon Skin Set (Vira)
addappid(1907950) -- Granblue Fantasy Versus - Weapon Skin Pack 1
addappid(1907951) -- Granblue Fantasy Versus - Weapon Skin Pack 2
addappid(1907952) -- Granblue Fantasy Versus - Weapon Skin Pack 3