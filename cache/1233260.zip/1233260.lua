-- 1233260's Lua and Manifest Created by Hubcap Manifest
-- FAIRY TAIL
-- Created: September 29, 2025 at 11:23:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 62

-- MAIN APPLICATION
addappid(1233260) -- FAIRY TAIL
-- MAIN APP DEPOTS
addappid(1233261, 1, "b78e09baad5d30bf9c0678e42b20b8f8d41a75adae4d3766cdad156a6b383557") -- FAIRY_TAIL
setManifestid(1233261, "6458951679189595317", 6136558912)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1333175) -- FAIRY TAIL Natsus Costume Fairy Tail Team A
addappid(1333176) -- FAIRY TAIL Lucys Costume Fairy Tail Team A
addappid(1333177) -- FAIRY TAIL Grays Costume Fairy Tail Team A
addappid(1333178) -- FAIRY TAIL Erzas Costume Fairy Tail Team A
addappid(1333179) -- FAIRY TAIL Wendys Costume Fairy Tail Team A
addappid(1362080) -- FAIRY TAIL Natsus Costume Special Swimsuit
addappid(1362100) -- FAIRY TAIL Lucys Costume Special Swimsuit
addappid(1362101) -- FAIRY TAIL Erzas Costume Special Swimsuit
addappid(1362102) -- FAIRY TAIL Grays Costume Special Swimsuit
addappid(1362103) -- FAIRY TAIL Wendys Costume Special Swimsuit
addappid(1362104) -- FAIRY TAIL Laxuss Costume Special Swimsuit
addappid(1362105) -- FAIRY TAIL Gajeels Costume Special Swimsuit
addappid(1362106) -- FAIRY TAIL Jellals Costume Special Swimsuit
addappid(1362107) -- FAIRY TAIL Juvias Costume Special Swimsuit
addappid(1362108) -- FAIRY TAIL Mirajanes Costume Special Swimsuit
addappid(1362109) -- FAIRY TAIL Gildartss Costume Special Swimsuit
addappid(1362110) -- FAIRY TAIL Sherrias Costume Special Swimsuit
addappid(1362111) -- FAIRY TAIL Kaguras Costume Special Swimsuit
addappid(1362112) -- FAIRY TAIL Ichiyas Costume Special Swimsuit
addappid(1362113) -- FAIRY TAIL Stings Costume Special Swimsuit
addappid(1362114) -- FAIRY TAIL Rogues Costume Special Swimsuit
addappid(1362115) -- FAIRY TAIL Special Swimsuit Costume Set for 16 Playable Characters
addappid(1362116) -- FAIRY TAIL Natsus Costume Anime Final Season
addappid(1362117) -- FAIRY TAIL Lucys Costume Anime Final Season
addappid(1362118) -- FAIRY TAIL Erzas Costume Anime Final Season
addappid(1362119) -- FAIRY TAIL Grays Costume Anime Final Season
addappid(1362150) -- FAIRY TAIL Wendys Costume Anime Final Season
addappid(1362151) -- FAIRY TAIL Laxuss Costume Anime Final Season
addappid(1362152) -- FAIRY TAIL Gajeels Costume Anime Final Season
addappid(1362153) -- FAIRY TAIL Jellals Costume Anime Final Season
addappid(1362154) -- FAIRY TAIL Juvias Costume Anime Final Season
addappid(1362155) -- FAIRY TAIL Mirajanes Costume Anime Final Season
addappid(1362156) -- FAIRY TAIL Gildartss Costume Anime Final Season
addappid(1362157) -- FAIRY TAIL Sherrias Costume Anime Final Season
addappid(1362158) -- FAIRY TAIL Kaguras Costume Anime Final Season
addappid(1362159) -- FAIRY TAIL Ichiyas Costume Anime Final Season
addappid(1362160) -- FAIRY TAIL Stings Costume Anime Final Season
addappid(1362161) -- FAIRY TAIL Rogues Costume Anime Final Season
addappid(1362162) -- FAIRY TAIL Anime Final Season Costume Set for 16 Playable Characters
addappid(1362163) -- FAIRY TAIL Natsus Costume Dress-Up
addappid(1362164) -- FAIRY TAIL Lucys Costume Dress-Up
addappid(1362165) -- FAIRY TAIL Erzas Costume Dress-Up
addappid(1362166) -- FAIRY TAIL Grays Costume Dress-Up
addappid(1362167) -- FAIRY TAIL Wendys Costume Dress-Up
addappid(1362168) -- FAIRY TAIL Laxuss Costume Dress-Up
addappid(1362169) -- FAIRY TAIL Gajeels Costume Dress-Up
addappid(1362170) -- FAIRY TAIL Jellals Costume Dress-Up
addappid(1362171) -- FAIRY TAIL Juvias Costume Dress-Up
addappid(1362172) -- FAIRY TAIL Mirajanes Costume Dress-Up
addappid(1362173) -- FAIRY TAIL Gildartss Costume Dress-Up
addappid(1362174) -- FAIRY TAIL Sherrias Costume Dress-Up
addappid(1362175) -- FAIRY TAIL Kaguras Costume Dress-Up
addappid(1362176) -- FAIRY TAIL Ichiyas Costume Dress-Up
addappid(1362177) -- FAIRY TAIL Stings Costume Dress-Up
addappid(1362178) -- FAIRY TAIL Rogues Costume Dress-Up
addappid(1362179) -- FAIRY TAIL Dress-Up Costume Set for 16 Playable Characters
addappid(1362180) -- FAIRY TAIL FAIRY TAIL Season Pass
addappid(1362220) -- FAIRY TAIL Additional Friends Set Lyon
addappid(1362221) -- FAIRY TAIL Additional Friends Set Levy
addappid(1362222) -- FAIRY TAIL Additional Friends Set Lisanna  Elfman
addappid(1362223) -- FAIRY TAIL Additional Dungeon Rift in Time and Space
addappid(1362224) -- FAIRY TAIL Very Difficult Requests Set