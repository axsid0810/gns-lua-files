-- 1502970's Lua and Manifest Created by Hubcap Manifest
-- Atelier Sophie: The Alchemist of the Mysterious Book DX
-- Created: September 28, 2025 at 23:28:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1502970) -- Atelier Sophie: The Alchemist of the Mysterious Book DX
-- MAIN APP DEPOTS
addappid(1502971, 1, "fb5fba0d1b9cf2cfd5cce84570192696aaef33ec3606b6e4e0d758b13e8c5b3a") -- Atelier Sophie: The Alchemist of the Mysterious Book DX Content
setManifestid(1502971, "8776610622804473404", 10080762846)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)