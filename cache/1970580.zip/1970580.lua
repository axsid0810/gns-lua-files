-- 1970580's Lua and Manifest Created by Hubcap Manifest
-- Backpack Hero
-- Created: September 28, 2025 at 23:53:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1970580, 1, "f520ab5adecff123f4a796fd9bf559bceec91bbba7c47536c0335599b1fe79b9") -- Backpack Hero
-- MAIN APP DEPOTS
addappid(1970581, 1, "7bae37e1619e3eaf89e2689a47977fe767293487db2dc87eeea151deb59b4e2a") -- Depot 1970581
setManifestid(1970581, "3178627114856544901", 644939191)
addappid(1970582, 1, "47cefda381bf839c765b093c9d27e09a805d90509379e96950ab2b9baf93bfb4") -- Depot 1970582
setManifestid(1970582, "176513439720981009", 1302766470)
addappid(1970583, 1, "6218e47340a54721ed75b10918487fc70956b4005f56d5464f48dacf4ad4ef1d") -- Depot 1970583
setManifestid(1970583, "8957818974901801959", 646251679)