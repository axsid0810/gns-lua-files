-- 1839950's Lua and Manifest Created by Hubcap Manifest
-- Terminator: Dark Fate - Defiance
-- Created: January 20, 2026 at 19:23:55 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 2 (1 excluded)
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1839950) -- Terminator: Dark Fate - Defiance
-- MAIN APP DEPOTS
addappid(1839951, 1, "f8a253a01b8b47e291118b994126a4f5f12fa7146e083b8c0f48b4ad041bae2f") -- Depot 1839951
setManifestid(1839951, "3260276259345089428", 30200568216)
addappid(1839952, 1, "b83da0b0e6b2221774a9c75f43afc8858d66b3cd6de96001dcf565886e8b38d4") -- Depot 1839952
setManifestid(1839952, "1480901871792038467", 7072499)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITH DEDICATED DEPOTS
-- Terminator Dark Fate - Defiance We are Legion (AppID: 3227830)
addappid(3227830)
addappid(3227830, 1, "46a7b11f496997b5b8e36c135cc8371ae061f82f86fec4472b31841743be8a9f") -- Terminator Dark Fate - Defiance We are Legion - Depot 3227830
setManifestid(3227830, "726207669938025595", 36)
-- Terminator Dark Fate - Defiance Uprising (AppID: 3650450)
addappid(3650450)
addappid(3650450, 1, "76c1d6c2843fd680c34962b936d9e31046bdbc46f8ce12cc10f6987494309ba3") -- Terminator Dark Fate - Defiance Uprising - Depot 3650450
setManifestid(3650450, "767593220524574887", 36)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4157110) -- Terminator: Dark Fate - Defiance: Evolution (unreleased)