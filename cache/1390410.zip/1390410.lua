-- 1390410's Lua and Manifest Created by Hubcap Manifest
-- Midnight Fight Express
-- Created: September 30, 2025 at 00:42:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1390410) -- Midnight Fight Express
-- MAIN APP DEPOTS
addappid(1390411, 1, "5b50203d3a7725347707e61fc215b127dc8ad0e20171db61260b0a860df904f1") -- Depot 1390411
setManifestid(1390411, "2241535972425418561", 7173303058)