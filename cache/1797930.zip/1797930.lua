-- 1797930's Lua and Manifest Created by Hubcap Manifest
-- Para Eyes
-- Created: October 02, 2025 at 09:20:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1797930) -- Para Eyes
-- MAIN APP DEPOTS
addappid(1797931, 1, "bc1e2e14a3ab2e88341765e30be5e29763ebbeab7f66129660c8179541d10722") -- Depot 1797931
setManifestid(1797931, "7564414322070493790", 1469639624)