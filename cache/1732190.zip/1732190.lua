-- 1732190's Lua and Manifest Created by Hubcap Manifest
-- FATAL FRAME / PROJECT ZERO: Maiden of Black Water
-- Created: September 29, 2025 at 11:53:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 5
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1732190) -- FATAL FRAME / PROJECT ZERO: Maiden of Black Water
-- MAIN APP DEPOTS
addappid(1732191, 1, "41fbca52fbea25bd47005f1c64a88877acf4621890040a4dd2f54ee07b05e8dd") -- FATAL FRAME / PROJECT ZERO: Maiden of Black Water
setManifestid(1732191, "5426184032901443170", 19729695446)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- FATAL FRAME  PROJECT ZERO MOBW - YuriMiuRen Exclusive Costume Camera Obscura Hat  YuriMiu Exclusive Costume  Witchs Hat (AppID: 1751200)
addappid(1751200)
addappid(1751200, 1, "5ad283afb5d2525d5f7bf5c1c95ad9847aa9be16a9df4f98015ef0adc76b81e5") -- FATAL FRAME  PROJECT ZERO MOBW - YuriMiuRen Exclusive Costume Camera Obscura Hat  YuriMiu Exclusive Costume  Witchs Hat - FATAL FRAME / PROJECT ZERO: MOBW - Yuri/Miu/Ren Exclusive Costume: Camera Obscura Hat & Yuri/Miu Exclusive Costume:  Witch's Hat (1751200) デポ
setManifestid(1751200, "775183834941695855", 47106304)
-- FATAL FRAME  PROJECT ZERO MOBW - Yuri Exclusive Costume Ryza Outfit, Ryza Hat (AppID: 1751201)
addappid(1751201)
addappid(1751201, 1, "b89827dae7308c51c72ff8c69f724f1db76dfefae10b759f846106bb90446bb7") -- FATAL FRAME  PROJECT ZERO MOBW - Yuri Exclusive Costume Ryza Outfit, Ryza Hat - FATAL FRAME / PROJECT ZERO: MOBW - Yuri Exclusive Costume: Ryza Outfit, Ryza Hat (1751201) デポ
setManifestid(1751201, "747587657479076756", 46219200)
-- FATAL FRAME  PROJECT ZERO MOBW - 20th Anniversary Digital Artbook (AppID: 1751203)
addappid(1751203)
addappid(1751203, 1, "4adafabbc0acd89e419fa3d001b3e5145f9c1610b20ea41c589f71c86630359f") -- FATAL FRAME  PROJECT ZERO MOBW - 20th Anniversary Digital Artbook - FATAL FRAME / PROJECT ZERO: MOBW - 20th Anniversary Digital Artbook (1751203) デポ
setManifestid(1751203, "109097717630190306", 4346397270)
-- FATAL FRAME  PROJECT ZERO MOBW - Past Protagonists Costume Set (AppID: 1751204)
addappid(1751204)
addappid(1751204, 1, "07ff8fbe297d5350d7cf72088d7c4363bc7f39f8039601e30a222ab5548c8129") -- FATAL FRAME  PROJECT ZERO MOBW - Past Protagonists Costume Set - FATAL FRAME / PROJECT ZERO: MOBW - Past Protagonists Costume Set (1751204) デポ
setManifestid(1751204, "547659163536929531", 242338064)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1751202) -- FATAL FRAME  PROJECT ZERO MOBW - FATAL FRAME  PROJECT ZERO 20th Anniversary Celebration DLC