-- 3920610's Lua and Manifest Created by Hubcap Manifest
-- FATAL FRAME II: Crimson Butterfly REMAKE
-- Created: June 21, 2026 at 21:12:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 6
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3920610, 1, "8c9b8ce81e2921eea49b102eed1821aa883ad85645ff92115830bb24cbfa0bfc") -- FATAL FRAME II: Crimson Butterfly REMAKE
-- MAIN APP DEPOTS
addappid(3920611, 1, "12bffaedca2f7ee446211ba60b97b8262a19e282d803fde20b020cdd0d8ab780") -- Depot 3920611
setManifestid(3920611, "1113019213164715548", 37566317811)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- FATAL FRAME II Crimson Butterfly REMAKE Digital Art Book  Digital Soundtrack (AppID: 4123380)
addappid(4123380)
addappid(4123380, 1, "373ac671ea014e7cf29c347bbb4f27efa8fb93238f339504fa412757e9bd6b0a") -- FATAL FRAME II Crimson Butterfly REMAKE Digital Art Book  Digital Soundtrack - Depot 4123380
setManifestid(4123380, "2859176425516100251", 1949115876)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4122450) -- FATAL FRAME II Crimson Butterfly REMAKE Pre-Order Bonus Set
addappid(4123350) -- FATAL FRAME II Crimson Butterfly REMAKE Early Purchase Bonus Set
addappid(4123360) -- FATAL FRAME II Crimson Butterfly REMAKE Digital Deluxe Bonus Set
addappid(4123370) -- FATAL FRAME II Crimson Butterfly REMAKE Digital Deluxe Upgrade
addappid(4423570) -- FATAL FRAME II Crimson Butterfly REMAKE x SILENT HILL f Costume Set