-- 4158870's Lua and Manifest Created by Hubcap Manifest
-- Japanese Rural Life Adventure
-- Created: June 09, 2026 at 00:25:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4158870, 1, "e3a7aa174b5b3b29ef17c830fc859f467bbfd4a7d6ccda56b7bfafbbca73cfce") -- Japanese Rural Life Adventure
-- MAIN APP DEPOTS
addappid(4158871, 1, "3572d23e28fe810f631002260bf811383939e1ef9203b5203b93dd0e65375fb0") -- Depot 4158871
setManifestid(4158871, "6290121244943521825", 224787769)