-- 3723310's Lua and Manifest Created by Hubcap Manifest
-- My Cute Roommate 2
-- Created: June 28, 2026 at 14:22:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3723310, 1, "54d4cd0035d36f55533bd488a5dec2b265f2db5579977c1457d57921948ea78a") -- My Cute Roommate 2
-- MAIN APP DEPOTS
addappid(3723311, 1, "aeee58e0a109d82ca3723d48d73b93cffe96b080ebf53e2ce31ba50bf6410b35") -- Depot 3723311
setManifestid(3723311, "983971760765151391", 4809918885)