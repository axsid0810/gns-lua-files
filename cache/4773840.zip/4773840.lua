-- 4773840's Lua and Manifest Created by Hubcap Manifest
-- City Lights Love Bites Season 1 - The Reset
-- Created: July 27, 2026 at 02:24:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4773840) -- City Lights Love Bites Season 1 - The Reset
-- MAIN APP DEPOTS
addappid(4773842, 1, "f4c1c70bc5cff14bc969f7ed32304d0dae894661fc1d0cf67007ccec6dcaa57d") -- Depot 4773842
setManifestid(4773842, "5588522986327233026", 14395604828)