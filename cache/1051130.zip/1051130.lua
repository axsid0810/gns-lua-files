-- 1051130's Lua and Manifest Created by Hubcap Manifest
-- Trial of the Towers
-- Created: October 01, 2025 at 03:42:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0 (1 excluded)
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1051130) -- Trial of the Towers
-- MAIN APP DEPOTS
addappid(1051132, 1, "7b4f5b215c4a886210c045ae1c8f9534b9e4b1d8a665f68a15eb39cb66f541c6") -- Trial of the Towers - Win64
setManifestid(1051132, "6138018399942795482", 354472916)
addappid(1051131, 1, "3fdc449fdd7752264791c9359e7933c04225d7e390998f1ea8ef1def3aa27617") -- Trial of the Towers - Win32
setManifestid(1051131, "8437746374184056606", 323966341)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Trial of the Towers - Support Soundtrack (AppID: 1053050) - missing depot keys
-- addappid(1053050)