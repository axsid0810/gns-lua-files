-- 814000's Lua and Manifest Created by Hubcap Manifest
-- ONE PIECE ODYSSEY
-- Created: September 30, 2025 at 04:50:16 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 14
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(814000) -- ONE PIECE ODYSSEY
-- MAIN APP DEPOTS
addappid(814001, 1, "42d84d2e42b1e4103fb7597c5044385c294167829b1e033d894530ec3e3c4456") -- Depot 814001
setManifestid(814001, "3541244075542598126", 31440053579)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- ONE PIECE ODYSSEY Adventure Expansion Pack (AppID: 1888180)
addappid(1888180)
addappid(1888180, 1, "9b6b1e02076f2b3b11efddeddcf5f205f632842421696481a24be1cbfbd6a46a") -- ONE PIECE ODYSSEY Adventure Expansion Pack - Depot 1888180
setManifestid(1888180, "1333443026720192680", 2321746985)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2004600) -- ONE PIECE ODYSSEY Traveling Outfit Set
addappid(2004601) -- ONE PIECE ODYSSEY Sniper King Outfit Set
addappid(2004602) -- ONE PIECE ODYSSEY Deaths Edge Petite Power Jewelry
addappid(2004603) -- ONE PIECE ODYSSEY TP Auto Regen Petite Jewelry
addappid(2004604) -- ONE PIECE ODYSSEY HP Auto Regen Petite Jewelry
addappid(2004605) -- ONE PIECE ODYSSEY TP Regen Petite Jewelry
addappid(2004606) -- ONE PIECE ODYSSEY Drop Rate Up Petite Jewelry
addappid(2004607) -- ONE PIECE ODYSSEY HP Conversion Petite Jewelry
addappid(2114010) -- ONE PIECE ODYSSEY 100,000 Berries
addappid(2114030) -- ONE PIECE ODYSSEY Adventure Expansion Pack100,000 Berries
addappid(2281180) -- OPO EU E-Commerce Bundle
addappid(2281181) -- OPO EU Retail Bundle
addappid(2282610) -- ONE PIECE ODYSSEY Jewelry Pack