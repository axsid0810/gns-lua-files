-- 2356560's Lua and Manifest Created by Hubcap Manifest
-- Monster Hunter Stories
-- Created: November 10, 2025 at 11:37:30 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2356560) -- Monster Hunter Stories
-- MAIN APP DEPOTS
addappid(2356561, 1, "25a51c9b191133072944947dcbc0425baa8267da1034b8c652067297d0833386") -- Depot 2356561
setManifestid(2356561, "8049987982984778989", 10171124403)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2620130) -- Monster Hunter Stories - Navirous Outfits King and Queen