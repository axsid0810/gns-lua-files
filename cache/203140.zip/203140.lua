-- 203140's Lua and Manifest Created by Hubcap Manifest
-- Hitman: Absolution
-- Created: January 18, 2026 at 06:11:06 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 35
-- Total DLCs: 12
-- Blacklisted Depots: 3
--   Depot 203154: Blacklisted
--   Depot 203155: Blacklisted
--   Depot 203152: Blacklisted

-- MAIN APPLICATION
addappid(203140, 1, "38acff3963fd343d79a2446b320ab99bd1fe6b720f821a6cf76d20557f9f9913") -- Hitman: Absolution
-- MAIN APP DEPOTS
addappid(203141, 1, "dcc91556c4d852727be05a24754a39b6e2e78e084a14b49793d6b4715427bf46") -- Main Content
setManifestid(203141, "4500859568925075151", 24479889842)
addappid(203142, 1, "96c5165b779f74214d9514523e2a3636692362c74415fabbb284f77e4e07d150") -- Executable
setManifestid(203142, "4707517681983701730", 35035648)
addappid(203143, 1, "4672ea1ab6a957bccfcf9e6ac550ca1fc7dcdd96121c1be6cba1650a0c0460c3") -- English
setManifestid(203143, "4234813678723460302", 590389501)
addappid(203144, 1, "719fdaccbaad26c8966202100749c17969c7d54e658ccd618d9f9368ea7e96f5") -- French
setManifestid(203144, "4231952700937855362", 568206127)
addappid(203145, 1, "11878955afcc1ebfb88eeeeef844676a8119f135ca46d09bd5e7940b37b01eef") -- Italian
setManifestid(203145, "6782289881271275500", 623825415)
addappid(203146, 1, "4db5edcc515461e9f48171e88dc0ace8d54171f471958012d48f97f032bd3a43") -- German
setManifestid(203146, "1035791686537171778", 614933734)
addappid(203147, 1, "92cb51cf62bc09e042fd2faa8f6a54951e39db4b3008aa51fc4f07d958dcfb75") -- Spanish
setManifestid(203147, "6762799788960639438", 594837217)
addappid(203148, 1, "d993ebfcfe6d5b7ec92f6a69009675b5d2922e3e5c17c1ca0eb30564f8e07c6f") -- Russian
setManifestid(203148, "1568194848291531205", 620753051)
addappid(203149, 1, "445f59e9639cbd2e8d0e5632e6b8ce7ed69888c6eb1da94483ca435bd07c708a") -- Polish
setManifestid(203149, "1459060224201281287", 598727716)
addappid(203150, 1, "834e05d6d358030dd02e4dd06cf20558280bb7ebf8cd31f3258ab6f54aae1ea7") -- Japanese
setManifestid(203150, "777969866232517818", 3245747990)
addappid(203151, 1, "c655e68c64b2679d1e53be8bf4d4f7c0ff309fab34c209c525fbb5b509c76bbf") -- Turkish
setManifestid(203151, "4927376437833616831", 590389501)
addappid(203153, 1, "23b2010a4d15732743f19b08431a0a0bdc41e428a06045e43395ac3009c8119e") -- EFIGSRPT SKU
setManifestid(203153, "449153452439859666", 8)
addappid(203156, 1, "f2011a5459624885290cfe661e3b5936036e9c18043f1dc9d96ead8cc326d4bb") -- Professional Edition Art Content
setManifestid(203156, "5030393338909761466", 1929369934)
addappid(203157, 1, "1e3c6c2b9f0d9df3b541361bfdcbae5fee53c3accec6c7307c20cd227e5ea9a5") -- Mac Main Content
setManifestid(203157, "3095542515985630150", 22278624122)
addappid(203158, 1, "1839e868888791083cef441013eaa167cbd136f15bfbd68d344dbe9562381ce9") -- Mac Executable
setManifestid(203158, "1360959774907683128", 108650124)
addappid(203159, 1, "1943cb654d595b5a903e76ce94bd8ec685a588cf6db740b5965df2e1ca2d648f") -- Mac English
setManifestid(203159, "2973016662816979377", 590389503)
addappid(266891, 1, "0ceb49aa51639268e82f1dde89a8be52625b0bf376ea770d96183d7f3bdc81c3") -- Mac French
setManifestid(266891, "1978793499008846426", 568206129)
addappid(266892, 1, "6c928b37806a30e202bbdc47aaac89efdb871db68e1f55573d389db89a0ab3ba") -- Mac Italian
setManifestid(266892, "2809413338564448132", 623825417)
addappid(266893, 1, "d5d75d8b47c04d6f1b62e5f267ea6a07817d00d18ade0d284437c4e459701e97") -- Mac German
setManifestid(266893, "9053568959681786426", 614933736)
addappid(266894, 1, "5c278489efd5ce5cbeb1fe3579489a8d03d6dd0173b244234a8ba50777badc7b") -- Mac Spanish
setManifestid(266894, "6687227426442601291", 594837219)
addappid(266895, 1, "9e034c49d8f25be672ca5d409bc4ba9a701eaf685a904e93cf11e7f8f6202c33") -- Mac Russian
setManifestid(266895, "6630339068469590381", 620753053)
addappid(266896, 1, "dd8d8e0f535ac3d6873bd372303c08b5ddb530e42309a724f120ae87c136bddc") -- Mac Polish
setManifestid(266896, "4864616128532435201", 598727718)
addappid(266898, 1, "ba19e7fe17f8c119d2596321638719bfa153fb81c1f92302a2026957d980623f") -- Mac Turkish
setManifestid(266898, "1574341006623937499", 590389503)
addappid(267011, 1, "d834537971cc737a963b9e0de93d9e181c6789bc6d7dec7dd840e1f28102cd94") -- Professional Edition Art Content
setManifestid(267011, "3216158920845093679", 1929369934)
-- DLCS WITH DEDICATED DEPOTS
-- Hitman Absolution - Agency Jagd P22G  (AppID: 216411)
addappid(216411)
addappid(216411, 1, "1f2f85d1ec693780d4a8726f7e47206a90d8d0b1db4b6f4193cf145fbae74b6d") -- Hitman Absolution - Agency Jagd P22G  - Agency Jagd P22G
setManifestid(216411, "8952006441057630829", 510202)
-- Hitman Absolution - Agency SPS 12 (AppID: 216412)
addappid(216412)
addappid(216412, 1, "3f7dacd7710f8dcdad1bf0deda65f3d3bee916a8b4bb8c4dfeb558e63fedd60c") -- Hitman Absolution - Agency SPS 12 - Agency SPS 12
setManifestid(216412, "7653478202657417840", 510369)
-- Hitman Absolution - Agency HX UMP (AppID: 216413)
addappid(216413)
addappid(216413, 1, "60c47f77740879ddf6bbd89e4923503e8e911b29471fd5487021dc7c665e44cc") -- Hitman Absolution - Agency HX UMP - Agency HX UMP
setManifestid(216413, "7587332490090392983", 510256)
-- Hitman Absolution - Bartoli Custom Gun (AppID: 216414)
addappid(216414)
addappid(216414, 1, "b36ac076bbb8f818572a92889a6e3cd165a75992fb67586ae1144ebd06b5bf10") -- Hitman Absolution - Bartoli Custom Gun - Bartoli Custom Gun
setManifestid(216414, "2721849911120397445", 8428916)
-- Hitman Absolution - Krugermeier 2-2 Gun (AppID: 216415)
addappid(216415)
addappid(216415, 1, "12645550cce3e9403a0a104081b62dd2502e348d889c005f1790742a52936f54") -- Hitman Absolution - Krugermeier 2-2 Gun - Krugermeier 2-2 Gun
setManifestid(216415, "1808872715655678108", 8327962)
-- Hitman Absolution - Bronson M1928 Gun (AppID: 216416)
addappid(216416)
addappid(216416, 1, "3024db8f0d9b41325a7eb0c4d1346395a4ab75a85b935903105de6c16894fcdd") -- Hitman Absolution - Bronson M1928 Gun - Bronson M1928 Gun
setManifestid(216416, "1016875605573705949", 12303258)
-- Hitman Absolution - High Tech Disguise  (AppID: 216417)
addappid(216417)
addappid(216417, 1, "c8c1e2bce758d7996b9d6386cf439351a717e05390ff889464bf8ab66542de36") -- Hitman Absolution - High Tech Disguise  - High Tech Disguise
setManifestid(216417, "8550191879894420067", 60292720)
-- Hitman Absolution - High Roller Disguise (AppID: 216418)
addappid(216418)
addappid(216418, 1, "b134fe02aafa3baccc831ac596a760fde5d8dbde4affc8c11f0e452e96040ae1") -- Hitman Absolution - High Roller Disguise - High Roller Disguise
setManifestid(216418, "7565992362606627229", 44055001)
-- Hitman Absolution - Public Enemy Disguise (AppID: 216419)
addappid(216419)
addappid(216419, 1, "612e4283165d195e3df60a1228fd97344a9a0ba9f6cfda8166655feee3db2567") -- Hitman Absolution - Public Enemy Disguise - Public Enemy Disguise
setManifestid(216419, "1721955041182413140", 44221646)
-- Hitman Absolution - Deus Ex (Adam Jensen) Disguise (AppID: 216420)
addappid(216420)
addappid(216420, 1, "a92a82a61b550f2b2513b1d708f3f22f5a74ae083128642620c89cc691f149f6") -- Hitman Absolution - Deus Ex (Adam Jensen) Disguise - Deus Ex (Adam Jensen) Disguise
setManifestid(216420, "4511782306596923476", 42822423)
-- Hitman Absolution - Deus Ex (Adam Jensen) Handgun (AppID: 216421)
addappid(216421)
addappid(216421, 1, "2b03d7598c37d8620bc23d4f960f70438eadcda70624bb8d6da7c0cd1fd30b2b") -- Hitman Absolution - Deus Ex (Adam Jensen) Handgun - Deus Ex (Adam Jensen) Handgun
setManifestid(216421, "9184806344898357029", 8825889)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(216429) -- Hitman Absolution - Sniper Challenge Unlock
addtoken(216429, "17880548749638493481")