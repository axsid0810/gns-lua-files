-- 896950's Lua and Manifest Created by Hubcap Manifest
-- Jumanji: The Video Game
-- Created: September 29, 2025 at 20:15:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(896950) -- Jumanji: The Video Game
-- MAIN APP DEPOTS
addappid(896951, 1, "8876b7c9d3dc237a3763c90708ba29ffbbc4e9dba49a6e599182f3b7fcca5a7f") -- Jumanji Content
setManifestid(896951, "5735712851545575007", 2589837278)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)