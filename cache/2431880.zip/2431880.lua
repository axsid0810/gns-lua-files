-- 2431880's Lua and Manifest Created by Hubcap Manifest
-- High Sea Saga DX
-- Created: September 29, 2025 at 17:49:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2431880) -- High Sea Saga DX
-- MAIN APP DEPOTS
addappid(2431881, 1, "5ae964a51726dfa3bf17c04c59f3f2bca50dc7a8132dc6b90d47501160dd5d1a") -- Depot 2431881
setManifestid(2431881, "6260057607116683369", 84234503)