-- 312610's Lua and Manifest Created by Hubcap Manifest
-- METAL SLUG X
-- Created: September 30, 2025 at 00:30:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(312610) -- METAL SLUG X
-- MAIN APP DEPOTS
addappid(312611, 1, "7f1d0f535b6ae360297a32d8be65cde7b69860a123f019983d3b56e37933df8a") -- Metal Slug X Content
setManifestid(312611, "3206672683359619399", 104375382)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)