-- 202750's Lua and Manifest Created by Hubcap Manifest
-- Alan Wake's American Nightmare
-- Created: September 28, 2025 at 21:56:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(202750) -- Alan Wake's American Nightmare
-- MAIN APP DEPOTS
addappid(202754, 1, "1795197bdc2c91b59cf4a33eeb2f44d42376587b55e17385832546e2405bc2e6") -- alan wakes american nightmare thirdparty
setManifestid(202754, "5471547335244149003", 108169848)
addappid(202753, 1, "af0aefc9555f14239125448febf8928816e84f3c684157f00d214315aa53e858") -- alan wakes american nightmare videos
setManifestid(202753, "6872456980209314713", 1133136180)
addappid(202752, 1, "14dd7e9111b050b18a408013cce986c4e09912a1f13ba4b922d818ba6712b131") -- alan wakes american nightmare datas
setManifestid(202752, "1417488794446718668", 1217681172)
addappid(202751, 1, "8f0773b538465fbf739ab1c93f7a7139d3d1de24817d4631bf06ba3bef32f3dd") -- alan wakes american nightmare exeandshaders
setManifestid(202751, "8499727884355977081", 28096012)