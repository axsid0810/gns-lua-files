-- 4324480's Lua and Manifest Created by Hubcap Manifest
-- Dirty Business
-- Created: July 22, 2026 at 18:54:32 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4324480, 1, "01ba04adf015365a20ef646239cef96ee73af65f613f36aa4a14b9586576c6e7") -- Dirty Business
-- MAIN APP DEPOTS
addappid(4324481, 1, "c5df4573fdf1724349b33953fdf5ddcaa8ad0d98180aa74bf5ff92f38c5376de") -- Depot 4324481
setManifestid(4324481, "132175798953354813", 9000692194)