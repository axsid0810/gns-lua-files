-- 3112280's Lua and Manifest Created by Hubcap Manifest
-- Reclaiming the Lost
-- Created: June 29, 2026 at 12:13:12 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3112280, 1, "99a12b2be7c8762fd44354b6658013759934a65da37fb0737d8fa0a75349a245") -- Reclaiming the Lost
-- MAIN APP DEPOTS
addappid(3112281, 1, "8a1787ce374cb2ba72de205cdebd655424fbba6db8a652615f408c873ff9f5c9") -- Depot 3112281
setManifestid(3112281, "6697050108002742371", 10014616300)