-- 285190's Lua and Manifest Created by Hubcap Manifest
-- Warhammer 40,000: Dawn of War III
-- Created: January 20, 2026 at 14:24:52 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 10
-- Total DLCs: 2
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(285190, 1, "de1c423b629ff2536b640e828eec5482caf9fc38a5012146fa536cea66e58103") -- Warhammer 40,000: Dawn of War III
-- MAIN APP DEPOTS
addappid(285191, 1, "61cb95500f7f309deee0cf3f496e1aa21591997a0817a79cec79c47a9b6ed6f8") -- P28 Content
setManifestid(285191, "1493000756667599616", 32195728362)
addappid(285193, 1, "19eda48eebf52834395dd54715e03cce001bbb7df4c17b106d6928c5f1ecab31") -- Mac Binary DoW3
setManifestid(285193, "6951964705395149396", 232526913)
addappid(285194, 1, "4be86101012a3ad449bb704d72bae7c38850c70a28860269389fd4af0fdfca0f") -- Mac Data DoW3
setManifestid(285194, "4857886706421179388", 31852359164)
addappid(285195, 1, "4cb0baf3198cb62f3c83ad15f54a2091e5ba089924fab46a6ce1dffc4e24b121") -- Linux Binary DoW3
setManifestid(285195, "9099903196937461883", 925941189)
addappid(285196, 1, "ba2b65c99a218abef8cd59322dde74cd3b02de61e010db33a6aa666674c6526b") -- Linux Data DoW3
setManifestid(285196, "7838188776009579464", 31881381774)
addappid(285199, 1, "1dfd5e0d10b716f1f8e0de351eaccf4cdb5c03158038641b3b4f5d31b9952b3e") -- Linux - Override Depot
setManifestid(285199, "7551428865308164089", 27903)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
-- DLCS WITH DEDICATED DEPOTS
-- Warhammer 40,000 Dawn of War III - Official Game Soundtrack (AppID: 607143)
addappid(607143)
addappid(607143, 1, "c63b76c63fd6d9fddd163fb5a2dfefc6adbdf2f7bd392eb6348b0112557d4a38") -- Warhammer 40,000 Dawn of War III - Official Game Soundtrack - Warhammer 40,000 Dawn of War III - Soundtrack
setManifestid(607143, "8597417948451381025", 127921585)
addappid(285197, 1, "6b9ecc2d03705accfffb41de29d373909f48b1467ab91e8523c74d616d5fe4f8") -- Warhammer 40,000 Dawn of War III - Official Game Soundtrack - Mac Soundtrack DoW3
setManifestid(285197, "1802830372562760473", 127921585)
addappid(285198, 1, "b75aad8ee8af1d26b86a0ec01ef7ccd2cb13306a472405cf01b0c5fba1e77ae4") -- Warhammer 40,000 Dawn of War III - Official Game Soundtrack - Linux Soundtrack DoW3
setManifestid(285198, "1973639673047480020", 127921585)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(626800) -- Warhammer 40,000 Dawn of War III - Skin Pack - Masters of War
-- EMPTY DEPOTS (no content on any branch)
-- addappid(285192) -- Depot 285192 (empty depot)