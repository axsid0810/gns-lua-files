-- 1122340's Lua and Manifest Created by Hubcap Manifest
-- Chef Life: A Restaurant Simulator
-- Created: March 16, 2026 at 16:51:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 4
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1122340, 1, "2c0b3fd482246ad9caa7c8154550fa4e41a2c55cc67c370e196af164b8610714") -- Chef Life: A Restaurant Simulator
-- MAIN APP DEPOTS
addappid(1122341, 1, "665ebc24cc4faf83b747a90a218c20b4b8831ec9278ab2e29fe344da7aa4005a") -- Depot 1122341
setManifestid(1122341, "1266563124938887346", 3368298902)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Chef Life - Tokyo Delight (AppID: 2608340)
addappid(2608340)
addappid(2608340, 1, "fc6646306b4a88da27523925990093b2c4291951ce72abd33cc0b8e7436abee0") -- Chef Life - Tokyo Delight - Depot 2608340
setManifestid(2608340, "843877125311523294", 358766814)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1788350) -- Chef Life - BON APPTIT PACK						
addappid(1788351) -- Chef Life - AL FORNO PACK
addappid(2608330) -- Chef Life - Cooking Lab