-- 4242290's Lua and Manifest Created by Hubcap Manifest
-- SPITE: Taking the Boss's Wife, Sister and Mother
-- Created: July 24, 2026 at 12:03:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4242290, 1, "c08a0ec4a1c1e7ef348fbf139936a09bae91f8062f132765446b70b2244f2ab4") -- SPITE: Taking the Boss's Wife, Sister and Mother
-- MAIN APP DEPOTS
addappid(4242291, 1, "193f712b8c3e06b1d21b9073523678087406578590945666d73079a628e08f6c") -- Depot 4242291
setManifestid(4242291, "9156360330770772421", 1151108082)