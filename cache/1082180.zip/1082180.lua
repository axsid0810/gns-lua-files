-- 1082180's Lua and Manifest Created by Hubcap Manifest
-- TT Isle of Man: Ride on the Edge 2
-- Created: October 01, 2025 at 04:10:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1082180) -- TT Isle of Man: Ride on the Edge 2
-- MAIN APP DEPOTS
addappid(1082181, 1, "7de4b3132732a7f661ed50c98e58dccf533e87d7280c749a8b5a00ff13036388") -- TT Isle of Man - Ride on the Edge 2 - All Languages
setManifestid(1082181, "5123329659964927792", 17068793406)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1189870) -- TT Isle of Man 2 Ducati 900SS TT - Mike Hailwood 1978
addappid(1189871) -- TT Isle of Man 2 Pro Newcomer Pack