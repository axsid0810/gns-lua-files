-- 3372060's Lua and Manifest Created by Hubcap Manifest
-- Hell Maiden
-- Created: July 17, 2026 at 20:50:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3372060) -- Hell Maiden
-- MAIN APP DEPOTS
addappid(3372061, 1, "f74389c861c791ea4a33813b7575ac42a7abca2578013a775bc62acb2e89003f") -- Depot 3372061
setManifestid(3372061, "2516222553703688215", 4116293311)