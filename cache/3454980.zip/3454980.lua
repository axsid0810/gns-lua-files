-- 3454980's Lua and Manifest Created by Hubcap Manifest
-- Mortal Kombat: Legacy Kollection
-- Created: April 29, 2026 at 01:21:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3454980, 1, "bf3c14faab31d795ec30ad6fa4cc528ef044c7a7e0974c31ea5b50a3745d5cff") -- Mortal Kombat: Legacy Kollection
-- MAIN APP DEPOTS
addappid(3454981, 1, "a411f1c5ad0ff5f71b4e8aab564c7fd8fbd44ac3598a07480f2af377bcf65a9f") -- Depot 3454981
setManifestid(3454981, "773238418824038723", 13719971159)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)