-- 1547000's Lua and Manifest Created by Hubcap Manifest
-- Grand Theft Auto: San Andreas - The Definitive Edition
-- Created: July 10, 2026 at 07:36:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1547000, 1, "ca7f99c2b9d94c16db93def0b731d526d31af35942c4737a9706cfdb3849a9ad") -- Grand Theft Auto: San Andreas - The Definitive Edition
-- MAIN APP DEPOTS
addappid(1547001, 1, "625ab457b256e557dc28337fec8a01b39731624ee6008b92670ac977c2691806") -- Depot 1547001
setManifestid(1547001, "6814041191190748315", 20004627540)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(1899671, 1, "b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b") -- RGL/SC Content (Shared from App 1899670)
setManifestid(1899671, "1378788310039702778", 239518253)