-- 1805110's Lua and Manifest Created by Hubcap Manifest
-- Solarpunk
-- Created: July 03, 2026 at 09:13:44 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1805110, 1, "e6a44c62ca28e1e3721a8208cf51283d071905e9e160894666ebe07dbd3c841a") -- Solarpunk
-- MAIN APP DEPOTS
addappid(1805111, 1, "c5241defefa1914cda91f5f5949ef7a14cf01e428d6de753f4e398eff41a632f") -- Depot 1805111
setManifestid(1805111, "6483188310386508280", 2344924694)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Solarpunk  The Lost Compass (Story Novel) (AppID: 4668630)
addappid(4668630)
addappid(4668631, 1, "0f8807c47861f68f2a1190bdc12707cf161c7800e47c547c473793e714a060ef") -- Solarpunk  The Lost Compass (Story Novel) - Depot 4668631
setManifestid(4668631, "5314438977656254847", 5197695)
-- Solarpunk  Official Book (AppID: 4668720)
addappid(4668720)
addappid(4668721, 1, "9e0e0cb216c26305c299ca3a0f91b1e57f0b75fd9fc569eeeb03f7fc8c40b536") -- Solarpunk  Official Book - Depot 4668721
setManifestid(4668721, "9221689233171475641", 64518703)