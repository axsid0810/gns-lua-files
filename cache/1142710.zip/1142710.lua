-- 1142710's Lua and Manifest Created by Hubcap Manifest
-- Total War: WARHAMMER III
-- Created: July 30, 2026 at 00:47:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 52
-- Total DLCs: 63
-- Shared Depots: 6

-- MAIN APPLICATION
addappid(1142710, 1, "ea64ef77605ae9352273e58066c4eeb8f461b8754e74e777fe291eadfc198b8f") -- Total War: WARHAMMER III
-- MAIN APP DEPOTS
addappid(1142711, 1, "ceca36efa000ee6431388ab086221aa72bb202dd8584a6c67e7e370a0b647e07") -- Depot 1142711
setManifestid(1142711, "5218949771588546813", 303851614)
addappid(1142712, 1, "305eb94a277165cc8f9e260016c8cacb52164ee5cbd10bec417ab3e298827804") -- Depot 1142712
setManifestid(1142712, "1959622576716276016", 90025045213)
addappid(1142713, 1, "adfd66adb2d6907493709244a246b6e6081a9c328240a9cb5e59b62b793a441f") -- Depot 1142713
setManifestid(1142713, "6088472991362806035", 2)
addappid(1142714, 1, "fc50835c8f532aa19375891b494905559ab374571c0ddbec6a0c78e8db3660d9") -- Depot 1142714
setManifestid(1142714, "3622264683308117676", 2)
addappid(1142715, 1, "0cd816d8e7b01f1c194b88f7efc731502e9184609b17f2c6bd66d8b53043026a") -- Depot 1142715
setManifestid(1142715, "1459637335183049178", 2)
addappid(1142716, 1, "0799c85e9c521504786dc75bd7a862466df5b3894b3e27f81070123990a8473d") -- Depot 1142716
setManifestid(1142716, "6710079216484448409", 2)
addappid(1142717, 1, "537862ddc7cd8886667bcbc3d82a726fc6f68616976c214e9d6030b4fabf32ee") -- Depot 1142717
setManifestid(1142717, "7071982132288265381", 2)
addappid(1142718, 1, "a5cc590d2995a39561388dd2e1d8efa01c69748f3df3bd04fb340b20690dfa85") -- Depot 1142718
setManifestid(1142718, "6939909223456557190", 2)
addappid(1142719, 1, "dd954a4e55d5208344f5c4ca1c551ce780644a84fb3b734ce32bcac872965238") -- Depot 1142719
setManifestid(1142719, "5353395848903157963", 2)
addappid(1143180, 1, "1f58c3d8a00212a789e6419b5db444be73a9b7152a189ee1ccc8c92173a0b83d") -- Depot 1143180
setManifestid(1143180, "4128327580205674160", 2)
addappid(1143181, 1, "a184976c1907a6c92b7c793c1733a9a3a5920dfa0de1be284df82d1c74de68fc") -- Depot 1143181
setManifestid(1143181, "1426222503569890400", 2)
addappid(1143182, 1, "ebd020e4428d26090c04db46db2e2b3a9d1e8ea3adcfaee0550135f64ae9a46d") -- Depot 1143182
setManifestid(1143182, "5459469807500853556", 2)
addappid(1143183, 1, "7735d95f0e5b7685b6c187e27847818fa0411877139986d96af201b5884e200a") -- Depot 1143183
setManifestid(1143183, "5730481803774042745", 2)
addappid(1143184, 1, "15217b338d29dc1d6fd3bad65b62cad04a657e15f52d9a52a4050e43d6df7cbd") -- Depot 1143184
setManifestid(1143184, "3461348633807822835", 2)
addappid(1143185, 1, "c4ca1e70a50588b96dd4482a69602fcc90f0abaa43ca785791c4d734d1dc2773") -- Depot 1143185
setManifestid(1143185, "2554965331021559023", 2)
addappid(1143186, 1, "be770448d65e746d8f0b679b03f35e4fc9408c7ab4c86ca9bb7e536dd8946cb7") -- Depot 1143186
setManifestid(1143186, "2187037487878938423", 267185111)
addappid(1143187, 1, "ed520bb1db7b6fcdd19596248b6865fd846fd0455632ccee50b500fa329de68b") -- Depot 1143187
setManifestid(1143187, "695302589570521092", 90040452386)
addappid(1143188, 1, "96658cd71559472857e0bb49ffa7b2745a3e159f636560d1c34ff71ead460b6d") -- Depot 1143188
setManifestid(1143188, "6066311981778953823", 2)
addappid(1143189, 1, "370d8981a34eb886e4e5c03536f711c7a33c59ab8dfd13712ea49dc8dd5c0c8b") -- Depot 1143189
setManifestid(1143189, "6467678122386685900", 2)
addappid(1143190, 1, "12b8478389a695c444fd6a82689af0c5662d88f41016decb4414bf4100716225") -- Depot 1143190
setManifestid(1143190, "364914668255535544", 2)
addappid(1143191, 1, "d3e739626ca589ca8263f8f9bc824bc276286cacd50b070029823b701463ef9c") -- Depot 1143191
setManifestid(1143191, "1207667369458607011", 2)
addappid(1143192, 1, "2910878855aaeef8046fc9d5024f52a8f71fa96571f8bb58786f58b9af08b67e") -- Depot 1143192
setManifestid(1143192, "3778376391359440840", 2)
addappid(1143193, 1, "6f4befb94e71a20a7e3b22f1439672c31c29d944bda957c57f106e71a19a55aa") -- Depot 1143193
setManifestid(1143193, "8942302147480374052", 2)
addappid(1143194, 1, "44124270857d9aa8a1fd91b0e370949cf4a3163bd12b712842f22f7184bf447f") -- Depot 1143194
setManifestid(1143194, "5126539716238709455", 2)
addappid(1143195, 1, "239bb3205e5c96ec1b3a0bc8cc0d5f7bc6ce365b57214deef36fa17899b66024") -- Depot 1143195
setManifestid(1143195, "771064496516762201", 2)
addappid(1143196, 1, "7bdf9d040b0a80f814773c6edeb342ab3f934053dc96b2de419ea0c8396ccbe1") -- Depot 1143196
setManifestid(1143196, "2718853160183746301", 2)
addappid(1143197, 1, "ac06f80c33642583d7ed1dadaa5987e357c981e295d62a049da462f85907d7e1") -- Depot 1143197
setManifestid(1143197, "3692112954324696121", 2)
addappid(1143198, 1, "0ffa1cbba216300709d78f364eef45458800a58dd2b0f916092ab402c519f56c") -- Depot 1143198
setManifestid(1143198, "2238121640359557808", 2)
addappid(1143199, 1, "7604c1fa4d31bec7ae8f9f2ecb701039a21ff26fe9f9c789393c7a44069c5c8b") -- Depot 1143199
setManifestid(1143199, "8596645411829590099", 2)
addappid(1143200, 1, "9fb0e31a9a954adce4bfeb41e639e38ecf8eddabd85a6b9545af696545cdd060") -- Depot 1143200
setManifestid(1143200, "8852481854321348409", 2)
addappid(1143202, 1, "3716a5301c2acb6ccb9bf67510fcf0c64231c3f643f1727a86e7863169925df0") -- Depot 1143202
setManifestid(1143202, "6023881527479714924", 464791358)
addappid(1143203, 1, "4e648a4bc46ff3527e75a81d672762a4f9d95904ac2ced427be01e765dc3db3b") -- Depot 1143203
setManifestid(1143203, "5496045040652327789", 90040452386)
addappid(1143204, 1, "9ad367d556bcb0016eabf25357cb041da8996f94d247588c321be1e1ed2c03db") -- Depot 1143204
setManifestid(1143204, "6939641391183274776", 2)
addappid(1143205, 1, "1cb1dc2f47727c58e81626b6f9c2897285ab8935db6db79111fa6a786eb88542") -- Depot 1143205
setManifestid(1143205, "6208995646661753065", 2)
addappid(1143206, 1, "af967f1cfb846d1945c56f94e72fa2c12f05c11d43b29acf3a0a65ca5b663e4f") -- Depot 1143206
setManifestid(1143206, "7836086091270588386", 2)
addappid(1143207, 1, "d539e370787fc554b2080ebaf4f6fef44ac6c6f46453892f01321d281845c16e") -- Depot 1143207
setManifestid(1143207, "2421308164937768555", 2)
addappid(1143208, 1, "53159ec4b75b8c4c0f1ae98038fa9cf1e8caee24d8a9727764200e89a93e6403") -- Depot 1143208
setManifestid(1143208, "7597068363122553966", 2)
addappid(1143209, 1, "07c906ac7f767428dc5ac06f7ca44f108cc08df8bb46225d02176ed477394069") -- Depot 1143209
setManifestid(1143209, "8581721147287126064", 2)
addappid(1143210, 1, "58a7f65b756deafba94bab47f6eb7d0e2c7683be4a1581ad95f059e6375d3b1d") -- Depot 1143210
setManifestid(1143210, "8975037473306021053", 2)
addappid(1143211, 1, "27aff687d5ea14ff74f972944ae90cfcae8a2d2a27f5439fa480d3be3111ad2d") -- Depot 1143211
setManifestid(1143211, "1290870284547823106", 2)
addappid(1143212, 1, "7c045ff1a0d42a1b983588dfb84d2aad265a70cbb435b1ee118b2c32ef193715") -- Depot 1143212
setManifestid(1143212, "3138871688519306424", 2)
addappid(1143213, 1, "38b00bf283e615f6fcdccd3e466e6ea56c23e9ce041c910c2c6f3c2dac21ad0c") -- Depot 1143213
setManifestid(1143213, "2239464022168345810", 2)
addappid(1143214, 1, "d9421a81982d1debc4ede56db328ae1496ef5bd97ae80be65e87e432839b8a25") -- Depot 1143214
setManifestid(1143214, "7208272623556572908", 2)
addappid(1143215, 1, "e31362e142e89fe457e497eb27917c37ecee4e58b343e56e1f0f2b2a4a534246") -- Depot 1143215
setManifestid(1143215, "8950676985659340451", 2)
addappid(1143216, 1, "020cacb5cdbee1d62f84b532e29e1a5f7b5a105b6ffbc856773a2f48d3e529fc") -- Depot 1143216
setManifestid(1143216, "7688045990442624232", 2)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Total War WARHAMMER III - Blood for the Blood God III (AppID: 1374300)
addappid(1374300)
addappid(1374300, 1, "fd608c58eb76cbd1822c0ef899bddcf9548a386c06530234942970c7f172e846") -- Total War WARHAMMER III - Blood for the Blood God III - Depot 1374300
setManifestid(1374300, "866517638047156002", 62115139)
addappid(1143201, 1, "b2e15305f5fab46302258f8e7209235c196bb9d64c0436f414aaf881ae229ffb") -- Total War WARHAMMER III - Blood for the Blood God III - Depot 1143201
setManifestid(1143201, "7409023150596106190", 57117473)
addappid(1143217, 1, "2b459ab249153f0b65c1592212d9c1f6e9cf94a359fc4ef7cab15b782aceee68") -- Total War WARHAMMER III - Blood for the Blood God III - Depot 1143217
setManifestid(1143217, "7988827090490807819", 57117473)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1670540) -- Total War WARHAMMER III - Ogre Kingdoms
addappid(1824060) -- Total War WARHAMMER III - Champions of Chaos
addappid(1834020) -- Total War WARHAMMER III - Chaos Warriors
addappid(1834021) -- Total War WARHAMMER III - Blood for the Blood God
addappid(1834022) -- Total War WARHAMMER III - Call of the Beastmen
addappid(1834023) -- Total War WARHAMMER III - The Grim and the Grave
addappid(1834024) -- Total War WARHAMMER III - Wurrzag
addappid(1834025) -- Total War WARHAMMER III - The King and the Warlord
addappid(1834026) -- Total War WARHAMMER III - Grombrindal The White Dwarf
addappid(1834027) -- Total War WARHAMMER III - Realm of The Wood Elves
addappid(1834030) -- Total War WARHAMMER III - Bretonnia
addappid(1834031) -- Total War WARHAMMER III - Isabella von Carstein
addappid(1834032) -- Total War WARHAMMER III - Krell
addappid(1834033) -- Total War WARHAMMER III - Norsca
addappid(1834034) -- Total War WARHAMMER III - 30th Anniversary Regiments
addappid(1834035) -- Total War WARHAMMER III - Jade Wizard
addappid(1834036) -- Total War WARHAMMER III - Grey Wizard
addappid(1834037) -- Total War WARHAMMER III - Rise of the Tomb Kings
addappid(1834038) -- Total War WARHAMMER III - Tretch Craventail
addappid(1834039) -- Total War WARHAMMER III - The Queen  The Crone
addappid(1834040) -- Total War WARHAMMER III - Steps of Isha
addappid(1834041) -- Total War WARHAMMER III - Alith Anar
addappid(1834042) -- Total War WARHAMMER III - Bone Giant
addappid(1834043) -- Total War WARHAMMER III - Curse of the Vampire Coast
addappid(1834044) -- Total War WARHAMMER III - Lokhir Fellheart
addappid(1834045) -- Total War WARHAMMER III - The Prophet  The Warlock
addappid(1834046) -- Total War WARHAMMER III - Tiktaqto
addappid(1834047) -- Total War WARHAMMER III - Amethyst Wizard
addappid(1834048) -- Total War WARHAMMER III - The Hunter and the Beast
addappid(1834049) -- Total War WARHAMMER III - Gor-Rok
addappid(1834050) -- Total War WARHAMMER III - Gotrek  Felix
addappid(1834051) -- Total War WARHAMMER III - The Shadow  The Blade
addappid(1834052) -- Total War WARHAMMER III - Repanse de Lyonesse
addappid(1834053) -- Total War WARHAMMER III - The Warden  The Paunch
addappid(1834054) -- Total War WARHAMMER III - Imrik
addtoken(1834054, "6221631525968037575")
addappid(1834055) -- Total War WARHAMMER III - Black Orc Big Boss
addappid(1834056) -- Total War WARHAMMER III - Catchweb Spidershrine
addappid(1834057) -- Total War WARHAMMER III  The Twisted  The Twilight
addappid(1834058) -- Total War WARHAMMER III - Skaven Chieftain
addappid(1834060) -- Total War WARHAMMER III  Glade Captain
addappid(1834061) -- Total War WARHAMMER III - Rakarth
addappid(1834062) -- Total War WARHAMMER III  The Silence  The Fury
addappid(1834063) -- Total War WARHAMMER III - Blood for the Blood God II
addappid(1834064) -- Total War WARHAMMER III - Thorek Ironbrow
addappid(1834065) -- Total War WARHAMMER III - Great Bray Shaman
addappid(1834066) -- Total War WARHAMMER III - Ogre Mercenaries
addappid(2059190) -- Total War WARHAMMER III - Forge of the Chaos Dwarfs	
addappid(2325830) -- Total War WARHAMMER III  Shadows of Change
addappid(2325832) -- Total War WARHAMMER III - Elspeth  Thrones of Decay
addappid(2574900) -- Total War WARHAMMER III - Gorbad  Omens of Destruction
addappid(2891700) -- Total War WARHAMMER III - Tamurkhan  Thrones of Decay
addappid(2891710) -- Total War WARHAMMER III - Malakai  Thrones of Decay
addappid(3130740) -- Total War WARHAMMER III - Golgfag  Omens of Destruction
addappid(3130750) -- Total War WARHAMMER III - Skulltaker  Omens of Destruction
addappid(3301110) -- Total War WARHAMMER III - The Changeling  Shadows of Change
addappid(3301120) -- Total War WARHAMMER III - Yuan Bo  Shadows of Change
addappid(3301130) -- Total War WARHAMMER III - Mother Ostankya  Shadows of Change
addappid(3450960) -- Total War WARHAMMER III - Aislinn  Tides of Torment
addappid(3450970) -- Total War WARHAMMER III - Sayl  Tides of Torment
addappid(3450980) -- Total War WARHAMMER III - Dechala  Tides of Torment
addappid(3858050) -- Total War WARHAMMER III - UPGRADE PACK
addappid(4399460) -- Total War WARHAMMER III - Bhashiva  Character Pack
-- FORCE-ADDED DLCS (BYPASSES ALL VALIDATION)
addappid(1834020) -- Total War: WARHAMMER III - Chaos Warriors
addappid(1834021) -- Total War: WARHAMMER III - Blood for the Blood God
addappid(1834022) -- Total War: WARHAMMER III - Call of the Beastmen
addappid(1834023) -- Total War: WARHAMMER III - The Grim and the Grave
addappid(1834024) -- Total War: WARHAMMER III - Wurrzag
addappid(1834025) -- Total War: WARHAMMER III - The King and the Warlord
addappid(1834026) -- Total War: WARHAMMER III - Grombrindal The White Dwarf
addappid(1834027) -- Total War: WARHAMMER III - Realm of The Wood Elves
addappid(1834030) -- Total War: WARHAMMER III - Bretonnia
addappid(1834031) -- Total War: WARHAMMER III - Isabella von Carstein
addappid(1834032) -- Total War: WARHAMMER III - Krell
addappid(1834033) -- Total War: WARHAMMER III - Norsca
addappid(1834034) -- Total War: WARHAMMER III - 30th Anniversary Regiments
addappid(1834035) -- Total War: WARHAMMER III - Jade Wizard
addappid(1834036) -- Total War: WARHAMMER III - Grey Wizard
addappid(1834037) -- Total War: WARHAMMER III - Rise of the Tomb Kings
addappid(1834038) -- Total War: WARHAMMER III - Tretch Craventail
addappid(1834039) -- Total War: WARHAMMER III - The Queen & The Crone
addappid(1834040) -- Total War: WARHAMMER III - Steps of Isha
addappid(1834041) -- Total War: WARHAMMER III - Alith Anar
addappid(1834042) -- Total War: WARHAMMER III - Bone Giant
addappid(1834043) -- Total War: WARHAMMER III - Curse of the Vampire Coast
addappid(1834044) -- Total War: WARHAMMER III - Lokhir Fellheart
addappid(1834045) -- Total War: WARHAMMER III - The Prophet & The Warlock
addappid(1834046) -- Total War: WARHAMMER III - Tiktaq'to
addappid(1834047) -- Total War: WARHAMMER III - Amethyst Wizard
addappid(1834048) -- Total War: WARHAMMER III - The Hunter and the Beast
addappid(1834049) -- Total War: WARHAMMER III - Gor-Rok
addappid(1834050) -- Total War: WARHAMMER III - Gotrek & Felix
addappid(1834051) -- Total War: WARHAMMER III - The Shadow & The Blade
addappid(1834052) -- Total War: WARHAMMER III - Repanse de Lyonesse
addappid(1834053) -- Total War: WARHAMMER III - The Warden & The Paunch
addappid(1834054) -- Total War: WARHAMMER III - Imrik
addappid(1834055) -- Total War: WARHAMMER III - Black Orc Big Boss
addappid(1834056) -- Total War: WARHAMMER III - Catchweb Spidershrine
addappid(1834057) -- Total War: WARHAMMER III – The Twisted & The Twilight
addappid(1834058) -- Total War: WARHAMMER III - Skaven Chieftain
addappid(1834060) -- Total War: WARHAMMER III – Glade Captain
addappid(1834061) -- Total War: WARHAMMER III - Rakarth
addappid(1834062) -- Total War: WARHAMMER III – The Silence & The Fury
addappid(1834063) -- Total War: WARHAMMER III - Blood for the Blood God II
addappid(1834064) -- Total War: WARHAMMER III - Thorek Ironbrow
addappid(1834065) -- Total War: WARHAMMER III - Great Bray Shaman
addappid(1834066) -- Total War: WARHAMMER III - Ogre Mercenaries
addappid(2325830) -- Total War: WARHAMMER III – Shadows of Change
addappid(3858050) -- Total War: WARHAMMER III UPGRADE PACK
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1670540) -- Depot 1670540 (empty depot)