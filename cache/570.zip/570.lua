-- 570's Lua and Manifest Created by Hubcap Manifest
-- Dota 2
-- Created: July 25, 2026 at 06:13:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 22
-- Total DLCs: 44
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(570, 1, "d1c0e5cee633870d25ece907f9836bb6005a09ac6442ac0228f3667ffca7ca78") -- Dota 2
-- MAIN APP DEPOTS
addappid(373301, 1, "279c88be13d9b20cc225ac6a493938250bd3c466a10be0510ee63f3fee466e59") -- Dota 2 Content
setManifestid(373301, "4538523257869562682", 5030048653)
addappid(381451, 1, "c45d21d2567e6bbbaabd5d8c510cfc3df5c51ba614e8147758361b095d4fa385") -- Dota 2 Content 2
setManifestid(381451, "1644205904362630105", 2114992305)
addappid(381452, 1, "dbca512c4195d0acb381cb58961227a2389591eb8ef830fe0b2075034915429f") -- Dota 2 Content 3
setManifestid(381452, "1790151512922507464", 2125061963)
addappid(381453, 1, "7579e5293fe4e936f8c9e91699ad8331d317aef3fd772926c1fc5f6b3775d15e") -- Dota 2 Content 4
setManifestid(381453, "5723651394550524659", 2099946682)
addappid(381454, 1, "dad51b312f4226160bc7d83b4e5959f6b98aeccd7a2fd96040dc2bd91e93e006") -- Dota 2 Content 5
setManifestid(381454, "3653281149075627225", 2137432281)
addappid(381455, 1, "bce388e5d35bce02105c0a8de97259e0187df8220f13994a85546241c5cb46c7") -- Dota 2 Content 6
setManifestid(381455, "4202780698024707015", 61482213689)
addappid(373302, 1, "1bfcb4b8a591a7dcde8ebae166815a3881252a90420d8d86a6925d63ec728e1c") -- Dota 2 Win32
setManifestid(373302, "6949368311956215785", 135860023)
addappid(373303, 1, "005943def146b997e82e3d47d24cc7aeb993a35d3b5667b7085d22adc883af08") -- Dota 2 Win64
setManifestid(373303, "174830542049381597", 649730712)
addappid(373304, 1, "5aab0fdef9c8de1f871c67c0de61014bf541b726392f89caf1a288764b277edf") -- Dota 2 Mac
setManifestid(373304, "8874580088386875584", 633431793)
addappid(373305, 1, "322d1a4f7c1a278ebac8dd32abc6c68e3846c750840335829767f5bb61a9c20a") -- Dota 2 English
setManifestid(373305, "4435851250675935801", 0)
addappid(373306, 1, "84158152dd9c4100de7a63a6d8a0e78fed18291e599a5c533c3303b32399d45e") -- Dota 2 Linux
setManifestid(373306, "6757708270019775843", 750957279)
addappid(373307, 1, "11f3d9ff5db607675832505f1db661d511d7379fef7896eb2e12bff54a1655a4") -- Dota 2 Low Violence
setManifestid(373307, "7660638834009368395", 203861667)
addappid(373308, 1, "8624a7548d76e91640c6d312115a0d42d3a7eef930123df8888a9f1bd2d1349f") -- Dota 2 Korean
setManifestid(373308, "8126429463115692983", 797728138)
addappid(373309, 1, "84260bb289a869883362af02ffccd7a1cd6fa16337f747bff65ab7bfb576329b") -- Dota 2 Simplified Chinese
setManifestid(373309, "4494062286471729162", 5165987122)
addappid(381456, 1, "9f5ad847483a839ed9baf76434be1ddc183cb997433d124eb61480b1ff847144") -- Dota 2 Russian
setManifestid(381456, "8954184990626614529", 580546525)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Dota 2 Workshop Tools DLC (AppID: 313250)
addappid(313250)
addtoken(313250, "7007036278857765184")
addappid(381450, 1, "23009db3578e9bd5f750f2cbcfe897efdf07572b455ec53bb0cd02d9d09f0a39") -- Dota 2 Workshop Tools DLC - Dota 2 Workshop tools
setManifestid(381450, "3090127887135387705", 5921109136)
-- Dota 2 - OpenGL support for Windows (AppID: 401530)
addappid(401530)
addappid(401531, 1, "77d161ec79f984f0fcd75bf5448aaca4def24808131a932e75bbbe3265458a08") -- Dota 2 - OpenGL support for Windows - Dota 2 OpenGL Windows
setManifestid(401531, "3442758096700779883", 23)
-- Dota 2 - Vulkan support (AppID: 476580)
addappid(476580)
addtoken(476580, "12051381034871427382")
addappid(401535, 1, "3a8d99407e5e63bcf7357af8a2262fa8228b5eaa6e8dca73d9a65ceda0fb7115") -- Dota 2 - Vulkan support - Dota 2 Vulkan Common
setManifestid(401535, "1990577232290008990", 225882903)
addappid(401536, 1, "0c3e321b5203db650a2905168dc251639fd5c398f304de8e02a3b862b782f2e0") -- Dota 2 - Vulkan support - Dota 2 Vulkan Win64
setManifestid(401536, "8626830787987928686", 0)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(576) -- Dota 2 - SteelSeries DLC 
addappid(581) -- Dota 2 - Murrissey the Smeevil
addappid(582) -- Dota 2 - Lockjaw the Boxhound
addappid(583) -- Dota 2 - Drodo the Druffin
addappid(584) -- Dota 2 - Inflatable Donkey Courier
addappid(585) -- Dota 2 - Plush Donkey Courier
addappid(586) -- Dota 2 - International Axe
addappid(218571) -- Dota 2 - Axe Shirt
addappid(218572) -- Dota 2 - Axe shirt Jinx
addappid(218573) -- Dota 2 - Drow shirt
addappid(218574) -- Dota 2 - Drow shirt Jinx
addappid(218575) -- Dota 2 - Donkey and Wizard shirt
addappid(218576) -- Dota 2 - Donkey and wizard shirt Jinx
addtoken(218576, "14740863126040210741")
addappid(218577) -- Dota 2 - Tidehunter shirt
addappid(218578) -- Dota 2 - Tidehunter shirt Jinx
addappid(218579) -- Dota 2 - Portal 2 Soundtrack Bundle
addappid(218582) -- Dota 2 - Winter Sale 2012
addappid(318940) -- Dota 2 - Premium DLC
addappid(373300) -- Dota 2 - Reborn Beta
addtoken(373300, "7620803809741004454")
addappid(480610) -- The International 2016 Battle Pass
addappid(539760) -- The Fall 2016 Battle Pass
addtoken(539760, "3069829048022854314")
addappid(633890) -- The International 2017 Battle Pass - Level 1
addappid(635080) -- The International 2017 Battle Pass - Level 75
addappid(665530) -- The International 2017 Battle Level Bundle
addappid(859040) -- The International 2018 Battle Pass - Level 1
addappid(859041) -- The International 2018 Battle Pass - Level 75
addappid(1082350) -- The International 2019 Battle Pass
addappid(1082351) -- The International 2019 Battle Pass - Level 50
addappid(1082352) -- The International 2019 Battle Pass - Level 100
addappid(1082353) -- The International 2019 Battle Level Bundle
addappid(1082354) -- The International 10 Battle Pass
addappid(1082355) -- The International 10 Battle Pass - Level 50
addappid(1082356) -- The International 10 Battle Pass - Level 100
addappid(1082357) -- Nemestice 2021 Battle Pass
addappid(1082358) -- Nemestice 2021 Battle Pass - Level 50
addappid(1082359) -- Nemestice 2021 Battle Pass - Level 100
addappid(1126980) -- The International 2019 Battle Pass - Level 50 (CN Nvidia)
addtoken(1126980, "10471891316556182886")
addappid(1126981) -- The International 2019 Battle Pass - Level 100 (CN Nvidia)
addtoken(1126981, "13253038459313459640")
addappid(1838090) -- The Aghanims Labyrinth Battle Pass
addappid(1838091) -- The Aghanims Labyrinth Battle Pass - Level 50
addappid(1838092) -- The Aghanims Labyrinth Battle Pass - Level 100