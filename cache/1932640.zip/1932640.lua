-- 1932640's Lua and Manifest Created by Hubcap Manifest
-- Suikoden I&II HD Remaster Gate Rune and Dunan Unification Wars
-- Created: October 22, 2025 at 07:17:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1932640) -- Suikoden I&II HD Remaster Gate Rune and Dunan Unification Wars
-- MAIN APP DEPOTS
addappid(1932641, 1, "8cbcc48378f983709b2bd2959cf190421f3e54c57008b7a1f81ba6bfd9aad886") -- Depot 1932641
setManifestid(1932641, "6999958055610959056", 10991195159)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2148630) -- Special Item Pack (Suikoden III HD Remaster Pre-Order Bonus)