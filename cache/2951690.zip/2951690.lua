-- 2951690's Lua and Manifest Created by Hubcap Manifest
-- Sonic Rumble Party
-- Created: July 24, 2026 at 23:23:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2951690, 1, "269c49a840dfbac5da6269887266bcc2a6f68e11ca4a90fe9bee729f1ec90f77") -- Sonic Rumble Party
-- MAIN APP DEPOTS
addappid(2951691, 1, "9602e5045cf202c63cf0ea9ac20dcfb0feb12642168d61db9ff214c8da6954a1") -- Depot 2951691
setManifestid(2951691, "938608711413847044", 3861705097)