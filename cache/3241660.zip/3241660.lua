-- 3241660's Lua and Manifest Created by Hubcap Manifest
-- R.E.P.O.
-- Created: May 25, 2026 at 06:58:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3241660, 1, "f647b73aa575d1ab056b68c1922a108a7bdeb79f6d472db883bde0a2ff307f48") -- R.E.P.O.
-- MAIN APP DEPOTS
addappid(3241661, 1, "0a0fcffb2de6fb0fa6caff076a5a8cb960903d17320968d5c042fd5a4f9ad2ad") -- Depot 3241661
setManifestid(3241661, "8225435692675993447", 1492605039)