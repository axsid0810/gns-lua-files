-- 4189880's Lua and Manifest Created by Hubcap Manifest
-- O2Jam : The Beginning
-- Created: July 19, 2026 at 23:16:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 6

-- MAIN APPLICATION
addappid(4189880) -- O2Jam : The Beginning
-- MAIN APP DEPOTS
addappid(4189881, 1, "3d438deb8981c840e3180eb3ebba9b9c6c8542bef9a3e3f30938f15bb1e01f46") -- Depot 4189881
setManifestid(4189881, "4205432217637786030", 2360506207)
addappid(4189882, 1, "8fbbb2f9e681974e6f0af2c821870acdd8a42fb787e329cd3513930cccb225b7") -- Depot 4189882
setManifestid(4189882, "3406396572651553144", 2415239660)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4192740) -- O2Jam  The Beginning - Classic Pack Vol.1
addappid(4855340) -- O2Jam  The Beginning - Discovery Special Pack Vol.1
addappid(4855350) -- O2Jam  The Beginning - Discovery Special Pack Vol.2
addappid(4855360) -- O2Jam  The Beginning - Discovery Special Pack Vol.3
addappid(4855370) -- O2Jam  The Beginning - Extream Pack Vol.1
addappid(4868370) -- O2Jam  The Beginning - Extream Pack Vol.2