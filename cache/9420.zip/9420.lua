-- 9420's Lua and Manifest Created by Hubcap Manifest
-- Supreme Commander: Forged Alliance
-- Created: September 30, 2025 at 21:12:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 13
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(9420) -- Supreme Commander: Forged Alliance
-- MAIN APP DEPOTS
addappid(9424, 1, "f84edbc8b8deff4a4c1040aa6b8e02c9504ec1687177bab49212f8eef5d54337") -- Supreme Commander Forged Alliance Sound
setManifestid(9424, "6345214097578234380", 1479159805)
addappid(9423, 1, "ced2ccd69d612a40ced4903fbb8f793b18dbb6109178022fbb9ac13ca176ca57") -- Supreme Commander Forged Alliance Movies
setManifestid(9423, "4676321208144095012", 2477953024)
addappid(9422, 1, "6d6e1b19f4ef94cf8f98905bf85b6cfdcc0868f788d164fcc054375741b10cca") -- Supreme Commander Forged Alliance Maps
setManifestid(9422, "1133455244675255160", 1203956042)
addappid(9421, 1, "1458af9d50f07d21bb5d73790cdcefcea09ce90259d17d3ed25be0811d2fd318") -- Supreme Commander Forged Alliance Main
setManifestid(9421, "4147794321020030711", 3295748072)
addappid(9425, 1, "c51eb53cbd32a05731589c76dbdd588c44c8d26d9b37b25daecbad902e2eacdc") -- Supreme Commander Forged Alliance english
setManifestid(9425, "6826209869392592842", 433047)
addappid(9426, 1, "81329d7c83417f86eb49f4c26b496bfa66138660e619ceae5fb5b3e420074b63") -- Supreme Commander Forged Alliance french
setManifestid(9426, "6621626809246362120", 665999764)
addappid(9427, 1, "9c63038403441c14ea0ddf37ab87089ba9e3724238ce96dcffae1907ec068cab") -- Supreme Commander Forged Alliance italian
setManifestid(9427, "8802742999071240018", 548713)
addappid(9428, 1, "570d1f29542fd1e8494e984d413c0f9667f892419a87b4ec07b9607098d6ea1f") -- Supreme Commander Forged Alliance german
setManifestid(9428, "8620946726686075447", 677329523)
addappid(9429, 1, "f90a534c0455034d88a77bc53588f570041158f1679616539f66141de2b0dfe3") -- Supreme Commander Forged Alliance spanish
setManifestid(9429, "9081144444813441249", 687503525)
addappid(9430, 1, "decb99b1e4a0cda1227810923323185d4f27ac24f7ce73f484df81bb43963649") -- Supreme Commander Forged Alliance tchinese
setManifestid(9430, "6726924691693149587", 524267)
addappid(9431, 1, "9a6eb8745c91cca79e74f599358d539d1ca8abbc54b650506a76dfd92008417b") -- Supreme Commander Forged Alliance Czech
setManifestid(9431, "6010670930362249425", 580882)
addappid(9433, 1, "b1813cb45ad232cab502e225e1fb6ea5f3dedffd4a8e0dd3c95a3afa8ac6fb23") -- Supreme Commander Forged Alliance Russian
setManifestid(9433, "1012184089353301220", 788697368)
addappid(9434, 1, "a1b4484fc410cfffcf3c34544461098f381783f442dc079af76775078e06123e") -- Supreme Commander Forged Alliance Polish
setManifestid(9434, "972299199437057369", 608377)