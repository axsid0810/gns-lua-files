-- 20920's Lua and Manifest Created by Hubcap Manifest
-- The Witcher 2: Assassins of Kings Enhanced Edition
-- Created: October 01, 2025 at 01:22:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 11
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(20920) -- The Witcher 2: Assassins of Kings Enhanced Edition
-- MAIN APP DEPOTS
addappid(20926, 1, "805bd4b649d2922154963262548666e9a470ca75b9d09a2417eecfe47ded88ea") -- Data
setManifestid(20926, "315769246484065383", 19703726866)
addappid(20921, 1, "422ce9a62e74270124898f642cd6680a82b5a38e6df5355114bce1a3ba9e01f8") -- Windows Bin
setManifestid(20921, "8223514100734217719", 150321417)
addappid(20927, 1, "01ff943a47b237a777e411f8dbea92d4ffe9fa165470d7392cce3d87de72d1c1") -- Mac Bin
setManifestid(20927, "7361591508551106857", 323103325)
addappid(288910, 1, "161d4e1f29e3ac3895f12bec21c9f0cd794c2f651c2120a029a5a98d51253472") -- Linux Bin
setManifestid(288910, "1947434890495899226", 43913344)
addappid(20922, 1, "8ed7d445083710d9eaaedf3d0b4efb874c1f9f20e4592a067c10fcc26e589692") -- The Witcher 2 Succubus
setManifestid(20922, "3780814960985639249", 603123)
addappid(20937, 1, "f5739293fef7415775375580665da10e85fdb116deeb46117d258c48d74ba7a9") -- The Witcher 2 Russian
setManifestid(20937, "903372513047389057", 1223206679)
addappid(20923, 1, "8184a90b126793437d45e63790f1a1ab8f4b471bd051f7827fc89cb27b1a3906") -- The Witcher 2 Polish
setManifestid(20923, "6862011465667603014", 1019027129)
addappid(20924, 1, "0ad303acc7351993c72e4b268d414d83122c47fa36303c01db198d345291abbf") -- The Witcher 2 German
setManifestid(20924, "3594794442703802535", 1095785310)
addappid(20925, 1, "7be8e87634ee7e33581fac81d58d7acc80c3c1016062d950cd8ec0b0882d1e4f") -- The Witcher 2 French
setManifestid(20925, "5800386476642370826", 1035769815)
addappid(20928, 1, "4b0458f19e74d96213f3ea7e3a63f480e8c455c643f78ce181fc0f1a6caa00ee") -- The Witcher 2 Brazilian
setManifestid(20928, "5764482989207420007", 4699999664)
addappid(20938, 1, "6d46e31c91105bf2a2f2f7916d7ccbb516a27878625fac4dc8d18f164f56506c") -- The Witcher 2 Korean
setManifestid(20938, "4226047910205081744", 4696983900)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(228460) -- The Witcher 2 Bonus Content