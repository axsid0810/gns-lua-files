-- 2567870's Lua and Manifest Created by Hubcap Manifest
-- Chained Together
-- Created: September 29, 2025 at 03:44:35 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 0
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(2567870, 1, "3eb4ccd36ec5b43258c3051d9614925915db0d976e68e89c79eb4a576ac0bcd9") -- Chained Together
-- MAIN APP DEPOTS
addappid(2567871, 1, "84ff26693d69b1f13f653ad7d1a182142a2a5049bf0ce8dc73735d955d3cb186") -- Depot 2567871
setManifestid(2567871, "2564921531254078552", 7821776157)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 50450161)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") -- .NET 4.8 Redist (Shared from App 228980)
setManifestid(229007, "4477590687906973371", 117381405)