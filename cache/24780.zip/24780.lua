-- 24780's Lua and Manifest Created by Hubcap Manifest
-- SimCity 4 Deluxe
-- Created: September 30, 2025 at 14:16:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 18
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(24780) -- SimCity 4 Deluxe
-- MAIN APP DEPOTS
addappid(24781, 1, "6b102c5a65585629b8a246070c23fd096f8bab8db9ef9f6fecdcca92202b9f89") -- SimCity 4 Deluxe content
setManifestid(24781, "2801566233671323266", 1240493154)
addappid(24766, 1, "af188be2e991f6e057a74e5fe6e0f7faaad2a328e01b662037f5660788fcce11") -- SimCity 4 Deluxe Portuguese
setManifestid(24766, "9154809593397756046", 1849188)
addappid(24767, 1, "0a635b358180607240e9db7215d23be45819844b0691e09ec093a88c72a8ba14") -- SimCity 4 Deluxe Swedish
setManifestid(24767, "4572067608437750432", 1792859)
addappid(24782, 1, "32285c66bddc00c044718055de13beafb3f9fd94fd3ff6b7a739295b3eb02221") -- SimCity 4 Deluxe English
setManifestid(24782, "7035605754646021517", 961359)
addappid(24783, 1, "5436d148334306dae6bd339785b9fc90a101892a98ba9932e70e8722aa42509a") -- SimCity 4 Deluxe French
setManifestid(24783, "7815521656179663562", 1854446)
addappid(24784, 1, "f043c8e88adde335fbc8391f5a6776fead3addf3055f9a192352bc3001d79ceb") -- SimCity 4 Deluxe German
setManifestid(24784, "2458866074776067252", 1845149)
addappid(24785, 1, "406376155b1c36c45b182cd9528770a50de1bd9c34670ef177b4a56e0cc5338a") -- SimCity 4 Deluxe Italian
setManifestid(24785, "7685874573921705189", 1852312)
addappid(24786, 1, "9bb42da7acfe6e2ad1cfa6afe7e88e0c2e676007d5e7b2821b56ca10e1652d02") -- SimCity 4 Deluxe Spanish
setManifestid(24786, "8628227073806559267", 1832055)
addappid(24787, 1, "e4f62df43dedc9d953ecc32a57c869c54f688ebdff960baac2cc8156596743fd") -- SimCity 4 Deluxe Danish
setManifestid(24787, "1880640839278283419", 1791614)
addappid(24788, 1, "d2abada31579db201169a150caa0af2b4d7c11f173defe75d21d47d460cbf205") -- SimCity 4 Deluxe Dutch
setManifestid(24788, "1150173622644379277", 1835865)
addappid(294880, 1, "bfc6ee942b6b74ab3de5e77b613ef3b4b9de2f2ba8c51bd044f9c8a338c272dd") -- SimCity 4 Deluxe Mac Content
setManifestid(294880, "8816488775237078529", 1245673254)
addappid(294881, 1, "e3c356a94cd316df9a6418539cfd09740c4e848ed0a49a34db42df3b613c71ce") -- SimCity 4 Deluxe Mac Executable
setManifestid(294881, "942377056528604566", 30261387)
addappid(294882, 1, "df41dfa59ca7fb87c35c1248a45d775d2f0932ab85339d459d339d4b79f664c8") -- SimCity 4 Deluxe Mac English
setManifestid(294882, "2395431482754994816", 961359)
addappid(294883, 1, "c778db4f4cae816ba1bb100cab5c26783997b2fccecd8aae3db5e230ccbe2fd8") -- SimCity 4 Deluxe Mac French
setManifestid(294883, "7550234693090806083", 1854415)
addappid(294884, 1, "071c4e068c2d5fefabfadd1ff19b864a2ce85969a4ebc04f955ac9a22a3c5ca2") -- SimCity 4 Deluxe Mac German
setManifestid(294884, "3755468381896278476", 1845149)
addappid(294885, 1, "5b39b1d7f8178972ba77b15aea7a765a9b09e83513c7480b3e60599e1f118eef") -- SimCity 4 Deluxe Mac Italian
setManifestid(294885, "5624431994069711479", 1852312)
addappid(294886, 1, "24f5db7af50a1989d2987006076798808092d02a7a501f611ee59d5182f39239") -- SimCity 4 Deluxe Mac Spanish
setManifestid(294886, "1530463900464903497", 1832055)
addappid(294887, 1, "256b3d02a7d85ab86ec3490ffb303edfe057e578734c4c48d66a778bfb66d6f9") -- SimCity 4 Deluxe Mac Japanese
setManifestid(294887, "231593058320344065", 785778)