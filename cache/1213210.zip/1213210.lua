-- 1213210's Lua and Manifest Created by Hubcap Manifest
-- Command & Conquer™ Remastered Collection
-- Created: January 29, 2026 at 15:53:35 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1213210, 1, "9c9c5ba3776a08c7288b524f9e7a6a3ec56bda26975b167688eb214aac2eadb6") -- Command & Conquer™ Remastered Collection
-- MAIN APP DEPOTS
addappid(1213211, 1, "3468f5d4f6b3e520cbc3f0e07308b1b5d4d78d088198c01827294ae44ca80467") -- Command & Conquer Remastered Content
setManifestid(1213211, "2236074999146710886", 25937606477)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)