-- 589360's Lua and Manifest Created by Hubcap Manifest
-- Ni no Kuni™ II: Revenant Kingdom
-- Created: September 30, 2025 at 03:29:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 8
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(589360) -- Ni no Kuni™ II: Revenant Kingdom
-- MAIN APP DEPOTS
addappid(589361, 1, "9402d58bea96df572890e2739abfdddef9706b87e79a208795d15596a74e4e3f") -- Laponia Content
setManifestid(589361, "8491771559633445813", 30951978421)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(689800) -- Ni no Kuni II REVENANT KINGDOM - The Lair of the Lost Lord
addappid(689810) -- Ni no Kuni II REVENANT KINGDOM - The Tale of a Timeless Tome 
addappid(689860) -- Ni no Kuni II Revenant Kingdom - Season Pass
addappid(804740) -- Ni no Kuni II Revenant Kingdom - Special Sword Set
addappid(804741) -- Ni no Kuni II Revenant Kingdom - Princes Equipment Pack
addappid(804742) -- Ni no Kuni II Revenant Kingdom - Cat Kings Claw
addappid(804750) -- Ni no Kuni II Revenant Kingdom - Dragons Tooth
addappid(898570) -- Ni no Kuni II REVENANT KINGDOM - Adventure Pack