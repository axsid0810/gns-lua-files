-- 388410's Lua and Manifest Created by Hubcap Manifest
-- Darksiders II Deathinitive Edition
-- Created: September 29, 2025 at 06:38:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 0
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(388410) -- Darksiders II Deathinitive Edition
-- MAIN APP DEPOTS
addappid(388411, 1, "9897f0901ac852825579c6d178453f4bb46a33e9449a17e6e3d58d2af487df50") -- Darksiders II Deathinitive Edition Content
setManifestid(388411, "5667116516349422569", 13379106291)
addappid(388412, 1, "225c05c3336f76d730f2dba3a62f4886d48515f619bb3369d73ada74fbd97215") -- Darksiders II Deathinitive Edition German
setManifestid(388412, "520568948724086369", 469735251)
addappid(388413, 1, "96753de70babfa27928c6bc9b20584f56764ff7fb15b388e866532550e5fefe6") -- Darksiders II Deathinitive Edition French
setManifestid(388413, "662957773691504646", 414907128)
addappid(388414, 1, "6b13b8d677006140213686d243503d84bdf2aa6a7c55f61b60932d45c8dcff5b") -- Darksiders II Deathinitive Edition Italian
setManifestid(388414, "784515675261248728", 441657068)
addappid(388415, 1, "986eed9aaefbef56f9d98c1f02339c22220af75f16c0a70d9bb2860e80421a6a") -- Darksiders II Deathinitive Edition Spanish
setManifestid(388415, "2343018005241349429", 431829987)
addappid(388416, 1, "3d28361fbec3540cf2861863b0c7f3593243fb4658b1b0762fceb44bf8335743") -- Darksiders II Deathinitive Edition Russian
setManifestid(388416, "3913581469910340713", 508326295)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)