-- 329430's Lua and Manifest Created by Hubcap Manifest
-- State of Decay: Year-One
-- Created: September 30, 2025 at 19:54:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(329430) -- State of Decay: Year-One
-- MAIN APP DEPOTS
addappid(329431, 1, "b8142089d680a0dd39b0f2eacfff905ca0004a9c2325ce8c2c80d413e687f67e") -- Glendale Content
setManifestid(329431, "3091538373538585084", 2594115649)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- State of Decay Breakdown Year-One (AppID: 339300)
addappid(339300)
addtoken(339300, "7157364476947355008")
addappid(339300, 1, "e82138bd6b8f2ea0236b0330057d5c6b5a8c3cf052114ccc01e5eac7340f524e") -- State of Decay Breakdown Year-One - Glendale - DLC1 (339300) Depot
setManifestid(339300, "6169204902073515213", 8857098)
-- State of Decay Lifeline Year-One (AppID: 339301)
addappid(339301)
addtoken(339301, "11351225260641364750")
addappid(339301, 1, "5e8df18e12cf473ba1d495d4b6016705092b2691168d1da3a40c940a1379874a") -- State of Decay Lifeline Year-One - Glendale - DLC2 (339301) Depot
setManifestid(339301, "5216411856423802088", 543392656)
-- State of Decay YOSE Preppers Pack (AppID: 339302)
addappid(339302)
addtoken(339302, "12286238532218522536")
addappid(339302, 1, "63dd37d8abfb56e5575369d3552237ee7b55f9c520e3b0162ecb8f7f5a31189f") -- State of Decay YOSE Preppers Pack - Glendale - Day 1 Pack (339302) Depot
setManifestid(339302, "8533344909724431271", 112)
-- State of Decay YOSE Bonus Gurubani Kaur (AppID: 339303)
addappid(339303)
addtoken(339303, "8389888947876618244")
addappid(339303, 1, "92f7d66647f23a028445c3185b7eff16f0404179b383888965c1d04efa7ba318") -- State of Decay YOSE Bonus Gurubani Kaur - Glendale - Character (339303) Depot
setManifestid(339303, "5426021271405128716", 114)