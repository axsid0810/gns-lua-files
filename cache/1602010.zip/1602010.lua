-- 1602010's Lua and Manifest Created by Hubcap Manifest
-- Persona 4 Arena Ultimax
-- Created: September 30, 2025 at 06:24:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1602010) -- Persona 4 Arena Ultimax
-- MAIN APP DEPOTS
addappid(1602011, 1, "bda80d85becc8413a5051192377fce270c19310afa645bdb331247e705363b60") -- Depot 1602011
setManifestid(1602011, "1100331402471448369", 23049519330)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)