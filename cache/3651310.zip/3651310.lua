-- 3651310's Lua and Manifest Created by Hubcap Manifest
-- Little Corners
-- Created: March 19, 2026 at 11:34:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3651310) -- Little Corners
-- MAIN APP DEPOTS
addappid(3651311, 1, "4eb58e16048ebecbdaffd8fbfd730341347947c0a30bb547ad3806ec084241d2") -- Depot 3651311
setManifestid(3651311, "2652948881652794164", 1246123690)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)