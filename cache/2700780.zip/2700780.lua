-- 2700780's Lua and Manifest Created by Hubcap Manifest
-- my eyes deceive
-- Created: September 30, 2025 at 02:26:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2700780) -- my eyes deceive
-- MAIN APP DEPOTS
addappid(2700781, 1, "08f2019fe4e38500c4a66a05b0cb15e55999e3b0775e30f753973e6de1c272fa") -- Depot 2700781
setManifestid(2700781, "8160256104369397783", 310307483)