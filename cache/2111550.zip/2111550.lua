-- 2111550's Lua and Manifest Created by Hubcap Manifest
-- Schrodinger's Cat Burglar
-- Created: July 17, 2026 at 09:42:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2111550, 1, "4c4544e4df546f5eddd8524711f891257d79f70f7e4ccd23e8090c266cfddfd5") -- Schrodinger's Cat Burglar
-- MAIN APP DEPOTS
addappid(2111551, 1, "16d089f12a20095fcb8a5968c909340a1a91d47648d6086d9390cb42be6323d3") -- Depot 2111551
setManifestid(2111551, "4678307910810197054", 8657869949)
addappid(2111552, 1, "253d34b03f2a34973ef7ee9f6568c1405ae852b1b8c8d30ecaa9cb1e4db21aed") -- Depot 2111552
setManifestid(2111552, "8162155718553541927", 8819337923)
-- DLCS WITH DEDICATED DEPOTS
-- Schrodingers Cat Burglar - Supporter Pack (AppID: 4489230)
addappid(4489230)
addappid(4489230, 1, "a71d8bfeea33b2fbf0237289f6ab069e0529c870e159e1bb8195e6cf0ae9b207") -- Schrodingers Cat Burglar - Supporter Pack - Depot 4489230
setManifestid(4489230, "3566141696273541207", 61584983)