-- 1774580's Lua and Manifest Created by Hubcap Manifest
-- STAR WARS Jedi: Survivor™
-- Created: July 23, 2026 at 18:19:18 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 6
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1774580, 1, "f7b4bb3589f21f00dfc05944f80e264d91839c7bb3e87323d390b42d465a1dfa") -- STAR WARS Jedi: Survivor™
-- MAIN APP DEPOTS
addappid(1774581, 1, "94d6a0b0e4e36aadffcbc197792207f773276593c72faf9b02b4b4200135a36f") -- Depot 1774581
setManifestid(1774581, "6701111524392590510", 139372569038)
addappid(1774582, 1, "b6efa1ef672dce88aa6a6a094211c19110ebe78cf04b8bb87f7ba76e7cf15243") -- Depot 1774582
setManifestid(1774582, "6113531931136169727", 185501)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3340993, 1, "0f76c015b201b1c8249b6a433ef0873f41ef923a5653bef68f10f8cbc051f414") -- Depot 3340993 (Shared from App 3340990)
setManifestid(3340993, "854167310198639655", 240979978)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1774590) -- STAR WARS Jedi Survivor - Standard Edition Key
addappid(2161370) -- STAR WARS Jedi Survivor Deluxe Upgrade
addappid(2161740) -- STAR WARS Jedi Survivor Deluxe Edition Key
addappid(2161741) -- STAR WARS Jedi Survivor Preorder Key
addappid(2161742) -- STAR WARS Jedi Survivor Deluxe Edition Preorder Key
addappid(2334020) -- STAR WARS Jedi Survivor - Press Offer Key