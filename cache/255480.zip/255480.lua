-- 255480's Lua and Manifest Created by Hubcap Manifest
-- NBA 2K14
-- Created: September 30, 2025 at 03:00:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(255480) -- NBA 2K14
-- MAIN APP DEPOTS
addappid(255481, 1, "280addab6a3a224d1b4c245b3778ac8658b447284c8d41ed73e4bc027d7e6327") -- NBA2K14 Content
setManifestid(255481, "7773500769044867124", 7734243874)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)