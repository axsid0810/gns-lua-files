-- 1001140's Lua and Manifest Created by Hubcap Manifest
-- Angry Birds VR: Isle of Pigs
-- Created: March 12, 2026 at 19:15:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1001140, 1, "5c5f1f0bafcfa16acd48d19a27cc9eba9115a0c1747cb9d067c531d33ee13a4d") -- Angry Birds VR: Isle of Pigs
-- MAIN APP DEPOTS
addappid(1001141, 1, "81c14580c1a52c0777c343a23877b949988ebfec4c862156b88978af0ff32211") -- Angry Birds VR: Isle of Pigs Content
setManifestid(1001141, "2496695278507152957", 786343758)