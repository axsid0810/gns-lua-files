-- 2569510's Lua and Manifest Created by Hubcap Manifest
-- MLB 9 Innings Rivals 26
-- Created: July 26, 2026 at 05:52:46 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2569510, 1, "3e420ca312e63887e5c0060860caad5cc03e9dc4535c901292b7d619481f1f71") -- MLB 9 Innings Rivals 26
-- MAIN APP DEPOTS
addappid(2569511, 1, "aa9bad623f3f5f60cb0ead0ba890e9a51401a5a285ef007171dba86d9e0930e0") -- Depot 2569511
setManifestid(2569511, "2077677222652565374", 15151693321)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)