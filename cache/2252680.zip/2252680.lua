-- 2252680's Lua and Manifest Created by Hubcap Manifest
-- Farlands
-- Created: July 17, 2026 at 14:49:47 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2252680) -- Farlands
-- MAIN APP DEPOTS
addappid(2252681, 1, "73dbb18df72b601184646e91f441676cbac196f1540ba71c5b16a639e4bae4c0") -- Depot 2252681
setManifestid(2252681, "6881672572714167518", 2022575697)