-- 712730's Lua and Manifest Created by Hubcap Manifest
-- SIMULACRA
-- Created: September 30, 2025 at 14:17:41 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(712730) -- SIMULACRA
-- MAIN APP DEPOTS
addappid(712731, 1, "ac8763309f74adfd69e93e880c06d244939ad423b0a017bec77fb887483eff01") -- Windows Content
setManifestid(712731, "596356553582726633", 568355938)
addappid(712732, 1, "00ae4c39f93719bd83c3c4ee721cdbe50cb6f37fcab8cfd9127883dfe6a12f0e") -- MacOS Content
setManifestid(712732, "9198861372748232538", 463584789)