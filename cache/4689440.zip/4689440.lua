-- 4689440's Lua and Manifest Created by Hubcap Manifest
-- Happy Endings
-- Created: July 16, 2026 at 14:24:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4689440) -- Happy Endings
-- MAIN APP DEPOTS
addappid(4689441, 1, "05f732751da07c3758b14fc605072eb1609581fed6e9f85c12aeb39413cbe7de") -- Depot 4689441
setManifestid(4689441, "4202340815969042995", 464616405)