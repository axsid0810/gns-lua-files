-- 257350's Lua and Manifest Created by Hubcap Manifest
-- Baldur's Gate II: Enhanced Edition
-- Created: June 24, 2026 at 01:45:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(257350, 1, "acba9e8d61ab70200089daab53ccc7a1357444835ecb89d61249232e7c391e2e") -- Baldur's Gate II: Enhanced Edition
-- MAIN APP DEPOTS
addappid(257351, 1, "88e74b749a3e454dcff08e818290a58bcb741800f002aa0e40cfdca9d364f5c8") -- Baldur's Gate II Enhanced Edition Content
setManifestid(257351, "3152121405399028813", 8329272)
addappid(257352, 1, "e3455666047d6559b851052b68f9f73041bbffb76ee74ba8cb93b1f0ccc0e5fe") -- Baldur's Gate II: Enhanced Edition for Mac OS
setManifestid(257352, "8189250368044169298", 21880938)
addappid(257353, 1, "ef916ff1549de04b067c8cc39c4ce5ae4ebc1a8fb410c27b35ca856ba34b883d") -- Baldur's Gate II: Enhanced Edition for Linux
setManifestid(257353, "7246248921762562052", 16189616)
addappid(257354, 1, "b3c8a168d08424cbdab3eb502d4a177b32515e334c705d3257dfa8630073a818") -- Baldur's Gate II: Enhanced Edition Game Data
setManifestid(257354, "4737130585273772372", 3879781117)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- OpenAL 2.0.7.0 Redist (Shared from App 228980)
setManifestid(229020, "5799761707845834510", 810085)
-- DLCS WITH DEDICATED DEPOTS
-- Baldurs Gate II Reflections Of Myth  Valor (AppID: 2489050)
addappid(2489050)
addappid(2489050, 1, "6662f37ac2ed6ef91731f764678342a103ea91028bc8b077fe0cf4aca7028f05") -- Baldurs Gate II Reflections Of Myth  Valor - Depot 2489050
setManifestid(2489050, "7867110368598873128", 5501443)