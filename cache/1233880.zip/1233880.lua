-- 1233880's Lua and Manifest Created by Hubcap Manifest
-- Disgaea 4 Complete+
-- Created: September 29, 2025 at 07:55:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1233880) -- Disgaea 4 Complete+
-- MAIN APP DEPOTS
addappid(1233881, 1, "61c99a12f757f3bd4d8e69503c05e32e1184b97a184c79eec397860b1fdb578f") -- Disgaea 4 Complete+ Content
setManifestid(1233881, "1518598742057875236", 6580052117)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Disgaea 4 Complete Digital Art Book (AppID: 1342160)
addappid(1342160)
addappid(1342160, 1, "62982db0fc7f2531b1d0de0ae7dc139e94500fcfbaf74c68e0b61d11a04824d2") -- Disgaea 4 Complete Digital Art Book - Disgaea 4 Complete+ Digital Art Book (1342160) Depot
setManifestid(1342160, "5803122549446120156", 114623422)