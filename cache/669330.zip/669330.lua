-- 669330's Lua and Manifest Created by Hubcap Manifest
-- Mechabellum
-- Created: July 16, 2026 at 05:36:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 6

-- MAIN APPLICATION
addappid(669330, 1, "face437f5e2c9ec9a7fbd87c27e5609414209a04165df23ace57e552ca3e18cd") -- Mechabellum
-- MAIN APP DEPOTS
addappid(669331, 1, "cce2dbb82d8bf772c353fd8b749df375dd3679858007e05fecc5f398c9a266e1") -- Depot 669331
setManifestid(669331, "1714930072538023939", 15013582165)
addappid(669332, 1, "f13bf6d0cc48759920fe9a35134b8fce25395c8ef9b0307ae8070531e3ca7262") -- Depot 669332
setManifestid(669332, "7629423268640599694", 15184920041)
addappid(669333, 1, "7581839fc620dc26f7468d6a08719a72bf6c94866477c59e02914d89244a8328") -- Depot 669333
setManifestid(669333, "8157879328889515805", 15013582165)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3009940) -- Mechabellum DreamHack LAN
addappid(3202380) -- Mechabellum - EA Reward
addappid(3241600) -- Mechabellum - Mobile Forces Skin Pack
addappid(3241610) -- Mechabellum - Steel Skin Pack
addappid(3241620) -- Mechabellum - Gilded Worm Skin Pack
addappid(3241640) -- Mechabellum - Avatars  Emoticons