-- 1668520's Lua and Manifest Created by Hubcap Manifest
-- The Legend of Heroes: Trails to Azure
-- Created: October 01, 2025 at 00:09:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1668520) -- The Legend of Heroes: Trails to Azure
-- MAIN APP DEPOTS
addappid(1668521, 1, "7ff8469ddb0a97bf177dca7527ef140b913e1760b8b518d5c33d2c4ff6d83991") -- Depot 1668521
setManifestid(1668521, "3008127741263674469", 6103240447)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- The Legend of Heroes Trails to Azure - Azure Archives Art Book (AppID: 2318450)
addappid(2318450)
addappid(2318450, 1, "65baad6b6ab19166844a787c56547647791c3995b429de289bc040011930b501") -- The Legend of Heroes Trails to Azure - Azure Archives Art Book - Depot 2318450
setManifestid(2318450, "2839230936373364187", 50339950)