-- 1223500's Lua and Manifest Created by Hubcap Manifest
-- Umurangi Generation
-- Created: October 01, 2025 at 04:36:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1223500) -- Umurangi Generation
-- MAIN APP DEPOTS
addappid(1223501, 1, "91b6d957c063ce0a7d5c48914dbc0a4e20081d5c0ef2a62a56098490889d6bc0") -- Umurangi Generation Content
setManifestid(1223501, "3199333150478832417", 2170725884)
-- DLCS WITH DEDICATED DEPOTS
-- Umurangi Generation Macro (AppID: 1435580)
addappid(1435580)
addappid(1435580, 1, "29a3ac57af3bac830cd863cbb0205d0efe3fe34008310041186a370af31dffb2") -- Umurangi Generation Macro - Umurangi Generation Macro (1435580) Depot
setManifestid(1435580, "7236112336552798395", 0)