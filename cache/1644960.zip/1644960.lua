-- 1644960's Lua and Manifest Created by Hubcap Manifest
-- NBA 2K22
-- Created: September 30, 2025 at 03:00:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 5
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1644960) -- NBA 2K22
-- MAIN APP DEPOTS
addappid(1644961, 1, "7bd16fd362dc178163d8afa11b87e3fe72a6c53a23d000d8b4671c601f1c5d95") -- NBA 2K22 Content
setManifestid(1644961, "2365432848179719315", 127486802786)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1692530) -- NBA 2K22 Pre-Order Pack
addappid(1692531) -- 75th Edition Content
addappid(1692532) -- 75th Edition Content (B)
addappid(1749550) -- NBA 2K22 2K Store Preorder Bonus
addappid(1766870) -- Amazon B