-- 460790's Lua and Manifest Created by Hubcap Manifest
-- Bayonetta
-- Created: September 29, 2025 at 00:33:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(460790) -- Bayonetta
-- MAIN APP DEPOTS
addappid(460792, 1, "e80066b74e53039c621ea6adf902751eb8f1dac4ca0d402199191086cf6302b7") -- Papaya 個のデポ
setManifestid(460792, "3254100067932476528", 13841643176)
addappid(460793, 1, "cdea589ed071f14e0e3888afa183b8571b885073ac2994fad89e6830f5371cc8") -- Papaya Extra Content
setManifestid(460793, "2560085780250407658", 214145198)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)