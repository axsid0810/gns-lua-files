-- 2681030's Lua and Manifest Created by Hubcap Manifest
-- Outbound
-- Created: July 02, 2026 at 06:31:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(2681030, 1, "212c0a7b5c03882e040badb68ae28f5fed348c96e52b78942ab003e09f13700f") -- Outbound
-- MAIN APP DEPOTS
addappid(2681031, 1, "feac3f781af42ac4e65cdb05e24f482c33e5660d23b377e86d744be6cc53a4bd") -- Depot 2681031
setManifestid(2681031, "2755704904326554733", 13287216396)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4148860) -- Outbound  School Bus Adventures