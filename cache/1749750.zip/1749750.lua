-- 1749750's Lua and Manifest Created by Hubcap Manifest
-- Disgaea 6 Complete
-- Created: September 29, 2025 at 07:56:03 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1749750) -- Disgaea 6 Complete
-- MAIN APP DEPOTS
addappid(1749751, 1, "df1a43a719b08e88f04345fffa4c8675b5fd85304af261ada11233f805811173") -- Depot 1749751
setManifestid(1749751, "8419365330310087632", 6016880863)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(2051970, 1, "21e0f12d187860fe3b67d369bd2180cad8669d2726c4b1eee68d2e3d0eb3b74d") -- Depot 2051970 (Shared from App 2051970)
setManifestid(2051970, "4477225458045763001", 95475165)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1749780) -- Disgaea 6 Complete Hololive