-- 3079280's Lua and Manifest Created by Hubcap Manifest
-- さいはて駅
-- Created: April 17, 2026 at 11:07:00 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(3079280, 1, "683d62f1770cf53221b04572a313fd84194be8c438ece87ea16d7976c8b92e85") -- さいはて駅
-- MAIN APP DEPOTS
addappid(3079281, 1, "40bf78c858bfd69b7d077c6b2ba7d6b21ba172e87693f008cc414d965b49ab7a") -- Depot 3079281
setManifestid(3079281, "3077221341442860198", 610704935)
addappid(3079282, 1, "9ac2a83d7762447aa3ed41adfea2159670dd2537f2bddd7d98c814b3b82403d9") -- Depot 3079282
setManifestid(3079282, "9148683038676971321", 941103858)
-- DLCS WITH DEDICATED DEPOTS
--  [] (AppID: 3216040)
addappid(3216040)
addappid(3216040, 1, "26255c51d6e5628fc23d56de7435d9f494135bc7ac03b5ef821e3fe4d7787626") --  [] - Depot 3216040
setManifestid(3216040, "5567260851428885248", 778972299)
-- addappid(3216041, 1, "MISSING_KEY") --  [] - Depot 3216041 (no key available)
-- - (AppID: 3331460)
addappid(3331460)
addappid(3331460, 1, "4af9fb1a4d0e64251f119c47fc5b2028b58fcca087e8abcecdbe8eb2127073c6") -- - - Depot 3331460
setManifestid(3331460, "7564380384282683318", 75097342)
-- [] (AppID: 4143660)
addappid(4143660)
addappid(4143661, 1, "3e27316247e7d69c1197d2aac3e073683f09b36a81ed36b885f90be509b4c57f") -- [] - Depot 4143661
setManifestid(4143661, "6296749356382012308", 74823678)