-- 3760230's Lua and Manifest Created by Hubcap Manifest
-- Sherlock: Hidden Object & Match-3 Mystery
-- Created: July 22, 2026 at 22:13:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3760230) -- Sherlock: Hidden Object & Match-3 Mystery
-- MAIN APP DEPOTS
addappid(3760231, 1, "c357151818d8b44e7757afd08700302823f2ef5f6de73883b3f9be5ab2ee1ce2") -- Depot 3760231
setManifestid(3760231, "6569274122437931177", 3332222038)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)