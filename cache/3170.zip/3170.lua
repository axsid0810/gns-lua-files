-- 3170's Lua and Manifest Created by Hubcap Manifest
-- King's Bounty: Armored Princess
-- Created: September 29, 2025 at 20:49:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 10
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3170) -- King's Bounty: Armored Princess
-- MAIN APP DEPOTS
addappid(3171, 1, "921a19edf47daf39d595d28f26fc08675d0c3c91f1fb7a28f12bb28da096f091") -- King's Bounty: Armored Princess content
setManifestid(3171, "7000162273618671712", 5210225508)
addappid(3172, 1, "effa8fceb35af4638f17ec42facd24855e826f923a981c513f284bd6a26d98df") -- King's Bounty: Armored Princess French
setManifestid(3172, "5875511071316485277", 11253669)
addappid(3173, 1, "558c6619fe03422b24ecba923b05ac931e9db72d515dfc44d670db6e45c3703d") -- King's Bounty: Armored Princess German
setManifestid(3173, "8274223811092847279", 21116975)
addappid(3174, 1, "beac6f4c453b0acd3599011c9719be74836d37811081565f1990b552710b7351") -- King's Bounty: Armored Princess Italian
setManifestid(3174, "3887427215362311800", 225135182)
addappid(3175, 1, "c8da699165e91f49b4be879e36ab645a846028949d8c44899c1f7d35407782f9") -- King's Bounty: Armored Princess Russian
setManifestid(3175, "887021259926118429", 21181671)
addappid(3176, 1, "1b589c4581777f0ebe44b6a61b3b80e894bb5ea48641522be07bc4c710331cb9") -- King's Bounty: Armored Princess Spanish
setManifestid(3176, "1895914956567390915", 225194472)
addappid(3178, 1, "986fec60d5abd45014b8ffbaef050426069f745e765958964556af065c94855e") -- King's Bounty: Armored Princess Japanese
setManifestid(3178, "9031442267794055483", 8203427)
addappid(3179, 1, "e6c5373300ea52afe37dfef322f070bfdb1472b0b39de31718b5d5d3f45060a6") -- King's Bounty: Armored Princess Chinese
setManifestid(3179, "718766117640297873", 30062939)
addappid(3177, 1, "b755c71b28adb38609344430ff2b32f9ad39fa926e37f58ead791ac8fa26a425") -- MacMULTI6
setManifestid(3177, "7296093757183904227", 5259698973)
-- SHARED DEPOTS (from other apps)
addappid(63918, 1, "e80c69de8603ce52b217d30b2a67a8525ae38aa4e6a1e575791fe59973b3c430") -- Collectors Pack Artbook (Shared from App 63910)
setManifestid(63918, "7017086085140057710", 234733848)