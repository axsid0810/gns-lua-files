-- 1003590's Lua and Manifest Created by Hubcap Manifest
-- Tetris® Effect: Connected
-- Created: July 14, 2026 at 22:00:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1003590, 1, "d60ded1fbef3e9b68ce5e997d76cfccc1da49635d503ca9bfedba1fb806c00d3") -- Tetris® Effect: Connected
-- MAIN APP DEPOTS
addappid(1003591, 1, "99b924e52d47af4370ef8c397f6e2c53178b23c304560199bd8e2db4220c35f2") -- PERSON Content
setManifestid(1003591, "8212840959240856401", 5987986221)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Tetris Effect Connected Digital Deluxe DLC (AppID: 1723660)
addappid(1723660)
addappid(1723660, 1, "0999f814c44b12525a2676534b835e6957538f9d9e221e50386ab04d77827e86") -- Tetris Effect Connected Digital Deluxe DLC - Tetris® Effect: Connected Digital Deluxe DLC (1723660) デポ
setManifestid(1723660, "1866761018520453991", 101318686)